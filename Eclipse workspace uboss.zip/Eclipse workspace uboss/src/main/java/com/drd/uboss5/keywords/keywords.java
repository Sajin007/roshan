package com.drd.uboss5.keywords;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.ITestResult;

/*-- =============================================
-- Author		: basil.tharian
-- Created Date : Oct 21, 2020 , 1:12:37 PM
-- Description	: keywords.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class keywords {

	// DROP_DOWN
	/***********
	 * given value in then Drop-Down is selected based on Text value.
	 * 
	 * @param DropDownelement : This variable give value is webelemt such as
	 *                        xpath/id of Drop-Down
	 * @param DropDownvalue   : This variable give value is , Which value we wanted
	 *                        selected from drop-down
	 * @param DropDownLabel   : This variable give value is label of drop-down
	 *******/
	public void dropdown(WebElement DropDownelement, String DropDownvalue, String DropDownLabel)
			throws InterruptedException {
		Select DropDown = new Select(DropDownelement);
		if (DropDownvalue.equals("")) {
			WebElement defultopetion = DropDown.getFirstSelectedOption();
			String selectedvalue = defultopetion.getText();
			System.out.println(
					"There is no change in " + DropDownLabel + " DropDown and default value is : " + selectedvalue);
		} else {
			DropDown.selectByVisibleText(DropDownvalue);
			Thread.sleep(2000);
			WebElement defultopetion = DropDown.getFirstSelectedOption();
			String selectedvalue = defultopetion.getText();
			if (selectedvalue.contains(DropDownvalue)) {
				System.out.println("The value selected in " + DropDownLabel + " DropDown is : " + DropDownvalue);
			} else {
				System.err.println("Given value is not selected in " + DropDownLabel + " DropDown" + "(expect : "
						+ DropDownvalue + ", Result : " + selectedvalue + ")");
				Assert.fail("Test fail for selecting data in " + DropDownLabel + " DropDown" + "(expect : "
						+ DropDownvalue + ", Result : " + selectedvalue + ")");
			}
		}
	}

	// CheckBox
	/**********
	 * CheckboxId should give in string.
	 * 
	 * @param driver          : This variable give value is driver
	 * @param CheckboxID      : This variable given value is Id of the checkbox and
	 *                        the variable should in string not in webelement.
	 * @param Checkboxelement : This variable give value is webelemnt such as
	 *                        xpath/ID and which is clickable in checkbox.
	 * @param CheckBoxvalue   : This variable give value is "Yes/No", while we pass
	 *                        'Yes' value its means that checkbox wanted to
	 *                        check,and while we pass 'No' it means that checkBox
	 *                        wanted to uncheck
	 * @param CheckBoxLabel   : This variable given value is label of checkbox
	 **********/
	public void Checkbox(WebDriver driver, String CheckboxID, WebElement Checkboxelement, String CheckBoxvalue,
			String CheckBoxLabel) throws InterruptedException {
		if (CheckboxID.equals("")) {
			Checkboxelement.click();
			System.out.println(CheckBoxLabel + " CheckBox is : checked");
			System.out.println(
					CheckBoxLabel + " CheckBox all  senarios is not checked becouse of checkbox ID is not visible");
		} else {
			String Valueofcheckbox = driver.findElement(By.id(CheckboxID)).getAttribute("checked");
			if (CheckBoxvalue.toUpperCase().equals("YES")) {
				if (Valueofcheckbox == null) {
					Checkboxelement.click();
					Thread.sleep(2000);
					String checkboxchecked = driver.findElement(By.id(CheckboxID)).getAttribute("checked");
					if (checkboxchecked==null) {
						System.err.println(
								CheckBoxLabel + " CheckBox not checked " + "(expect : Checked, Result : Not-Checked)");
						Assert.fail("Test fail for " + CheckBoxLabel + " CheckBox check"
								+ "(expect : Checked, Result : Not-Checked)");
					} else {
						System.out.println(CheckBoxLabel + " CheckBox is : checked");						
					}
				} else {
					System.out.println(CheckBoxLabel + " CheckBox is Already checked");
				}
			} else if (CheckBoxvalue.toUpperCase().equals("NO")) {
				if (Valueofcheckbox == null) {
					System.out.println(CheckBoxLabel + " CheckBox is Already Unchecked");
				} else {
					Checkboxelement.click();
					Thread.sleep(2000);
					String checkboxUNchecked = driver.findElement(By.id(CheckboxID)).getAttribute("checked");
					if (checkboxUNchecked == null) {
						System.out.println(CheckBoxLabel + " CheckBox is : UNchecked");
					} else {
						System.err.println(
								CheckBoxLabel + " CheckBox not Unchecked" + "(expect : UnChecked, Result : Checked)");
						Assert.fail("Test fail for " + CheckBoxLabel + " CheckBox  Uncheck"
								+ "(expect : UnChecked, Result : Checked)");
					}
				}
			} else {
				if (Valueofcheckbox == null) {
					System.out.println("There is no change in " + CheckBoxLabel + " CheckBox is unchecked : Defult");
				} else {
					System.out.println("There is no change in " + CheckBoxLabel + " CheckBox is checked : Defult");
				}
			}
		}
	}

	// RedioButton
	/****
	 * In radiobutton element should taken as xpath only and this Xpaths should be
	 * in String variable The following steps are to show , how to give xpath should
	 * be; when comparing two radiobutton xpath , 2 xpath should be same but there
	 * is one value should Increment. So find that Increment value and change to
	 * small letter 'x' , for example :- If there is two radio button and the two
	 * radio button xpath is :- A :
	 * /html/body/div[2]/div/div/div/div[3]/div/form/div/div/div[8]/div/div/div/div/label[1]
	 * B :
	 * /html/body/div[2]/div/div/div/div[3]/div/form/div/div/div[8]/div/div/div/div/label[2]
	 * while compare with is above two xpath there should change in label value '1
	 * and 2' so thats value is Incrementing so change that Incrementing value to
	 * 'x' , then the xpath is looks like :-
	 * /html/body/div[2]/div/div/div/div[3]/div/form/div/div/div[8]/div/div/div/div/label[x];
	 * 
	 * In radio button there should be two element given, because we wanted to check
	 * and click in the radio button so in our web the xpath for checking and click
	 * is different , that is why we given two xpath.
	 * 
	 * if there is Only one radio button the give radio button full xpath and also not follow above steps
	 * xpath : /html/body/div[2]/div/div/div/div[3]/div/form/div/div/div[8]/div/div/div/div/label[1]
	 * 
	 * @param RadiobuttonelementCheck : This variable give value is WebElement
	 *                                'xpath', this WebElement to check checkbox is
	 *                                checked or not
	 * @param RadiobuttonelementClick : This variable give value is is webelement
	 *                                'Xpath' to click the radio button
	 * @param RadiobuttonValue        : This variable give value Radiobutton name
	 * @param RadiobuttonLabel        : This variable give value Radiobutton main
	 *                                label name
	 */
	public void radiobutton(WebDriver driver, String RadiobuttonelementCheck, String RadiobuttonelementClick,
			String RadiobuttonValue, String RadiobuttonLabel) throws InterruptedException {
		if (RadiobuttonValue.equals("")) {
			System.out.println("There is no change in " + RadiobuttonLabel + " Rediobutton selection");
		}else if(RadiobuttonValue.equals("")&&!"".equals(RadiobuttonelementClick)) {
			driver.findElement(By.xpath(RadiobuttonelementClick)).click();
			String name = driver.findElement(By.xpath(RadiobuttonelementCheck)).getAttribute("checked");
			if (name == null) {
				System.err.println(" Radiobutton not selected for " + RadiobuttonLabel
						+ "(expect : Checked, Result : Not Check)");
				Assert.fail("Test fail for selecting " + RadiobuttonLabel + " Radiobutton (expect : Checked, Result : Not Checked)");

			} else {
				System.out
						.println("Radio button selected for " + RadiobuttonLabel + " is : " + RadiobuttonValue);
			}
		}		
		else {
			List<String> Listvalues = new ArrayList<String>();
			String changecheck = RadiobuttonelementClick.replace("[x]", "Change");
			String[] Splitcheck = changecheck.split("Change");
			Listvalues = Arrays.asList(Splitcheck);
			String check = Listvalues.get(0);
			int count = driver.findElements(By.xpath(check)).size();
			for (int i = 1; i <= count; i++) {
				String number = Integer.toString(i);
				String Radiobuttonelement = RadiobuttonelementClick.replace("x", number);
				String Radiobuttonname = driver.findElement(By.xpath(Radiobuttonelement)).getText();
				if (RadiobuttonValue.equals(Radiobuttonname)) {
					driver.findElement(By.xpath(Radiobuttonelement)).click();
				}
			}
			for (int i = 1; i <= count; i++) {
				String number = Integer.toString(i);
				String Radiobuttonelement = RadiobuttonelementClick.replace("x", number);
				String Radiobuttonname = driver.findElement(By.xpath(Radiobuttonelement)).getText();
				if (RadiobuttonValue.equals(Radiobuttonname)) {
					Thread.sleep(2000);
					String Radiobuttoncheck = RadiobuttonelementCheck.replace("x", number);
					System.out.println(Radiobuttoncheck);
					String name = driver.findElement(By.xpath(Radiobuttoncheck)).getAttribute("checked");
					if (name == null) {
						System.err.println(RadiobuttonValue + " Radiobutton not selected for " + RadiobuttonLabel
								+ "(expect : Checked, Result : Not Check)");
						Assert.fail("Test fail for selecting " + RadiobuttonValue + " Radiobutton in "
								+ RadiobuttonLabel + "(expect : Checked, Result : Not Checked)");

					} else {
						System.out
								.println("Radio button selected for " + RadiobuttonLabel + " is : " + RadiobuttonValue);
					}
				}
			}
		}
	}

	// TextField
	/************
	 * To clear text filed use 'Clear' in Inputvalue variable If there is No value
	 * then Default value should be taken
	 * 
	 * @param InputFiledelement : This variable given value is WebElement such as
	 *                          'xpath/id' of the text input filed
	 * @param Inputvalue        : This variable given value is which data wanted to
	 *                          enter in the text input filed
	 * @param InputfiledLabel   : This variable given value is label of text input
	 *                          filed
	 ********/
	public void Inputdata(WebElement InputFiledelement, String Inputvalue, String InputfiledLabel)
			throws InterruptedException {
		if (Inputvalue.equals("")) {
			String getvalue = InputFiledelement.getAttribute("value");
			System.out.println("There is no change in " + InputfiledLabel + " and defult value is :" + getvalue);
		} else if (Inputvalue.toUpperCase().equals("CLEAR")) {
			Thread.sleep(1000);
			InputFiledelement.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
			System.out.println(InputfiledLabel + " text filed is : Empty");
			Thread.sleep(1000);
		} else {
			Thread.sleep(1000);
			InputFiledelement.clear();
			Thread.sleep(1000);
			InputFiledelement.sendKeys(Inputvalue);
			Thread.sleep(2000);
			String getvalue = InputFiledelement.getAttribute("value");
			if (getvalue.equals(Inputvalue)) {
				System.out.println("Input Data in " + InputfiledLabel + " : " + Inputvalue);
			} else {
				System.err.println("Given value is not entered in " + InputfiledLabel + "(expect : " + Inputvalue
						+ ", Result : " + getvalue + ")");
				Assert.fail("Test fail while input data in " + InputfiledLabel + "(expect : " + Inputvalue
						+ ", Result : " + getvalue + ")");
			}
		}
	}

	/************************************************
	 * Common Code
	 ***********************************************/
	// Validation
	/****
	 * @param GetValiadtion : This variable given value is data get from web to
	 *                      compare
	 * @param Setvalidation : This variable given value is String Array and its
	 *                      contains one or more data to compare
	 * 
	 */
	public void Validation(String GetValiadtion, String[] Setvalidation) {
		System.out.println("Checking validation--------------");
		ArrayList<String> Validationlist = new ArrayList<String>();
		for (int j = 0; j <= Setvalidation.length - 1; j++) {
			Validationlist.add(Setvalidation[j]);
		}
		for (int i = 0; i < Validationlist.size(); i++) {
			if (Validationlist.contains(GetValiadtion)) {
				System.out.println("Validation is correct , Result : " + GetValiadtion);
				break;
			}  else {
				System.err.println("Validation is incorrect , Result : " + GetValiadtion);
				Assert.fail("Test fail for chceking validation , Result : " + GetValiadtion);
			}
		}

	}

	// ListPage Check
	/********
	 * List page is compare in list table Header and sorting
	 * 
	 * @param driver
	 * @param headers : This variable given the table header list in String Array
	 *                type
	 * @param Funtion : This variable given the value should be 'Header/All' If we
	 *                given value is Header, then only check giver header are listed
	 *                in this table, if we given value is 'All', then all scenario
	 *                such as sorting and header name should be check.
	 * @throws InterruptedException
	 */
	public void listpage(WebDriver driver, String[] headers, String Funtion) throws InterruptedException {
		Thread.sleep(1000);
		if (Funtion.equals("")) {
			System.out.println("List Table senario is not checking for this page");
		} else if (Funtion.toUpperCase().equals("HEADER") || Funtion.toUpperCase().equals("ALL")) {
			System.out.println("Checking List Table senarios................");
			System.out.println("CHECKING HEADERS......");
			ArrayList<String> ListHeadrs = new ArrayList<String>();
			String Pass = null;
			ArrayList<String> PassHeader = new ArrayList<String>();
			ArrayList<String> FailHeader = new ArrayList<String>();
			for (int j = 0; j <= headers.length - 1; j++) {
				ListHeadrs.add(headers[j]);
			}
			int count = driver.findElements(By.xpath("//*[@id=\"datagrid\"]/thead/tr/th")).size();
			for (int j = 0; j < ListHeadrs.size(); j++) {
				for (int i = 1; i <= count; i++) {
					String getheader = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/thead/tr/th[" + i + "]"))
							.getText();
					if (getheader.equals(ListHeadrs.get(j))) {
						Pass = ListHeadrs.get(j);
						break;
					}
				}
				if (Pass == null) {
					FailHeader.add(ListHeadrs.get(j));
					Pass = null;
				} else {
					PassHeader.add(ListHeadrs.get(j));
					Pass = null;
				}
			}
			if (FailHeader.size() == 0) {
				System.out.println("Header in Table are showing correct , The Headers are  :" + PassHeader);
			} else if (PassHeader.size() == 0) {
				System.err.println("Header in Table are showing incorrect , The Headers are  :" + FailHeader);
				Assert.fail(
						"Test fail for checking ListPage , Header are showing in Table is incorrect : " + FailHeader);
			} else {
				System.err.println("In the Table Some Header are same but some are not listed :-");
				System.out.println("Header in Table listed  correct , The Headers are  :" + PassHeader);
				System.err.println("Header in Table listed incorrect , The Headers are  :" + FailHeader);
				Assert.fail("Test fail for checking ListPage ,Some Header are showing in Table is incorrect : "
						+ FailHeader);
			}
			if (Funtion.toUpperCase().equals("ALL")) {
				System.out.println("CHECKING SORTING......");
				for (int k = 1; k <= count; k++) {
					driver.findElement(By.xpath("//*[@id=\"datagrid\"]/thead/tr/th[" + k + "]")).click();
					driver.findElement(By.xpath("//*[@id=\"datagrid\"]/thead/tr/th[" + k + "]")).click();
					Thread.sleep(2000);
					String Firstvalue = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr[1]/td[" + k + "]"))
							.getText();
					String sorting=driver.findElement(By.xpath("//*[@id=\"datagrid\"]/thead/tr/th[" + k + "]")).getAttribute("class");
					driver.findElement(By.xpath("//*[@id=\"datagrid\"]/thead/tr/th[" + k + "]")).click();
					Thread.sleep(2000);
					String secoundvalue = driver
							.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr[1]/td[" + k + "]")).getText();		
					 if (sorting.equals("sorting_disabled")) {
						String getheader = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/thead/tr/th[" + k + "]"))
								.getText();
						System.out
						.println("sorting fuctionality not done in table header " + getheader + " for this page");
					}
					 else if(Firstvalue.equals("")&&secoundvalue.equals("")) {
						String getheader = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/thead/tr/th[" + k + "]"))
								.getText();
						System.out.println("sorting fuction is working in table header " + getheader + " for this page");
					}
					else if (Firstvalue.equals(secoundvalue)) {
						
						String getheader = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/thead/tr/th[" + k + "]"))
								.getText();
						System.err
								.println("sorting fuction not working in table header " + getheader + " for this page");
						Assert.fail("Test fail for checking sorting fuction  in table");
					} else if(sorting.equals("sorting_asc")||sorting.equals("sorting_desc")) {
						String getheader = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/thead/tr/th[" + k + "]"))
								.getText();
						System.out
								.println("sorting fuction is working in table header " + getheader + " for this page");
					}

				}
			} else {
				System.out.println("sorting fuction is not done in table for this page");
			}
		}
		System.out.println("------------------------");
	}

	// ScrollPage

	/****
	 * To Scroll up - 0,-700 TO Scroll Down - 0,700
	 ****/
	public void ScrollPage(WebDriver driver, String ScrollBy) throws AWTException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + ScrollBy + ")");

	}

	// Checking Page issue to do
	/************
	 * This method is compare to data to conform to there is any issue like loading
	 * or redirecting to next page etc..
	 * 
	 * @param Pagenameelement : This variable given value is WebElemnet such as
	 *                        'xpath/id' of any header or any text value that shown
	 *                        in web page
	 * @param labelName       : This variable given value label or text name to
	 *                        compare with web value
	 * @throws InterruptedException
	 */
	public void checkPageIssue(WebElement Pagenameelement, String labelName) throws InterruptedException {
		Thread.sleep(2000);
		String Pagetitle = Pagenameelement.getText();
		if (labelName.equals("Pagetitle")) {
			System.out.println("Header is :" + labelName);
			System.out.println("Page loaded succesfully");
		} else {
			System.err.println(Pagetitle);
			System.out.println("Header is not correct, Page loading issue ");
			Assert.fail("Test Fail");
		}

	}

}
