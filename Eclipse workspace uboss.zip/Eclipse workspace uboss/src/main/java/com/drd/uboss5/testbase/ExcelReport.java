package com.drd.uboss5.testbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

/*-- =============================================
-- Author		: basil.tharian
-- Created Date : Oct 1, 2020 , 2:46:40 PM
-- Description	: TESTExcel.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class ExcelReport {
	String Pass;
	String Fail;
	String starttime;
	String Endtime;

	public void InputData_ExcelReport(String ClassName, String MethodName, String Result, String Remark)
			throws IOException {
		String Classname = "Testing Started : " + getClass();
		String[] classname = Classname.split("class", 2);
		String name = classname[1];
		String TestReport = name.replace(".", " > ");
		classname = TestReport.split(">", 2);
		name = classname[1];
		String page = classname[0];
		if (Result.toUpperCase().equals("PASS")) {
			Pass = "Yes";
			Fail = "";
		} else if (Result.toUpperCase().equals("FAIL") || Result.toUpperCase().equals("SKIP")) {
			Fail = "Yes";
			Pass = "";
		}

		File file = new File(System.getProperty("user.dir") + "\\test-output\\Automation Excel Report.xls");
		String DATE;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate now = LocalDate.now();
		DATE = dtf.format(now);
		String username = System.getProperty("user.name");
		String uname = username.toUpperCase();
		FileInputStream inputStream = new FileInputStream(file);
		Workbook guru99Workbook = null;
		guru99Workbook = new HSSFWorkbook(inputStream);
		Sheet sheet = guru99Workbook.getSheet("Sheet1");
		int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
		Row row = sheet.getRow(0);
		Row newRow = sheet.createRow(rowCount + 1);
		String ReportName = row.getCell(0).getStringCellValue();

		if (ReportName.equals("REPORT NAME")) {
			String s = "value";

			row.getCell(0).setCellValue("AUTOMATION DETAIL REPORT - [" + uname + " , " + DATE + "]");

		}

		for (int i = rowCount; i >= 0; i--) {
			Row oldRow = sheet.getRow(i);
			String excelvalue = oldRow.getCell(1).getStringCellValue();
			if (excelvalue.equals(name)) {
				name = "";

			}
		}
		for (int i = rowCount; i >= 0; i--) {
			Row oldRow = sheet.getRow(i);
			String excelvalue = oldRow.getCell(0).getStringCellValue();
			if (excelvalue.equals(page)) {
				page = "";
			}
		}

		Cell cell = newRow.createCell(0);
		cell.setCellValue(page);

		Cell cell1 = newRow.createCell(1);
		cell1.setCellValue(name);

		Cell cell2 = newRow.createCell(2);
		cell2.setCellValue(MethodName);

		Cell cell3 = newRow.createCell(3);
		cell3.setCellValue(Pass);

		Cell cell4 = newRow.createCell(4);
		cell4.setCellValue(Fail);

		Cell cell5 = newRow.createCell(5);
		cell5.setCellValue(Remark);

		inputStream.close();
		FileOutputStream outputStream = new FileOutputStream(file);
		guru99Workbook.write(outputStream);

		outputStream.close();

	}
}
