
package com.drd.uboss5.testbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class TestBase extends ExcelReport {

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;
	public WebDriver driver;
	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest TESTCASE;
	public static String description;
	public static String ClassName;
	ArrayList<String> Methodlist = new ArrayList<String>();
	ArrayList<String> Resultlist = new ArrayList<String>();
	ArrayList<String> Remarklist = new ArrayList<String>();

	@BeforeSuite
	public void setUp() throws IOException {
		String username = System.getProperty("user.name");
		String name = username.toUpperCase();
		System.out.println(name);
		htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "/test-output/AutoamtionReport.html");
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		htmlReporter.config().setChartVisibilityOnOpen(true);
		htmlReporter.config().setDocumentTitle("Automation Testing Report");
		htmlReporter.config().setReportName("AUTOMATION REPORT  :  " + name);
		extent.setSystemInfo("User Name", name);
		extent.setSystemInfo("Environment", "Automation Testing");
		extent.setSystemInfo("Designation", "Software Testing");
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReporter.config().setTheme(Theme.STANDARD);
	}

	public void init() throws IOException {
		String Classname = "Testing Started : " + getClass();
		String[] classname = Classname.split("class", 2);
		String name = classname[1];
		String TestReport = name.replace(".", " > ");
		loadPropertiesFile();
		selectBrowser(Repository.getProperty("browser"));
		System.out.println(" ");
		System.out.println(
				"-----------------------------------" + description + "-----------------------------------------");
		System.out.println(" ");
		System.out.println("Testing Started : " + TestReport);
		System.out.println("----------");
		driver.get(Repository.getProperty("url"));
		TESTCASE = extent.createTest(TestReport, description);

	}

	public void init1() throws IOException {
		String Classname = "Testing Started : " + getClass();
		String[] classname = Classname.split("class", 2);
		String name = classname[1];
		String TestReport = name.replace(".", " > ");
		loadPropertiesFile();
		selectBrowser(Repository.getProperty("browser"));
		System.out.println(" ");
		System.out.println(
				"-----------------------------------NEW TESTCASE STARTED-----------------------------------------");
		System.out.println(" ");
		System.out.println("Testing Started : " + TestReport);
		System.out.println("----------");
		driver.get(Repository.getProperty("url1"));
		TESTCASE = extent.createTest(TestReport, description);

	}

	public static String capture(WebDriver driver, String name) throws IOException, InterruptedException {
		Thread.sleep(2000);
		String DATE;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate now = LocalDate.now();
		DATE = dtf.format(now);
		String username = System.getProperty("user.name");
		String Testername = username.toUpperCase();
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File("\\\\10.3.6.34\\developers\\ITT\\Automation-2020\\AutomationScript\\Screenshoots\\"
				+ Testername + "\\" + DATE + "-" + name + ".png");
		String errflpath = Dest.getAbsolutePath();
		FileUtils.copyFile(scrFile, Dest);
		return errflpath;
	}

	@AfterMethod
	public void getResult(ITestResult result) throws Exception {
		if (result.getStatus() == ITestResult.FAILURE) {
			System.out.println("  ");
			System.err.println(result.getName() + " : Completed and Status : FAIL");
			String testResult = "&nbsp; <br /> &nbsp; Senario checked in this method :  " + description;
			TESTCASE.log(Status.FAIL,
					MarkupHelper.createLabel("TESTING METHOD : " + result.getName().toUpperCase() + testResult
							+ "&nbsp; <br /> &nbsp; TEST FAILED" + ""
							+ "&nbsp; <br /> &nbsp; Test fail  due to below issues:", ExtentColor.RED));
//			TESTCASE.log(Status.FAIL,
//					TESTCASE.addScreenCaptureFromPath(capture(driver, getClass() + "-" + result.getName()))
//							+ "TEST FAILED");
			TESTCASE.fail(result.getThrowable());
			ClassName = "" + getClass();
			String Method = result.getName();
			String Result = "FAIL";
			Throwable remark = result.getThrowable();
			String Remark = remark.toString();
			if (Remark.contains("no such element: Unable to locate element:")) {
				Remark = "Unable to locate element,Because of  locator(id/xpath) is not found or change / loading issue)";
			} else if(Remark.contains("java.lang.AssertionError:")) {
				String[] RemarkSP = Remark.split(":", 2);
				Remark = RemarkSP[1];			
			}
			else if (Remark.contains("org.openqa.selenium.ElementNotVisibleException: element not visible")) {
				Remark = "element not visible becouse of loading issue or there is no data";
			}

			InputData_ExcelReport(ClassName, Method, Result, Remark);
			System.out.println("********************************************************************");
			System.out.println("  ");
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			System.out.println("  ");
			System.out.println(result.getName() + " : Completed and Status : PASS");
			String testResult = "&nbsp; <br /> &nbsp;  Senario checked in this method : " + description;
			TESTCASE.log(Status.PASS, MarkupHelper.createLabel("TESTING METHOD : " + result.getName().toUpperCase()
					+ testResult + "&nbsp; <br /> &nbsp; TEST  PASSED", ExtentColor.GREEN));
			ClassName = "" + getClass();
			String Method = result.getName();
			String Result = "PASS";
			String Remark = "-";

			InputData_ExcelReport(ClassName, Method, Result, Remark);
			System.out.println("********************************************************************");
			System.out.println("  ");
		} else if (result.getStatus() == ITestResult.SKIP) {
			System.out.println("  ");
			System.out.println(result.getName() + " : Completed and Status : SKIP");
			String testResult = "&nbsp; <br /> &nbsp; Senario checked in this method : " + description;
			TESTCASE.log(Status.SKIP, MarkupHelper.createLabel(
					result.getName() + testResult + "&nbsp; <br /> &nbsp Test Case SKIPPED", ExtentColor.YELLOW));
			TESTCASE.skip(result.getThrowable());
			ClassName = "" + getClass();
			String Method = result.getName();
			String Result = "SKIP";
			Throwable remark = result.getThrowable();
			String Remark = remark.toString();

			InputData_ExcelReport(ClassName, Method, Result, Remark);
			System.out.println("********************************************************************");
			System.out.println("  ");
		}
	}

//	public void excelreport() throws IOException {
//		for (int i = 0; i < Resultlist.size(); i++) {
//			if (Resultlist.get(i).equals("FAIL")) {
//				System.out.println(ClassName);
//				System.out.println("TEST2"+Remarklist.get(i));
//				String method = Methodlist.get(i);
//				String Remark = Remarklist.get(i);
//				InputData_ExcelReport(ClassName, method, "Fail", Remark);
//
//			} else if (Resultlist.get(i).equals("SKIP")) {
//				String method = Methodlist.get(i);
//				String Remark = Remarklist.get(i);
//				InputData_ExcelReport(ClassName, method, "Fail", Remark);
//
//			} else if (Resultlist.get(i).equals("PASS")) {
//				String method = Methodlist.get(i);
//				String Remark = Remarklist.get(i);
//				InputData_ExcelReport(ClassName, method, "PASS", Remark);
//			}
//
//		}
//
//	}

	@AfterSuite
	public void tearDown() throws IOException {
//		String username = System.getProperty("user.name");
		System.out.println("To view your TestCase report go to : \\test-output\\AutoamtionReport.html");
		extent.flush();
		// SendEmail.main(username);
		// Email.main("Automation Report", "Hi,"+"/n" + "Automation report File
		// attached");
	}

	public void after() {
//		String Classname = "Testing Started : " + getClass();
//		String[] classname = Classname.split("class", 2);
//		String name = classname[1];
//		String TestReport = name.replace(".", " > ");
		System.out.println(" ");

		System.out.println("----------------------------------------------------------------------------");
		description = "Please Write Discribtion for Test Case and Test Method";
		try {
			Thread.sleep(2000);
			driver.quit();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public void description(String Text) {
		description = Text;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-yyy HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		String Time = dtf.format(now);
		System.out.println("Testing : " + description +" ("+Time+")");
		System.out.println(" ");
	}
	public void Description(String Text) {
		description = Text;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-yyy HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		String Time = dtf.format(now);
		System.out.println("Testing : " + description +" ("+Time+")");
		System.out.println(" ");
	}


	public void loadPropertiesFile() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\src\\main\\java\\com\\drd\\uboss5\\config\\config.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public WebDriver selectBrowser(String browser) {

		if (browser.equals("chrome") || browser.equals("CHROME")) {
			System.out.println("Opening Chrome Browser");
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\src\\main\\java\\com\\drd\\uboss5\\driver\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		}
		return null;

	}

}
