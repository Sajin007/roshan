package com.drd.uboss5.testbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.testng.annotations.Test;

import com.google.common.io.Files;

/*-- =============================================
-- Author		: basil.tharian
-- Created Date : Sep 6, 2020
-- Description	: ClearScreenShootfolder.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class ExcelandScreenShot extends ExcelReport {

	
	// define an Excel Work Book
			HSSFWorkbook workbook;
			// define an Excel Work sheet
			HSSFSheet sheet;
		@Test(priority = 1, enabled = true)
		public void main() {
			String username = System.getProperty("user.name");
			String name = username.toUpperCase();
			String filelocation = "\\\\10.3.6.34\\developers\\ITT\\Automation-2020\\AutomationScript\\Screenshoots\\" + name
					+ "\\";
			File folder = new File(filelocation);
			for (File file : folder.listFiles()) {
				if (file.getName().endsWith(".png")) {
					file.delete();
					
				}
			}
		}
		@Test(priority = 2, enabled = true)
		public void clearexcelreport() throws IOException {
			String username = System.getProperty("user.name");
			String name = username.toUpperCase();
			File Folder = new File(System.getProperty("user.dir") + "\\test-output\\");
			for (File file : Folder.listFiles()) {
				if (file.getName().equals("Automation Excel Report.xls")) {
					file.delete();
				}
			}
			 File source = new File(System.getProperty("user.dir") +"\\src\\main\\java\\com\\drd\\uboss5\\testbase\\Automation Excel Report.xls");
		      File dest = new File(System.getProperty("user.dir") + "\\test-output\\Automation Excel Report.xls");
		     long start = System.nanoTime();
	         start = System.nanoTime();
	        Files.copy(source, dest);
	        
	        System.out.println("Automation Excel Report Created in Test-Output folder");
		}
}
