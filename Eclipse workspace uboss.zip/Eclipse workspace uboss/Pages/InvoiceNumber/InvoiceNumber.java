/*-- =============================================
-- Author		: Dennu Thomas
-- Created Date : 08-Apr-20
-- Description	: Invoice Number 
-- Modified by	: Dennu Thomas
-- Modified Date: 30-Oct-20
-- Project		: UBOSS-5-0-5
-- =============================================*/

package InvoiceNumber;

import java.awt.AWTException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.drd.uboss5.keywords.keywords;

public class InvoiceNumber extends keywords {
	WebDriver driver;

	@FindBy(id = "txtNextInvoiceNo")
	WebElement NextInvoiceNo;

	@FindBy(id = "txtInvoicePrefix")
	WebElement InvoicePrefix;

	@FindBy(id = "txtInvoiceSuffix")
	WebElement InvoiceSuffix;

	@FindBy(id = "txtMiniInvoiceValue")
	WebElement MiniInvoiceValue;

	@FindBy(id = "save")
	WebElement Save;

	public InvoiceNumber(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}

	public void invoicenum(String invoicenum) throws InterruptedException {
		Thread.sleep(3000);
		Inputdata(NextInvoiceNo, invoicenum, "Next Invoice Number");
	}

	public void invoiceprefix(String invoiceprefix) throws InterruptedException {
		Thread.sleep(3000);
		Inputdata(InvoicePrefix, invoiceprefix, "Invoice Prefix");
		
	}

	public void invoicesuffix(String invoicesuffix) throws InterruptedException {
		Thread.sleep(3000);
		Inputdata(InvoiceSuffix, invoicesuffix, "Invoice suffix");
	}

	public void invoicevalue(String invoicevalue) throws InterruptedException {
		Thread.sleep(3000);
		Inputdata(MiniInvoiceValue, invoicevalue, "Minimum invoice Value");
	}

	public void ClickonSave() throws InterruptedException {
		Thread.sleep(3000);
		Save.click();
	}


	/*******************************************************************
	 * Validation[page 1]
	 ***********************************************/

	@FindBy(id = "txtNextInvoiceNo-error")
	WebElement InvoiceNovalidation;

	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[2]/div/div/p")
	WebElement SaveandDelete_Validation;
	
	@FindBy(id = "txtMiniInvoiceValue-error")
	WebElement Minimumvalue_Validation;

	String[] InvoicenumVal = {"Next Invoice No cannot be empty","Enter Valid Invoice Number"};
	String[] Minimumvalueval= {"Please enter a valid Number"};
	String[] saveval = {"Saved successfully"};

	public void invnumval() throws InterruptedException {
		Thread.sleep(2000);
		Save.click();
		String[] setvalidation = InvoicenumVal;
		String getValiadtion = InvoiceNovalidation.getText();
		Validation(getValiadtion, setvalidation);
	}
	
	public void minvalueval() throws InterruptedException {
		Thread.sleep(2000);
		Save.click();
		String[] setvalidation = Minimumvalueval;
		String getValiadtion = Minimumvalue_Validation.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void saveval() throws InterruptedException {
		Thread.sleep(2000);
		String[] setvalidation = saveval;
		String getValiadtion = SaveandDelete_Validation.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void validation_page1() throws InterruptedException {
		this.invnumval();
		this.minvalueval();

	}

	public void Save_validation() throws InterruptedException {
		this.saveval();
	}

	/*********************************************
	 * MainMethod
	 *************************************************/

	public void Invoicenumber_Validation(String invoicenum,String invoicevalue) throws InterruptedException, AWTException {
		// Step 1
		this.invoicenum("clear");
		this.invoiceprefix("clear");
		this.invoicesuffix("clear");
		this.invoicevalue(invoicevalue);
		this.ClickonSave();
		this.validation_page1();
		this.invoicenum(invoicenum);
		this.ClickonSave();
		this.validation_page1();
		Thread.sleep(3000);

	}

	public void Invoicenumumber(String invoicenum, String invoiceprefix, String invoicesuffix, String invoicevalue)
			throws InterruptedException, AWTException {
		Thread.sleep(3000);
		// Step 1
		this.invoicenum(invoicenum);
		this.invoiceprefix(invoiceprefix);
		this.invoicesuffix(invoicesuffix);
		this.invoicevalue(invoicevalue);
		Thread.sleep(3000);
		this.ClickonSave();
		Thread.sleep(3000);
		this.Save_validation();

	}

}