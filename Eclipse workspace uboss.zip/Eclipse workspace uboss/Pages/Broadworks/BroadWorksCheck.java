package Broadworks;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: basil.tharian
-- Created Date : Jun 23, 2020
-- Description	: BroadWorksCheck.java
-- Modified by	: 
-- Modified Date:
-- Project		: Uboss-5-0-0-Eugin
-- =============================================*/
public class BroadWorksCheck {
	WebDriver driver;

	@FindBy(xpath = "/html/body/form/table/tbody/tr[3]/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td[2]/input")
	WebElement loginID;
	@FindBy(xpath = "/html/body/form/table/tbody/tr[3]/td/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/input")
	WebElement Password;
	@FindBy(xpath = "/html/body/form/table/tbody/tr[3]/td/table/tbody/tr/td[2]/table/tbody/tr/td/a")
	WebElement LogInBtn;

	String Type;
	String Name;
	String Xpaths;
	int ingremetValue;
	int XPPTnumber;
	ArrayList<String> ListType = new ArrayList<String>();
	ArrayList<String> ListName = new ArrayList<String>();
	ArrayList<String> ListElemts = new ArrayList<String>();
	List<String> Listvalues = new ArrayList<String>();
	List<String> ListXpath = new ArrayList<String>();

	public BroadWorksCheck(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl() throws InterruptedException {
		Thread.sleep(1000);
		driver.get("http://10.4.66.9/Login/");
		Thread.sleep(1000);
		loginID.sendKeys("ubossadmin@lab.insmartcloud.com");
		Password.sendKeys("22mN5HQkzj8A");
		LogInBtn.click();

	}

	public void selectMenu(String[] TypeName, String[] Webelement) throws InterruptedException {
		Thread.sleep(2000);
		for (int j = 0; j <= TypeName.length; j++) {
//			 System.out.println(TypeName[j]);
//			 System.out.println(Webelement[j]);
			if (TypeName[j].equals("")) {
				// System.out.println("Type List Completed");
				break;
			} else {
				String[] SPLITMENU = TypeName[j].split("__", 3);
				Type = SPLITMENU[0];
				Name = SPLITMENU[1];
				ListType.add(Type);
				ListName.add(Name);
			}
			if (Webelement[j].equals("")) {
				// System.out.println("Webelement List Completed");
				break;
			} else {
				Xpaths = Webelement[j];
				ListElemts.add(Xpaths);
			}
		}

		for (int i = 0; i <= ListType.size() - 1; i++) {
			String gettype = ListType.get(i).toUpperCase();
			String getName = ListName.get(i);
			String getxpath = ListElemts.get(i);
//			 System.out.println("Type:"+gettype);
//			 System.out.println("name:"+getName);
//			System.out.println("Xpath:"+getxpath);
			Thread.sleep(2000);
			switch (gettype) {
			case "MENU":
				if (!"no".equals(getxpath)) {
					driver.findElement(By.xpath(getxpath)).click();
				} else {
					driver.findElement(By.linkText(getName)).click();
					break;
				}
			case "DROP":
				// System.out.println(getName);
				WebElement Drop = driver.findElement(By.xpath(getxpath));
				Select dropdown1 = new Select(Drop);
				dropdown1.selectByVisibleText(getName);
				break;
			case "INPUTTEXT":
				WebElement text = driver.findElement(By.xpath(getxpath));
				text.sendKeys(getName);
				break;
			case "CLICK":
				WebElement click = driver.findElement(By.xpath(getxpath));
				click.click();
				break;
			case "SELECT":
				this.selectiteams(getName, getxpath);
				break;
			case "TABLECOMPAER":
				this.tabelCompare(getName, getxpath);
				break;
			case "COMPAREDATA":
				this.comparetype(getName, getxpath);
				break;

			default:
				break;
			}

		}

	}

	public void selectiteams(String Label, String Webelement) throws InterruptedException {
		Thread.sleep(4000);
		String label = Label;
		String Text = Webelement;
		String XPT = Webelement.replace("tr[x]/td[", "change&tr"); 
		String[] SPLITXpathtr = XPT.split("&", 2);
		String countxpathtr = SPLITXpathtr[0].replace("change", "tr");
		String xpath;
		int Counts = driver.findElements(By.xpath(countxpathtr)).size();
		for (int i = 2; i <= Counts; i++) {
			String number = String.valueOf(i);
			xpath = Text.replace("x", number);
			String text = driver.findElement(By.xpath(xpath)).getText();
			if (label.contains(text)) {
				driver.findElement(By.xpath(xpath)).click();
				break;
			}

		}
	}

	public void tabelCompare(String getName, String getxpath) throws InterruptedException {
		ingremetValue=0;
		int valuepos = 0;
		String[] SPLITValue = getName.split("&&");
		Listvalues = Arrays.asList(SPLITValue);
		String[] SPLITXpathtr = getxpath.split("z", 2);
		String countxpathtr = SPLITXpathtr[0].replace("tr[x]/td[", "tr");
		int counttr = driver.findElements(By.xpath(countxpathtr)).size();
		for (int i = 0; i < 1; i++) {
			int a = i + 2;
			String number = String.valueOf(a);
			String xpath = getxpath.replace("x", number);
			String xpathtd = xpath.replace("td[z]", "Change");
			String[] SPLITXpathtd = xpathtd.split("Change", 2);
			String countxpathtd = SPLITXpathtd[0] + "td";
			int counttd = driver.findElements(By.xpath(countxpathtd)).size();
			for (int j = 0; j < counttr - 1 & ingremetValue < Listvalues.size() - 1; j++) {
				int l = j + 2;
				String number1 = String.valueOf(l);
				String xpathtr = getxpath.replace("x", number1);
				for (int k = 0, L = 0; k < counttd-1; k++, L++) {
					int m = k + 2;
					String numberxpath = String.valueOf(m);
					String Fullxpath = xpathtr.replace("z", numberxpath);
					try {
						driver.findElement(By.xpath(Fullxpath));
						Xpaths = Fullxpath;
					} catch (org.openqa.selenium.NoSuchElementException e) {
						int n = m + 1;
						String pos = String.valueOf(n);
						Xpaths = xpathtr.replace("z", pos);
						k = k + 1;
					}
					ingremetValue = L + valuepos;
					String Value01 = Listvalues.get(ingremetValue);
					XPPTnumber = L + 1;
					this.comparetype(Value01, Xpaths);

				}
				valuepos = ingremetValue + 1;

			}

		}

	}

	public void comparetype(String getName, String getxpath) throws InterruptedException {

		String[] SPLITMENU = getName.split("#", 2);
		Type = SPLITMENU[0].toUpperCase();
		Name = SPLITMENU[1];
//		System.out.println("Type :"+Type);
//		System.out.println("Name :"+Name);
//		System.out.println("xpath :"+getxpath);
		switch (Type) {
		case "DROP":
			String x = getxpath + "/select";
			Select select = new Select(driver.findElement(By.xpath(x)));
			WebElement option = select.getFirstSelectedOption();
			String defaultItem = option.getText();
			if (Name.equals(defaultItem)) {
				System.out.println("Value  shown in BW also same  : " + Name);
			} else if (Name.toUpperCase().equals("EMPTY")) {
				System.out.println("There is no value to check in BW : " + Name);
			} else {
				System.err
						.println("Value  shown in BW is not same Expect Value : " + Name + ", Result : " + defaultItem);
				Assert.fail("Value  shown in BW is not same Expect Value : " + Name + ", Result : " + defaultItem);
			}
			break;
		case "TEXT":
			String getvalue = driver.findElement(By.xpath(getxpath)).getAttribute("value");
			if (getvalue == null) {
				getvalue = driver.findElement(By.xpath(getxpath)).getText();
				if (Name.equals(getvalue)) {
					System.out.println("Value  shown in BW also same : " + Name);
				} else if (Name.toUpperCase().equals("EMPTY")) {
					System.out.println("There is no value to check in BW : " + Name);
				} else {
					String y = getxpath + "/input";
					getvalue = driver.findElement(By.xpath(y)).getAttribute("value");
					if (Name.equals(getvalue)) {
						System.out.println("Value  shown in BW also Same : " + Name);
					} else {
						System.err.println(
								"Value  shown in BW is not same Expect Value : " + Name + ", Result : " + getvalue);
						Assert.fail("Value  shown in BW is not same Expect Value : " + Name + ", Result : " + getvalue);
					}
				}
			} else if (Name.equals(getvalue)) {
				System.out.println(getvalue);
				System.out.println("Value  shown in BW also same : " + Name);
			} else if (Name.toUpperCase().equals("EMPTY")) {
				System.out.println("There is no value to check in BW :" + Name);
			} else {
				System.err.println("Value  shown in BW is not same Expect Value : " + Name + ", Result : " + getvalue);
				Assert.fail("Value  shown in BW is not same Expect Value : " + Name + ", Result : " + getvalue);
			}
			break;
		case "TEXTBOXASSING":
			this.tableValues(getxpath, Name);
			break;

		case "CHECKBOXSELECTED":
			this.checkboxisselected(Name, getxpath);
			break;

		case "CHECKBOXNOTSELECTED":
			this.checkboxisNotselected(Name, getxpath);
			break;

		default:
			break;
		}

	}

	public void checkboxisselected(String Name, String Webelement) {
		try {
			String str = driver.findElement(By.xpath(Webelement)).getAttribute("checked");
			if (str.equalsIgnoreCase("true")) {
				System.out.println("Checkbox is also selected in BW : " + Name);
			} else {
				System.err.println("In BW checkbox is show as not selected : " + Name);
				Assert.fail("In BW checkbox is show as not selected : " + Name);
			}
		} catch (org.openqa.selenium.NoSuchElementException e) {
			String y = Webelement + "/input";
			try {
				String str = driver.findElement(By.xpath(y)).getAttribute("checked");
				if (str.equalsIgnoreCase("true")) {
					System.out.println("Checkbox is also selected in BW : " + Name);
				} else {
					System.err.println("In BW checkbox is show as not selected : " + Name);
					Assert.fail("In BW checkbox is show as not selected : " + Name);
				}
			} catch (org.openqa.selenium.NoSuchElementException f) {
				String x = Webelement + "/input[" + XPPTnumber + "]";
				String str = driver.findElement(By.xpath(x)).getAttribute("checked");
				if (str.equalsIgnoreCase("true")) {
					System.out.println("Checkbox is also selected in BW : " + Name);
				} else {
					System.err.println("In BW checkbox is show as not selected : " + Name);
					Assert.fail("In BW checkbox is show as not selected : " + Name);
				}
			}
		}
	}

	public void checkboxisNotselected(String Name, String Webelement) {
		try {
			String str = driver.findElement(By.xpath(Webelement)).getAttribute("checked");
			if (str == null) {
				System.out.println("Checkbox  is  not selected in BW : " + Name);
			} else {
				System.err.println("In BW checkbox is show as  selected :" + Name);
				Assert.fail("In BW checkbox is show as  selected :" + Name);
			}
		} catch (org.openqa.selenium.NoSuchElementException e) {
			String y = Webelement + "/input";
			try {
				String str = driver.findElement(By.xpath(y)).getAttribute("checked");
				if (str == null) {
					System.out.println("Checkbox  is  not selected in BW : " + Name);
				} else {
					System.err.println("In BW checkbox is show as  selected :" + Name);
					Assert.fail("In BW checkbox is show as  selected :" + Name);
				}
			} catch (org.openqa.selenium.NoSuchElementException f) {
				String x = Webelement + "/input[" + XPPTnumber + "]";
				String str = driver.findElement(By.xpath(x)).getAttribute("checked");
				if (str == null) {
					System.out.println("Checkbox  is  not selected in BW : " + Name);
				} else {
					System.err.println("In BW checkbox is show as  selected :" + Name);
					Assert.fail("In BW checkbox is show as  selected :" + Name);
				}
			}
		}

	}

	public void tableValues(String xpath, String values) {
		String tabelexpath = xpath;
		String makexpath = tabelexpath.replace("select", "change-name");
		String[] SPLITXpathtr = makexpath.split("-", 2);
		String countxpathtr = SPLITXpathtr[0].replace("change", "select");
		System.out.println(countxpathtr);
		String Gettablevalues = driver.findElement(By.xpath(countxpathtr)).getText();
		if (Gettablevalues == null) {
			System.err.println("In BW Given Value is  Not List in Table :" + values);
			Assert.fail("In BW Given Value is Not List in Table :" + values);
		} else {

			String countxpath = tabelexpath.replace("option[x]", "option");
			int count = driver.findElements(By.xpath(countxpath)).size();
			for (int i = 1; i <= count; i++) {
				String number = Integer.toString(i);
				String tablevaluexpath = tabelexpath.replace("x", number);
				String Gettablevalue = driver.findElement(By.xpath(tablevaluexpath)).getText();
				if (Gettablevalue.equals(values)) {
					System.out.println("Given value " + Gettablevalue + " is also shown in broadworks");
				}
			}

		}

	}

	/**********************************
	 * Main Method *
	 *********************************/

	public void mainBroadworks(String[] TypeName, String[] Webelement) throws InterruptedException {
		this.GoToUrl();
		this.selectMenu(TypeName, Webelement);

	}

}
