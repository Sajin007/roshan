/*-- =============================================
-- Author		: Oommen K Raju
-- Created Date : 08-04-2020
-- Description	: Package Edit [common class used for PO,Distibutor]
-- Modified by	: Oommen K Raju
-- Modified Date: 25-03-2021
-- Project		: UBOSS-5-0-5
-- =============================================*/

package Package;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.drd.uboss5.keywords.keywords;
public class Package_Editt extends keywords {
	WebDriver driver;

	@FindBy(xpath = "//u[contains(.,'Automation2020 Package')]")
	WebElement Automation2020Package;

	@FindBy(id = "tabgeneral")
	WebElement GeneralTab;
	
	@FindBy(id = "sel_avail_disti")
	WebElement AvailableToDistributor;
	

	@FindBy(xpath = "//select[@id='sel_avail_reseller'] |//select[@id='availableto'] ")
	WebElement AvailableToReseller;

	@FindBy(xpath = "//input[@name='txtName']")
	WebElement Name;

	@FindBy(xpath = "//textarea[@name='txtDecription']")
	WebElement Description;

	@FindBy(xpath = "//input[@name='packagecode']")
	WebElement PackageCode;

	@FindBy(id = "sel_country")
	WebElement Country;

	@FindBy(id = "sel_packagetype")
	WebElement PackageType;
	
	@FindBy(id = "sel_primarypackage")
	WebElement PrimaryPackage;
	
	@FindBy(id = "ddlcommission")
	WebElement CommisionCategory;
	
	@FindBy(id = "sel_fill_device")
	WebElement DeviceRented;
	
	@FindBy(id = "sel_upgrade_priority")
	WebElement UpgradePriority;
	
		
	@FindBy(id = "sel_assignmenttype")
	WebElement AssignmentType;
	
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[9]/div/label/span")
	WebElement IsPrimary;
		
	@FindBy(id = "sel_keylamp")
	WebElement KeyAndLamp;
	
	
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[11]/div/label/span")
	WebElement CanAlterPackage;

	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[12]/div/label/span")
	WebElement CanBeAssigned;


	@FindBy(xpath="//button[@id='save_btn'] | //button[@id='updatecontract']")
	WebElement Save;
	
	@FindBy(xpath="//button[text()=' Save '] | (//button[@type='button'][contains(@id,'btn')][contains(.,'Save')])[2] ")
	WebElement Save1;
	
	@FindBy(id= "delete_btn")
	WebElement Delete;

	@FindBy(xpath = "(//a[contains(.,'Cancel')])[2]")
	WebElement Cancel;
	
	
	/***********************************
	 * page2 [Contract Rule tab]
	 ***********************************/

	@FindBy(id = "tabcontractrule")
	WebElement ContractRuleTab;

	@FindBy(xpath = "//input[@name='txtMinimumDuration']")
	WebElement MinimumDuration;

	@FindBy(xpath = "//input[@name='txtNotificationPeriod']")
	WebElement NotificationPeriod;

	@FindBy(xpath = "//input[@name='txtQuarantinePeriod']")
	WebElement QuarantinePeriod;

	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div/form/div[4]/div/label/span[2]")
	WebElement NotificationPeriodCheckbox;

	
	/******************************************
	 * page3 [Usage-instancewise tab]
	 *****************************************/

	@FindBy(id = "tabinstancewise")
	WebElement UsageInstanceTab;


	@FindBy(xpath ="//button[@id= 'btn_settings']")
	WebElement Settings;
	
	@FindBy(xpath ="//button[@id= 'btn_download']")
	WebElement Download;
	
	
	/********************************************
	 * page4 [Usage-Packagewise tab]
	 ********************************************/

	@FindBy(id = "tab4")
	WebElement UsagePackagewiseTab;

	@FindBy(xpath = "//span[contains(@class,'checkmark')]")
	WebElement IncludeRemovedCheckBoxTab4;

	@FindBy(id = "btn_download")
	WebElement Export;

	@FindBy(xpath = "//*[@id=\"datagrid_info\"]")
	WebElement ShowingEntries;

	@FindBy(xpath = "//input[@placeholder='Search..']")
	WebElement SearchData;
	
	@FindBy(xpath = "//span[@id='clear_btn'] | //i[@class='fa fa-times hidemsg']")
	WebElement Search_close;
		
	@FindBy(xpath = "//button[@id='search_btn']")
	WebElement Search_click;
		
	@FindBy(xpath = "//*[@id=\"datagrid\"]/tbody/tr[1]/td[1]/a/u")
	WebElement testLink;
	
	@FindBy(xpath = "//button[contains(.,'Yes')] ")
	WebElement Yes;
		
	@FindBy(xpath="//span[@id='tabactivity']")
	WebElement PackageActivityTab;
	
	
	/*************************** [List Page]***********************************/
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div[2]/div/div/div/label/span")
	WebElement includeremovedcheck;

	/*********************************************************
	 * Page 1[METHODS]
	 **********************************************************/

	public Package_Editt(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	
	public void Automation2020PackageClick() throws InterruptedException {
		Thread.sleep(2000);
		Automation2020Package.click();
		Thread.sleep(1000);
	}

	public void GeneralTab() throws InterruptedException {
	Thread.sleep(5000);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();",GeneralTab);
		
	}
	
	public void AvailableToDistributor() throws InterruptedException
	{
		try
		{
			Select select = new Select(AvailableToDistributor);
			WebElement option = select.getFirstSelectedOption();
			String defaultvalue = option.getText();
		    System.out.println("Available To Distributor: " + defaultvalue);
					
			}
		catch (org.openqa.selenium.NoSuchElementException e) {

		}	
	}
	
	public void AvailableToReseller() throws InterruptedException
	{
		try
		{
					
					Select select = new Select(AvailableToReseller);
					WebElement option = select.getFirstSelectedOption();
					String defaultvalue = option.getText();
				    System.out.println("Available To: " + defaultvalue);
			
					
		} catch (org.openqa.selenium.NoSuchElementException e) {

		}	
		}	
	
	
	public void name(String name) throws InterruptedException {
		Inputdata(Name, name, "Name");
	}

	public void Description(String description) throws InterruptedException {
		Inputdata(Description, description, "Description");
		
	}

	public void PackageCode(String packageCode) throws InterruptedException {
		Inputdata(PackageCode, packageCode, "Package code");
		
	}

	public void Country() throws InterruptedException
	{
		try {
			
			if(Country.isDisplayed())
			{
					Select select = new Select(Country);
					WebElement option = select.getFirstSelectedOption();
					String defaultvalue = option.getText();
				    System.out.println("Country: " + defaultvalue);
			}
			
			else
			{
				System.out.println("Since level is Reseller , Country dropdown is not present");
			}
					
		} catch (org.openqa.selenium.NoSuchElementException e) {

		}}
	
	
	public void PackageType() throws InterruptedException
	{
		try {
			if(PackageType.isEnabled())
				{
					Assert.fail("Test Fail , because PackageType dropdown field is enabled ");
								
				} else {
					
					Select select = new Select(PackageType);
					WebElement option = select.getFirstSelectedOption();
					String defaultvalue = option.getText();
				    System.out.println("Package Type: " + defaultvalue);
			}
					
		} catch (org.openqa.selenium.NoSuchElementException e) {

			
		}	}
	
	public void AssignmentType() throws InterruptedException
	{
		try {
			if(AssignmentType.isEnabled())
				{
					Assert.fail("Test Fail , because AssignmentType dropdown field is enabled ");
								
				} else {
					
					Select select = new Select(AssignmentType);
					WebElement option = select.getFirstSelectedOption();
					String defaultvalue = option.getText();
				    System.out.println("Assignment Type: " + defaultvalue);
			}
					
		} catch (org.openqa.selenium.NoSuchElementException e) {

			System.out.println("Assignment type dropdown is not present");
		}	}
	
	public void KeyAndLamp() throws InterruptedException
	{
		try {
			if(KeyAndLamp.isEnabled())
				{
					Assert.fail("Test Fail , because KeyAndLamp dropdown field is enabled ");
								
				} else {
					
					Select select = new Select(KeyAndLamp);
					WebElement option = select.getFirstSelectedOption();
					String defaultvalue = option.getText();
				    System.out.println("Key & Lamp Count: " + defaultvalue);
			}
					
		} catch (org.openqa.selenium.NoSuchElementException e) {
			
			System.out.println("Key & Lamp filed is not present");
			
		}	}
	
	public void CommisionCategory(String commisionCategory) throws InterruptedException
	{
		try {
			dropdown(CommisionCategory, commisionCategory, "Commision category");
			
		} catch (org.openqa.selenium.NoSuchElementException e) {

			
		}	
		
	}
	public void PrimaryPackage()
	{
		try {
			
				Select select = new Select(PrimaryPackage);
				WebElement option = select.getFirstSelectedOption();
				String defaultvalue = option.getText();
			    System.out.println("Primary Package :" + defaultvalue);
			
		} catch (org.openqa.selenium.NoSuchElementException e) {
			
		}
		
	}
	public void Devicerented()
	{
		try {
			if(DeviceRented.isEnabled())
			{
				Assert.fail("Test Fail , because Device-rented dropdown field is enabled ");
			}
			
			else
			{
				Select select = new Select(DeviceRented);
				WebElement option = select.getFirstSelectedOption();
				String defaultvalue = option.getText();
			    System.out.println("Device - Rented :" + defaultvalue);
			}
			
		}catch (org.openqa.selenium.NoSuchElementException e) {
			System.out.println("Device Rented dropdown is not present");
		}
		
	}
	
	public void UpgradePriority()
	{
		try
		{
		
				Select select = new Select(UpgradePriority);
				WebElement option = select.getFirstSelectedOption();
				String defaultvalue = option.getText();
			    System.out.println("Upgrade Priority :" + defaultvalue);
			}
			
		catch (org.openqa.selenium.NoSuchElementException e) {
		}
		
	}
	
	
	public void Save() throws InterruptedException {
	Thread.sleep(5000);
		
		if(Save.isDisplayed())
		{
		System.out.println("Save button is present");
		
		//new WebDriverWait(driver,20).until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Save '] | (//button[@type='button'][contains(@id,'btn')][contains(.,'Save')])[2] "))).click();
		Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Save1);
		}
		else                                                                                  
		{
			Assert.fail("Save button not present");
		}
		
		
	}

	public void Cancel() throws InterruptedException, AWTException {
		Thread.sleep(5000);
		ScrollPage(driver, "0,10000");
		if(Cancel.isDisplayed())
		{
			Thread.sleep(3000);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click();", Cancel);
		
		}
		else
		{
			Assert.fail("Cancel button not present");
		}
	}

	public void GeneralTabFieldClear() throws AWTException, InterruptedException {
		Inputdata(Name, "clear", "Name");
		Inputdata(Description, "clear", "Description");
		Inputdata(PackageCode, "clear", "PackageCode");
	}
	
	
	
public void OwnLevelServices(String[] ownlevelServiceCheckbox,String[] ownlevelService) throws InterruptedException, AWTException {
        this.ScrollPage(driver, "0,1000");	
		try {
			
			String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[14]/div[1]/table[3]/tbody/tr";
			String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[14]/div[1]/table[3]/tbody/tr[x]/td/span";
			String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[14]/div[1]/table[3]/tbody/tr[x]/td/label/span";
			String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[14]/div[1]/table[3]/tbody/tr[x]/td/label/input";
			String vlaue =driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
			this.ownLevelService(ownlevelService, countxpath, labelxpath, Checkboxid, checkboxpath, ownlevelServiceCheckbox);
		} catch (org.openqa.selenium.NoSuchElementException e1) {
			
			try {
				
				String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[13]/div[1]/table[3]/tbody/tr";
				String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[13]/div[1]/table[3]/tbody/tr[x]/td/span";
				String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[13]/div[1]/table[3]/tbody/tr[x]/td/label/span";
				String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[13]/div[1]/table[3]/tbody/tr[x]/td/label/input";
				String vlaue =driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
				this.ownLevelService(ownlevelService, countxpath, labelxpath, Checkboxid, checkboxpath, ownlevelServiceCheckbox);
			} catch (org.openqa.selenium.NoSuchElementException e2) {
				
									
				}
								
			}
		}

	
	
	public void ownLevelService(String[] ownlevelService,String countxpath,String labelxpath, String Checkboxid,String checkboxpath,String[] ownlevelServiceCheckbox) throws InterruptedException {
		Select select = new Select(PackageType);
		WebElement option = select.getFirstSelectedOption();
		String defaultvaluePackageType = option.getText();
				
			if (ownlevelService.length != 0) 
			{
				int count = driver.findElements(By.xpath(countxpath)).size();
				// System.out.println(count);
					 
				 if (count <=0) {
											
					 String LabelXpath = countxpath + "/td[1]/label/span";
					String Checkboxpath = countxpath + "/td[1]/label";
									 
						 for (int j = 0; j < ownlevelService.length; j++) {
							 String OwnlevelServiceCheckbox = ownlevelServiceCheckbox[j];
							Thread.sleep(1000);
							String ValueServiceCheckbox = driver.findElement(By.xpath("Checkboxpath")).getAttribute("checked");
							if (OwnlevelServiceCheckbox.toUpperCase().equals("YES")) {
									
							if (ValueServiceCheckbox == null) {
								Thread.sleep(2000);
							 	driver.findElement(By.xpath(Checkboxpath)).click();
							 	
							 	WebElement Service1 = driver.findElement(By.xpath("Checkboxpath"));
								String ValueService1 = Service1.getAttribute("checked");
										 	
								if (ValueService1 == null) {
									System.err.println("Parent service Checkbox is not checked for  " + ownlevelService[j]);
									Assert.fail("Test fail for Parent Service Checkbox to check");
								}
								
								else {
									System.out.println("Own level Service Checkbox is checked for  " + ownlevelService[j]);
								}
							} else {
								System.out.println("Own level Service Checkbox is already checked for  " + ownlevelService[j]);
							}
						}
							
							else if (OwnlevelServiceCheckbox.toUpperCase().equals("NO")) {
								if (ValueServiceCheckbox == null) {
									System.out.println("Own level Service Checkbox is already unchecked for  " + ownlevelService[j]);
								} else if (ValueServiceCheckbox != null) {
									driver.findElement(By.xpath(Checkboxpath)).click();
									WebElement Parentservice = driver.findElement(By.xpath("Checkboxpath"));
									String ValueServiceCheckbox1 =  Parentservice.getAttribute("checked");
									if (ValueServiceCheckbox1 == null) {
										System.out.println("Own level checkbox is Unchecked for " + ownlevelService[j]);
									} else {
										System.err.println("Own level checkbox is not Unchecked for Category " + ownlevelService[j]);
										Assert.fail("Test fail for checking Service Checkbox to uncheck");
									}
								}

							} else {
								System.out.println("There is no Change in Own level Checkbox for  " + ownlevelService[j]);

						}
								
					}		
							}
			
				 else {
						
						this.Multiple_CheckBox_Selection(ownlevelService, countxpath, labelxpath, Checkboxid,checkboxpath,ownlevelServiceCheckbox);
					 }
					 
					}
							
				 }
				 
			
		
		


	/********************************************
	 * tab 2
	 *********************************************/

	public void ContractRuleTab() throws InterruptedException {
		Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", ContractRuleTab);
			
	}

	public void MinimumDuration(String minimumDuration) throws InterruptedException {
		Inputdata(MinimumDuration, minimumDuration, "MinimumDuration");
	}

	public void NotificationPeriod(String notificationPeriod) throws InterruptedException {
		Inputdata(NotificationPeriod, notificationPeriod, "NotificationPeriod");
		
	}

	public void QuarantinePeriod(String quarantinePeriod) throws InterruptedException {
		Inputdata(QuarantinePeriod, quarantinePeriod, "QuarantinePeriod");
		
	}

	public void NotificationPeriodCheckbox(String NotificationPeriodCheckboxValue) throws InterruptedException {
		
		Checkbox(driver,"chkCombineNotificationPeriodForPackage", NotificationPeriodCheckbox, NotificationPeriodCheckboxValue, "Notification Period");
		
	}



	public void contractRuleFieldClear() throws InterruptedException {
		Inputdata(MinimumDuration, "clear", "MinimumDuration");
		Inputdata(NotificationPeriod, "clear", "Contract Rule");
		Inputdata(QuarantinePeriod, "clear", "Quarantine Period");
		
	}

	/*********************************************
	 * tab 3
	 *********************************************/

	public void UsageInstanceTab() throws InterruptedException {
	Thread.sleep(3000);
		
		if(UsageInstanceTab.isDisplayed())
	{
		System.out.println("UsageWise instance Tab is present");	
		UsageInstanceTab.click();
		System.out.println("UsageWise instance Tab clicked sucessfully");	
		}
		else
		{
			Assert.fail("Usage instance tab not present");
		}
	}
	
	

	public void SearchUsageInstancewise(String searchusageInstancewise,String includeremovedValue) throws InterruptedException, AWTException {
			this.view_data();
			this.ListSearch(searchusageInstancewise);   
			Thread.sleep(2000);
			this.Settings();
			Thread.sleep(3000);
			this.IncludeRemovedCheckBox(includeremovedValue);
		}
	
	
	public void PackageActivityTab() throws InterruptedException
	{
		try {
			
			if(PackageActivityTab.isDisplayed())
			{
			System.out.println("Package Updation Activity is present");
			Thread.sleep(3000);
			PackageActivityTab.click();
			}
			
			else
			{
				System.out.println(" Package Updation Activity is not present");
				
			}
			
		} catch (org.openqa.selenium.NoSuchElementException e) {
			
			System.out.println("Since Normal Package selected Package Updation Activity is not present");
			}
		
	}

	/**********************************************
	 * tab 4
	 *********************************************/

	public void UsagePackagewiseTab() throws InterruptedException {
	Thread.sleep(3000);
		
		try {
			if(UsagePackagewiseTab.isDisplayed())
			{
			System.out.println("Usaage Package Wise Tab is present");
			UsagePackagewiseTab.click();
			}
			
			else
			{
			
			Assert.fail("Test fail,Usaage Package Wise Tab is not present");
			}
		} catch (org.openqa.selenium.NoSuchElementException e) {
			System.out.println("Usage Package wise tab not present");
		}
		

	}
	
	public void Settings() throws InterruptedException {
		
		try {
			if(Settings.isDisplayed())
			{
			System.out.println("Settings icon is present");
			Thread.sleep(3000);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click();", Settings);
		
			System.out.println("Settings clicked successfully");
			}
			else
			{
				Assert.fail("Test fail,Setting icon not present");
			}
			
		} catch (org.openqa.selenium.NoSuchElementException e) {
			// TODO: handle exception
		}
		
	}

	public void IncludeRemovedCheckBox(String includeremovedValue) throws InterruptedException {
		Checkbox(driver, "includeremoved", IncludeRemovedCheckBoxTab4, includeremovedValue, "Include Removed");
		
	
	}

	public void Export() {
		
		if(Export.isDisplayed())
		{
		try {
			Thread.sleep(3000);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click();", Export);
			System.out.println("File Exported sucessfully");
		} catch (Exception e) {
			
		}
		}
		
		else
		{
			System.out.println("Export is not present");
		}
	}
	
	

	public void Search(String search,String includeremovedValue) throws InterruptedException, AWTException {
			try {
				this.view_data();
				this.ListSearch(search);   
				this.Export();
				Thread.sleep(4000);
				Search_close.click();
				Thread.sleep(2000);
				this.Settings();
				Thread.sleep(3000);
				this.IncludeRemovedCheckBox(includeremovedValue);
			}catch (org.openqa.selenium.NoSuchElementException e) {
				
			}
		    
		}
	

	/*********************************************
	 * List page [Delete]
	 *********************************************/

	public void testLink() throws InterruptedException {
		//Thread.sleep(3000);
		
		testLink.click();
	}

	
	public void ListSearch(String searchDataListpage) throws InterruptedException, AWTException {
		try {
			
		Thread.sleep(4000);
		Search_close.click();
		Thread.sleep(3000);
		SearchData.sendKeys(searchDataListpage);
		Thread.sleep(4000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Search_click);
		
			
		} catch (Exception e) {
			
		}
			
		try {
			
			this.testLink();
			this.ScrollPage("0,2000");
			
		} 	catch (org.openqa.selenium.NoSuchElementException e) {

		}
		

	}



	public void Delete() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		ScrollPage(driver, "0,700");
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Delete);
		Thread.sleep(2000);
		this.Yes();
	}
	
	
	
	public void Yes() throws InterruptedException {
			
	Thread.sleep(3000);
	JavascriptExecutor js = (JavascriptExecutor)driver;
	js.executeScript("arguments[0].click();", Yes);
	
	}
	
	


	/******************************************
	 * Validation[tab 1]
	 ******************************************/

	@FindBy(xpath = "//label[contains(.,'Name cannot be empty')]")
	WebElement NameValidation;

	@FindBy(xpath = "//label[contains(.,'Description cannot be empty')]")
	WebElement DescriptionValidation;

	@FindBy(id = "txtMinimumDuration-error")
	WebElement MinimumDurationValidation;

	@FindBy(id = "txtNotificationPeriod-error")
	WebElement NotificationPeriodValidation;

	@FindBy(id = "txtQuarantinePeriod-error")
	WebElement QuarantinePeriodValidation;

	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveValidation;

	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement DeleteValidation;

	String[] NameVal ={ "Name cannot be empty"};
	String[] DescriptionVal ={ "Description cannot be empty"};
	String[] MinimumDurationVal ={ "Minimum duration cannot be empty","Please enter a valid number"};
	String[] NotificationPeriodVal ={ "Notification period cannot be empty","Please enter a valid number"};
	String[] QuarantinePeriodVal ={ "Quarantine period cannot be empty/zero","Please enter a valid number"};
	String[] SaveVal ={ "Saved successfully"};
	String[] DeleteVal ={ "Deleted successfully"};
	String[] servervalidation = {"Cannot be deleted, which is used as dependent package by another package/service" };

	public void nameval() throws InterruptedException {
		Thread.sleep(2000);
		String[] setvalidation = NameVal;
		String getValiadtion = NameValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void descriptionval() throws InterruptedException {
		Thread.sleep(2000);
		String[] setvalidation = DescriptionVal;
		String getValiadtion = DescriptionValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void Clearfield_GeneralTab() throws InterruptedException, AWTException {
		this.GeneralTabFieldClear();
		this.validation_page1();
		this.ScrollPage("0,-500");

	}

	public void validation_page1() throws InterruptedException, AWTException {

		this.Save();
		this.nameval();
		this.descriptionval();

	}

	/***************************************
	 * Validation[tab 2]
	 ***************************************/

	public void MinimumDurationVal() throws InterruptedException {
		Thread.sleep(2000);

		String[] setvalidation = MinimumDurationVal;
		String getValiadtion = MinimumDurationValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void NotificationPeriodVal() throws InterruptedException {
		Thread.sleep(2000);

		String[] setvalidation = NotificationPeriodVal;
		String getValiadtion = NotificationPeriodValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void QuarantinePeriodVal() throws InterruptedException {
		Thread.sleep(2000);

		String[] setvalidation = QuarantinePeriodVal;
		String getValiadtion = QuarantinePeriodValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void ContractTabVal() throws InterruptedException
	{
		this.MinimumDurationVal();
		this.QuarantinePeriodVal();
		this.NotificationPeriodVal();
	}
	public void validation_page2(String invalidData) throws InterruptedException, AWTException {

		this.contractRuleFieldClear();
		this.ScrollPage("0,500");
		this.Save();
		this.ContractTabVal();
		this.ScrollPage("0,-500");
		this.MinimumDuration(invalidData);
		this.NotificationPeriod(invalidData);
		this.QuarantinePeriod(invalidData);
		this.ContractTabVal();
		this.ScrollPage("0,-500");

	}

	

	/***********************************************************
	 * Validation[Save]
	 ***********************************************************/

	public void SaveVal() throws InterruptedException {
		Thread.sleep(4000);
		String[] setvalidation = SaveVal;
		String getValiadtion = SaveValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void DeleteVal() throws InterruptedException {
		Thread.sleep(4000);
		String[] setvalidation = DeleteVal;
		String getValiadtion = DeleteValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	/*************************************************
	 * Main Method
	 **************************************************/

	public void Package_Edit_Validation(String listsearchh,String invalidData) throws InterruptedException, AWTException {
		this.ListSearch(listsearchh);
		Thread.sleep(5000);
		this.Clearfield_GeneralTab();
		this.ContractRuleTab();
		this.validation_page2(invalidData);
		this.GeneralTab();
		this.Cancel();
		Thread.sleep(2000);
		Search_close.click();

	}

	public void Package_Edit(String listsearch1, String name, String description, String packageCode,String []ownlevelServiceCheckbox,String []ownlevelService,
			String minimumDuration, String notificationPeriod, String quarantinePeriod, String searchUsageInstancewise,
			String search,String includeremovedValue,String commisionCategory) throws InterruptedException, AWTException {
		this.ListSearch(listsearch1);
		Thread.sleep(2000);
		this.AvailableToDistributor();
		this.AvailableToReseller();
		Thread.sleep(2000);
		this.name(name);
     	this.Description(description);
		this.PackageCode(packageCode);
		this.Country();
		this.PackageType();
		this.CommisionCategory(commisionCategory); 
		this.PrimaryPackage();
		this.Devicerented();
		this.UpgradePriority();
		this.AssignmentType();
		this.KeyAndLamp();
		this.OwnLevelServices(ownlevelServiceCheckbox,ownlevelService);
		this.ScrollPage("0,-700");
		this.ContractRuleTab();
		this.MinimumDuration(minimumDuration);
		this.NotificationPeriod(notificationPeriod);
		this.QuarantinePeriod(quarantinePeriod);
		this.ScrollPage("0,-1000");
		this.UsageInstanceTab();
		this.SearchUsageInstancewise(searchUsageInstancewise, includeremovedValue);
		this.UsagePackagewiseTab();
		this.Search(search,includeremovedValue);
		this.PackageActivityTab();
		this.GeneralTab();
		this.ScrollPage("0,2500");
		this.Save();
		Thread.sleep(6000);
		this.SaveVal();
		Thread.sleep(8000);

	}
	public void Package_Delete(String listsearchh,String []FileTpye) throws InterruptedException, AWTException {
		this.ListSearch(listsearchh);
		this.Delete();
		Thread.sleep(8000);
		this.DeleteVal();
		Thread.sleep(4000);
		this.includeremovedcheck(listsearchh);
		Thread.sleep(2000);
		this.Export(FileTpye);
		Thread.sleep(2000);
		includeremovedcheck.click();
		Thread.sleep(5000);
		
	}

	/***********************************************************
	 * CommonMethod
	 ***************************************************************/

	public void Validation(String GetValiadtion, String Setvalidation) {

		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.err.println("Validation is incorrect: " + GetValiadtion);
			Assert.fail("Test fail for chceking validation : (Expected Result : "+Setvalidation+" Actual Result : "+GetValiadtion);
		}

	}

	public void ScrollPage(String ScrollBy) throws AWTException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + ScrollBy + ")");

	}
		
	
	public void Export(String[] FileTpye) throws InterruptedException {
		Thread.sleep(5000);
		for (int i = 1; i <= FileTpye.length; i++) {
			Download.click();
			String text = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div[1]/div[2]/div/ul/li[" + i + "]/a")).getText();
			if (FileTpye[i-1].equals(text)) {
				driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div[1]/div[2]/div/ul/li[" + i + "]/a")).click();
				System.out.println("File type found and File is expoxted sucessfully (Expected Result : "+FileTpye[i - 1]+" Actual Result : "+text);
				Thread.sleep(4000);
                assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
			}

			else {

				System.err.println("File type not found because : (Expected Result : "+FileTpye[i-1]+" Actual Result : "+text);

			}

		}
	}
	public void includeremovedcheck(String deletedValue) throws InterruptedException {
		Settings.click();
		Thread.sleep(1000);
		includeremovedcheck.click();
		Thread.sleep(4000);
		
		int Counts = driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")).size();
		Thread.sleep(2000);
		for (int i = 1; i <= Counts; i++) {
			String inputvalue=driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr["+i+"]/td[1]")).getText();
			if(inputvalue.equals(deletedValue)) {
				String color = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr["+i+"]/td[1]")).getCssValue("color");

				String[] hexValue = color.replace("rgba(", "").replace(")", "").split(",");

				int hexValue1 = Integer.parseInt(hexValue[0]);
				hexValue[1] = hexValue[1].trim();
				int hexValue2 = Integer.parseInt(hexValue[1]);
				hexValue[2] = hexValue[2].trim();
				int hexValue3 = Integer.parseInt(hexValue[2]);

				String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);

				Assert.assertEquals("#fc4b6c", actualColor);
				System.out.println(deletedValue+" is deleted and also listed in include removed");
				break;
			}
		}
	}
	public void view_data() throws InterruptedException, AWTException
	{
		Thread.sleep(2000);
		this.ScrollPage("0,200");
		// Get all the table row elements from the table
		List<WebElement> allRows= driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div/div/div/div[3]/div/div/div[2]/table/tbody/tr")); 
		System.out.println(" Usage - Package wise/Instance wise tab View list :");
		for(WebElement row : allRows)
		{
			List<WebElement> allColumnsInRow=row.findElements(By.tagName("td"));
		for(WebElement cell : allColumnsInRow)
		{
			System.out.print(cell.getText()+ "|");
		}
		System.out.println();
		}
	}


	public void servervalidation() {
		List<WebElement> dynamicElement = driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p"));
		if (dynamicElement.size() != 0) {
			ArrayList<String> servervalidlist = new ArrayList<String>();
			int count = driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p")).size();
			for (int j = 0; j < servervalidation.length; j++) {
				servervalidlist.add(servervalidation[j]);
			}
			if (count < 1) {
				String getvalidation = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p"))
						.getText();
				if (servervalidlist.contains(getvalidation)) {
					System.out.println("Server validtion Showing correct : " + getvalidation);
				} else {
					System.err.println("Server validation showing incorrect ");
					Assert.fail("Test fail  for checking servervalidation");
				}
			} else {
				for (int i = 1; i <= count; i++) {
					String getvalidation = driver
							.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p[" + i + "]"))
							.getText();
					if (servervalidlist.contains(getvalidation)) {
						System.out.println("Server validtion Showing correct : " + getvalidation);
					} else {
						System.err.println("Server validation showing incorrect ");
						Assert.fail("Test fail  for checking servervalidation");
					}
				}
			}
		} else {
			System.out.println("There no server validation to check");
		}
	}
	public void Multiple_CheckBox_Selection(String[] labels, String Count, String Text,String CheckboxID,String CheckBox,String[] CheckBoxvalue)
			throws InterruptedException {
		String pass = "";
		String fail = "";
		ArrayList<String> ListLabel = new ArrayList<String>();
//
		for (int j = 0; j <= labels.length - 1; j++) {
			ListLabel.add(labels[j]);
		}

		int Counts = driver.findElements(By.xpath(Count)).size();
		//System.out.println(ListLabel.size());
		for (int j = 0; j < ListLabel.size(); j++) {
			//System.out.println(Counts);
			for (int i = 1; i <= Counts; i++) {
				String number = Integer.toString(i);
				String xpath1 = Text.replace("x", number);
				String xpath2 = CheckBox.replace("x", number);
				String xpath3 = CheckboxID.replace("x", number);   
				String text = driver.findElement(By.xpath(xpath1)).getText();
			//	System.out.println(ListLabel.get(j));
			//	System.out.println(text);
				
				if (ListLabel.get(j).equals(text)) {
					
					Thread.sleep(3000);
					WebElement Xpath2= driver.findElement(By.xpath(xpath2));
					String checkBoxvalue = CheckBoxvalue[j];
					String Valueofcheckbox = driver.findElement(By.xpath(xpath3)).getAttribute("checked");
										
					if (checkBoxvalue.toUpperCase().equals("YES")) {
						if (Valueofcheckbox == null) {
																				
							Xpath2.click();
							Thread.sleep(2000);
							String checkboxchecked = driver.findElement(By.xpath(xpath3)).getAttribute("checked");
							if (checkboxchecked==null) {
								System.err.println(	text + " CheckBox not checked " + "(expect : Checked, Result : Not-Checked)");
								Assert.fail("Test fail for " + text + " CheckBox check"+ "(expect : Checked, Result : Not-Checked)");
							} else {
								System.out.println(text + " CheckBox is : checked");	
								
							}
						} else {
							System.out.println(text + " CheckBox is Already checked");
						}
					} else if (checkBoxvalue.toUpperCase().equals("NO")) {
						if (Valueofcheckbox == null) {
							System.out.println(text + " CheckBox is Already Unchecked");
						} else {
							Xpath2.click();
							Thread.sleep(2000);
							String checkboxUNchecked = driver.findElement(By.xpath(xpath3)).getAttribute("checked");
							if (checkboxUNchecked == null) {
								System.out.println(text + " CheckBox is : UNchecked");
							} else {
								System.err.println(text + " CheckBox not Unchecked" + "(expect : UnChecked, Result : Checked)");
								Assert.fail("Test fail for " + text + " CheckBox  Uncheck"+ "(expect : UnChecked, Result : Checked)");
							}
						}
					} else {
						if (Valueofcheckbox == null) {
							System.out.println("There is no change in " + text + " CheckBox is unchecked : Defult");
						} else {
							System.out.println("There is no change in " + text + " CheckBox is checked : Defult");
						}
					}
				
									
				}
					

		}
		}}}
	
	


