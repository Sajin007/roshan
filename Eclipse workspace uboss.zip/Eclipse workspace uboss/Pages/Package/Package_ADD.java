/*-- =============================================
-- Author		: Oommen K Raju
-- Created Date : 03-04-2020
-- Description	: Package Creation PO level
-- Modified by	: Oommen K Raju
-- Modified Date: 25-03-2021
-- Project		: UBOSS-5-0-5
-- =============================================*/

package Package;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.drd.uboss5.keywords.keywords;
import com.sun.org.apache.xerces.internal.impl.xpath.XPath;

public class Package_ADD extends keywords {
	WebDriver driver;

	@FindBy(xpath= "//a[@id='btn_add']")
	WebElement Add;
	
	@FindBy(id = "sel_avail_disti")
	WebElement AvailableToDistributor;

	@FindBy(id = "sel_avail_reseller")
	WebElement AvailableToReseller;

	@FindBy(id = "txtName")
	WebElement Name;

	@FindBy(id = "txtDecription")
	WebElement Description;

	@FindBy(id = "txtPackageCode")
	WebElement PackageCode;

	@FindBy(id = "sel_country")
	WebElement Country;

	@FindBy(id = "sel_packagetype")
	WebElement PackageType;

	@FindBy(id = "sel_assignmenttype")
	WebElement AssignmentType;

	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[9]/div/label/span")
	WebElement IsPrimary;

	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[9]/label")
	WebElement IsPrimaryLabel;

	@FindBy(id = "sel_keylamp")
	WebElement KeyLampCount;

	@FindBy(id = "sel_dependprimarypackage")
	WebElement DependentPackage;

	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[12]/div/label/span")
	WebElement CanAlterPackage;

	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div/label/span")
	WebElement CanBeAssigned;

	@FindBy(xpath = "//*[@id=\"divmultipleallowed\"]/div/label/span")
	WebElement MultipleInstancesAllowed;

	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/table/thead/tr/th[1]/label/span")
	WebElement NumberCategory_ALL;

	@FindBy(id = "lstNumberCategory_InstanceCount_41")
	WebElement NumberCategory_Instance;

	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[17]/table/tbody/tr[51]/td[1]/label/span")
	WebElement BWCallWaiting;

	@FindBy(id = "btn_pkg_next")
	WebElement Next1;

	@FindBy(id = "btnnext")
	WebElement NextButton;

	@FindBy(xpath = "//a[@id='btn_pkg_cancel']")
	WebElement CancelButton;

	/**************************************
	 * page 2
	 ********************************************/

	@FindBy(xpath= " //input[@id='txtFreeDays_11373'] | //input[@id='txtFreeDays_11391'] | //input[@id='txtFreeDays_11408'] | //input[@id='txtFreeDays_11415'] |//input[@id='txtFreeDays_12379'] |//input[@id='txtFreeDays_12440']")
	WebElement FreeDays;
		
	/********************************
	 * page 2[prorata & single rate]
	 *************************************/
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[2]/div/div[1]/div/div[1]/div/div/label[2]/span")
	WebElement ThresholdType_Prorata;

	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[2]/div/div[1]/div/div[1]/div/div/label[3]/span")
	WebElement ThresholdType_SingleRate;

	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[2]/div/div[1]/div/div[1]/div/div/label[1]/span")
	WebElement NoneCheckbox;
	
	
	@FindBy(xpath = "//button[contains(.,'Add New')]")
	WebElement AddNewButton;

	
	@FindBy(xpath= "//input[@id='txtQuantityFrom_11373'] | //input[@id='txtQuantityFrom_11391'] | //input[@id='txtQuantityFrom_11408'] | //input[@id='txtQuantityFrom_11415'] | //input[@id='txtQuantityFrom_12379']| //input[@id='txtQuantityFrom_12440']")
	WebElement QuantityFrom;
	
	@FindBy(xpath= "//input[@id='txtQuantityTo_11373'] | //input[@id='txtQuantityTo_11391'] | //input[@id='txtQuantityTo_11408'] | //input[@id='txtQuantityTo_11415']| //input[@id='txtQuantityTo_12379'] | //input[@id='txtQuantityTo_12440']")
	WebElement QuantityTo;
		
	@FindBy(xpath= "//input[@id='txtSlabRecurringCharge_11373'] | //input[@id='txtSlabRecurringCharge_11391'] | //input[@id='txtSlabRecurringCharge_11408'] | //input[@id='txtSlabRecurringCharge_11415'] | //input[@id='txtSlabRecurringCharge_12379'] | //input[@id='txtSlabRecurringCharge_12440']")
	WebElement Recurringcharge;
	
	
	@FindBy(xpath = "//button[contains(.,'Save')]")
	WebElement SlabDetails_Save;

	@FindBy(id = "btn_cancel")
	WebElement SlabDetails_Cancel;

	@FindBy(id = "btnnext")
	WebElement Save;

	@FindBy(id = "btncancel")
	WebElement Cancel;
	
	
	@FindBy(xpath="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div/label/span")
	WebElement NoPackage;

	/*********************************
	 * page 2[rental]
	 *************************************/
	
	@FindBy(xpath= "//input[@id='txtSetupCharge_11373'] | //input[@id='txtSetupCharge_11391']  | //input[@id='txtSetupCharge_11408'] | //input[@id='txtSetupCharge_11415'] | //input[@id='txtSetupCharge_12379'] | //input[@id='txtSetupCharge_12440']")
	WebElement SetupCharge;
	
	@FindBy(xpath= "//input[@id='txtRecurringCharge_11373'] | //input[@id='txtRecurringCharge_11391'] | //input[@id='txtRecurringCharge_11408'] | //input[@id='txtRecurringCharge_11415'] | //input[@id='txtRecurringCharge_12379'] | //input[@id='txtRecurringCharge_12440']")
	WebElement RecurringCharge;
	
	@FindBy(xpath= "//input[@id='txtCeaseCharge_11373'] | //input[@id='txtCeaseCharge_11391'] | //input[@id='txtCeaseCharge_11408'] | //input[@id='txtCeaseCharge_11415']| //input[@id='txtCeaseCharge_12379'] | //input[@id='txtCeaseCharge_12440']")
	WebElement CeaseCharge;
	
	@FindBy(xpath= "//input[@id='txtRebateValue_11373'] | //input[@id='txtRebateValue_11391']| //input[@id='txtRebateValue_11408'] | //input[@id='txtRebateValue_11415'] | //input[@id='txtRebateValue_12379'] | //input[@id='txtRebateValue_12440'] ")
	WebElement RebateValue;
	
	@FindBy(xpath= "//input[@id='txtSecondaryRebateValue_11373'] | //input[@id='txtSecondaryRebateValue_11391'] | //input[@id='txtSecondaryRebateValue_11408'] | //input[@id='txtSecondaryRebateValue_11415'] | //input[@id='txtSecondaryRebateValue_12379'] | //input[@id='txtSecondaryRebateValue_12440']")
	WebElement SecondaryRebateValue;
	
	@FindBy(xpath= "//select[@id='sel_SetupChargeNominalCode_11373'] | //select[@id='sel_SetupChargeNominalCode_11391'] | //select[@id='sel_SetupChargeNominalCode_11408'] | //select[@id='sel_SetupChargeNominalCode_11415'] | //select[@id='sel_SetupChargeNominalCode_12379'] | //select[@id='sel_SetupChargeNominalCode_12440']")
	WebElement SetupChargeNominalCode;
		
	@FindBy(xpath= "//select[@id='sel_RecurringChargeNominalCode_11373'] | //select[@id='sel_RecurringChargeNominalCode_11391'] | //select[@id='sel_RecurringChargeNominalCode_11408'] | //select[@id='sel_RecurringChargeNominalCode_11415'] | //select[@id='sel_RecurringChargeNominalCode_12379'] | //select[@id='sel_RecurringChargeNominalCode_12440']")
	WebElement RecurringChargeNominalCode;
		
	@FindBy(xpath= "//select[@id='sel_CeaseChargeNominalCode_11373'] | //select[@id='sel_CeaseChargeNominalCode_11391'] | //select[@id='sel_CeaseChargeNominalCode_11408'] | //select[@id='sel_CeaseChargeNominalCode_11415'] | //select[@id='sel_CeaseChargeNominalCode_12379'] | //select[@id='sel_CeaseChargeNominalCode_12440']")
	WebElement CeaseChargeNominalCode;
	
	@FindBy(xpath= "//input[@id='txtThirdPartySetupCost_11373'] | //input[@id='txtThirdPartySetupCost_11391'] | //input[@id='txtThirdPartySetupCost_11408'] |  //input[@id='txtThirdPartySetupCost_11415'] |  //input[@id='txtThirdPartySetupCost_12379'] |  //input[@id='txtThirdPartySetupCost_12440'] ")
	WebElement SetupCostBuy;
	
	@FindBy(xpath= "//input[@id='txtThirdPartyRecurringCost_11373'] | //input[@id='txtThirdPartyRecurringCost_11391'] | //input[@id='txtThirdPartyRecurringCost_11408'] | //input[@id='txtThirdPartyRecurringCost_11415'] | //input[@id='txtThirdPartyRecurringCost_12379'] | //input[@id='txtThirdPartyRecurringCost_12440'] ")
	WebElement RecurringCostBuy;
	
	@FindBy(xpath= "//input[@id='txtCeaseCost_11373'] | //input[@id='txtCeaseCost_11391'] | //input[@id='txtCeaseCost_11408'] | //input[@id='txtCeaseCost_11415'] | //input[@id='txtCeaseCost_12379'] | //input[@id='txtCeaseCost_12440']")
	WebElement CeaseCostBuy;
	
	/****************************
	 * page 2[Eternity License Charges]
	 ******************************/
	@FindBy(xpath= "//input[@id='txtLicenseSetupCharge_11373'] | //input[@id='txtLicenseSetupCharge_11391'] | //input[@id='txtLicenseSetupCharge_11408'] |  //input[@id='txtLicenseSetupCharge_11415'] |  //input[@id='txtLicenseSetupCharge_12379'] |  //input[@id='txtLicenseSetupCharge_12440']")
	WebElement LicensePurchasePrice;
	
	@FindBy(xpath= "//input[@id='txtLicenseAssignedCharge_11373'] | //input[@id='txtLicenseAssignedCharge_11391'] | //input[@id='txtLicenseAssignedCharge_11408'] | //input[@id='txtLicenseAssignedCharge_11415'] | //input[@id='txtLicenseAssignedCharge_12379'] | //input[@id='txtLicenseAssignedCharge_12440']")
	WebElement MonthlyFeeAssigned;
	
	@FindBy(xpath= "//input[@id='txtLicenseUnAssignedCharge_11373'] | //input[@id='txtLicenseUnAssignedCharge_11391'] | //input[@id='txtLicenseUnAssignedCharge_11408'] |  //input[@id='txtLicenseUnAssignedCharge_11415'] |  //input[@id='txtLicenseUnAssignedCharge_12379'] |  //input[@id='txtLicenseUnAssignedCharge_12440']")
	WebElement MonthlyFeeUnassigned;
		
	
	@FindBy(xpath= "//select[@id='sel_LicenseSetupNominal_11373'] | //select[@id='sel_LicenseSetupNominal_11391'] | //select[@id='sel_LicenseSetupNominal_11408'] | //select[@id='sel_LicenseSetupNominal_11415'] | //select[@id='sel_LicenseSetupNominal_12379'] | //select[@id='sel_LicenseSetupNominal_12440']")
	WebElement LicensePurchaseNominal;
	
	@FindBy(xpath= "//select[@id='sel_LicenseAssignedNominal_11373'] | //select[@id='sel_LicenseAssignedNominal_11391']  | //select[@id='sel_LicenseAssignedNominal_11408'] | //select[@id='sel_LicenseAssignedNominal_11415']| //select[@id='sel_LicenseAssignedNominal_12379'] | //select[@id='sel_LicenseAssignedNominal_12440']")
	WebElement MonthlyFeeAssignedNominal;
	
	@FindBy(xpath= "//select[@id='sel_LicenseUnAssignedNominal_11373'] | //select[@id='sel_LicenseUnAssignedNominal_11391'] | //select[@id='sel_LicenseUnAssignedNominal_11408'] |  //select[@id='sel_LicenseUnAssignedNominal_11415']|  //select[@id='sel_LicenseUnAssignedNominal_12379'] |  //select[@id='sel_LicenseUnAssignedNominal_12440']")
	WebElement MonthlyFeeUnassignedNominal;
	
	@FindBy(xpath= "//input[@id='txtLicenseSetupCost_11373'] | //input[@id='txtLicenseSetupCost_11391'] | //input[@id='txtLicenseSetupCost_11408'] | //input[@id='txtLicenseSetupCost_11415'] | //input[@id='txtLicenseSetupCost_12379'] | //input[@id='txtLicenseSetupCost_12440']") 
	WebElement LicenseSetupCost;
	
	@FindBy(xpath= "//input[@id='txtLicenseAssignedCost_11373'] | //input[@id='txtLicenseAssignedCost_11391']| //input[@id='txtLicenseAssignedCost_11408'] | //input[@id='txtLicenseAssignedCost_11415'] | //input[@id='txtLicenseAssignedCost_12379'] | //input[@id='txtLicenseAssignedCost_12440']")
	WebElement LicenseAssignedCost;
	
	@FindBy(xpath= "//input[@id='txtLicenseUnassignedCost_11373'] | //input[@id='txtLicenseUnassignedCost_11391'] | //input[@id='txtLicenseUnassignedCost_11408'] | //input[@id='txtLicenseUnassignedCost_11415'] | //input[@id='txtLicenseUnassignedCost_12379'] | //input[@id='txtLicenseUnassignedCost_12440']")
	WebElement LicenseUnassignedCost;

	@FindBy(xpath = "//span[@class='checkmark'])[125] | //span[@class='checkmark'])[21]")
	WebElement ApplyallSDRTariff;

	@FindBy(id = "btnprevious")
	WebElement PreviousButton;

	/**********************************
	 * page 3[Contract Rule]
	 **************************************/

	@FindBy(id = "txtMinimumDuration")
	WebElement MinimumDuration;

	@FindBy(id = "txtNotificationPeriod")
	WebElement NotificationPeriod;

	@FindBy(id = "txtQuarantinePeriod")
	WebElement QuarantinePeriod;

	@FindBy(xpath = "//span[@class='checkmark'])[22] | //span[@class='checkmark'])[126]")
	WebElement NotificationPeriodCheckbox;

	@FindBy(xpath = "//a[contains(.,'FINISH')]")
	WebElement Finish;

	@FindBy(xpath = "//p[contains(.,'Dependent package assignment type is not the same as the current assignment type.Either both must be `Hosted` or `SIP` or `Both` or combination of `Hosted/SIP` & `Both`')]")
	WebElement Check;

	/**********************************************************************************/
	// Distributor level Webelements
	/**********************************************************************************/

	/*******************************************
	 * page 1
	 ********************************************/

	@FindBy(id = "availableto")
	WebElement AvailableTo_Distributor;

	@FindBy(id ="sel_primarypackage")
	WebElement PrimaryPackage;
	
	@FindBy(id = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[10]/div/label/span")
	WebElement CanBeAssigned_Distributor;

	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[9]/div/label/span")
	WebElement MultipleInstancesAllowed_Distributor;;

	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div/form/div[2]/section[2]/div/div[1]/div/div[1]/div/div/label[2]/span")
	WebElement ThresholdType_Prorata_Distributor;

	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div/form/div[2]/section[2]/div/div[1]/div/div[1]/div/div/label[3]/span")
	WebElement ThresholdType_SingleRate_Distributor;

	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div/form/div[2]/section[2]/div/div[1]/div/div[1]/div/div/label[1]/span")
	WebElement NoneCheckbox_Distributor;
	
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[2]/div/div[4]/div[10]/div/label/span")
	WebElement ApplyallSDRTariff_Distributor;;
	
	
	/**********************************************************************************/
	// Reseller level Webelements
	/**********************************************************************************/
	
	@FindBy(id="sel_commisioncategory")
	WebElement CommisonCategory_Reseller;
	
	@FindBy(id = "sel_fill_device")
	WebElement DeviceRented_Reseller;

	@FindBy(id = "sel_upgrade_priority")
	WebElement Updatepriority_Reseller;
	
	
	@FindBy(id = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[12]/div/label/span")
	WebElement CanBeAssigned_Reseller;


	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[11]/div/label/span")
	WebElement MultipleInstancesAllowed_Reseller;

	/**********************************************************************************/
	// Business level Webelements
	/**********************************************************************************/

	@FindBy(xpath = "(//span[(@class='checkmark')])[2] | (//span[(@class='checkmark')])[3]")
	WebElement CanBeAssigned_Business;
	
	/************************** Page 1[METHODS] ***********************************/

	public Package_ADD(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);
	}

	public void ClickonAdd() throws InterruptedException {
		Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Add);
		
	}


	public void AvailableToDistributor(String availableToDistributor) throws InterruptedException {

		try {
			dropdown(AvailableToDistributor, availableToDistributor, "Available To Distributor");
		}

		catch (org.openqa.selenium.NoSuchElementException e) {

			try {

				dropdown(AvailableTo_Distributor, availableToDistributor, "Available To");

			}

			catch (Exception e2) {

			}
		}
	}

	public void AvailableToReseller(String availableToReseller) throws InterruptedException {
		try {
			dropdown(AvailableToReseller, availableToReseller, "Available To Reseller*");
		} catch (org.openqa.selenium.NoSuchElementException e) {
			
		}

	}

	public void name(String name) throws InterruptedException {
		Inputdata(Name, name, "Name");
	}

	public void Description(String description) throws InterruptedException {
		Inputdata(Description, description, "Description");

	}

	public void PackageCode(String packageCode) throws InterruptedException {
		Inputdata(PackageCode, packageCode, "Package Code");

	}

	public void Country(String country) throws InterruptedException {
		try {
			
			if(Country.isDisplayed())
			{
			dropdown(Country, country, "country");
			}
		} catch (org.openqa.selenium.NoSuchElementException e) {
			
		}
		
	}

	public void PackageType(String packageType) throws InterruptedException {
		dropdown(PackageType, packageType, "Package Type");
	}

	public void AssignmentType(String assignmentType) throws InterruptedException {
		try {
			
			dropdown(AssignmentType, assignmentType, "Assignment Type");
			

		} catch (org.openqa.selenium.NoSuchElementException e) {
			
		}

	}

	public void IsPrimary(String isPrimaryCheckboxValue) throws InterruptedException {

		Select select = new Select(PackageType);
		WebElement option = select.getFirstSelectedOption();
		String defaultvaluePackageType = option.getText();

		try {
			Select select1 = new Select(AssignmentType);
			WebElement option1 = select1.getFirstSelectedOption();
			String defaultvalueAssignementType = option1.getText();

			if (defaultvaluePackageType.equals("User Package") && defaultvalueAssignementType != "Both") {
				Thread.sleep(2000);
				Checkbox(driver, "chk_isprimary", IsPrimary, isPrimaryCheckboxValue, "Is Primary");
			} else if (IsPrimary.isDisplayed()) {
				System.err.println("Error occured because package type selected is " + defaultvaluePackageType+ " and assignment type selected is " + defaultvalueAssignementType+ " Is primary Checkbox is  present Value of Is primary checkbox:- " + IsPrimary.isDisplayed());
				Assert.fail("Test fail ,Error occured because package type selected is " + defaultvaluePackageType+ " and assignment type selected is " + defaultvalueAssignementType+ " Is primary Checkbox is  present Value of Is primary checkbox:- " + IsPrimary.isDisplayed());

			} else {
				System.out.println("Since the package type selected is " + defaultvaluePackageType+ " and assignment type selected is " + defaultvalueAssignementType+ " Is primary Checkbox is not present, Value of Is primary checkbox:- "+ IsPrimary.isDisplayed());
			}
		} catch (org.openqa.selenium.NoSuchElementException e) {

			
		}
		
	}
	
		
	public void PrimaryPackage(String primaryPackage) throws InterruptedException {
		Select select = new Select(PackageType);
		WebElement option = select.getFirstSelectedOption();
		String defaultvaluePackageType = option.getText();
		try {
			
		if (defaultvaluePackageType.equals("User Package")) {
			Thread.sleep(2000);
			Select select1 = new Select(PrimaryPackage);
			select1.selectByVisibleText(primaryPackage);
			System.out.println(defaultvaluePackageType+ " selected and primary package :- "+primaryPackage+ "selected");

		}

		else if (defaultvaluePackageType.equals("Site Package")|| defaultvaluePackageType.equals("Business Package")|| defaultvaluePackageType.equals("BusinessSite Package")) {
			System.out.println(defaultvaluePackageType+ " selected : Since it is a group package,PrimaryPackage Dropdown is not present ");
		} else {
			System.err.println("There is some issue with Primary package dropdown");
			Assert.fail("Test fail for choosing Primary package dropdown");
		}

	} catch (org.openqa.selenium.NoSuchElementException e1) {
		
	}

}
	public void KeyLampCount(String keyLampCount) throws InterruptedException {
		try {

			String ValueofIsPrimaryCheckbox = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[9]/div/label/input")).getAttribute("checked");
			Select select = new Select(PackageType);
			WebElement option = select.getFirstSelectedOption();
			String defaultvaluePackageType = option.getText();

			Select select1 = new Select(AssignmentType);
			WebElement option1 = select1.getFirstSelectedOption();
			String defaultvalueAssignementType = option1.getText();

			if (defaultvaluePackageType.equals("User Package") && ValueofIsPrimaryCheckbox != null&& defaultvalueAssignementType != "SIPOnly") {
				dropdown(KeyLampCount, keyLampCount, "Key & Lamp Count");
			}

			else if (KeyLampCount.isDisplayed()) {
				System.err.println("Error occured because package type selected is " + defaultvaluePackageType+ " and assignment type selected is " + defaultvalueAssignementType+ " Key & Lamp Count dropdown is  present, Value of Key & Lamp Count dropdown:- "+ KeyLampCount.isDisplayed());
				Assert.fail("Test fail ,Error occured because package type selected is " + defaultvaluePackageType+ " and assignment type selected is " + defaultvalueAssignementType+ " Key & Lamp Count dropdown  is  present Value of Key & Lamp Count dropdown:- "+ KeyLampCount.isDisplayed());

			} else {
				System.out.println("Pacakge type selected is :" + defaultvaluePackageType+ " and assignment type selected is " + defaultvalueAssignementType+ "-Key & Lamp Count field not present,Value of Key & Lamp Count dropdown:- "+ KeyLampCount.isDisplayed());
			}
		}

		catch (org.openqa.selenium.NoSuchElementException e) {
			
		}
	}

	public void DependentPackage(String dependentPackage) throws InterruptedException {

		try {

			String ValueofIsPrimaryCheckbox = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[9]/div/label/input")).getAttribute("checked");
			Select select = new Select(PackageType);
			WebElement option = select.getFirstSelectedOption();
			String defaultvaluePackageType = option.getText();

			Select select1 = new Select(AssignmentType);
			WebElement option1 = select1.getFirstSelectedOption();
			String defaultvalueAssignementType = option1.getText();
			if ((defaultvaluePackageType.equals("User Package") && defaultvalueAssignementType.equals("HostedOnly")&& ValueofIsPrimaryCheckbox == null)|| (defaultvaluePackageType.equals("User Package") && defaultvalueAssignementType.equals("SIPOnly")&& ValueofIsPrimaryCheckbox == null || defaultvalueAssignementType.equals("Both"))) {
			
					dropdown(DependentPackage, dependentPackage, "dependent Package");
				
				
			}

			else {
				if (DependentPackage.isDisplayed()) {
					System.err.println("Error occured because package type selected is " + defaultvaluePackageType+ " and assignment type selected is " + defaultvalueAssignementType+ "Dependent Package dropdown is  present, Value of Key & Lamp Count dropdown:- "+ DependentPackage.isDisplayed());
					Assert.fail("Test fail ,Error occured because package type selected is " + defaultvaluePackageType+ " and assignment type selected is " + defaultvalueAssignementType+ " and Is primary checkbox selected:" + ValueofIsPrimaryCheckbox+ " Dependent dropdown  is  present Value of Dependent dropdown:- "+ DependentPackage.isDisplayed());
				}

				else {
					System.out.println("Since Package type selected is :" + defaultvaluePackageType+ " Assignment type selected is:" + defaultvaluePackageType+ " and Is primary checkbox selected:" + ValueofIsPrimaryCheckbox+ " Dependent Package field is not present Value of Dependent Package:- "+ DependentPackage.isDisplayed());
				}
			}

		} catch (org.openqa.selenium.NoSuchElementException e) {

		}

	}

	public void CanAlterPackage(String canAlterPackageCheckboxValue) throws InterruptedException {
		try {
			Checkbox(driver, "chk_caneditinchild", CanAlterPackage, canAlterPackageCheckboxValue, "Can Alter Package");

		} catch (org.openqa.selenium.NoSuchElementException e) {
			
		}

	}

	public void CanBeAssigned(String canBeAssignedCheckboxValue) throws InterruptedException {
		try {
			Checkbox(driver, "chk_canassign", CanBeAssigned, canBeAssignedCheckboxValue, "Can Be Assigned");
		} catch (org.openqa.selenium.NoSuchElementException e) {

			try {

				Checkbox(driver, "chk_canassign", CanBeAssigned_Distributor, canBeAssignedCheckboxValue,"Can Be Assigned");
			} catch (org.openqa.selenium.NoSuchElementException e1) {

				try {
					Checkbox(driver, "chk_canassign", CanBeAssigned_Business, canBeAssignedCheckboxValue,"Can Be Assigned");
				}
				catch (org.openqa.selenium.NoSuchElementException e2) {
					try {
						
					}  catch (org.openqa.selenium.NoSuchElementException e3) {
						
					}
				}
				
			}
		}

	}
	
	public void MultipleInstancesAllowed(String multipleInstancesAllowedValue) throws InterruptedException {
		Select select = new Select(PackageType);
		WebElement option = select.getFirstSelectedOption();
		String defaultvaluePackageType = option.getText();

		try {

			Select select1 = new Select(AssignmentType);
			WebElement option1 = select1.getFirstSelectedOption();
			String defaultvalueAssignementType = option1.getText();

			String ValueofMultipleInstanceCheckbox = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/div/label/input")).getAttribute("checked");

			if (defaultvaluePackageType != "User Package" && defaultvalueAssignementType.equals("HostedOnly")
					&& ValueofMultipleInstanceCheckbox == null) {

				if (MultipleInstancesAllowed.isDisplayed()) {

					Checkbox(driver, "chk_multipleallowed", MultipleInstancesAllowed, multipleInstancesAllowedValue,"Multiple Instances Allowed");
				}

				else {
					System.out.println("Since package type selected is " + defaultvaluePackageType+ " Multiple Instance Allowed Checkbox is not present Value:- "+ MultipleInstancesAllowed.isDisplayed());
				}
			}

		} catch (org.openqa.selenium.NoSuchElementException e) {
			try {
				if (defaultvaluePackageType != "User Package") {
					if (MultipleInstancesAllowed.isDisplayed()) {
						Thread.sleep(3000);
						Checkbox(driver, "chk_multipleallowed", MultipleInstancesAllowed_Distributor,multipleInstancesAllowedValue, "Multiple Instances Allowed");
					}

					else if (defaultvaluePackageType.equals("User Package")) {
						System.out.println("Pacakge type selected is :" + defaultvaluePackageType+ " Multiple insatnce Allowed checkbox not present ,Value of Mutiple Instance Allowed Checkbox Value :- "+ MultipleInstancesAllowed.isDisplayed());
					}

					else {
						System.err.println("Error occured because Multiple instance Allowed checkbox is displayed when package type selected is "+ defaultvaluePackageType);
						Assert.fail("Test fail ,Error occured because Multiple instance Allowed checkbox is displayed when package type selected is "+ defaultvaluePackageType);

					}
				}

			} catch (org.openqa.selenium.NoSuchElementException e2) {
				try {
					if (defaultvaluePackageType != "User Package") {
						if (MultipleInstancesAllowed.isDisplayed()) {
							Thread.sleep(3000);
							Checkbox(driver, "chk_multipleallowed", MultipleInstancesAllowed_Reseller,multipleInstancesAllowedValue, "Multiple Instances Allowed");
						}

						else if (defaultvaluePackageType.equals("User Package")) {
							System.out.println("Pacakge type selected is :" + defaultvaluePackageType+ " Multiple insatnce Allowed checkbox not present ,Value of Mutiple Instance Allowed Checkbox Value :- "+ MultipleInstancesAllowed.isDisplayed());
						}

						else {
							System.err.println("Error occured because Multiple instance Allowed checkbox is displayed when package type selected is "+ defaultvaluePackageType);
							Assert.fail("Test fail ,Error occured because Multiple instance Allowed checkbox is displayed when package type selected is "+ defaultvaluePackageType);

						}
					}

				} catch (org.openqa.selenium.NoSuchElementException e3) {
					
			}
			}}

	}

	
	public void NumberCategory(String[] CategoryCheckbox,String[] numberCategory)  throws InterruptedException, AWTException {
		Thread.sleep(3000);
				try {
					
					String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[17]/table/tbody/tr";
					String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[17]/table/tbody[x]/tr/td[1]/label";
					String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[17]/table/tbody/tr[x]/td[1]/label/span";
					String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[17]/table/tbody/tr/td[1]/label/input";
							
					String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
					this.numbercatagoryCheckbox(CategoryCheckbox, numberCategory, countxpath, labelxpath,Checkboxid, checkboxpath);
				} catch (org.openqa.selenium.NoSuchElementException e1) {
					try {
												
						String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/table/tbody/tr";
						String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/table/tbody/tr[x]/td[1]";
						String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/table/tbody/tr[x]/td[1]/label/span";
						String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/table/tbody/tr/td[1]/label/span";
						String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
						this.numbercatagoryCheckbox(CategoryCheckbox, numberCategory, countxpath, labelxpath,Checkboxid, checkboxpath);
					} catch (org.openqa.selenium.NoSuchElementException e2) {
						
						try {
								
							String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/table/tbody/tr";
							String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/table/tbody/tr[x]/td[1]/label";
							String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/table/tbody/tr[x]/td[1]/label/span";
							String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/table/tbody/tr[x]/td[1]/label/input";
							String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
							this.numbercatagoryCheckbox(CategoryCheckbox, numberCategory, countxpath, labelxpath,Checkboxid, checkboxpath);
						} catch (org.openqa.selenium.NoSuchElementException e3) {
							
							try {
								String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/table/tbody/tr";
								String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/table/tbody/tr[x]/td[1]/label";
								String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/table/tbody/tr[x]/td[1]/label/span";
								String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/table/tbody/tr[x]/td[1]/label/input";
								String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
								this.numbercatagoryCheckbox(CategoryCheckbox, numberCategory, countxpath, labelxpath,Checkboxid, checkboxpath);
								
							}  catch (org.openqa.selenium.NoSuchElementException e4) {
																
								try {
									String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[18]/table/tbody/tr";
									String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[18]/table/tbody/tr[x]/td[1]/label";
									String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[18]/table/tbody/tr[x]/td[1]/label/span";
									String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[18]/table/tbody/tr[x]/td[1]/label/input";
									String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
									this.numbercatagoryCheckbox(CategoryCheckbox, numberCategory, countxpath, labelxpath,Checkboxid, checkboxpath);
									
								} catch (org.openqa.selenium.NoSuchElementException e5) {
									
								}
								
								
								}
								
							}
							
						}
		
					}
				}
		
	
	
	public void numbercatagoryCheckbox(String[] CategoryCheckbox,String[] numberCategory, String countxpath, String labelxpath,String Checkboxid,String checkboxpath) throws InterruptedException {
		Select select = new Select(PackageType);
		WebElement option = select.getFirstSelectedOption();
		String defaultvaluePackageType = option.getText();
		if (defaultvaluePackageType.equals("User Package")) {
			if (numberCategory.length != 0) 
			{
				int count = driver.findElements(By.xpath(countxpath)).size();
				// System.out.println(count);
					 
				 if (count <=1) {
								
					 String LabelXpath = countxpath + "/td[1]/label/span";
					String Checkboxpath = countxpath + "/td[1]/label";
							 for (int j = 0; j < numberCategory.length; j++) {
							 String categoryCheckbox = CategoryCheckbox[j];
							Thread.sleep(1000);
							String ValueCategoryCheckbox = driver.findElement(By.id("lstNumberCategory_chk_229")).getAttribute("checked");
							if (categoryCheckbox.toUpperCase().equals("YES")) {
								
							if (ValueCategoryCheckbox == null) {
								Thread.sleep(2000);
							 	driver.findElement(By.xpath(Checkboxpath)).click();
							 	
							 	WebElement Category = driver.findElement(By.id("lstNumberCategory_chk_229"));
								String ValueCategory1 = Category.getAttribute("checked");
										 	
								if (ValueCategory1 == null) {
									System.err.println("Number Category Checkbox is not checked for  " + numberCategory[j]);
									Assert.fail("Test fail for Number Category Checkbox to check");
								}
								
								else {
									System.out.println("Number Category Checkbox is checked for  " + numberCategory[j]);
								}
							} else {
								System.out.println("Number Category Checkbox is already checked for  " + numberCategory[j]);
							}
						}
							
							else if (categoryCheckbox.toUpperCase().equals("NO")) {
								if (ValueCategoryCheckbox == null) {
									System.out.println("Number Category Checkbox is already unchecked for  " + numberCategory[j]);
								} else if (ValueCategoryCheckbox != null) {
									driver.findElement(By.xpath(Checkboxpath)).click();
									WebElement Category = driver.findElement(By.id("lstNumberCategory_chk_229"));
									String ValueCategory1 = Category.getAttribute("checked");
									if (ValueCategory1 == null) {
										System.out.println("Number Category Unchecked for " + numberCategory[j]);
									} else {
										System.err.println("Number Category Checkbox is not Unchecked for Category " + numberCategory[j]);
										Assert.fail("Test fail for checking Category Checkbox to uncheck");
									}
								}

							} else {
								System.out.println("There is no Change in Category Checkbox for  " + numberCategory[j]);

							}
								
					}
									
							}
				 
				 else {

									
						this.Multiple_CheckBox_Selection(numberCategory, countxpath, labelxpath, Checkboxid, checkboxpath, CategoryCheckbox);
						
						

					}
							
				 }
				 
			}
		
		else
		{
			System.out.println("Since Package type selected is: "+defaultvaluePackageType + " Number category checkbox is not present");
		}
	}
		

	public void Service(String[] ServiceCheckbox,String[] Service,String secondaryPackageCheckboxValue) throws InterruptedException, AWTException {
        
		Thread.sleep(3000);
		try {
			
			String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[18]/table/tbody/tr";
			String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[18]/table/tbody/tr[x]/td[1]/span";
			String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[18]/table/tbody/tr[x]/td[1]/label/span";
			String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[18]/table/tbody/tr[x]/td[1]/label/input";
			String vlaue =driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
		
			this.ServiceName(ServiceCheckbox, Service, secondaryPackageCheckboxValue, countxpath, labelxpath, Checkboxid, checkboxpath);
		} catch (org.openqa.selenium.NoSuchElementException e1) {
			try {
				
				String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[2]/div/table/tbody/tr";
				String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[2]/div/table/tbody/tr[x]/td[1]";
				String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[2]/div/table/tbody/tr[x]/td[1]/label/span";
				String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[2]/div/table/tbody/tr[x]/td[1]/label/input";
				String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
				this.ServiceName(ServiceCheckbox, Service, secondaryPackageCheckboxValue, countxpath, labelxpath, Checkboxid, checkboxpath);
			
			} catch (org.openqa.selenium.NoSuchElementException e2) {
				
				try {
					
					String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[2]/div/table/tbody/tr";
					String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[2]/div/table/tbody/tr[x]/td[1]";
					String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[2]/div/table/tbody/tr[x]/td[1]/label/span";
					String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[2]/div/table/tbody/tr[x]/td[1]/label/input";
					String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
					this.ServiceName(ServiceCheckbox, Service, secondaryPackageCheckboxValue, countxpath, labelxpath, Checkboxid, checkboxpath);
				
					
					
				} catch (org.openqa.selenium.NoSuchElementException e3) {
					
					try {
						
						String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[2]/div/table/tbody/tr";
						String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[2]/div/table/tbody/tr[x]/td[1]";
						String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[2]/div/table/tbody/tr[x]/td[1]/label/span";
						String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[2]/div/table/tbody/tr[x]/td[1]/label/input";
						String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
						this.ServiceName(ServiceCheckbox, Service, secondaryPackageCheckboxValue, countxpath, labelxpath, Checkboxid, checkboxpath);
						
					} catch (org.openqa.selenium.NoSuchElementException e4) {
						
						
						try {
							
							String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[19]/table/tbody/tr";
							String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[19]/table/tbody/tr[x]/td[1]";
							String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[19]/table/tbody/tr[x]/td[1]/label/span";
							String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[19]/table/tbody/tr[x]/td[1]/label/input";
							String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
							this.ServiceName(ServiceCheckbox, Service, secondaryPackageCheckboxValue, countxpath, labelxpath, Checkboxid, checkboxpath);
							
						} catch (org.openqa.selenium.NoSuchElementException e5) {
							
						}
						
					}
					
				}
			}
		}
	}
	
	
	public void ServiceName(String[] ServiceCheckbox,String[] Service,String secondaryPackageCheckboxValue, String countxpath, String labelxpath,String Checkboxid,String checkboxpath) throws InterruptedException, AWTException {
		Select select = new Select(PackageType);
		WebElement option = select.getFirstSelectedOption();
		String defaultvaluePackageType = option.getText();
		String SecondaryPackageCheckboxValue = secondaryPackageCheckboxValue.toUpperCase();	
		
		 if (defaultvaluePackageType.equals("User Package")  ||defaultvaluePackageType.equals("Site Package") && SecondaryPackageCheckboxValue.equals("YES")|| defaultvaluePackageType.equals("Business Package") && SecondaryPackageCheckboxValue.equals("YES") || defaultvaluePackageType.equals("BusinessSite Package") && SecondaryPackageCheckboxValue.equals("YES")) {
		
		{
			if (Service.length != 0) 
			{
				ScrollPage(driver, "0,40");
				int count = driver.findElements(By.xpath(countxpath)).size();
			// System.out.println(count);
					 
				 if (count <=0) {
										
					 String LabelXpath = countxpath + "/td[1]/label/span";
					String Checkboxpath = countxpath + "/td[1]/label";
									 
						 for (int j = 0; j < Service.length; j++) {
							 String serviceCheckbox = ServiceCheckbox[j];
							Thread.sleep(1000);
							String ValueServiceCheckbox = driver.findElement(By.xpath("Checkboxpath")).getAttribute("checked");
							if (serviceCheckbox.toUpperCase().equals("YES")) {
									
							if (ValueServiceCheckbox == null) {
								Thread.sleep(2000);
							 	driver.findElement(By.xpath(Checkboxpath)).click();
							 	
							 	WebElement Service1 = driver.findElement(By.xpath("Checkboxpath"));
								String ValueService1 = Service1.getAttribute("checked");
										 	
								if (ValueService1 == null) {
									System.err.println("Service Checkbox is not checked for  " + Service[j]);
									Assert.fail("Test fail for Service Checkbox to check");
								}
								
								else {
									System.out.println("Service Checkbox is checked for  " + Service[j]);
								}
							} else {
								System.out.println("Service Checkbox is already checked for  " + Service[j]);
							}
						}
							
							else if (serviceCheckbox.toUpperCase().equals("NO")) {
								if (ValueServiceCheckbox == null) {
									System.out.println("Service Checkbox is already unchecked for  " + Service[j]);
								} else if (ValueServiceCheckbox != null) {
									driver.findElement(By.xpath(Checkboxpath)).click();
									WebElement Category = driver.findElement(By.xpath("Checkboxpath"));
									String ValueServiceCheckbox1 = Category.getAttribute("checked");
									if (ValueServiceCheckbox1 == null) {
										System.out.println("Service checkbox is Unchecked for " + Service[j]);
									} else {
										System.err.println("Service checkbox is not Unchecked for service " + Service[j]);
										Assert.fail("Test fail for checking Service Checkbox to uncheck");
									}
								}

							} else {
								System.out.println("There is no Change in Service Checkbox for  " + Service[j]);

						}
								
					}		
							}
			
				 else {
						
						this.Multiple_CheckBox_Selection(Service, countxpath, labelxpath, Checkboxid,checkboxpath,ServiceCheckbox);
					 }
					 
					}
							
				 }
				 
			}
		
		 }
		 

	public void ParentPackage(String[] ParentPackageCheckbox,String[] ParentPackage) throws InterruptedException, AWTException {
                  
		try {
			
			String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[1]/div[1]/table/tbody/tr";
			String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[1]/div[1]/table/tbody/tr[x]/td/span";
			String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[1]/div[1]/table/tbody/tr[x]/td/label/span";
			String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[1]/div[1]/table/tbody/tr[x]/td/label/input";
			String vlaue =driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
			this.parentPackageName(ParentPackageCheckbox, ParentPackage, countxpath, labelxpath, Checkboxid, checkboxpath);
		} catch (org.openqa.selenium.NoSuchElementException e1) {
			try {
		
				String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/div[1]/div[1]/table/tbody/tr";
				String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/div[1]/div[1]/table/tbody/tr[x]/td/span";
				String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/div[1]/div[1]/table/tbody/tr[x]/td/label/span";
				String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/div[1]/div[1]/table/tbody/tr[x]/td/label/input";
				String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
				this.parentPackageName(ParentPackageCheckbox, ParentPackage, countxpath, labelxpath, Checkboxid, checkboxpath);
			
			} catch (org.openqa.selenium.NoSuchElementException e2) {
				
				try {
					
					String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[1]/div[1]/table/tbody/tr";
					String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[1]/div[1]/table/tbody/tr[x]/td/span";
					String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[1]/div[1]/table/tbody/tr[x]/td/label/span";
					String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[1]/div[1]/table/tbody/tr[x]/td/label/input";
					String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
					this.parentPackageName(ParentPackageCheckbox, ParentPackage, countxpath, labelxpath, Checkboxid, checkboxpath);
				
				} catch (org.openqa.selenium.NoSuchElementException e3) {
					
					try {

						String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[1]/div[1]/table/tbody/tr";
						String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[1]/div[1]/table/tbody/tr[x]/td/span";
						String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[1]/div[1]/table/tbody/tr[x]/td/label/span";
						String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[1]/div[1]/table/tbody/tr[x]/td/label/input";
						String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
						this.parentPackageName(ParentPackageCheckbox, ParentPackage, countxpath, labelxpath, Checkboxid, checkboxpath);
					
						
					} catch (org.openqa.selenium.NoSuchElementException e4) {
						
					}
				}
			}
		}
	}
	
	
	

	public void parentPackageName(String[] ParentPackageCheckbox,String[] ParentPackage, String countxpath, String labelxpath,String Checkboxid,String checkboxpath) throws InterruptedException {
		Select select = new Select(PackageType);
		WebElement option = select.getFirstSelectedOption();
		String defaultvaluePackageType = option.getText();
		
		
		if (defaultvaluePackageType.equals("User Package") || defaultvaluePackageType.equals("Site Package") || defaultvaluePackageType.equals("Business Package") || defaultvaluePackageType.equals("BusinessSite Package")) {
		
		{
			if (ParentPackage.length != 0) 
			{
				int count = driver.findElements(By.xpath(countxpath)).size();
			//	 System.out.println(count);
					 
				 if (count <=0) {
											
					 String LabelXpath = countxpath + "/td[1]/label/span";
					String Checkboxpath = countxpath + "/td[1]/label";
									 
						 for (int j = 0; j < ParentPackage.length; j++) {
							 String parentPackageCheckbox = ParentPackageCheckbox[j];
							Thread.sleep(1000);
							String ValueServiceCheckbox = driver.findElement(By.xpath("Checkboxpath")).getAttribute("checked");
							if (parentPackageCheckbox.toUpperCase().equals("YES")) {
									
							if (ValueServiceCheckbox == null) {
								Thread.sleep(2000);
							 	driver.findElement(By.xpath(Checkboxpath)).click();
							 	
							 	WebElement Service1 = driver.findElement(By.xpath("Checkboxpath"));
								String ValueService1 = Service1.getAttribute("checked");
										 	
								if (ValueService1 == null) {
									System.err.println("Service Checkbox is not checked for  " + ParentPackage[j]);
									Assert.fail("Test fail for Service Checkbox to check");
								}
								
								else {
									System.out.println("Service Checkbox is checked for  " + ParentPackage[j]);
								}
							} else {
								System.out.println("Service Checkbox is already checked for  " + ParentPackage[j]);
							}
						}
							
							else if (parentPackageCheckbox.toUpperCase().equals("NO")) {
								if (ValueServiceCheckbox == null) {
									System.out.println("Service Checkbox is already unchecked for  " + ParentPackage[j]);
								} else if (ValueServiceCheckbox != null) {
									driver.findElement(By.xpath(Checkboxpath)).click();
									WebElement Category = driver.findElement(By.xpath("Checkboxpath"));
									String ValueServiceCheckbox1 = Category.getAttribute("checked");
									if (ValueServiceCheckbox1 == null) {
										System.out.println("Service checkbox is Unchecked for " + ParentPackage[j]);
									} else {
										System.err.println("Service checkbox is not Unchecked for Category " + ParentPackage[j]);
										Assert.fail("Test fail for checking Service Checkbox to uncheck");
									}
								}

							} else {
								System.out.println("There is no Change in Service Checkbox for  " + ParentPackage[j]);

						}
								
					}		
							}
			
				 else {
						
						this.Multiple_CheckBox_Selection(ParentPackage, countxpath, labelxpath, Checkboxid,checkboxpath,ParentPackageCheckbox);
					 }
					 
					}
							
				 }
				 
			}
		
		 }
	
	public void ParentService(String[] parentServiceCheckbox,String[] parentService) throws InterruptedException, AWTException {
        
		try {
			
			String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[1]/div[2]/table/tbody/tr";
			String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[1]/div[2]/table/tbody/tr[x]/td/span";
			String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[1]/div[2]/table/tbody/tr[x]/td/label/span";
			String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[1]/div[2]/table/tbody/tr[x]/td/label/input";
			String vlaue =driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
			this.parentService(parentService, countxpath, labelxpath, Checkboxid, checkboxpath, parentServiceCheckbox);
		} catch (org.openqa.selenium.NoSuchElementException e1) {
			try {
		
				String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/div[1]/div[2]/table/tbody/tr";
				String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/div[1]/div[2]/table/tbody/tr[x]/td/span";
				String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/div[1]/div[2]/table/tbody/tr[x]/td/label/span";
				String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[13]/div[1]/div[2]/table/tbody/tr[x]/td/label/input";
				String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
				this.parentService(parentService, countxpath, labelxpath, Checkboxid, checkboxpath, parentServiceCheckbox);
			
			} catch (org.openqa.selenium.NoSuchElementException e2) {
				
				try {
					
					String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[1]/div[2]/table/tbody/tr";
					String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[1]/div[2]/table/tbody/tr[x]/td/span";
					String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[1]/div[2]/table/tbody/tr[x]/td/label/span";
					String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[1]/div[2]/table/tbody/tr[x]/td/label/input";
					String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
					this.parentService(parentService, countxpath, labelxpath, Checkboxid, checkboxpath, parentServiceCheckbox);
				
				} catch (org.openqa.selenium.NoSuchElementException e3) {
					
					try {
						String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[1]/div[2]/table/tbody/tr";
						String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[1]/div[2]/table/tbody/tr[x]/td/span";
						String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[1]/div[2]/table/tbody/tr[x]/td/label/span";
						String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[1]/div[2]/table/tbody/tr[x]/td/label/input";
						String vlaue = driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
						this.parentService(parentService, countxpath, labelxpath, Checkboxid, checkboxpath, parentServiceCheckbox);
					
						
						
					} catch (Exception e) {
						
					}
				}
			}
		}
	}
	
	
	
	public void parentService(String[] parentService,String countxpath,String labelxpath, String Checkboxid,String checkboxpath,String[] ParentServiceCheckbox) throws InterruptedException {
		Select select = new Select(PackageType);
		WebElement option = select.getFirstSelectedOption();
		String defaultvaluePackageType = option.getText();
		
		
		if (defaultvaluePackageType.equals("User Package") || defaultvaluePackageType.equals("Site Package") || defaultvaluePackageType.equals("Business Package") || defaultvaluePackageType.equals("BusinessSite Package")) {
		
		{
			if (parentService.length != 0) 
			{
				int count = driver.findElements(By.xpath(countxpath)).size();
				// System.out.println(count);
					 
				 if (count <=0) {
											
					 String LabelXpath = countxpath + "/td[1]/label/span";
					String Checkboxpath = countxpath + "/td[1]/label";
									 
						 for (int j = 0; j < parentService.length; j++) {
							 String parentServiceCheckbox = ParentServiceCheckbox[j];
							Thread.sleep(1000);
							String ValueServiceCheckbox = driver.findElement(By.xpath("Checkboxpath")).getAttribute("checked");
							if (parentServiceCheckbox.toUpperCase().equals("YES")) {
									
							if (ValueServiceCheckbox == null) {
								Thread.sleep(2000);
							 	driver.findElement(By.xpath(Checkboxpath)).click();
							 	
							 	WebElement Service1 = driver.findElement(By.xpath("Checkboxpath"));
								String ValueService1 = Service1.getAttribute("checked");
										 	
								if (ValueService1 == null) {
									System.err.println("Parent service Checkbox is not checked for  " + parentService[j]);
									Assert.fail("Test fail for Parent Service Checkbox to check");
								}
								
								else {
									System.out.println("Parent Service Checkbox is checked for  " + parentService[j]);
								}
							} else {
								System.out.println("Parent Service Checkbox is already checked for  " + parentService[j]);
							}
						}
							
							else if (parentServiceCheckbox.toUpperCase().equals("NO")) {
								if (ValueServiceCheckbox == null) {
									System.out.println("Parent Service Checkbox is already unchecked for  " + parentService[j]);
								} else if (ValueServiceCheckbox != null) {
									driver.findElement(By.xpath(Checkboxpath)).click();
									WebElement Parentservice = driver.findElement(By.xpath("Checkboxpath"));
									String ValueServiceCheckbox1 =  Parentservice.getAttribute("checked");
									if (ValueServiceCheckbox1 == null) {
										System.out.println("Service checkbox is Unchecked for " + parentService[j]);
									} else {
										System.err.println("Service checkbox is not Unchecked for Category " + parentService[j]);
										Assert.fail("Test fail for checking Service Checkbox to uncheck");
									}
								}

							} else {
								System.out.println("There is no Change in Service Checkbox for  " + parentService[j]);

						}
								
					}		
							}
			
				 else {
						
						this.Multiple_CheckBox_Selection(parentService, countxpath, labelxpath, Checkboxid,checkboxpath,ParentServiceCheckbox);
					 }
					 
					}
							
				 }
				 
			}
		
		 }
	
	
	
	
public void OwnLevelServices(String[] ownlevelServiceCheckbox,String[] ownlevelService) throws InterruptedException, AWTException {
        
		try {
			
			String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[1]/div[3]/table/tbody/tr";
			String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[1]/div[3]/table/tbody/tr[x]/td/span";
			String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[1]/div[3]/table/tbody/tr[x]/td/label/span";
			String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[14]/div[1]/div[3]/table/tbody/tr[x]/td/label/input";
			String vlaue =driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
			this.ownLevelService(ownlevelService, countxpath, labelxpath, Checkboxid, checkboxpath, ownlevelServiceCheckbox);
		} catch (org.openqa.selenium.NoSuchElementException e1) {
			
			try {
				
				String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[1]/div[3]/table/tbody/tr";
				String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[1]/div[3]/table/tbody/tr[x]/td/span";
				String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[1]/div[3]/table/tbody/tr[x]/td/label/span";
				String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[16]/div[1]/div[3]/table/tbody/tr[x]/td/label/input";
				String vlaue =driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
				this.ownLevelService(ownlevelService, countxpath, labelxpath, Checkboxid, checkboxpath, ownlevelServiceCheckbox);
			} catch (org.openqa.selenium.NoSuchElementException e2) {
				
				try {
					
					String countxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[1]/div[3]/table/tbody/tr";
					String labelxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[1]/div[3]/table/tbody/tr[x]/td/span";
					String checkboxpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[1]/div[3]/table/tbody/tr[x]/td/label/span";
					String Checkboxid="/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/section[1]/div[15]/div[1]/div[3]/table/tbody/tr[x]/td/label/input";
					String vlaue =driver.findElement(By.xpath(countxpath)).getAttribute("vlaue");
					this.ownLevelService(ownlevelService, countxpath, labelxpath, Checkboxid, checkboxpath, ownlevelServiceCheckbox);
				} catch (org.openqa.selenium.NoSuchElementException e3) {
					
					
			}
		}
}
}



public void ownLevelService(String[] ownlevelService,String countxpath,String labelxpath, String Checkboxid,String checkboxpath,String[] ownlevelServiceCheckbox) throws InterruptedException {
	Select select = new Select(PackageType);
	WebElement option = select.getFirstSelectedOption();
	String defaultvaluePackageType = option.getText();
	
	
	if (defaultvaluePackageType.equals("User Package") || defaultvaluePackageType.equals("Site Package") || defaultvaluePackageType.equals("Business Package") || defaultvaluePackageType.equals("BusinessSite Package")) {
	
	{
		if (ownlevelService.length != 0) 
		{
			int count = driver.findElements(By.xpath(countxpath)).size();
			// System.out.println(count);
				 
			 if (count <=0) {
										
				 String LabelXpath = countxpath + "/td[1]/label/span";
				String Checkboxpath = countxpath + "/td[1]/label";
								 
					 for (int j = 0; j < ownlevelService.length; j++) {
						 String OwnlevelServiceCheckbox = ownlevelServiceCheckbox[j];
						Thread.sleep(1000);
						String ValueServiceCheckbox = driver.findElement(By.xpath("Checkboxpath")).getAttribute("checked");
						if (OwnlevelServiceCheckbox.toUpperCase().equals("YES")) {
								
						if (ValueServiceCheckbox == null) {
							Thread.sleep(2000);
						 	driver.findElement(By.xpath(Checkboxpath)).click();
						 	
						 	WebElement Service1 = driver.findElement(By.xpath("Checkboxpath"));
							String ValueService1 = Service1.getAttribute("checked");
									 	
							if (ValueService1 == null) {
								System.err.println("Parent service Checkbox is not checked for  " + ownlevelService[j]);
								Assert.fail("Test fail for Parent Service Checkbox to check");
							}
							
							else {
								System.out.println("Own level Service Checkbox is checked for  " + ownlevelService[j]);
							}
						} else {
							System.out.println("Own level Service Checkbox is already checked for  " + ownlevelService[j]);
						}
					}
						
						else if (OwnlevelServiceCheckbox.toUpperCase().equals("NO")) {
							if (ValueServiceCheckbox == null) {
								System.out.println("Own level Service Checkbox is already unchecked for  " + ownlevelService[j]);
							} else if (ValueServiceCheckbox != null) {
								driver.findElement(By.xpath(Checkboxpath)).click();
								WebElement Parentservice = driver.findElement(By.xpath("Checkboxpath"));
								String ValueServiceCheckbox1 =  Parentservice.getAttribute("checked");
								if (ValueServiceCheckbox1 == null) {
									System.out.println("Own level checkbox is Unchecked for " + ownlevelService[j]);
								} else {
									System.err.println("Own level checkbox is not Unchecked for Category " + ownlevelService[j]);
									Assert.fail("Test fail for checking Service Checkbox to uncheck");
								}
							}

						} else {
							System.out.println("There is no Change in Own level Checkbox for  " + ownlevelService[j]);

					}
							
				}		
						}
		
			 else {
					
					this.Multiple_CheckBox_Selection(ownlevelService, countxpath, labelxpath, Checkboxid,checkboxpath,ownlevelServiceCheckbox);
				 }
				 
				}
						
			 }
			 
		}
	
	 }



	/******************************
	 * Page 1 Reseller[METHODS]
	 *********************************/
	
	public void CommisonCategory_Reseller(String commisonCategory_Reseller) throws InterruptedException {
		try {
			dropdown(CommisonCategory_Reseller, commisonCategory_Reseller, "Commision Catgory");
		} catch (org.openqa.selenium.NoSuchElementException e) {
			
		}

	}
	
public void DeviceRented(String deviceRented,String primaryPackage) throws InterruptedException {
	Select select = new Select(PackageType);
	WebElement option = select.getFirstSelectedOption();
	String defaultvaluePackageType = option.getText();
	try {
		if (defaultvaluePackageType.equals("User Package")&& primaryPackage!="None") {
			dropdown(DeviceRented_Reseller, deviceRented, "Device - Rented");
	}
	} catch (org.openqa.selenium.NoSuchElementException e) {
		
	}
		
}

	public void UpgradePriority(String upgradePriority,String primaryPackage) throws InterruptedException {
		Select select = new Select(PackageType);
		WebElement option = select.getFirstSelectedOption();
		String defaultvaluePackageType = option.getText();
		try {
			if (defaultvaluePackageType.equals("User Package")&& primaryPackage!="None") {
				dropdown(Updatepriority_Reseller, upgradePriority, "Upgrade Priority");
				
			}
		} catch (org.openqa.selenium.NoSuchElementException e) {
			
		}
		

	}

	public void NoPackage(String nopackageValue) throws InterruptedException
	{
		try {
			
			Checkbox(driver, "chk_bwnopackage", NoPackage, nopackageValue, "No package in Broadworks");
		} catch (Exception e) {
						
			
		}
		
	}

	public void NextButton() throws InterruptedException {
		Thread.sleep(6000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", NextButton);
	}

	/******************************
	 * Page 2[METHODS]
	 *******************************************/
	public void FreeDays(String freeDays) throws InterruptedException {
		Inputdata(FreeDays, freeDays, "Free Days");
	}

	public void ApplyDate(String applyDate) throws InterruptedException {
		Thread.sleep(3000);
		try {
			String a = "document.getElementById('txtFreeDays_5865').";
			String b = "value='" + applyDate + "'";
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(a + b);
		}

		catch (org.openqa.selenium.NoSuchElementException e) {

			try {
				String a = "document.getElementById('txtApplyDate_5881').";
				String b = "value='" + applyDate + "'";
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript(a + b);
			} catch (org.openqa.selenium.NoSuchElementException e1) {
				
			}
		}

	}

	public void ThresholdType_Prorata() throws InterruptedException {
		Thread.sleep(1000);
		try {
			ThresholdType_Prorata.click();
		}

		catch (org.openqa.selenium.NoSuchElementException e) {

			try {

				ThresholdType_Prorata_Distributor.click();

			} catch (org.openqa.selenium.NoSuchElementException e1) {
				
			}
		}

	}

	public void ThresholdType_SingleRate() throws InterruptedException {
		try {
			ThresholdType_SingleRate.click();

		} catch (org.openqa.selenium.NoSuchElementException e) {

			try {

				ThresholdType_SingleRate_Distributor.click();

			} catch (org.openqa.selenium.NoSuchElementException e1) {
				
			}

		}
	}

	public void NoneCheckbox() throws InterruptedException {
		try {
			NoneCheckbox.click();
		} catch (org.openqa.selenium.NoSuchElementException e) {

			try {

				NoneCheckbox_Distributor.click();
			} catch (org.openqa.selenium.NoSuchElementException e1) {
				
			}

		}
	}


	public void AddNewButton() throws InterruptedException, AWTException {
		Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", AddNewButton);
		ScrollPage(driver, "0,300");
	}

	public void QuantityFrom(String quantityFrom) throws InterruptedException {
		Inputdata(QuantityFrom, quantityFrom, "Quantity From");
		 
	}

	
	public void QuantityTo(String quantityTo) throws InterruptedException {
		Inputdata(QuantityTo, quantityTo, "Quantity To*");
	}

	public void Recurringcharge(String recurringcharge) throws InterruptedException {
		Inputdata(Recurringcharge, recurringcharge, "Recurring charge*");
	}

	public void SlabDetails_Save() throws InterruptedException {
			Thread.sleep(3000);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click();", SlabDetails_Save);
			
	}

	

	public void SlabDetails_Cancel() throws InterruptedException, AWTException {
		try {
			SlabDetails_Cancel.click();
			ScrollPage(driver, "0,-300");
		} catch (org.openqa.selenium.NoSuchElementException e) {

		}
	}

	public void SetupCharge(String setupCharge) throws InterruptedException {
		Inputdata(SetupCharge, setupCharge, "Setup charge (Sale)");
	}

	public void RecurringCharge(String recurringCharge) throws InterruptedException {
		Inputdata(RecurringCharge, recurringCharge, "Recurring charge (Sale)");
		
	}

	public void CeaseCharge(String ceaseCharge) throws InterruptedException {
		Inputdata(CeaseCharge, ceaseCharge, "Cease Charge (Sale)");
	}

	public void RebateValue(String rebateValue) throws InterruptedException {
		Inputdata(RebateValue, rebateValue, "Rebate Value (Sale)");
		
	}

	public void SecondaryRebateValue(String secondaryRebateValue) throws InterruptedException {
		Inputdata(SecondaryRebateValue, secondaryRebateValue, "Secondary Rebate Value (Sale)");
	}

	public void SetupChargeNominalCode(String setupChargeNominalCode) throws InterruptedException {
		dropdown(SetupChargeNominalCode, setupChargeNominalCode, "Setup Charge Nominal Code");
		
	}

	public void RecurringChargeNominalCode(String recurringChargeNominalCode) throws InterruptedException {
		dropdown(RecurringChargeNominalCode, recurringChargeNominalCode, "Recurring Charge Nominal Code");
		}
	
	
	public void CeaseChargeNominalCode(String ceaseChargeNominalCode) throws InterruptedException {
		dropdown(CeaseChargeNominalCode, ceaseChargeNominalCode, "Cease Charge Nominal Code");
	}

	public void SetupCostBuy(String setupCostBuy) throws InterruptedException {
		Inputdata(SetupCostBuy, setupCostBuy, "Setup Cost (Buy)");
	}

	public void RecurringCostBuy(String recurringCostBuy) throws InterruptedException {
		Inputdata(RecurringCostBuy, recurringCostBuy, "Recurring Cost (Buy)");
	}

	public void CeaseCostBuy(String ceaseCostBuy) throws InterruptedException {
		Inputdata(CeaseCostBuy, ceaseCostBuy, "Cease Cost (Buy)");
		}
	public void LicensePurchasePrice(String licensePurchasePrice) throws InterruptedException {
			Inputdata(LicensePurchasePrice, "clear", "License Purchase Price (Sale)");
			Inputdata(LicensePurchasePrice, licensePurchasePrice, "License Purchase Price (Sale)");
		}

	public void MonthlyFeeAssigned(String monthlyFeeAssigned) throws InterruptedException {
			Inputdata(MonthlyFeeAssigned, "clear", "Monthly Fee - Assigned (Sale)");
			Inputdata(MonthlyFeeAssigned, monthlyFeeAssigned, "Monthly Fee - Assigned (Sale)");
	}

	public void MonthlyFeeUnassigned(String monthlyFeeUnassigned) throws InterruptedException {
			Inputdata(MonthlyFeeUnassigned, "clear", "Monthly Fee - Unassigned (Sale)");
			Inputdata(MonthlyFeeUnassigned, monthlyFeeUnassigned, "Monthly Fee - Unassigned (Sale)");
	}

	public void LicensePurchaseNominal(String licensePurchaseNominal) throws InterruptedException {
		dropdown(LicensePurchaseNominal, licensePurchaseNominal, "License Purchase Nominal");
		
	}

	public void MonthlyFeeAssignedNominal(String monthlyFeeAssignedNominal) throws InterruptedException {
		dropdown(MonthlyFeeAssignedNominal, monthlyFeeAssignedNominal, "Monthly Fee - Assigned Nominal");
		
	}

	public void MonthlyFeeUnassignedNominal(String monthlyFeeUnassignedNominal) throws InterruptedException {
		dropdown(MonthlyFeeUnassignedNominal, monthlyFeeUnassignedNominal, "Monthly Fee - Unassigned Nominal");
	}

	public void LicenseSetupCost(String licenseSetupCost) throws InterruptedException {
			Inputdata(LicenseSetupCost, "clear", "License Setup Cost (Buy)");
			Inputdata(LicenseSetupCost, licenseSetupCost, "License Setup Cost (Buy)");
		}

	public void LicenseAssignedCost(String licenseAssignedCost) throws InterruptedException {
			Inputdata(LicenseAssignedCost, "clear", "License Assigned Cost  (Buy)");
			Inputdata(LicenseAssignedCost, licenseAssignedCost, "License Assigned Cost  (Buy)");
		 
	}

	public void LicenseUnassignedCost(String licenseUnassignedCost) throws InterruptedException {
			Inputdata(LicenseUnassignedCost, "clear", "License Unassigned Cost  (Buy)");
			Inputdata(LicenseUnassignedCost, licenseUnassignedCost, "License Unassigned Cost  (Buy)");
		} 

	public void ApplyallSDRTariff(String applyallSDRTariffCheckBoxvalue) throws InterruptedException {
		try {
			Checkbox(driver, "chk_forallSDRTariff", ApplyallSDRTariff, applyallSDRTariffCheckBoxvalue,"Apply to all the SDR Tariffs");
		}

		catch (org.openqa.selenium.NoSuchElementException e) {
			try {
				Checkbox(driver, "chk_forallSDRTariff", ApplyallSDRTariff_Distributor, applyallSDRTariffCheckBoxvalue,"Apply to all the SDR Tariffs");
			} catch (org.openqa.selenium.NoSuchElementException e1) {
			}
		}
	}

	/**********************************
	 * Page3
	 ******************************************/

	public void MinimumDuration(String minimumDuration) throws InterruptedException {

		Inputdata(MinimumDuration, "clear", "Minimum Duration (Days)*");
		Inputdata(MinimumDuration, minimumDuration, "Minimum Duration (Days)*");
	}

	public void NotificationPeriod(String notificationPeriod) throws InterruptedException {

		Inputdata(NotificationPeriod, "clear", "Notification Period (Days)*");
		Inputdata(NotificationPeriod, notificationPeriod, "Notification Period (Days)*");
	}

	public void QuarantinePeriod(String quarantinePeriod) throws InterruptedException {
		Inputdata(QuarantinePeriod, "clear", "Quarantine Period (Days)*");
		Inputdata(QuarantinePeriod, quarantinePeriod, "Quarantine Period (Days)*");

	}

	public void NotificationPeriodCheckbox(String notificationPeriodCheckboxCheckBoxvalue) throws InterruptedException {
		Checkbox(driver, "chkCombineNotificationPeriodForPackage", NotificationPeriodCheckbox,notificationPeriodCheckboxCheckBoxvalue,"Notification Period to be Included as Part of Minimum Contract Period");

	}
	

	public void Next1() {
		Next1.click();
	}

	public void Next() {
		NextButton.click();
	}

	public void Cancel() {
		try {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click();", Cancel);
			
			Thread.sleep(5000);
		} catch (Exception e) {
			
			}
		}
	

	public void Previous() {
		PreviousButton.click();
	}

	public void Finish() throws InterruptedException {
		Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", Finish);
	}
	
	

	/**************************************
	 * Validation[webelements]
	 ***********************************************/

	@FindBy(id = "txtName-error")
	WebElement NameValidation;

	@FindBy(id = "txtDecription-error")
	WebElement DescriptionValidation;

	@FindBy(id = "sel_country-error")
	WebElement CountryValidation;

	@FindBy(id = "sel_assignmenttype-error")
	WebElement AssignmentTypeValidation;

	@FindBy(xpath = "//span[@class='ml-2'][contains(.,'Atleast one slab is mandatory as threshold is selected for tariff(s) :SDR')]")
	WebElement SlabValidation;

	@FindBy(xpath= "//label[@id='txtFreeDays_11373-error'] | //label[@id='txtFreeDays_11391-error'] | //label[@id='txtFreeDays_11408-error']| //label[@id='txtFreeDays_11415-error'] |  //label[@id='txtFreeDays_12379-error'] |  //label[@id='txtFreeDays_12440-error']")
	WebElement FreedaysValidation;
	
	@FindBy(xpath= "//label[@id='txtSlabRecurringCharge_11373-error'] | //label[@id='txtSlabRecurringCharge_11391-error'] | //label[@id='txtSlabRecurringCharge_11408-error'] | //label[@id='txtSlabRecurringCharge_11415-error'] | //label[@id='txtSlabRecurringCharge_12379-error'] | //label[@id='txtSlabRecurringCharge_12440-error']")
	WebElement RecurringChargeSlabValidation;
	
	@FindBy(xpath= "//label[@id='txtQuantityFrom_11373-error'] | //label[@id='txtQuantityFrom_11391-error'] | //label[@id='txtQuantityFrom_11408-error']  | //label[@id='txtQuantityFrom_11415-error'] | //label[@id='txtQuantityFrom_12379-error'] | //label[@id='txtQuantityFrom_12440-error']")
	WebElement QuantityFromValidation;
	
	@FindBy(xpath= "//label[@id='txtQuantityTo_11373-error'] | //label[@id='txtQuantityTo_11391-error'] | //label[@id='txtQuantityTo_11408-error'] | //label[@id='txtQuantityTo_11415-error'] | //label[@id='txtQuantityTo_12379-error'] | //label[@id='txtQuantityTo_12440-error'] ")
	
	WebElement QuantityToValidation;
		
	@FindBy(xpath= "//label[@id='txtSetupCharge_11373-error'] | //label[@id='txtSetupCharge_11391-error']  | //label[@id='txtSetupCharge_11408-error'] | //label[@id='txtSetupCharge_11415-error'] | //label[@id='txtSetupCharge_12379-error'] | //label[@id='txtSetupCharge_12440-error']")
	WebElement SetupChargeValidation;
		
	@FindBy(xpath= "//label[@id='txtRecurringCharge_11373-error'] | //label[@id='txtRecurringCharge_11391-error'] | //label[@id='txtRecurringCharge_11408-error'] | //label[@id='txtRecurringCharge_11415-error'] | //label[@id='txtRecurringCharge_12379-error'] | //label[@id='txtRecurringCharge_12440-error']")
	WebElement RecurringChargeValidation;
	
	@FindBy(xpath= "//label[@id='txtCeaseCharge_11373-error'] | //label[@id='txtCeaseCharge_11391-error'] | //label[@id='txtCeaseCharge_11408-error'] | //label[@id='txtCeaseCharge_11415-error'] | //label[@id='txtCeaseCharge_12379-error'] | //label[@id='txtCeaseCharge_12440-error']")
	WebElement CeaseChargeValidation;
	
	@FindBy(xpath= "//label[@id='txtRebateValue_11373-error'] | //label[@id='txtRebateValue_11391-error'] | //label[@id='txtRebateValue_11408-error'] | //label[@id='txtRebateValue_11415-error'] | //label[@id='txtRebateValue_12379-error'] | //label[@id='txtRebateValue_12440-error']")
	WebElement RebateValueValidation;
	
	@FindBy(xpath= "//label[@id='txtSecondaryRebateValue_11373-error'] | //label[@id='txtSecondaryRebateValue_11391-error'] | //label[@id='txtSecondaryRebateValue_11408-error'] | //label[@id='txtSecondaryRebateValue_11415-error'] | //label[@id='txtSecondaryRebateValue_12379-error'] | //label[@id='txtSecondaryRebateValue_12440-error']")
	WebElement SecondaryRebateValueValidation;
	
	@FindBy(xpath= "//label[@id='txtThirdPartySetupCost_11373-error'] | //label[@id='txtThirdPartySetupCost_11391-error'] | //label[@id='txtThirdPartySetupCost_11408-error'] | //label[@id='txtThirdPartySetupCost_11415-error'] | //label[@id='txtThirdPartySetupCost_12379-error'] | //label[@id='txtThirdPartySetupCost_12440-error']")
	WebElement SetUpCostValidation;
	
	@FindBy(xpath= "//label[@id='txtThirdPartyRecurringCost_11373-error'] | //label[@id='txtThirdPartyRecurringCost_11391-error'] | //label[@id='txtThirdPartyRecurringCost_11408-error'] | //label[@id='txtThirdPartyRecurringCost_11415-error'] | //label[@id='txtThirdPartyRecurringCost_12379-error'] | //label[@id='txtThirdPartyRecurringCost_12440-error']") 
	WebElement RecurringCostValidation;
	
	@FindBy(xpath= "//label[@id='txtCeaseCost_11373-error'] | //label[@id='txtCeaseCost_11391-error'] | //label[@id='txtCeaseCost_11408-error'] | //label[@id='txtCeaseCost_11415-error'] | //label[@id='txtCeaseCost_12379-error'] | //label[@id='txtCeaseCost_12440-error']")
	WebElement CeaseCostValidation;
		
	@FindBy(xpath= "//label[@id='txtCeaseCost_11373-error'] | //label[@id='txtCeaseCost_11391-error'] | //label[@id='txtCeaseCost_11408-error'] | //label[@id='txtCeaseCost_11415-error'] | //label[@id='txtCeaseCost_12379-error'] | //label[@id='txtCeaseCost_12440-error']")
	WebElement LicensePurshaseValidation;
	
	@FindBy(xpath= "//label[@id='txtLicenseSetupCharge_11373-error'] | //label[@id='txtLicenseSetupCharge_11391-error'] | //label[@id='txtLicenseSetupCharge_11408-error'] | //label[@id='txtLicenseSetupCharge_11415-error'] | //label[@id='txtLicenseSetupCharge_12379-error'] | //label[@id='txtLicenseSetupCharge_12440-error'] ")
	WebElement LicensePurshasePriceValidation;
		
	@FindBy(xpath= "//label[@id='txtLicenseAssignedCharge_11373-error'] | //label[@id='txtLicenseAssignedCharge_11391-error'] | //label[@id='txtLicenseAssignedCharge_11408-error'] | //label[@id='txtLicenseAssignedCharge_11415-error'] | //label[@id='txtLicenseAssignedCharge_12379-error'] | //label[@id='txtLicenseAssignedCharge_12440-error']")
	WebElement MonthlyFeeAssignedValidation;
	
	@FindBy(xpath= "//label[@id='txtLicenseUnAssignedCharge_11373-error'] | //label[@id='txtLicenseUnAssignedCharge_11391-error']  | //label[@id='txtLicenseUnAssignedCharge_11408-error'] | //label[@id='txtLicenseUnAssignedCharge_11415-error'] | //label[@id='txtLicenseUnAssignedCharge_12379-error'] | //label[@id='txtLicenseUnAssignedCharge_12440-error']") 
	WebElement MonthlyFeeUnassignedValidation;
	
	@FindBy(xpath= "//label[@id='txtLicenseSetupCost_11373-error'] | //label[@id='txtLicenseSetupCost_11391-error'] | //label[@id='txtLicenseSetupCost_11408-error'] | //label[@id='txtLicenseSetupCost_11415-error'] | //label[@id='txtLicenseSetupCost_12379-error'] | //label[@id='txtLicenseSetupCost_12440-error']")
	WebElement LicenseSetupCostValidation;
	
	@FindBy(xpath= "//label[@id='txtLicenseAssignedCost_11373-error'] | //label[@id='txtLicenseAssignedCost_11391-error'] | //label[@id='txtLicenseAssignedCost_11408-error'] | //label[@id='txtLicenseAssignedCost_11415-error'] | //label[@id='txtLicenseAssignedCost_12379-error'] | //label[@id='txtLicenseAssignedCost_12440-error']")
	WebElement LicenseAssignedCostValidation;
		
	@FindBy(xpath= "//label[@id='txtLicenseUnassignedCost_11373-error'] | //label[@id='txtLicenseUnassignedCost_11391-error'] | //label[@id='txtLicenseUnassignedCost_11408-error'] | //label[@id='txtLicenseUnassignedCost_11415-error'] | //label[@id='txtLicenseUnassignedCost_12379-error'] | //label[@id='txtLicenseUnassignedCost_12440-error']")
	WebElement LicenseUnassignedCostValidation;
		
	@FindBy(id = "txtMinimumDuration-error")
	WebElement MinimumDurationValidation;

	@FindBy(id = "txtNotificationPeriod-error")
	WebElement NotificationPeriodValidation;

	@FindBy(id = "txtQuarantinePeriod-error")
	WebElement QuarantinePeriodValidation;

	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveValidation;

	String[] NameVal = { "Name cannot be empty" };
	String[] DescriptionVal = { "Description cannot be empty" };
	String[] CountryVal = { "Select Country" };
	String[] AssignmentTypeVal = { "Select Assignment Type" };
	String[] FreedaysVal = { "Free Days Cannot be empty", "Please enter a valid Number" };
	String[] QuantityFromVal = { "Quantity From Cannot be empty", "Please enter a valid Number" };
	String[] QuantityToVal = { "Quantity To Cannot be empty", "Please enter a valid Number" };

	String[] SlabVal = { "Atleast one slab is mandatory as threshold is selected for tariff(s) :SDR" };
	String[] RecurringChargeSlabVal = { "Recurring charge cannot be empty", "Please enter a valid Number" };

	String[] SetUpChargeVal = { "Please enter a valid Number" };
	String[] RecurringChargeVal = { "Please enter a valid Number" };
	String[] CeasechargeVal = { "Please enter a valid Number" };
	String[] RebateValueVal = { "Please enter a valid Number" };
	String[] SecondaryRebateValueVal = { "Please enter a valid Number" };
	String[] SetupCostVal = { "Please enter a valid Number" };
	String[] RecurringCostVal = { "Please enter a valid Number" };
	String[] CeaseCostVal = { "Please enter a valid Number" };
	String[] LicensePurshasePriceVal = { "Please enter a valid Number" };
	String[] MonthlyFeeAssignedVal = { "Please enter a valid Number" };
	String[] MonthlyFeeUnAssignedVal = { "Please enter a valid Number" };
	String[] LicenseSetUpCostVal = { "Please enter a valid Number" };
	String[] LicenseAssignedCostVal = { "Please enter a valid Number" };
	String[] LicenseUnAssignedCostVal = { "Please enter a valid Number" };

	String[] MinimumDurationVal = { "Minimum duration for package cannot be less than 30","Minimum duration cannot be empty", "Please enter a valid Number" };
	String[] NotificationPeriodVal = { "Notification period for package cannot be less than 30","Notification period cannot be empty", "Please enter a valid Number" };
	String[] QuarantinePeriodVal = { "Quarantine period cannot be empty/zero", "Please enter a valid Number" };
	String[] servervalidation = {"Saved successfully","Already Exists","Multiple webex services cannot be included in same package","Select At least One Service","Dependent package assignment type is not the same as the current assignment type.Either both must be `Hosted` or `SIP` or `Both` or combination of `Hosted/SIP` & `Both`","Select At least One Service From Parent Package :-AutomationBoth User Pkg","Select At least One Service for creation","Cannot recreate package without device.Since parent package has included device." };

	String[] SaveVal = { "Saved successfully" };

	/****************************
	 * Validation[page 1 ->Methods]
	 ******************************/
	public void nameval() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = NameVal;
		String getValiadtion = NameValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void descriptionval() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = DescriptionVal;
		String getValiadtion = DescriptionValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void countryVal() throws InterruptedException, AWTException {
		try {
			Thread.sleep(2000);
			String[] setvalidation = CountryVal;
			String getValiadtion = CountryValidation.getText();
			this.Validation(getValiadtion, setvalidation);
		} catch (org.openqa.selenium.NoSuchElementException e1) {
			
		}
		
		
	}

	public void assignmentTypeVal() throws InterruptedException, AWTException {

		try {

			Thread.sleep(2000);
			String[] setvalidation = AssignmentTypeVal;
			String getValiadtion = AssignmentTypeValidation.getText();
			this.Validation(getValiadtion, setvalidation);

		} catch (org.openqa.selenium.NoSuchElementException e1) {
			
		}

	}

	public void validation_page1() throws InterruptedException, AWTException {
		this.nameval();
		this.descriptionval();
		this.countryVal();
		this.assignmentTypeVal();

	}

	/***********************************
	 * Validation[page 2]
	 ***********************************************/

	public void FreedaysVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = FreedaysVal;
		String getValiadtion = FreedaysValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void RecurringChargeSlabVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = RecurringChargeSlabVal;
		String getValiadtion = RecurringChargeSlabValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void QuantityFromVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = QuantityFromVal;
		String getValiadtion = QuantityFromValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void QuantityToVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = QuantityToVal;
		String getValiadtion = QuantityToValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void SetUpChargeVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = SetUpChargeVal;
		String getValiadtion = SetupChargeValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void RecurringChargeVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = RecurringChargeVal;
		String getValiadtion = RecurringChargeValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void CeasechargeVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = CeasechargeVal;
		String getValiadtion = CeaseChargeValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void RebateValueVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = RebateValueVal;
		String getValiadtion = RebateValueValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void SecondaryRebateValueVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = SecondaryRebateValueVal;
		String getValiadtion = SecondaryRebateValueValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void SetupCostVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = SetupCostVal;
		String getValiadtion = SetUpCostValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void RecurringCostVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = RecurringCostVal;
		String getValiadtion = RecurringCostValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void CeaseCostVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = CeaseCostVal;
		String getValiadtion = CeaseCostValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void LicensePurshasePriceVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = LicensePurshasePriceVal;
		String getValiadtion = LicensePurshasePriceValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void MonthlyFeeAssignedVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = MonthlyFeeAssignedVal;
		String getValiadtion = MonthlyFeeAssignedValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void MonthlyFeeUnAssignedVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = MonthlyFeeUnAssignedVal;
		String getValiadtion = MonthlyFeeUnassignedValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void LicenseSetUpCostVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = LicenseSetUpCostVal;
		String getValiadtion = LicenseSetupCostValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void LicenseAssignedCostVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = LicenseAssignedCostVal;
		String getValiadtion = LicenseAssignedCostValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void LicenseUnAssignedCostVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = LicenseUnAssignedCostVal;
		String getValiadtion = LicenseUnassignedCostValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void SlabVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = SlabVal;
		String getValiadtion = SlabValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void validation_page2_Freedays() throws InterruptedException, AWTException {
		Inputdata(FreeDays, "clear", "Free Days");
		this.NextButton();
		this.FreedaysVal();
		
	}

	public void validation_page2_Pro_SingleRate() throws InterruptedException, AWTException {
		this.ThresholdType_Prorata();
		this.AddNewButton();
		this.SlabDetails_Save();
		this.QuantityFromVal();
		this.QuantityToVal();
		this.RecurringChargeSlabVal();
		this.SlabDetails_Cancel();
		this.NoneCheckbox();
	}

	public void validation_page2(String InvalidData_Test) throws InterruptedException, AWTException {
		this.validation_page2_Freedays();
		this.validation_page2_Pro_SingleRate();
		this.FreeDays(InvalidData_Test);
		this.SetupCharge(InvalidData_Test);
		this.RecurringCharge(InvalidData_Test);
		this.CeaseCharge(InvalidData_Test);
		this.RebateValue(InvalidData_Test);
		this.SecondaryRebateValue(InvalidData_Test);
		this.SetupCostBuy(InvalidData_Test);
		this.RecurringCostBuy(InvalidData_Test);
		this.CeaseCostBuy(InvalidData_Test);
		this.LicensePurchasePrice(InvalidData_Test);
		this.MonthlyFeeAssigned(InvalidData_Test);
		this.MonthlyFeeUnassigned(InvalidData_Test);
		this.LicenseSetupCost(InvalidData_Test);
		this.LicenseAssignedCost(InvalidData_Test);
		this.LicenseUnassignedCost(InvalidData_Test);
		this.NextButton();
		this.FreedaysVal();
		this.SetUpChargeVal();
		this.RecurringChargeVal();
		this.CeasechargeVal();
		this.RebateValueVal();
		this.SecondaryRebateValueVal();
		this.SetupCostVal();
		this.RecurringCostVal();
		this.CeaseCostVal();
		this.LicensePurshasePriceVal();
		this.MonthlyFeeAssignedVal();
		this.MonthlyFeeUnAssignedVal();
		this.LicenseSetUpCostVal();
		this.LicenseAssignedCostVal();
		this.LicenseUnAssignedCostVal();

	}

	/********************************
	 * Validation[page 3]
	 *****************************************/

	public void MinimumDurationVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = MinimumDurationVal;
		String getValiadtion = MinimumDurationValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void NotificationPeriodVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = NotificationPeriodVal;
		String getValiadtion = NotificationPeriodValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void QuarantinePeriodVal() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		String[] setvalidation = QuarantinePeriodVal;
		String getValiadtion = QuarantinePeriodValidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void contractVal() throws InterruptedException
	{
		Inputdata(MinimumDuration, "clear", "Minimum duration");
		Inputdata(NotificationPeriod, "clear", "Notification Period");
		Inputdata(QuarantinePeriod, "clear", "Quaratine Period");
	}
	public void ContractValidation() throws InterruptedException, AWTException {
		this.MinimumDurationVal();
		this.QuarantinePeriodVal();
		this.NotificationPeriodVal();
	}

	public void validation_page3(String InvalidData_Test) throws InterruptedException, AWTException {
		this.ContractValidation();
		this.MinimumDuration(InvalidData_Test);
		this.NotificationPeriod(InvalidData_Test);
		this.QuarantinePeriod(InvalidData_Test);
		this.Finish();
		this.ContractValidation();
	}

	/*************************** Validation[Save] ********************************/

	public void SaveVal() throws InterruptedException, AWTException {
		Thread.sleep(4000);

		String validationAfterSave = SaveValidation.getText();
		if (validationAfterSave.equals("Saved successfully")) {
			String[] setvalidation = SaveVal;
			String getValiadtion = SaveValidation.getText();
			this.Validation(getValiadtion, setvalidation);
		}

		else {
			Thread.sleep(2000);
			this.servervalidation();
			Thread.sleep(2000);
			ScrollPage(driver, "0,800");
			this.Cancel();
		}

	}

	/*****************************
	 * Main Method
	 ****************************************/
	public void Package_PlatformOwner_ADD_Validation(String availableToDistributor, String availableToReseller,
			String name, String description, String packageCode, String country, String packageType,
			String assignmentType, String multipleInstancesAllowedValue, String isPrimaryCheckboxValue,
			String dependentPackage, String keyLampCount, String canAlterPackageCheckboxValue,
			String canBeAssignedCheckboxValue,String []CategoryCheckbox,String[] numberCategory,String [] ServiceCheckbox,String[] userPackage,
			String freeDays, String setupCharge, String recurringCharge, String ceaseCharge, String rebateValue,
			String secondaryRebateValue, String setupChargeNominalCode, String recurringChargeNominalCode,
			String ceaseChargeNominalCode, String setupCostBuy, String recurringCostBuy, String ceaseCostBuy,
			String licensePurchasePrice, String monthlyFeeAssigned, String monthlyFeeunassigned,
			String licensePurchaseNominal, String monthlyFeeAssignedNominal, String monthlyFeeUnassignedNominal,
			String licenseSetupCost, String licenseAssignedCost, String licenseUnassignedCost,
			String applyallSDRTariffCheckBoxvalue, String minimumDuration, String notificationPeriod,
			String quarantinePeriod, String notificationPeriodCheckBoxvalue, String primaryPackage,
			String[] ParentPackageCheckbox,String[] ParentPackage,String [] parentServiceCheckbox,String[] parentService,String secondaryPackageCheckboxValue, String InvalidData_Test)
			throws InterruptedException, AWTException {

		this.ClickonAdd();
		Thread.sleep(5000);
		this.Next1();
		this.validation_page1();
		this.AvailableToDistributor(availableToDistributor);
		this.AvailableToReseller(availableToReseller);
		this.name(name);
		this.Description(description);
		this.PackageCode(packageCode);
		this.Country(country);
		this.PackageType(packageType);
		this.AssignmentType(assignmentType);
		this.MultipleInstancesAllowed(multipleInstancesAllowedValue);
		this.IsPrimary(isPrimaryCheckboxValue);
		this.PrimaryPackage(primaryPackage);
	
		this.KeyLampCount(keyLampCount);
		this.CanAlterPackage(canAlterPackageCheckboxValue);
		this.CanBeAssigned(canBeAssignedCheckboxValue);
		ScrollPage(driver, "0,130");

		this.NumberCategory(CategoryCheckbox, numberCategory);
		this.ParentPackage(ParentPackageCheckbox, ParentPackage);
		this.Service(ServiceCheckbox, userPackage, secondaryPackageCheckboxValue);
		this.ParentService(parentServiceCheckbox, parentService);
		ScrollPage(driver, "0,2000");
		this.NextButton();
		
		this.validation_page2(InvalidData_Test);
		this.FreeDays(freeDays);
		this.SetupCharge(setupCharge);
		this.RecurringCharge(recurringCharge);
		this.CeaseCharge(ceaseCharge);
		this.RebateValue(rebateValue);
		this.SecondaryRebateValue(secondaryRebateValue);
		this.SetupChargeNominalCode(setupChargeNominalCode);
		this.RecurringChargeNominalCode(recurringChargeNominalCode);
		this.CeaseChargeNominalCode(ceaseChargeNominalCode);
		this.SetupCostBuy(setupCostBuy);
		this.RecurringCostBuy(recurringCostBuy);
		this.CeaseCostBuy(ceaseCostBuy);
		
		this.LicensePurchasePrice(licensePurchasePrice);
		this.MonthlyFeeAssigned(monthlyFeeAssigned);
		this.MonthlyFeeUnassigned(monthlyFeeunassigned);
		this.LicensePurchaseNominal(licensePurchaseNominal);
		this.MonthlyFeeAssignedNominal(monthlyFeeAssignedNominal);
		this.MonthlyFeeUnassignedNominal(monthlyFeeUnassignedNominal);
		this.LicenseSetupCost(licenseSetupCost);
		this.LicenseAssignedCost(licenseAssignedCost);
		this.LicenseUnassignedCost(licenseUnassignedCost);
		this.ApplyallSDRTariff(applyallSDRTariffCheckBoxvalue);
		this.NextButton();
		Thread.sleep(3000);
		this.contractVal();
		this.Finish();
		Thread.sleep(3000);
		this.validation_page3(InvalidData_Test);
		this.MinimumDuration(minimumDuration);
		this.NotificationPeriod(notificationPeriod);
		this.QuarantinePeriod(quarantinePeriod);
		this.NotificationPeriodCheckbox(notificationPeriodCheckBoxvalue);
		Thread.sleep(2000);
		this.Cancel();
		
	}

	public void Package_PlatformOwner_ADD(String availableToDistributor, String availableToReseller, String name,
			String description, String packageCode, String country, String packageType, String assignmentType,
			String multipleInstancesAllowedValue, String isPrimaryCheckboxValue, String dependentPackage,
			String keyLampCount, String canAlterPackageCheckboxValue, String canBeAssignedCheckboxValue,String nopackageValue,String []CategoryCheckbox,
			String[] numberCategory,String[] ServiceCheckbox, String[] userPackage, String freeDays, String setupCharge, String recurringCharge,
			String ceaseCharge, String rebateValue, String secondaryRebateValue, String setupChargeNominalCode,
			String recurringChargeNominalCode, String ceaseChargeNominalCode, String setupCostBuy,
			String recurringCostBuy, String ceaseCostBuy, String licensePurchasePrice, String monthlyFeeAssigned,
			String monthlyFeeunassigned, String licensePurchaseNominal, String monthlyFeeAssignedNominal,
			String monthlyFeeUnassignedNominal, String licenseSetupCost, String licenseAssignedCost,
			String licenseUnassignedCost, String applyallSDRTariffCheckBoxvalue, String minimumDuration,
			String notificationPeriod, String quarantinePeriod,

			String primaryPackage,String[] ParentPackageCheckbox, String[] parentPackage,String[] parentServiceCheckbox, String[] parentService,String[] ownlevelServiceCheckbox,String[] ownlevelService,String secondaryPackageCheckboxValue,String commisonCategory_Reseller,String deviceRented,String upgradePriority)
			throws InterruptedException, AWTException {
		this.ClickonAdd();
		Thread.sleep(1000);
		this.AvailableToDistributor(availableToDistributor);
		this.AvailableToReseller(availableToReseller);
		this.name(name);
		this.Description(description);
		this.PackageCode(packageCode);
		this.Country(country);
		this.PackageType(packageType);
		this.AssignmentType(assignmentType);
		this.MultipleInstancesAllowed(multipleInstancesAllowedValue);
		this.IsPrimary(isPrimaryCheckboxValue);
		this.PrimaryPackage(primaryPackage);
		this.CommisonCategory_Reseller(commisonCategory_Reseller);
		this.DeviceRented(deviceRented, primaryPackage);
		this.UpgradePriority(upgradePriority,primaryPackage);
		
		this.DependentPackage(dependentPackage);
		this.KeyLampCount(keyLampCount);
		this.CanAlterPackage(canAlterPackageCheckboxValue);
		this.CanBeAssigned(canBeAssignedCheckboxValue);
		this.NoPackage(nopackageValue);
		ScrollPage(driver, "0,300");
		this.NumberCategory(CategoryCheckbox, numberCategory);
		this.ParentPackage(ParentPackageCheckbox, parentPackage);
	
		this.Service(ServiceCheckbox, userPackage, secondaryPackageCheckboxValue);
		this.ParentService(parentServiceCheckbox, parentService);
		this.OwnLevelServices(ownlevelServiceCheckbox,ownlevelService);
		
		ScrollPage(driver, "0,2000");
		this.NextButton();
		this.FreeDays(freeDays);
		this.SetupCharge(setupCharge);
		this.RecurringCharge(recurringCharge);
		this.CeaseCharge(ceaseCharge);
		this.RebateValue(rebateValue);
		this.SecondaryRebateValue(secondaryRebateValue);
		this.SetupChargeNominalCode(setupChargeNominalCode);
		this.RecurringChargeNominalCode(recurringChargeNominalCode);
		this.CeaseChargeNominalCode(ceaseChargeNominalCode);
		this.SetupCostBuy(setupCostBuy);
		this.RecurringCostBuy(recurringCostBuy);
		this.CeaseCostBuy(ceaseCostBuy);

		this.LicensePurchasePrice(licensePurchasePrice);
		this.MonthlyFeeAssigned(monthlyFeeAssigned);
		this.MonthlyFeeUnassigned(monthlyFeeunassigned);
		this.LicensePurchaseNominal(licensePurchaseNominal);
		this.MonthlyFeeAssignedNominal(monthlyFeeAssignedNominal);
		this.MonthlyFeeUnassignedNominal(monthlyFeeUnassignedNominal);
		this.LicenseSetupCost(licenseSetupCost);
		this.LicenseAssignedCost(licenseAssignedCost);
		this.LicenseUnassignedCost(licenseUnassignedCost);
		this.ApplyallSDRTariff(applyallSDRTariffCheckBoxvalue);
		this.NextButton();
		Thread.sleep(5000);
		this.MinimumDuration(minimumDuration);
		this.NotificationPeriod(notificationPeriod);
		this.QuarantinePeriod(quarantinePeriod);
		this.Finish();
		Thread.sleep(22000);
		this.servervalidation();
		this.Cancel();
	

	}

	/********************
	 * CommonMethod
	 ********************/

	public void Validation(String GetValiadtion, String Setvalidation) throws InterruptedException, AWTException {

		if (GetValiadtion.equals("Dependent package assignment type is not the same as the current assignment type.Either both must be `Hosted` or `SIP` or `Both` or combination of `Hosted/SIP` & `Both`")) {
			System.out.println("Package Type :- User Package & Secondary Package Selected , Validation is showing correct as Dependent package assignment type is not the same as the current assignment type.Either both must be `Hosted` or `SIP` or `Both` or combination of `Hosted/SIP` & `Both`");
			Thread.sleep(2000);
			ScrollPage(driver, "0,2000");
			Thread.sleep(2000);
			this.Cancel();
		}

		else if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.err.println("Validation is incorrect: " + GetValiadtion);
			Assert.fail("Test fail for chceking validation : (Expected Result : " + Setvalidation + " Actual Result : "
					+ GetValiadtion);
		}

	}

	public void servervalidation() {
		List<WebElement> dynamicElement = driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p"));
		if (dynamicElement.size() != 0) {
			ArrayList<String> servervalidlist = new ArrayList<String>();
			int count = driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p")).size();
			for (int j = 0; j < servervalidation.length; j++) {
				servervalidlist.add(servervalidation[j]);
			}
			if (count < 1) {
				String getvalidation = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p"))
						.getText();
				if (servervalidlist.contains(getvalidation)) {
					System.out.println("Server validtion Showing correct : " + getvalidation);
				} else {
					System.err.println("Server validation showing incorrect ");
					Assert.fail("Test fail  for checking servervalidation");
				}
			} else {
				for (int i = 1; i <= count; i++) {
					String getvalidation = driver
							.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p[" + i + "]"))
							.getText();
					if (servervalidlist.contains(getvalidation)) {
						System.out.println("Server validtion Showing correct : " + getvalidation);
					} else {
						System.err.println("Server validation showing incorrect ");
						Assert.fail("Test fail  for checking servervalidation");
					}
				}
			}
		} else {
			System.out.println("There no server validation to check");
		}
	}

	String Text4;
	String Text0;
	String CheckBox4;
	String CheckBox0;

	public void Multiple_CheckBox_Selection(String[] labels, String Count, String Text,String CheckboxID,String CheckBox,String[] CheckBoxvalue)
			throws InterruptedException {
		String pass = "";
		String fail = "";
		ArrayList<String> ListLabel = new ArrayList<String>();
//
		for (int j = 0; j <= labels.length - 1; j++) {
			ListLabel.add(labels[j]);
		}

		int Counts = driver.findElements(By.xpath(Count)).size();
	//	System.out.println(ListLabel.size());
		for (int j = 0; j < ListLabel.size(); j++) {
		//	System.out.println(Counts);
			for (int i = 1; i <= Counts; i++) {
				String number = Integer.toString(i);
				String xpath1 = Text.replace("x", number);
				String xpath2 = CheckBox.replace("x", number);
				String xpath3 = CheckboxID.replace("x", number);   
				String text = driver.findElement(By.xpath(xpath1)).getText();
//				System.out.println(ListLabel.get(j));
//				System.out.println(text);
				if (ListLabel.get(j).equals(text)) {
					Thread.sleep(3000);
					WebElement Xpath2= driver.findElement(By.xpath(xpath2));
					String checkBoxvalue = CheckBoxvalue[j];
					String Valueofcheckbox = driver.findElement(By.xpath(xpath3)).getAttribute("checked");
					if (checkBoxvalue.toUpperCase().equals("YES")) {
						if (Valueofcheckbox == null) {
																				
							Xpath2.click();
							Thread.sleep(2000);
							String checkboxchecked = driver.findElement(By.xpath(xpath3)).getAttribute("checked");
							if (checkboxchecked==null) {
								System.err.println(	text + " CheckBox not checked " + "(expect : Checked, Result : Not-Checked)");
								Assert.fail("Test fail for " + text + " CheckBox check"+ "(expect : Checked, Result : Not-Checked)");
							} else {
								System.out.println(text + " CheckBox is : checked");	
								
							}
						} else {
							System.out.println(text + " CheckBox is Already checked");
						}
					} else if (checkBoxvalue.toUpperCase().equals("NO")) {
						if (Valueofcheckbox == null) {
							System.out.println(text + " CheckBox is Already Unchecked");
						} else {
							Xpath2.click();
							Thread.sleep(2000);
							String checkboxUNchecked = driver.findElement(By.xpath(xpath3)).getAttribute("checked");
							if (checkboxUNchecked == null) {
								System.out.println(text + " CheckBox is : UNchecked");
							} else {
								System.err.println(text + " CheckBox not Unchecked" + "(expect : UnChecked, Result : Checked)");
								Assert.fail("Test fail for " + text + " CheckBox  Uncheck"+ "(expect : UnChecked, Result : Checked)");
							}
						}
					} else {
						if (Valueofcheckbox == null) {
							System.out.println("There is no change in " + text + " CheckBox is unchecked : Defult");
						} else {
							System.out.println("There is no change in " + text + " CheckBox is checked : Defult");
						}
					}
				
									
				}
					
//					Thread.sleep(3000);
//					pass = text + " Checkbox  is found";
//					break;
				} 
			
//			else {
//					fail = ListLabel.get(j) + " Checkbox  is not found";
//
//				}

			}
//			if (pass.equals("")) {
//				System.err.println(fail);
//				Assert.fail("Test Fail, " + fail);
//				pass="";
//				fail="";
//			} else {
//				System.out.println(pass);
//				pass="";
//				fail="";			
//			}
			
		}
	}
	
	
