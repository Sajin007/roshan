package Portaluser;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.drd.uboss5.keywords.keywords;

/*-- =============================================
-- Author		:Roshan Raju
-- Created Date : 31- March-2020
-- Description	:Portal user edit and delete page
-- Modified by	:Roshan Raju
-- Modified Date:11- November-2020
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class Portaluser_Edit extends keywords {

	WebDriver driver;
	@FindBy(id = "btn_add")
	WebElement Addbutton;
	@FindBy(id = "txtEmail")
	WebElement Email;
	@FindBy(id = "txtPassword")
	WebElement Password;
	@FindBy(id = "txtConfirmPassword")
	WebElement Confirmpassword;
	@FindBy(id = "Name")
	WebElement Displayname;
	@FindBy(id = "txtPhoneNumber")
	WebElement Phonenumber;
	@FindBy(id = "ddlRoleRecording")
	WebElement callrecordingsecurity;
	@FindBy(id = "listBuddyAgents")
	WebElement tickeAgentlist;
	@FindBy(id = "ToUser")
	WebElement Ticketmovesto;
	@FindBy(id = "listBuddy")
	WebElement buddylist;
	@FindBy(id = "COMMONA716")
	WebElement buddyadd;
	@FindBy(id = "SERVICE181")
	WebElement Removebutton;
	@FindBy(id = "TimeZoneID")
	WebElement Timezone;
	@FindBy(id = "ddlLanguage")
	WebElement Language;
	@FindBy(id = "update")
	WebElement save;
	@FindBy(id = "txtUserImage")
	WebElement Photos;
	@FindBy(xpath = "//*[@id=\"user_role_data\"]/tbody/tr[1]/td[1]/label/span")
	WebElement userrolecheckbox;
	@FindBy(xpath = "//*[@id=\"form-portaluser\"]/div/div[4]/div[2]/div/div/div[1]/label/span")
	WebElement ticketstausdefaultcheckbox;
	@FindBy(xpath = "//*[@id=\"form-portaluser\"]/div/div[4]/div[3]/div/div/div[1]/label/span[1]")
	WebElement relesenotificationcheckbox;
	@FindBy(xpath = "//*[@id=\"form-portaluser\"]/div/div[4]/div[4]/div/div/div[7]/label/span")
	WebElement numberportstatuscheckbox;
	@FindBy(xpath = "//*[@id=\"actionbuttons\"]/div/a")
	WebElement cancel;

	@FindBy(id = "search_data")
	WebElement Search;

	@FindBy(xpath = "//*[@id=\"datagrid\"]/tbody/tr/td[1]/a/u")
	WebElement searchlink;

	@FindBy(xpath = "//*[@id=\"search_btn\"]/i")
	WebElement Search_Button;

	@FindBy(xpath = "//*[@id=\"tabs\"]/li[2]/a/span[2]")
	WebElement Roletab;

	@FindBy(xpath = "//*[@id=\"tabs\"]/li[3]/a/span[2]")
	WebElement Tickettab;

	@FindBy(xpath = "//*[@id=\"tabs\"]/li[4]/a/span[2]")
	WebElement Numberportstatustab;

	@FindBy(xpath = "//span[contains(.,'ACTIVITY LOG')]")
	WebElement Activitylogtab;

	@FindBy(xpath = "//*[@id=\"datagrid\"]/tbody/tr/td[3]")
	WebElement logdetails;

	@FindBy(xpath = "/html/body/div[4]/div/div/div[2]/div")
	WebElement POPUPMSG;

	@FindBy(id = "deletefull")
	WebElement Delete;

	@FindBy(xpath = "/html/body/div[4]/div/div/div[3]/button[1]")
	WebElement Delete_popup;

	@FindBy(xpath = "//*[@id=\"settings\"]/div/div/label/span")
	WebElement includeremovedcheck;

	@FindBy(xpath = "//*[@id=\"btn_settings\"]/i")
	WebElement settings;

	public Portaluser_Edit(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}

	public void Searchbutton(String srch) throws InterruptedException, AWTException {
		Thread.sleep(7000);
		Inputdata(Search, srch, "Search..");
		Thread.sleep(4000);
		Search_Button.click();
	}

	public void textlink() throws InterruptedException, AWTException {
		Thread.sleep(9000);
		searchlink.click();

	}

	public void password_Edit(String passsword) throws InterruptedException {

		Thread.sleep(1000);
		Inputdata(Password, passsword, "Password");
	}

	public void phonenumber_Edit(String phonenumber) throws InterruptedException {

		Thread.sleep(1000);
		Inputdata(Phonenumber, phonenumber, "Phone Numbers");
	}

	public void Confirmpassword_Edit(String confirmpassword) throws InterruptedException {

		Thread.sleep(1000);
		Inputdata(Confirmpassword, confirmpassword, "Confirm Password");
	}

	public void timezone_Edit(String timezone) throws InterruptedException {

		dropdown(Timezone, timezone, "Time Zone");
	}

	public void language_Edit(String language) throws InterruptedException {

		dropdown(Language, language, "Language");
	}

	public void displayname_Edit(String displayname) throws InterruptedException {

		Thread.sleep(1000);
		Inputdata(Displayname, displayname, "Display Name");
	}

	public void callrecordingsecurity_Edit(String callrecordingsecurity1) throws InterruptedException {

		dropdown(callrecordingsecurity, callrecordingsecurity1, "Call Recording Security");

	}

	public void clickonsave() throws InterruptedException {

		Thread.sleep(4000);
		save.click();

	}

	public void clickoncancel() throws InterruptedException {

		Thread.sleep(4000);
		cancel.click();

	}

	public void delete() throws InterruptedException, AWTException {
		Thread.sleep(2000);
		ScrollPage(driver, "0,+600");
		Thread.sleep(7000);
		Delete.click();
		Thread.sleep(4000);
		String popupmessage = "Do you want to delete the portal user?";
		String Popup = POPUPMSG.getText();
		if (popupmessage.equals(Popup)) {

			Thread.sleep(2000);

			System.out.println("Pop up message displayed is correct");
		}

		else {

			System.out.println("Pop up message is not correct");
		}

		Delete_popup.click();

	}

	public void clickonRoletab() throws InterruptedException, AWTException {

		Thread.sleep(1000);
		ScrollPage(driver, "0,-600");
		Roletab.click();

	}

	public void clickonTickettab() throws InterruptedException {

		Thread.sleep(5000);
		Tickettab.click();

	}
	
	public void Ticketmovesto(String ticketmovesto) throws InterruptedException, AWTException {

		dropdown(Ticketmovesto, ticketmovesto, "Ticket Moves To");
		ScrollPage(driver, "0,+400");

	}
//	
//	public void FreeDays(String freeDays) throws InterruptedException {
//		try {
//			PO
//		Inputdata(FreeDays, freeDays, "Free Days");
//		}catch(org.openqa.selenium.NoSuchElementException D) {
//			try {
//			Disti
//			Inputdata(FreeDays, freeDays, "Free Days");
//			}catch (Exception R) {
//				try {
//					Res
//				}catch (Exception B) {
//					try {
//						BillingB
//					}catch (Exception EB) {
//						EB
//					}
//				}
//			}
//		}
//	}



	public void TicketBuddy(String[] buddynames, String[] buttons) throws InterruptedException {
		
		
		try {
			
			
			String pass = "";
			String fail = "";
			for (int j = 0; j < buddynames.length; j++) {
				String buddy = buddynames[j];
				if (buttons[j].toUpperCase().equals("ADD")) {
					String Count = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[3]/div/div[3]/div/div/div[1]/select/option";
					String Text = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[3]/div/div[3]/div/div/div[1]/select/option[x]";
					String buddylistadd = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[3]/div/div[3]/div/div/div[1]/select/option[x]";
					String[] Buddy= {buddy};
					this.listselect(Buddy, Count, Text, buddylistadd);
					Thread.sleep(1000);
					buddyadd.click();
					Thread.sleep(2000);
					int Counts_buddy = driver.findElements(By.xpath(
							"/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[3]/div/div[3]/div/div/div[3]/select/option"))
							.size();
					for (int i = 1; i <= Counts_buddy; i++) {
					String Text_buddies = driver.findElement(By.xpath(
								"/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[3]/div/div[3]/div/div/div[3]/select/option["
										+ i + "]"))
								.getText();
						Thread.sleep(5000);
					if(Text_buddies.equals(buddy)) {			
						Thread.sleep(4000);
						pass = buddy + " is added as buddy and present in the filed";
						break;
					} else {
						fail = buddy + " is not added and not present in the field";
					}

					}
					if (pass.equals("")) {
						System.err.println(fail);
						Assert.fail("Test Fail, " + fail);
						pass="";
						fail="";
					} else {
						System.out.println(pass);
						pass="";
						fail="";
						
					}
				
				} else if (buttons[j].toUpperCase().equals("REMOVE")) {
					
				   try {
					   
					   
					   String Count = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[3]/div/div[3]/div/div/div[3]/select/option";
						String Text = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[3]/div/div[3]/div/div/div[3]/select/option[x]";
						String buddylistadd = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[3]/div/div[3]/div/div/div[3]/select/option[x]";
						String[] RemoveBuddy= {buddy};
						this.listselect(RemoveBuddy, Count, Text, buddylistadd);
						Removebutton.click();
						Thread.sleep(4000);
						
						int Counts_buddy = driver.findElements(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[3]/div/div[3]/div/div/div[3]/select/option")).size();
						System.out.println(Counts_buddy);
						//for (int i = Counts_buddy; i <= Counts_buddy; i--) {
						
						for (int i =Counts_buddy; i <= Counts_buddy; i++) {
								Thread.sleep(4000);
						String Text_buddiesremove = driver.findElement(By.xpath(
									"/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[3]/div/div[3]/div/div/div[3]/select/option["+ i + "]")).getText();
						System.out.println(Text_buddiesremove);
							Thread.sleep(5000);
							if(Text_buddiesremove.contains(buddy)) {			
							Thread.sleep(5000);
							System.out.println(buddy + " present");
							}
							
							
							else {
								
								System.out.println(buddy + " removed");
							}
							
						
							}
					
				} 
					catch (org.openqa.selenium.NoSuchElementException e) {
						System.out.println("Buddy list empty");
					}
					
					
				}
					
				
			//	
				
				
					
				}
			
		} catch (AssertionError e) {
			System.out.println("Buddy list section not present");
		}
		
		
			
			}
	
		
			
	         
			
		
	

		

	

	public void listselect(String[] labels, String Count, String Text, String buddylistadd)
			throws InterruptedException {
		String pass = "";
		String fail = "";
		ArrayList<String> ListLabel = new ArrayList<String>();

		for (int j = 0; j <= labels.length - 1; j++) {
			ListLabel.add(labels[j]);
		}

		int Counts = driver.findElements(By.xpath(Count)).size();
		for (int j = 0; j < ListLabel.size(); j++) {
			for (int i = 1; i <= Counts; i++) {
				String number = Integer.toString(i);
				String xpath1 = Text.replace("x", number);
				String xpath2 = buddylistadd.replace("x", number);
				String text = driver.findElement(By.xpath(xpath1)).getText();
				if (ListLabel.get(j).equals(text)) {
					driver.findElement(By.xpath(xpath2)).click();
					Thread.sleep(2000);
					pass = text + " name given as input  is found";
					break;
				} else {
					fail = text + " name given as input  is not found";
				}

			}
			if (pass.equals("")) {
				System.err.println(fail);
				Assert.fail("Test Fail, " + fail);
				pass="";
				fail="";
			} else {
				System.out.println(pass);
				pass="";
				fail="";
			}
		}
	}

	public void clickonnumberportstatustab() throws InterruptedException, AWTException {

		Thread.sleep(3000);
		ScrollPage(driver, "0,-600");
		Numberportstatustab.click();

	}

	public void clickonactivitylogtab() throws InterruptedException {

		Thread.sleep(3000);
		Activitylogtab.click();

		Thread.sleep(4000);
		String log = "Portal User Created";
		String activitylogdetails = logdetails.getText();
		if (log.equals(activitylogdetails)) {

			Thread.sleep(2000);

			System.out.println(activitylogdetails);
		}

		else {

			System.out.println("log detail is not correct");
		}

	}

	public void setuserrolecheckbox_edit(String[] UserRole) throws AWTException, InterruptedException {
		String Count = "//*[@id=\"role\"]/div/div/div/div/div/table/tbody/tr";
		String Text = "//*[@id=\"role\"]/div/div/div/div/div/table/tbody/tr[1]/td[2]";
		String CheckBox = "//*[@id=\"role\"]/div/div/div/div/div/table/tbody/tr[1]/td[1]/label/span";
		this.Multiple_CheckBox_Selection(UserRole, Count, Text, CheckBox);

	}

	public void TicketStatusDefaults_edit(String[] Status) {
		String Count = "//*[@id=\"ticket\"]/div/div[1]/div/div/div/div";
		String Text = "//*[@id=\"ticket\"]/div/div[1]/div/div/div/div[0]/label";
		String CheckBox = "//*[@id=\"ticket\"]/div/div[1]/div/div/div/div[0]/label/span";
		this.Multiple_CheckBox_Selection(Status, Count, Text, CheckBox);

	}

	public void messagingpreferencecheckbox_edit(String[] releasenotifi) {

		String Count = "//*[@id=\"message\"]/div/div/div/div/div/div";
		String Text = "//*[@id=\"message\"]/div/div/div/div/div/div[0]/label/span[2]";
		String CheckBox = "//*[@id=\"message\"]/div/div/div/div/div/div[0]/label/span[1]";
		this.Multiple_CheckBox_Selection(releasenotifi, Count, Text, CheckBox);

	}

	public void numberportcheckbox_edit(String[] numberport) {

		String Count = "//*[@id=\"numberport\"]/div/div/div/div/div/div";
		String Text = "//*[@id=\"numberport\"]/div/div/div/div/div/div[0]/label";
		String CheckBox = "//*[@id=\"numberport\"]/div/div/div/div/div/div[0]/label/span";
		this.Multiple_CheckBox_Selection(numberport, Count, Text, CheckBox);

	}

	/***********************************
	 * Validation elements
	 *****************************************/

	@FindBy(id = "Name-error")
	WebElement Displaynamevalidation;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDeletemessenger;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement Buddyvalidation;
	@FindBy(id = "txtConfirmPassword-error")
	WebElement ConfirmPasswordvalidation;
	@FindBy(id = "TimeZoneID-error")
	WebElement timezonevalidation;

	String[] Displaynameval = { "Display Name cannot be empty" };
	String[] SaveVal = { "Saved successfully" };
	String[] DeletVal = { "Deleted successfully" };
	String[] BuddyVal = {"Unable to add selected Buddy,The Edited user and the selected buddy does not belongs to the same queue/assigned ticket queue" };
	String[] ConfirmpasswordVal = { "Confirm password should be the same as New Password" };
	String[] Timezoneval = { "Select Time Zone" };

	public void Displayname_Edit() throws InterruptedException {
		Thread.sleep(1000);
		Displayname.clear();
	}

	public void PhotoEdit(String FilePath) throws InterruptedException, AWTException {
		Thread.sleep(2000);
		Photos.click();
		Thread.sleep(2000);
		this.UploadFile(FilePath);
		Thread.sleep(4000);
		this.checkuploadedfileerrorValidationEdit();
		Thread.sleep(12000);
	}

	public void Displaynameval() throws InterruptedException {

		try {

			Thread.sleep(2000);
			String[] setvalidation = Displaynameval;
			String getValiadtion = Displaynamevalidation.getText();
			Validation(getValiadtion, setvalidation);

		} catch (org.openqa.selenium.NoSuchElementException e) {
			System.out.println("no validation for display name while passing input");
		}
	}

	public void ConfirmpasswordVal() throws InterruptedException {

		try {

			Thread.sleep(2000);
			String[] setvalidation = ConfirmpasswordVal;
			String getValiadtion = ConfirmPasswordvalidation.getText();
			Validation(getValiadtion, setvalidation);
		}

		catch (org.openqa.selenium.NoSuchElementException e) {
			System.out.println("no validation for confirm password field while passing input");
		}

	}

	public void Timezoneval() throws InterruptedException {

		try {

			Thread.sleep(2000);
			String[] setvalidation = Timezoneval;
			String getValiadtion = timezonevalidation.getText();
			Validation(getValiadtion, setvalidation);

		}

		catch (org.openqa.selenium.NoSuchElementException e) {
			System.out.println("no validation for Timezone while selecting value in dropdown");
		}

	}

	public void checkuploadedfileerrorValidationEdit() throws InterruptedException {
		try {
			Thread.sleep(5000);
			String uploaderrormessage = "The file is not allowed (jpg, jpeg, pjpeg, gif, x-png, png, bmp only).";
			Thread.sleep(5000);
			String uploadedfileerror = driver.findElement(By.xpath(
					"/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[1]/div/div[7]/div[3]/div/div/div[3]/ul/li"))
					.getText();
			Thread.sleep(5000);
			System.out.println(uploadedfileerror);
			if (uploadedfileerror.equals(uploaderrormessage)) {
				System.out.println("invalid file or file not selected");
			}
		} catch (org.openqa.selenium.NoSuchElementException e) {
			System.out.println("Valid file is selected");
		}
	}

	public void BuddyVal() throws InterruptedException {
		Thread.sleep(5000);
		String[] setvalidation = BuddyVal;
		String getValiadtion = Buddyvalidation.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void SaveVal() throws InterruptedException {
		Thread.sleep(2000);
		String[] setvalidation = SaveVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void DeleteVal() throws InterruptedException {
		Thread.sleep(8000);
		String[] setvalidation = DeletVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void Save_validation() throws InterruptedException {
		this.SaveVal();
	}

	public void Delete_validation() throws InterruptedException {
		this.DeleteVal();
	}

	public void validation_Edit() throws InterruptedException {

		this.Displaynameval();
		this.ConfirmpasswordVal();
		this.Timezoneval();

	}

	public void includeremovedcheck(String deletedValue) throws InterruptedException {
		settings.click();
		Thread.sleep(4000);
		includeremovedcheck.click();
		Thread.sleep(5000);
		int Counts = driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")).size();
		System.out.println(Counts);
		Thread.sleep(2000);
		for (int i = 1; i <= Counts; i++) {
			String inputvalue = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr[" + i + "]/td[2]"))
					.getText();
			System.out.println(inputvalue);
			if (inputvalue.equals(deletedValue)) {

				String color = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr[" + i + "]/td[2]"))
						.getCssValue("color");
				String[] hexValue = color.replace("rgba(", "").replace(")", "").split(",");

				int hexValue1 = Integer.parseInt(hexValue[0]);
				hexValue[1] = hexValue[1].trim();
				int hexValue2 = Integer.parseInt(hexValue[1]);
				hexValue[2] = hexValue[2].trim();
				int hexValue3 = Integer.parseInt(hexValue[2]);

				String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);
				System.out.println(actualColor);
				Assert.assertEquals("#fc4b6c", actualColor);
				System.out.println(deletedValue + " is deleted and also listed in include removed");

			}
		}
	}

	/********************************
	 * Main Method
	 ***********************************/

	public void Portaluser_Edit_validation(String Search, String Password, String Phone_Numbers, String Time_Zone,
			String Language, String Photo, String Display_Name, String Confirm_Password, String Call_Recording_Security)
			throws InterruptedException, AWTException {
		this.Searchbutton(Search);
		this.textlink();
		this.password_Edit(Password);
		this.phonenumber_Edit(Phone_Numbers);
		this.timezone_Edit(Time_Zone);
		this.language_Edit(Language);
		this.PhotoEdit(Photo);
		this.displayname_Edit(Display_Name);
		this.Confirmpassword_Edit(Confirm_Password);
		this.callrecordingsecurity_Edit(Call_Recording_Security);
		this.clickonsave();
		this.validation_Edit();
		this.clickoncancel();
	}

	public void Portaluser_edit(String Search, String Password, String Phone_Numbers, String Time_Zone, String Language,
			String Photo, String Display_Name, String Confirm_Password, String Call_Recording_Security,
			String[] setuserrolecheckbox, String[] TicketStatusDefaults, String ticketmovesto, String [] buttons,String[] buddynames,
			String[] numberportcheckbox) throws InterruptedException, AWTException {
		this.Searchbutton(Search);
		this.textlink();
		this.password_Edit(Password);
		this.phonenumber_Edit(Phone_Numbers);
		this.timezone_Edit(Time_Zone);
		this.language_Edit(Language);
		//this.PhotoEdit(Photo);
		this.displayname_Edit(Display_Name);
		this.Confirmpassword_Edit(Confirm_Password);
		this.callrecordingsecurity_Edit(Call_Recording_Security);
		this.clickonRoletab();
		this.setuserrolecheckbox_edit(setuserrolecheckbox);
		this.clickonTickettab();
		this.TicketStatusDefaults_edit(TicketStatusDefaults);
		this.Ticketmovesto(ticketmovesto);
		this.TicketBuddy(buddynames,buttons);
		this.clickonnumberportstatustab();
//		this.numberportcheckbox_edit(numberportcheckbox);
//		this.clickonactivitylogtab();
//		this.clickonRoletab();
//		this.clickonsave();
//		this.Save_validation();

	}

	public void Portaluser_Delete(String Search) throws InterruptedException, AWTException {
		this.Searchbutton(Search);
		this.textlink();
		this.delete();
		this.Delete_validation();
		Thread.sleep(8000);
		this.includeremovedcheck(Search);

	}

	/**************************************
	 * CommonMethod
	 *************************************************************/

	// Validation

	public void Validation(String GetValiadtion, String Setvalidation) {
		PageFactory.initElements(driver, this);
		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.out.println("Validation is incorrect: " + GetValiadtion);
			Assert.fail("Test Fail");
		}

	}

	public void UploadFile(String FilePath) throws InterruptedException, AWTException {
		String filePath = System.getProperty("user.dir") + "\\src\\main\\java\\com\\drd\\uboss5\\attachments\\"
				+ FilePath;
		driver.switchTo().activeElement().sendKeys(filePath);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_CONTROL);
	}

	/******************************************/
	String Text0;
	String Text4;
	String CheckBox0;
	String CheckBox4;

	/*****************************************/

	public void Multiple_CheckBox_Selection(String[] labels, String Count, String Text, String CheckBox) {
		if (Text.contains("table")) {
			String[] SPLITTEXT = Text.split("tr", 2);
			String Text1 = SPLITTEXT[0];
			String Text2 = SPLITTEXT[1];
			String[] Text3 = Text2.split("1", 2);
			Text4 = Text3[1];
			Text0 = Text1 + "tr[";
		} else {
			String[] SPLITTEXT = Text.split("0", 2);
			String Text1 = SPLITTEXT[0];
			String Text2 = SPLITTEXT[1];
			Text4 = Text2;
			Text0 = Text1;
		}
		if (CheckBox.contains("table")) {
			String[] SPLITCheckBox = CheckBox.split("tr", 2);
			String CheckBox1 = SPLITCheckBox[0];
			String CheckBox2 = SPLITCheckBox[1];
			String[] CheckBox3 = CheckBox2.split("1", 2);
			CheckBox4 = CheckBox3[1];
			CheckBox0 = CheckBox1 + "tr[";
		} else {
			String[] SPLITCheckBox = CheckBox.split("0", 2);
			String CheckBox1 = SPLITCheckBox[0];
			String CheckBox2 = SPLITCheckBox[1];
			CheckBox4 = CheckBox2;
			CheckBox0 = CheckBox1;

		}

		ArrayList<String> ListLabel = new ArrayList<String>();

		for (int j = 0; j <= labels.length - 1; j++) {
			ListLabel.add(labels[j]);
		}

		int Counts = driver.findElements(By.xpath(Count)).size();
		for (int i = 1; i <= Counts; i++) {
			String text = driver.findElement(By.xpath(Text0 + i + Text4)).getText();
			if (ListLabel.contains(text)) {
				driver.findElement(By.xpath(CheckBox0 + i + CheckBox4)).click();
				System.out.println(text + " Checkbox  is found and cheked");
			}

			else {

				// System.out.println("Status is not found");

			}

		}
	}

	public void ScrollPage(String ScrollBy) throws AWTException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + ScrollBy + ")");

	}

}
