package Portaluser;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.drd.uboss5.keywords.keywords;

/*-- =============================================
-- Author		:Roshan Raju
-- Created Date : 31- March-2020
-- Description	:Portal user add page
-- Modified by	:Roshan Raju
-- Modified Date: 06- November-2020
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class Portaluser_ADD extends keywords {

	WebDriver driver;
	@FindBy(id = "btn_add")
	WebElement Addbutton;
	@FindBy(id = "txtEmail")
	WebElement Email;
	@FindBy(id = "txtPassword")
	WebElement Password;
	@FindBy(id = "txtConfirmPassword")
	WebElement Confirmpassword;
	@FindBy(id = "Name")
	WebElement Displayname;
	@FindBy(id = "txtPhoneNumber")
	WebElement Phonenumber;
	@FindBy(id = "ddlRoleRecording")
	WebElement callrecordingsecurity;
	@FindBy(id = "TimeZoneID")
	WebElement Timezone;
	@FindBy(xpath = "//*[@id=\"form-portaluser\"]/div/div[3]/div[6]/div/label/span[1]")
	WebElement sendemailcheckbox;
	@FindBy(id = "ddlLanguage")
	WebElement Language;
	@FindBy(id = "add")
	WebElement save;
	@FindBy(id = "txtUserImage")
	WebElement Photos;
	@FindBy(xpath = "//*[@id=\"user_role_data\"]/tbody/tr[1]/td[1]/label/span")
	WebElement userrolecheckbox;
	@FindBy(xpath = "//*[@id=\"form-portaluser\"]/div/div[4]/div[2]/div/div/div[1]/label/span")
	WebElement ticketstausdefaultcheckbox;
	@FindBy(xpath = "//*[@id=\"form-portaluser\"]/div/div[4]/div[3]/div/div/div[1]/label/span[1]")
	WebElement relesenotificationcheckbox;
	@FindBy(xpath = "//*[@id=\"form-portaluser\"]/div/div[4]/div[4]/div/div/div[7]/label/span")
	WebElement numberportstatuscheckbox;
	@FindBy(id = "btn_cancel")
	WebElement cancel;

	public Portaluser_ADD(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}

	public void clickonAdd() throws InterruptedException {

		Thread.sleep(6000);
		Addbutton.click();
	}

	public void setemail(String email) throws InterruptedException {

		Inputdata(Email, email, "Email");
	}

	public void setpassworddetails(String passsword, String confirmpassword) throws InterruptedException {

		Inputdata(Password, passsword, "Password");
		Inputdata(Confirmpassword, confirmpassword, "Confirm Password");

	}

	public void setdisplayname(String displayname) throws InterruptedException {

		Inputdata(Displayname, displayname, "Display Name");

	}

	public void setphonenumber(String phonenumber) throws InterruptedException {

		Inputdata(Phonenumber, phonenumber, "Phone Numbers");

	}

	public void setcallrecordingsecurity(String callrecordingsecurity1) throws InterruptedException {

		dropdown(callrecordingsecurity, callrecordingsecurity1, "Call Recording Security");
	}
	
	

	public void Photo(String FilePath) throws InterruptedException, AWTException {
		Thread.sleep(2000);
		Photos.click();
		Thread.sleep(2000);
		this.UploadFile(FilePath);
		Thread.sleep(4000);
		this.checkuploadedfileerrorValidation();
		Thread.sleep(10000);
	}

	public void SendEmailcheckbox(String sendEmailcheckbox) throws InterruptedException {

		Thread.sleep(2000);
		Checkbox(driver, "chkSendMail", sendemailcheckbox, sendEmailcheckbox, "Send Email");
	}

	public void settimezone(String timezone) throws InterruptedException, AWTException {
		dropdown(Timezone, timezone, "Time Zone");
	}

	public void setlanguage(String language) throws InterruptedException {

		dropdown(Language, language, "Language");

	}

	public void TicketStatusDefaults(String[] Status) throws InterruptedException {
		String Count = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[4]/div[2]/div/div/div";
		String Text = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[4]/div[2]/div/div/div[x]/label";
		String CheckBox = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[4]/div[2]/div/div/div[x]/label/span";
		this.Multiple_CheckBox_Selection(Status, Count, Text, CheckBox);

	}

	public void setuserrolecheckbox(String[] UserRole) throws AWTException, InterruptedException {
		String Count = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[4]/div[1]/div/div/table/tbody/tr";
		String Text = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[4]/div[1]/div/div/table/tbody/tr[x]/td[2]";
		String CheckBox = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[4]/div[1]/div/div/table/tbody/tr[x]/td[1]/label/span";

		this.Multiple_CheckBox_Selection(UserRole, Count, Text, CheckBox);

	}

	public void numberportcheckbox(String[] numberport) throws InterruptedException {

		String Count = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[4]/div[3]/div/div/div";
		String Text = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[4]/div[3]/div/div/div[x]/label";
		String CheckBox = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[4]/div[3]/div/div/div[x]/label/span";
		this.Multiple_CheckBox_Selection(numberport, Count, Text, CheckBox);

	}

	public void clickonsave() throws InterruptedException {

		Thread.sleep(4000);
		save.click();

	}

	public void clickoncancel() throws InterruptedException {

		Thread.sleep(4000);
		cancel.click();

	}

	/***********************************
	 * Validation elements
	 *****************************************/

	@FindBy(id = "txtEmail-error")
	WebElement Emailvalidation;
	@FindBy(id = "txtPassword-error")
	WebElement Passwordvalidation;
	@FindBy(id = "txtConfirmPassword-error")
	WebElement ConfirmPasswordvalidation;
	@FindBy(id = "Name-error")
	WebElement Displaynamevalidation;
	@FindBy(id = "TimeZoneID-error")
	WebElement timezonevalidation;
	@FindBy(id = "roleids[]-error")
	WebElement userrolevalidation;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDeletemessenger;

	String[] Emailval = { "Email cannot be empty","Email ID is in incorrect format" };
	String[] Passwordval = { "Password cannot be empty" };
	String[] ConfirmpasswordVal = { "Confirm Password cannot be empty","Confirm password should be the same as New Password"};
	String[] Displaynameval = { "Display Name cannot be empty" };
	String[] Timezoneval = { "Select Time Zone" };
	String[] UserroleVal = { "Select atleast one user role." };
	String[] SaveVal = { "Saved successfully" };
	String[] AlreadyexistsVal = { "Already Exists" };

	public void Emailval() throws InterruptedException {
		Thread.sleep(2000);
		String[] Setvalidation = Emailval;
		String GetValiadtion = Emailvalidation.getText();
		Validation(GetValiadtion, Setvalidation);
	}

	public void Passwordval() throws InterruptedException {
		try {
			
		Thread.sleep(2000);
		String[] setvalidation = Passwordval;
		String getValiadtion = Passwordvalidation.getText();
		Validation(getValiadtion, setvalidation);
		}
		
	catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("no validation for password field while passing input");
		}
		
	}

	public void ConfirmpasswordVal() throws InterruptedException {
		Thread.sleep(2000);
		String[] setvalidation = ConfirmpasswordVal;
		String getValiadtion = ConfirmPasswordvalidation.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void Displaynameval() throws InterruptedException {
		try
		{
			Thread.sleep(2000);
			String[] setvalidation = Displaynameval;
			String getValiadtion = Displaynamevalidation.getText();
			Validation(getValiadtion, setvalidation);
			
		}
		catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("no validation for display name while passing input");
		}
		
	}

	public void Timezoneval() throws InterruptedException {
		
		try {
		
		Thread.sleep(2000);
		String[] setvalidation = Timezoneval;
		String getValiadtion = timezonevalidation.getText();
		Validation(getValiadtion, setvalidation);

	}
	
	catch(org.openqa.selenium.NoSuchElementException e)
	{
		System.out.println("no validation for Timezone while selecting value in dropdown");
	}
	
}

	public void UserroleVal() throws InterruptedException {
		
		try {
		
		Thread.sleep(2000);
		String[] setvalidation = UserroleVal;
		String getValiadtion = userrolevalidation.getText();
		Validation(getValiadtion, setvalidation);
	}
		
		catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("no validation for Userrole checkbox while checkbox is enabled");
		}
	}
	
	
	public void checkuploadedfileerrorValidation() throws InterruptedException
	{
		try
		{
		Thread.sleep(5000);
		String uploaderrormessage = "The file is not allowed (jpg, jpeg, pjpeg, gif, x-png, png, bmp only).";
		String uploadedfileerror = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/form/div/div[3]/div[5]/div/div/div[3]/ul/li")).getText();
		if(uploadedfileerror.equals(uploaderrormessage))
		{
			System.out.println("invalid file or file not selected");
		}else {
			System.err.println("There is some issue when giving invalid file");
			Assert.fail("Test fail for checking invalid file validation");
		}
		}
		catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("Valid file is selected");
		}
	}
	

	public void Save_validation() throws InterruptedException {

		Thread.sleep(2000);
		String[] Setvalidation = SaveVal;
		String GetValiadtion = SaveandDeletemessenger.getText();
		Validation(GetValiadtion, Setvalidation);
	}

	public void validation() throws InterruptedException {
		this.Emailval();
		this.Passwordval();
		this.ConfirmpasswordVal();
		this.Displaynameval();
		this.Timezoneval();
		this.UserroleVal();
	}

	/*******************************************
	 * Main Methods
	 ***************************************/

	public void portaluser_Add(String Email, String Password, String Confirm_Password, String Display_Name,
			String Phone_Numbers, String Call_Recording_Security, String Photo, String sendEmailcheckbox,String Time_Zone,
			String Language, String[] setuserrolecheckbox, String[] TicketStatusDefaults,
			String[] releasenotificationcheckbox, String[] numberportcheckbox)
			throws InterruptedException, AWTException {

		this.clickonAdd();
		this.setemail(Email);
		this.setpassworddetails(Password, Confirm_Password);
		this.setdisplayname(Display_Name);
		this.setphonenumber(Phone_Numbers);
		this.setcallrecordingsecurity(Call_Recording_Security);
		this.Photo(Photo);
		this.SendEmailcheckbox(sendEmailcheckbox);
		this.settimezone(Time_Zone);
		this.setlanguage(Language);
		this.setuserrolecheckbox(setuserrolecheckbox);
		this.TicketStatusDefaults(TicketStatusDefaults);
		this.numberportcheckbox(numberportcheckbox);
		this.clickonsave();
		this.Save_validation();

	}

	public void Portaluser_creation_validation(String Email, String Password, String Confirm_Password,
			String Display_Name, String Phone_Numbers, String Call_Recording_Security, String Photo,
			String sendEmailcheckbox, String Time_Zone, String Language, String[] setuserrolecheckbox,
			String[] TicketStatusDefaults, String[] numberportcheckbox) throws InterruptedException, AWTException {
		this.clickonAdd();
		this.setemail(Email);
		this.setpassworddetails(Password, Confirm_Password);
		this.setdisplayname(Display_Name);
		this.setphonenumber(Phone_Numbers);
		this.setcallrecordingsecurity(Call_Recording_Security);
		//this.Photo(Photo);
		this.SendEmailcheckbox(sendEmailcheckbox);
		this.settimezone(Time_Zone);
		this.setlanguage(Language);
		this.setuserrolecheckbox(setuserrolecheckbox);
		this.TicketStatusDefaults(TicketStatusDefaults);
		this.numberportcheckbox(numberportcheckbox);
		this.clickonsave();
		this.validation();
		this.clickoncancel();
		this.listTable();
	}

	/****************************************
	 * Common Method
	 **************************************************/

	public void listTable() throws InterruptedException {
		Thread.sleep(2000);
		String[] header = { "EMAIL", "DISPLAY NAME", "ROLE", "CREATED DATE", "LAST LOGIN DATE", "STATUS" };
		listpage(driver, header, "all");

	}

	
	public void UploadFile(String FilePath) throws InterruptedException, AWTException {
		String filePath = System.getProperty("user.dir") + "\\src\\main\\java\\com\\drd\\uboss5\\attachments\\"
				+ FilePath;
		driver.switchTo().activeElement().sendKeys(filePath);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_CONTROL);
	}

	/*****************/

	/********************/

	public void Multiple_CheckBox_Selection(String[] labels, String Count, String Text, String CheckBox)
			throws InterruptedException {
		String pass = "";
		String fail = "";
		ArrayList<String> ListLabel = new ArrayList<String>();

		for (int j = 0; j <= labels.length - 1; j++) {
			ListLabel.add(labels[j]);
		}

		int Counts = driver.findElements(By.xpath(Count)).size();
		for (int j = 0; j < ListLabel.size(); j++) {
			for (int i = 1; i <= Counts; i++) {
				String number = Integer.toString(i);
				String xpath1 = Text.replace("x", number);
				String xpath2 = CheckBox.replace("x", number);
				String text = driver.findElement(By.xpath(xpath1)).getText();
				if (ListLabel.get(j).equals(text)) {
					driver.findElement(By.xpath(xpath2)).click();
					pass = text + " Checkbox  is found and cheked";
					break;
				} else {
					fail = text + " Checkbox  is not found and cheked";

				}

			}
			if (pass.equals("")) {
				System.err.println(fail);
				Assert.fail("Test Fail, " + fail);
			} else {
				System.out.println(pass);
			}
		}
	}

}
