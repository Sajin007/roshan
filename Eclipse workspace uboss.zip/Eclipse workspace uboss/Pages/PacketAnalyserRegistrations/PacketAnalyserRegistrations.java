package PacketAnalyserRegistrations;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Jun 1, 2020,8:26:58 AM
-- Description	: PacketAnalyserRegistrations.java
-- Modified by	: 
-- Modified Date: 
-- Project		: UBOSS-5-0-0-Dennu
-- =============================================*/
public class PacketAnalyserRegistrations {
  WebDriver driver;
  // Registrations Tab
    @FindBy(id="tabHeader_1")
	WebElement RegistrationsTab ;
	
	@FindBy(id = "refreshbutton1")
	WebElement Refreshbtn ;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div/div[2]/div[1]/div[2]/select")
	WebElement RegtabSecondsdrpdwn ;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div/div[2]/div[1]/div[3]/div/input")
	WebElement Datetime ;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div/div[2]/div[1]/div[3]/div/div/span")
	WebElement Calendar ;
	
	@FindBy(xpath = "/html/body/div[6]/div[4]/button[2]")
	WebElement Applybtn ;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div/div[2]/div[1]/div[4]/button")
	WebElement GoTobtn ;
	
	@FindBy(id = "clear_btn")
	WebElement Clear ;
	
	@FindBy(id = "search_btn")
	WebElement Searchbtn ;
	
	@FindBy(id = "search_data")
	WebElement Searchtext ;
	
	@FindBy(xpath = "//*[@id=\"datagrid\"]/tbody/tr/td[1]/a")
	WebElement clickEdit;
	
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/div[2]/div[4]/div[2]/div/div[2]/button")
	WebElement DownloadReg;	
	
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/div[2]/div[4]/div[2]/div/div[2]/ul/li/a")
	WebElement CSVReg;
	
	//Active Registrations Tab
	
	 @FindBy(id="tabHeader_2")
	WebElement ActiveRegistrationsTab ;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div[1]/div[2]/div/div[2]/button")
	WebElement ActDownload;	
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div[1]/div[2]/div/div[2]/ul/li/a")
	WebElement ActCSV;
	//Attempted Registrations Tab
	 @FindBy(id="tabHeader_3")
	WebElement AttemptedRegistrationsTab ;
	
	@FindBy(id = "btnview")
	WebElement View ;
	
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div[1]/div/div/div[3]/div[2]/div/div[2]/button")
	WebElement DownloadAttemp;	
	
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div[1]/div/div/div[3]/div[2]/div/div[2]/ul/li/a")
	WebElement CSVAttemp;
	
	 @FindBy(id="tabHeader_4")
	WebElement UnmappedRegistrationsTab ;
	
	public PacketAnalyserRegistrations(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void GoToUrl(String Url) {
		driver.get(Url);
	}
	
	 public void Registrations_Tab(String Reg_Visibility) throws InterruptedException
		{
			
			if (Reg_Visibility.equals("Yes"))
			{
				Thread.sleep(3000);
				RegistrationsTab.click();
				Thread.sleep(3000);
				
				
			}
			else
			{
				System.out.println("Registrations Tab is not visible");
			}
		}
	
	

		 	
	 public void SetDateTime(String Datetime) throws InterruptedException {
			Thread.sleep(3000);
			String a = "document.getElementById('fromtimes').";
			String b = "value='" + Datetime + "'";
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(a + b);
		}
	 
	 public void clickonrefreshbutton() throws InterruptedException {
			
			Thread.sleep(1000);
			Refreshbtn.click();
		}
	 
	 public void Regsec_dropdown(String sec) throws InterruptedException {
			
			if (sec.equals("")) {
				System.out.println("Drop Down is not selected");
			} else {
				Thread.sleep(2000);
				Select select = new Select(RegtabSecondsdrpdwn);
				select.selectByVisibleText(sec);
			}
		}
	 
	 public void clickongotobutton() throws InterruptedException {
			
			Thread.sleep(3000);
			GoTobtn.click();
		}
	 public void ExportRegtab(String[] FileTpye) throws InterruptedException {
			System.out.println("Export Checking :");
				for (int i = 1; i <= FileTpye.length; i++) {
					String Records = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr/td")).getText();
					if(Records.equals("No data available in table")) {
						Thread.sleep(2000);
						DownloadReg.click();
						String text1 = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/div[2]/div[4]/div[2]/div/div[2]/ul/li[" + i + "]/a")).getText();					
						if (FileTpye[i-1].equals(text1)) {
						driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/div[2]/div[4]/div[2]/div/div[2]/ul/li[" + i + "]/a")).click();
						String Validation = driver.findElement(By.xpath("//*[@id=\"messenger\"]/div/div/p")).getText();
						if(Validation.equals("No records to export")) {
							System.out.println("Validation is correct : " +Validation);
							Thread.sleep(4000);
							assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
						}
						else {
							System.out.println("Validation is wrong");
							Thread.sleep(4000);
							assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
						}
					}
					}
					else if(!"No data available in table".equals(Records)) {
						Thread.sleep(2000);
						DownloadReg.click();
						String text = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/div[2]/div[4]/div[2]/div/div[2]/ul/li[" + i + "]/a")).getText();					
						if (FileTpye[i-1].equals(text)) {
							driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/div[2]/div[4]/div[2]/div/div[2]/ul/li[" + i + "]/a")).click();
							System.out.println("File type found");
							Thread.sleep(4000);
							assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
						}

						else {

							System.out.println("File type not found");

						}
					}
					else {
						System.err.println("There is an issues in page");
					}

				}
			}
		
		
		public void Clickonsearch(String searchs) throws InterruptedException {
			Searchtext.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
			Thread.sleep(3000);
			Searchtext.sendKeys(searchs);
		}
		
		public void Clickonclear() throws InterruptedException {
			Thread.sleep(1000);
			Clear.click();
			
		}
	

		public void Clickonsearchbtn() throws InterruptedException {
			Thread.sleep(1000);
			Searchbtn.click();
		}
		
		public void Clickonsearchitem() throws InterruptedException {
			Thread.sleep(1000);
			clickEdit.click();
		}

		
		public void showingrecords() throws InterruptedException
		{
		Thread.sleep(4000);
		
		int total = driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")).size();
		System.out.println("Total Number of records = " + total);
		
		for (int i = 1; i <= total; i++) 
		{
		
			String mpath = "//*[@id='datagrid']/tbody/tr[" + i + "]/td[1]";
			String fullXpath = String.format(mpath);
		
			String RPtext = driver.findElement(By.xpath(fullXpath)).getText();
			System.out.println("data  " + i + " is - " + RPtext);
		}
		
		
		}
		 public void ActiveRegistrations_Tab(String ActReg_Visibility) throws InterruptedException
			{
				
				if (ActReg_Visibility.equals("Yes"))
				{
					Thread.sleep(5000);
					//driver.findElement(By.cssSelector("#tab2")).sendKeys(Keys.CONTROL+"t");
					ActiveRegistrationsTab.click();
//					
//     				WebElement webElement = driver.findElement(By.id("tabHeader_2"));
//					webElement.sendKeys(Keys.TAB);
//					webElement.sendKeys(Keys.ENTER);
//					
//					Thread.sleep(5000);
//					
					
				}
				else
				{
					System.out.println("Active Registrations Tab is not visible");
				}
			}
		 
		 public void ExportActivetab(String[] FileTpye) throws InterruptedException {
				System.out.println("Export Checking :");
					for (int i = 1; i <= FileTpye.length; i++) {
						String Records = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr/td")).getText();
						if(Records.equals("No data available in table")) {
							Thread.sleep(2000);
							ActDownload.click();
							String text1 = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div/div/div[1]/div[2]/div/div[2]/ul/li[" + i + "]/a")).getText();					
							if (FileTpye[i-1].equals(text1)) {
							driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div/div/div[1]/div[2]/div/div[2]/ul/li[" + i + "]/a")).click();
							String Validation = driver.findElement(By.xpath("//*[@id=\"messenger\"]/div/div/p")).getText();
							if(Validation.equals("No records to export")) {
								System.out.println("Validation is correct : " +Validation);
								Thread.sleep(4000);
								assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
							}
							else {
								System.out.println("Validation is wrong");
								Thread.sleep(4000);
								assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
							}
						}
						}
						else if(!"No data available in table".equals(Records)) {
							Thread.sleep(2000);
							ActDownload.click();
							String text = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div/div/div[1]/div[2]/div/div[2]/ul/li[" + i + "]/a")).getText();					
							if (FileTpye[i-1].equals(text)) {
								driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div/div/div[1]/div[2]/div/div[2]/ul/li[" + i + "]/a")).click();
								System.out.println("File type found");
								Thread.sleep(4000);
								assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
							}

							else {

								System.out.println("File type not found");

							}
						}
						else {
							System.err.println("There is an issues in page");
						}

					}
				}
			

		 
		 public void ClickonsearchActive(String searchs) throws InterruptedException {
				Searchtext.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
				Thread.sleep(3000);
				Searchtext.sendKeys(searchs);
			}
			
			public void ClickonclearActive() throws InterruptedException {
				Thread.sleep(1000);
				Clear.click();
				
			}

			public void ClickonsearchbtnActive() throws InterruptedException {
				Thread.sleep(1000);
				Searchbtn.click();
			}
		 
		 
		 public void AttemptedRegistrations_Tab(String AttemptReg_Visibility) throws InterruptedException
			{
				
				if (AttemptReg_Visibility.equals("Yes"))
				{
					Thread.sleep(5000);
					AttemptedRegistrationsTab.click();
					Thread.sleep(5000);
					
					
				}
				else
				{
					System.out.println("Attempted Registrations Tab is not visible");
				}
			}
		 
		 public void SetFromDate(String FromDate) throws InterruptedException {
				Thread.sleep(3000);
				String a = "document.getElementById('fromdate').";
				String b = "value='" + FromDate + "'";
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript(a + b);
			}
		 
		 public void SetToDate(String ToDate) throws InterruptedException {
				Thread.sleep(3000);
				String a = "document.getElementById('todate').";
				String b = "value='" + ToDate + "'";
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript(a + b);
			}
		 public void ClickonviewbtnAttemp() throws InterruptedException {
				Thread.sleep(1000);
				View.click();
			}
		 
		 public void ExportAttempttab(String[] FileTpye) throws InterruptedException {
				System.out.println("Export Checking :");
					for (int i = 1; i <= FileTpye.length; i++) {
						String Records = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr/td")).getText();
						if(Records.equals("No data available in table")) {
							Thread.sleep(2000);
							DownloadAttemp.click();
							String text1 = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div[1]/div/div/div[3]/div[2]/div/div[2]/ul/li[" + i + "]/a")).getText();					
							if (FileTpye[i-1].equals(text1)) {
							driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div[1]/div/div/div[3]/div[2]/div/div[2]/ul/li[" + i + "]/a")).click();
							String Validation = driver.findElement(By.xpath("//*[@id=\"messenger\"]/div/div/p")).getText();
							if(Validation.equals("No records to export")) {
								System.out.println("Validation is correct : " +Validation);
								Thread.sleep(4000);
								assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
							}
							else {
								System.out.println("Validation is wrong");
								Thread.sleep(4000);
								assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
							}
						}
						}
						else if(!"No data available in table".equals(Records)) {
							Thread.sleep(2000);
							DownloadAttemp.click();
							String text = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div[1]/div/div/div[3]/div[2]/div/div[2]/ul/li[" + i + "]/a")).getText();					
							if (FileTpye[i-1].equals(text)) {
								driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div[1]/div/div/div[3]/div[2]/div/div[2]/ul/li[" + i + "]/a")).click();
								System.out.println("File type found");
								Thread.sleep(4000);
								assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
							}

							else {

								System.out.println("File type not found");

							}
						}
						else {
							System.err.println("There is an issues in page");
						}

					}
				}
			
		 
		 public void UnmappedRegistrations_Tab(String Unmap_Visibility) throws InterruptedException
			{
				
				if (Unmap_Visibility.equals("Yes"))
				{
					Thread.sleep(3000);
					UnmappedRegistrationsTab.click();
					Thread.sleep(3000);
					
					
				}
				else
				{
					System.out.println("Unmapped Registrations Tab is not visible");
				}
			}
			 			
		 public void ExportUnmaptab(String[] FileTpye) throws InterruptedException {
				System.out.println("Export Checking :");
					for (int i = 1; i <= FileTpye.length; i++) {
						String Records = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr/td")).getText();
						if(Records.equals("No data available in table")) {
							Thread.sleep(2000);
							DownloadAttemp.click();
							String text1 = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div[1]/div/div/div[3]/div[2]/div/div[2]/ul/li[" + i + "]/a")).getText();					
							if (FileTpye[i-1].equals(text1)) {
							driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div[1]/div/div/div[3]/div[2]/div/div[2]/ul/li[" + i + "]/a")).click();
							String Validation = driver.findElement(By.xpath("//*[@id=\"messenger\"]/div/div/p")).getText();
							if(Validation.equals("No records to export")) {
								System.out.println("Validation is correct : " +Validation);
								Thread.sleep(4000);
								assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
							}
							else {
								System.out.println("Validation is wrong");
								Thread.sleep(4000);
								assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
							}
						}
						}
						else if(!"No data available in table".equals(Records)) {
							Thread.sleep(2000);
							DownloadAttemp.click();
							String text = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div[1]/div/div/div[3]/div[2]/div/div[2]/ul/li[" + i + "]/a")).getText();					
							if (FileTpye[i-1].equals(text)) {
								driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/div/div[3]/div/div[1]/div/div/div[3]/div[2]/div/div[2]/ul/li[" + i + "]/a")).click();
								System.out.println("File type found");
								Thread.sleep(4000);
								assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
							}

							else {

								System.out.println("File type not found");

							}
						}
						else {
							System.err.println("There is an issues in page");
						}

					}
				}
				
		
		/*********************************************
		 * Main Method
		 * @throws Exception 
		 ***************************************/
		public void registrationtab_View(String reg,String sec,String DateTime,String searchs,String[] FileTpye,String ActReg,String searchs1,String[] FileTpye1,String AttReg,String FromDate,String ToDate,String searchs2,String[] FileTpye2,String Unmap,String FromDate1,String ToDate1,String searchs3,String[] FileTpye3) throws Exception
		{
		Thread.sleep(2000);
		this.Registrations_Tab(reg);
		Thread.sleep(2000);
		this.clickonrefreshbutton();
		Thread.sleep(2000);
		this.Regsec_dropdown(sec);
		Thread.sleep(2000);
		this.SetDateTime(DateTime);
		Thread.sleep(2000);
		this.clickongotobutton();
		Thread.sleep(2000);
		this.Clickonsearch(searchs);
		this.Clickonsearchbtn();
		this.showingrecords();
		Thread.sleep(2000);
		this.ExportRegtab(FileTpye);
		Thread.sleep(5000);
		this.Clickonsearchitem();
		Thread.sleep(5000);
		this.ActiveRegistrations_Tab(ActReg);
		Thread.sleep(3000);
		this.Clickonsearch(searchs1);
		this.Clickonsearchbtn();
		this.showingrecords();		
		this.ExportActivetab(FileTpye1);	
		this.AttemptedRegistrations_Tab(AttReg);
		this.SetFromDate(FromDate);
		this.SetToDate(ToDate);
		this.ClickonviewbtnAttemp();
		this.Clickonsearch(searchs2);
		this.Clickonsearchbtn();
		this.showingrecords();		
		this.ExportActivetab(FileTpye2);
		this.UnmappedRegistrations_Tab(Unmap);
		this.SetFromDate(FromDate1);
		this.SetToDate(ToDate1);
		this.ClickonviewbtnAttemp();
		this.Clickonsearch(searchs3);
		this.Clickonsearchbtn();
		this.showingrecords();
		this.ExportUnmaptab(FileTpye3);
		}
		

		/*********************************************
		 * Common Method
		 ***************************************/

		public void Validation(String GetValiadtion, String Setvalidation) {

			if (GetValiadtion.equals(Setvalidation)) {
				System.out.println("Validation is correct as  " + GetValiadtion);
			} else {
				System.out.println("Validation is incorrect");
				Assert.fail("Test Fail");
			}

		}

		public void ScrollPage(String ScrollBy) throws AWTException {

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(" + ScrollBy + ")");

		}
}
