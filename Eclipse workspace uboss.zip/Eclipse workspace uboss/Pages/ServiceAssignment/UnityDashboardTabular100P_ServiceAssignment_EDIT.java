package ServiceAssignment;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Oct 6, 2020 , 3:35:18 PM
-- Description	: UnityDashboardTabular100P_ServiceAssignment_EDIT.java
-- Modified by	: 
-- Modified Date:
-- Project		: Uboss-5-0-5
-- =============================================*/
public class UnityDashboardTabular100P_ServiceAssignment_EDIT {
	
	WebDriver driver;
	
	@FindBy(id = "search_data")
	WebElement search;

	@FindBy(xpath = "//i[contains(@class,'fas fa-search')]")
	WebElement searchbutton;

	@FindBy(xpath = "//*[@id=\"datagrid\"]/tbody/tr[1]/td/a")
	WebElement clickEdit;
	
	@FindBy(id = "description")
	WebElement Description;
	
	@FindBy(id = "ddldepartment")
	WebElement ChargeDept;
	
	@FindBy(id = "btnupdate")
	WebElement Save;
	
	@FindBy(id = "btndelete")
	WebElement deletebtn;

	@FindBy(xpath = "/html/body/div[4]/div/div/div[3]/button[1]")
	WebElement popupdelete;
	
	@FindBy(xpath = "//*[@id=\"settings\"]/div/div/label/span")
	WebElement includeremovedcheck;
		
	@FindBy(xpath = "//*[@id=\"btn_settings\"]/i")
	WebElement settings;

	@FindBy(id = "btn_cancel")
	WebElement Cancel;
	
	public UnityDashboardTabular100P_ServiceAssignment_EDIT(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}	
	
	public void Clickonsearch(String searchs) throws InterruptedException {
		search.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(3000);
		search.sendKeys(searchs);
	}

	public void Clickonsearchbtn() throws InterruptedException {
		Thread.sleep(1000);
		searchbutton.click();
	}

	public void Clickonsearchitem() throws InterruptedException {
		Thread.sleep(3000);
		clickEdit.click();
	}
	
	public void instancedescription(String instancedescription) throws InterruptedException {
		if(instancedescription.equals("")){
		System.out.println("not print");
		}else
		  {
		Description.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Description.sendKeys(instancedescription);
	}
	}	
	
	public void Department(String department ) throws InterruptedException, AWTException {
		if(department.equals(null)) {
			System.out.println("Drop Down is not selected");
		}
		else {
		Select drp1 = new Select(ChargeDept);
		drp1.selectByVisibleText(department);
		}
	}
	
	public void ClickonSave() throws InterruptedException {
		Thread.sleep(3000);
		Save.click();
	}

	public void ClickonCancel() throws InterruptedException {
		Thread.sleep(2000);
		Cancel.click();
	}
	
	public void Delete() throws InterruptedException {
		Thread.sleep(3000);
		deletebtn.click();
	}

	public void DeleteYesBtn() throws InterruptedException {
		Thread.sleep(3000);
		popupdelete.click();
	}
	public void includeremovedcheck(String deletedValue) throws InterruptedException {
		settings.click();
		Thread.sleep(3000);
		includeremovedcheck.click();
		int Counts = driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")).size();
		Thread.sleep(4000);
		for (int i = 1; i <= Counts; i++) {
			String inputvalue=driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr["+i+"]/td[1]")).getText();
			if(inputvalue.equals(deletedValue)) {
				String color = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr["+i+"]/td[1]")).getCssValue("color");

				String[] hexValue = color.replace("rgba(", "").replace(")", "").split(",");

				int hexValue1 = Integer.parseInt(hexValue[0]);
				hexValue[1] = hexValue[1].trim();
				int hexValue2 = Integer.parseInt(hexValue[1]);
				hexValue[2] = hexValue[2].trim();
				int hexValue3 = Integer.parseInt(hexValue[2]);

				String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);

				Assert.assertEquals("#fc4b6c", actualColor);
				System.out.println(deletedValue+" is deleted and also listed in include removed");

			}
		}
	}

	
	/*******************************************************************
	 * Validation[page 1]
	 ***********************************************/
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDelete_Validation;
	
	String saveval = "Saved successfully";
	String deleteval = "Unassigned successfully";
	
	public void saveval() throws InterruptedException {
		Thread.sleep(1000);
		String setvalidation = saveval;
		String getValiadtion = SaveandDelete_Validation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	public void deleteval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = deleteval;
		String getValiadtion = SaveandDelete_Validation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	public void Save_validation() throws InterruptedException {
		Thread.sleep(5000);
		this.saveval();
	}

	public void Delete_validation() throws InterruptedException {
		Thread.sleep(5000);
		this.deleteval();
	}
	/*******************************************
	 * Main Methods
	 ********************************/
	public void Serviceassignment_EDIT(String searchs,String des,String department)
			throws InterruptedException, AWTException {
		Thread.sleep(3000);
		// Step 1
		this.Clickonsearch(searchs);
		Thread.sleep(3000);
		this.Clickonsearchbtn();
		Thread.sleep(3000);
		this.Clickonsearchitem();
		Thread.sleep(3000);
		this.instancedescription(des);
		this.Department(department);
		this.ClickonSave();
		Thread.sleep(4000);
		this.Save_validation();
	}
	
	public void Serviceassignment_Delete(String searchs)
			throws InterruptedException, AWTException {
		Thread.sleep(3000);
		// Step 1
		this.Clickonsearch(searchs);
		Thread.sleep(3000);
		this.Clickonsearchbtn();
		Thread.sleep(3000);
		this.Clickonsearchitem();
		Thread.sleep(3000);
		this.ScrollPage("0,2000");
		Thread.sleep(5000);
		this.Delete();
		Thread.sleep(5000);
		this.DeleteYesBtn();
		Thread.sleep(5000);
		this.Delete_validation();
		Thread.sleep(5000);
		this.includeremovedcheck(searchs);
	}

	
	/***********************************************************
	 * CommonMethod
	 
	 ***************************************************************/


		public void Validation(String GetValiadtion, String Setvalidation) throws InterruptedException {

			if (GetValiadtion.equals(Setvalidation)) {
				System.out.println("Validation is correct as " + GetValiadtion);
			}
			
			else {
				System.out.println("Validation is incorrect");
				Assert.fail("Test Fail");
			}
		}
	public void ScrollPage(String ScrollBy) throws AWTException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + ScrollBy + ")");

	}
}
