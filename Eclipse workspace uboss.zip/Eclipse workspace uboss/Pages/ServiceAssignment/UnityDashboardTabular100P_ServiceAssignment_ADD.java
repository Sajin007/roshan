package ServiceAssignment;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Oct 6, 2020 , 3:35:04 PM
-- Description	: UnityDashboardTabular100P_ServiceAssignment_ADD.java
-- Modified by	: 
-- Modified Date:
-- Project		: Uboss-5-0-5
-- =============================================*/
public class UnityDashboardTabular100P_ServiceAssignment_ADD {

	WebDriver driver;

	@FindBy(id = "ddlserviceassignment")
	WebElement Service;
	
	@FindBy(id = "btnassign")
	WebElement Assign;
	
	@FindBy(id = "txtmacaddress")
	WebElement Macaddress;
	
	@FindBy(id = "instancename")
	WebElement InstanceName;
	
	@FindBy(id = "description")
	WebElement Description;
	
	@FindBy(id = "ddldepartment")
	WebElement ChargeDept;
	
	@FindBy(id = "save_btn")
	WebElement Save;

	@FindBy(id = "btn_cancel")
	WebElement Cancel;
	
	public UnityDashboardTabular100P_ServiceAssignment_ADD(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}	
	
	public void serviceassignment(String service) throws InterruptedException {
		Select drp1 = new Select(Service);
		drp1.selectByVisibleText(service);
	}
	public void Btnassign()throws InterruptedException, AWTException {
		Thread.sleep(3000);
		Assign.click();
	}
	
	
	public void instancename(String insname) throws InterruptedException {
		InstanceName.sendKeys(insname);
	}
	
	public void macaddress(String mac ) throws InterruptedException, AWTException {
		Thread.sleep(3000);
		Macaddress.sendKeys(mac);
	}
	
	public void instancedescription(String instancedescription) throws InterruptedException {
		if(instancedescription.equals("")){
		System.out.println("not print");
		}else
		  {
		Description.sendKeys(instancedescription);
	}
	}	
	
	public void Department(String department ) throws InterruptedException, AWTException {
		if(department.equals(null)) {
			System.out.println("Drop Down is not selected");
		}
		else {
		Select drp1 = new Select(ChargeDept);
		drp1.selectByVisibleText(department);
		}
	}
	
	public void save_btn()throws InterruptedException, AWTException {
		Thread.sleep(3000);
		Save.click();
	}
	
	public void btn_cancel() throws InterruptedException {
		Thread.sleep(5000);
		Cancel.click();
	}
	
	
	/*******************************************************************
	 * Validation[page 1]
	 ***********************************************/
	@FindBy(id = "instancename-error")
	WebElement InstanceNamevalidation;
	

	@FindBy(id = "txtmacaddress-error")
	WebElement MacaddressValidation;
	
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SavedSuccess;

	String InstanceNameVal = "The Instance Name Cannot be empty";
	String MacVal = "MacAddress Cannot be empty";
	String SavedSuccessfullyVal = "Saved successfully";
	String[] serverValidation1= {"Please enter a valid MAC Address. MAC Address must only contain 0-9 , A-F characters"};
	
	public void SavedSuccessfully_Validation() throws InterruptedException {
		Thread.sleep(1000);
		String setvalidation = SavedSuccessfullyVal;
		String getValiadtion = SavedSuccess.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	public void instancename_Validation() throws InterruptedException {
		Thread.sleep(1000);
		String setvalidation = InstanceNameVal;
		String getValiadtion = InstanceNamevalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void macaddress_Validation() throws InterruptedException {
		Thread.sleep(1000);
		String setvalidation = MacVal;
		String getValiadtion = MacaddressValidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	
	
public void serverValidation1() throws InterruptedException {
		
		Thread.sleep(1000);
		String[] setvalidation = serverValidation1;

		ArrayList<String> Validationlist = new ArrayList<String>();
		for (int j = 0; j <= setvalidation.length - 1; j++) {
			Validationlist.add(setvalidation[j]);
		}

		int Counts = driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p")).size();
		for (int i = 1; i <= Counts; i++) {
			String text = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p["+i+"]"))
					.getText();
			if (Validationlist.contains(text)) {
				System.out.println("Validation is correct :  " + text);

			} else {

				System.err.println("Validation is incorrect : " + text);
				Assert.fail("Test Fail for checking validation:(Aspect:"+setvalidation+"Result:"+text);

			}
		}
	}

public void validation() throws InterruptedException {
	
	List<WebElement> dynamicElement = driver.findElements(By.xpath("//*[@id=\"loginform\"]/div[1]/div/button"));
	if(dynamicElement.size() != 0){
	 //If list size is non-zero, element is present
	 System.out.println("Inputed Data is Invalid");
	 this.serverValidation1();
	}
	else{
	 //Else if size is 0, then element is not present
	 System.out.println("Inputed Data is correct");
		this.SavedSuccessfully_Validation();
	}
}
public void Validation() throws InterruptedException {
	this.instancename_Validation();
	this.macaddress_Validation();
}
/*******************************************
 * Main Methods
 ********************************/

public void Serviceassignment_ADD_Validation(String serviceassignment,String mac,String name)throws InterruptedException, AWTException {
	Thread.sleep(4000);
	this.serviceassignment(serviceassignment);
	Thread.sleep(4000);
	this.Btnassign();
	Thread.sleep(4000);
	this.save_btn();
	Thread.sleep(4000);
	this.Validation();
	this.macaddress(mac);
	this.instancename(name);
	Thread.sleep(4000);
	this.save_btn();
	Thread.sleep(4000);
	this.serverValidation1();	
	Thread.sleep(4000);
	this.btn_cancel();
} 

public void Serviceassignment_ADD(String serviceassignment,String mac, String name,String des,String department)
		throws InterruptedException, AWTException {
	Thread.sleep(3000);
	this.serviceassignment(serviceassignment);
	Thread.sleep(4000);
	this.Btnassign();
	this.macaddress(mac);
	this.instancename(name);
	Thread.sleep(3000);
	this.instancedescription(des);
	this.Department(department);
	this.save_btn();
	Thread.sleep(4000);
	this.SavedSuccessfully_Validation();
}


/***********************************************************
 * CommonMethod
 
 ***************************************************************/


	public void Validation(String GetValiadtion, String Setvalidation) throws InterruptedException {

		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as " + GetValiadtion);
		}
		
		else {
			System.err.println("Validation is incorrect : "+GetValiadtion);
			Assert.fail("Test Fail for checking validation:(Aspect:"+Setvalidation+"Result:"+GetValiadtion);
			this.validation();
		}
	}
public void ScrollPage(String ScrollBy) throws AWTException {

	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(" + ScrollBy + ")");

}
}