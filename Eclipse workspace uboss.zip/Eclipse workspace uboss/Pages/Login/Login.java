/*-- =============================================
-- Author		: 
-- Created Date :
-- Description	: 
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

package Login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class Login {

	WebDriver driver;
	@FindBy(xpath = "//*[@id='loginform']/div[1]/div/input")
	@CacheLookup
	WebElement loginID;
	@FindBy(xpath = "//*[@id='loginform']/div[2]/div/input")
	WebElement Password;
	@FindBy(xpath = "//*[@id='loginform']/div[4]/div/button")
	WebElement LogInBtn;
	@FindBy(xpath = "html/body/div[3]/header/nav/div[2]/ul[2]/li[2]/a/span")
	WebElement Profile;
	@FindBy(xpath = "html/body/div[3]/header/nav/div[2]/ul[2]/li[2]/div/ul/li[5]/a")
	WebElement LogOut;
	@FindBy(xpath = "html/body/section/section/div/div/form[1]/div[1]")
	WebElement Loginvalidation;
	@FindBy(xpath = "html/body/div[3]/div/div/div/div[1]/div/ol/li[1]/a")
	WebElement Home;

	// ******************************************
	public String loginHome = "Home";
	public String Validation = "Please fill out this field.";

	// ******************************************

	public Login(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void setLoginID(String strLoginId) {
		loginID.sendKeys(strLoginId);
	}

	public void setPassword(String strPassword) {
		Password.sendKeys(strPassword);
	}

	public void clickSignIn() throws InterruptedException {
		Thread.sleep(2000);
		LogInBtn.click();
	}

	public void LogintoUboss(String strLoginId, String strPassword) throws InterruptedException {

		this.setLoginID(strLoginId);
		this.setPassword(strPassword);
		this.clickSignIn();

	}

	public void refresh() {
		driver.navigate().refresh();
	}

	public void checkLogin() throws InterruptedException {
		Thread.sleep(4000);
		String home = Home.getText();
		System.out.println("Dashboard is " + home);

		if (loginHome.equals(home)) {
			System.out.println("Login Succesfully ");
		} else {
			System.out.println("Login Fail ");
			Assert.fail("Test Fail");
		}
	}

	public void clickProfile() throws InterruptedException {
		Thread.sleep(1000);
		Profile.click();
	}

	public void clickOnLogout() throws InterruptedException {
		Thread.sleep(1000);
		LogOut.click();
	}

	public void LogOutUboss() throws InterruptedException {
		this.clickProfile();
		this.clickOnLogout();
	}

	public void isPresent() {
		boolean ButtonLogin = LogInBtn.isDisplayed();
		if (ButtonLogin == true) {
			System.out.println("Login Out Succesfully");
		} else {
			System.out.println("Login Out Failed");
			Assert.fail("Test Fail");
		}
	}

	public void clearFields() throws InterruptedException {
		loginID.clear();
		Password.clear();
	}

	public void checkBlankFields() throws InterruptedException {
		this.clearFields();
		this.clickSignIn();
	}

	public void checkUsernameField() {
		String validationMessage = loginID.getAttribute("validationMessage");
		System.out.println(validationMessage);
		if (Validation.equals(validationMessage)) {
			System.out.println("Validation when Username field is blank is : " + validationMessage);
		} else {
			System.out.println("Validation when Username field is blank NOT found ");
			Assert.fail("Test Fail");
		}
	}

	public void PasswordField() {
		String validationMessage = Password.getAttribute("validationMessage");
		System.out.println(validationMessage);
		if (Validation.equals(validationMessage)) {
			System.out.println("Validation when Password field is blank is : " + validationMessage);
		} else {
			System.out.println("Validation when Password field is blank NOT found ");
			Assert.fail("Test Fail");
		}
	}

	public void checkPasswordField(String strLoginId) throws InterruptedException {
		this.setLoginID(strLoginId);
		this.clickSignIn();
		this.PasswordField();
	}

	public void WrongLogintoUboss(String strLoginId, String strPassword) throws InterruptedException {
		driver.navigate().refresh();
		Thread.sleep(3000);

		this.setLoginID(strLoginId);
		this.setPassword(strPassword);
		this.clickSignIn();

		String failed = Loginvalidation.getText();

		String tfailed = failed.substring(2);
		// System.out.println(tfailed);

		if (tfailed.equals("Login Failed")) {
			System.out.println("Validation is " + tfailed);
		} else if (tfailed.equals("You have 3 more attempts left for the account to get locked")) {
			System.out.println("Validation is " + tfailed);
		} else if (tfailed.equals("You have 2 more attempts left for the account to get locked")) {
			System.out.println("Validation is " + tfailed);
		} else if (tfailed.equals("You have 1 more attempt left, after that user will get blocked")) {
			System.out.println("Validation is " + tfailed);
		} else if (tfailed.equals(
				"Login blocked due to consecutive 5 attempts with incorrect credentials. Please check your email associated with this user account to login again.")) {
			System.out.println("Validation is " + tfailed);
		} else {
			System.out.println("Login - WC");
			Assert.fail("Test Fail");
		}

	}

	public void LoginIDwithSpace(String strLoginId, String strPassword) throws InterruptedException {
		driver.navigate().refresh();
		Thread.sleep(3000);

		loginID.sendKeys(strLoginId);
		Password.sendKeys(strPassword);
		this.clickSignIn();

		String spacevalidation = Loginvalidation.getText();
		String tspacevalidation = spacevalidation.substring(2);
		System.out.println(tspacevalidation);

		if (tspacevalidation.equals("Login Id should not contain whitespace")) {
			System.out.println("Validation is " + tspacevalidation);
		} else {
			System.out.println("Whitespaces are not validating");
			Assert.fail("Test Fail");
		}

	}

}
