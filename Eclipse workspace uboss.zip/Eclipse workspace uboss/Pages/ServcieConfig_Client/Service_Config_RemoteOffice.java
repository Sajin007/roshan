package ServcieConfig_Client;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Oct 12, 2020 , 2:37:25 PM
-- Description	: Service_Config_RemoteOffice.java
-- Modified by	: 
-- Modified Date:
-- Project		: Uboss-5-0-5
-- =============================================*/
public class Service_Config_RemoteOffice {
	WebDriver driver;

	@FindBy(xpath = "//*[@id=\"main-wrapper\"]/header/nav/div[2]/ul[1]/li[5]/a")
	WebElement serviceConf_Menu;

	@FindBy(xpath = "//*[@id=\"btncancel\"]")
	WebElement cancel;

	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div/label/span")
	WebElement enable;

	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/form/div[2]/div/label/span")
	WebElement RemoveRemoteOfficeSC;

	@FindBy(id = "txtRemoteOfficeNumber")
	WebElement RemoteOfficeNumber;

	@FindBy(id = "btnconfigure")
	WebElement save;

	public Service_Config_RemoteOffice(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String url) {
		driver.get(url);
	}

	public void servicConfigmenu() throws InterruptedException {
		Thread.sleep(2000);
		serviceConf_Menu.click();
	}

	public void serviceList(String Servicename) throws InterruptedException {
		Thread.sleep(17000);
		String Getservicename = driver.findElement(By.linkText(Servicename)).getText();
		if (Servicename.equals(Getservicename)) {
			System.out.println("Service is listed in Serivce config page of client : " + Getservicename);
			Thread.sleep(4000);
			driver.findElement(By.linkText(Servicename)).click();
			Thread.sleep(4000);
			

		} else {
			System.out.println("Expected :" + Servicename + " Result : " + Getservicename + "(Service is not listed)");
			Assert.fail("There is issues in service config client page" + "(Expected :" + Servicename + " Result : "
					+ Getservicename + ")");
		}
	}

	public void RemotOffice(String EnbaleCheckbox, String RemoveROCheckbox, String RONum) throws InterruptedException {
		this.Enableservice(EnbaleCheckbox);
		this.RemoveROserviceConf(RemoveROCheckbox);
		this.RemoteOfficeNum(RONum);
	}
	public void Enableservice(String EnbaleCheckbox) throws InterruptedException {
		Thread.sleep(1000);
		String ValueCheckbox = driver.findElement(By.id("IsActive")).getAttribute("checked");
		if (EnbaleCheckbox.toUpperCase().equals("YES")) {
			if (ValueCheckbox == null) {
				enable.click();
				System.out.println("Enable CheckBox is checked");
			} else {
				System.err.println("Enable CheckBox is Already checked");
				Assert.fail("Enable CheckBox is Already checked");
			}
		} else if (EnbaleCheckbox.toUpperCase().equals("NO")) {
			if (ValueCheckbox == null) {
				System.err.println("Enable CheckBox is Already Uchecked");
				Assert.fail("Enable CheckBox is Already Uchecked");
			} else {
				enable.click();
				System.out.println("Enable CheckBox is Unchecked");
			}
		} else {
			System.out.println("There is no Change in Enable CheckBox");
		}
	}

	public void RemoveROserviceConf(String RemoveROCheckbox) throws InterruptedException {
		Thread.sleep(1000);
		String ValueCheckbox = driver.findElement(By.id("IsDeactiveserviceConfiguration")).getAttribute("checked");
		if (RemoveROCheckbox.toUpperCase().equals("YES")) {
			if (ValueCheckbox == null) {
				RemoveRemoteOfficeSC.click();
				System.out.println("Remove Remote Office service configuration CheckBox is checked");
			} else {
				System.err.println("Remove Remote Office service configuration CheckBox is Already checked");
				Assert.fail("Remove Remote Office service configuration CheckBox is Already checked");
			}
		} else if (RemoveROCheckbox.toUpperCase().equals("NO")) {
			if (ValueCheckbox == null) {
				System.err.println("Remove Remote Office service configuration CheckBox is Already Uchecked");
				Assert.fail("Remove Remote Office service configuration CheckBox is Already Uchecked");
			} else {
				RemoveRemoteOfficeSC.click();
				System.out.println("Remove Remote Office service configuration CheckBox is Unchecked");
			}
		} else {
			System.out.println("There is no Change in Remove Remote Office service configuration");
		}
	}

	public void RemoteOfficeNum(String RONum) throws InterruptedException {
		if (RONum.equals("")) {
			Thread.sleep(1000);
			RemoteOfficeNumber.clear();
			System.out.println("There is no data input in Remote Office Number");
			Thread.sleep(1000);
		} else {
			Thread.sleep(1000);
			RemoteOfficeNumber.clear();
			Thread.sleep(1000);
			RemoteOfficeNumber.sendKeys(RONum);
			System.out.println("The Input value in Remote Office Number is : " + RONum);
		}
	}

	public void Save() throws InterruptedException {
		Thread.sleep(1000);
		save.click();
	}

	public void cancel() throws InterruptedException {
		Thread.sleep(1000);
		cancel.click();
		Thread.sleep(17000);
	}

	/************************** Validation **************************/

	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement saveval;
	@FindBy(id = "txtRemoteOfficeNumber-error")
	WebElement RemoteofficeNumbervali;

	String savevalidation = "Saved successfully";
	String RemoteofficeNumbervali01 = "Remote Office Phone Number Can Contain Only Numbers, .(dot) and *(asterik)";

	public void RemoteOfficevalidation(String EnbaleCheckbox, String RemoveROCheckbox, String RONum)
			throws InterruptedException {
		this.Enableservice(EnbaleCheckbox);
		this.RemoveROserviceConf(RemoveROCheckbox);
		this.RemoteOfficeNum(RONum);
		this.Save();
		Thread.sleep(5000);
		this.RemoteofficeNumbervalidation();

	}

	public void RemoteofficeNumbervalidation() throws InterruptedException {
		Thread.sleep(5000);
		String setvalidation = RemoteofficeNumbervali01;
		String getvalidtion = RemoteofficeNumbervali.getText();
		this.Validation(getvalidtion, setvalidation);
	}

	public void savevalidation() throws InterruptedException {
		Thread.sleep(15000);
		String setvalidation = savevalidation;
		String getvalidtion = saveval.getText();
		this.Validation(getvalidtion, setvalidation);
	}

	/****************************** Main Method *******************************/

	public void servicConfigValidation(String Servicename, String EnbaleCheckbox, String RemoveROCheckbox, String RONum)
			throws InterruptedException {
		this.servicConfigmenu();
		this.serviceList(Servicename);
		this.RemoteOfficevalidation(EnbaleCheckbox, RemoveROCheckbox, RONum);
		Thread.sleep(1000);
		this.cancel();
	}

	public void servicConfig(String Servicename, String EnbaleCheckbox, String RemoveROCheckbox, String RONum)
			throws InterruptedException {
		Thread.sleep(1000);
		this.servicConfigmenu();
		this.serviceList(Servicename);
		this.RemotOffice(EnbaleCheckbox, RemoveROCheckbox, RONum);
		Thread.sleep(1000);
		this.Save();
		this.savevalidation();
	}

	/**************************************
	 * Common method
	 ************************************************************/
	// Validation

	public void Validation(String GetValiadtion, String Setvalidation) {
		PageFactory.initElements(driver, this);
		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.err.println("Validation is incorrect: " + GetValiadtion);
			Assert.fail(
					"Test fail for chceking validation : (Aspect : " + Setvalidation + " Result : " + GetValiadtion);
		}

	}

}
