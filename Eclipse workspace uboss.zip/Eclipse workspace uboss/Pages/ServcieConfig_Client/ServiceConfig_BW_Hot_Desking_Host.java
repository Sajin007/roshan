package ServcieConfig_Client;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class ServiceConfig_BW_Hot_Desking_Host {

	
	WebDriver driver;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div/div[2]/div/label/span")
	WebElement Enforceassociation;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div/div[1]/div/label/span")
	WebElement EnabledCheckbox;
	

	@FindBy(id = "save_btn")
	WebElement SaveButton;
	
	@FindBy(id = "btn_cancel_1")
	WebElement cancel;
	
	@FindBy(id = "association_duration_limit")
	WebElement Associationdurationlimit;
	
	@FindBy(xpath = "//*[@id=\"main-wrapper\"]/header/nav/div[2]/ul[1]/li[5]/a")
	WebElement serviceConf_Menu;
	
	public ServiceConfig_BW_Hot_Desking_Host(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoTUrl(String Url)

	{
		driver.get(Url);
	}
	

	public void servicConfigmenu() throws InterruptedException {
		Thread.sleep(4000);
		serviceConf_Menu.click();
	}
	
	public void SaveButton() throws InterruptedException {
		
		Thread.sleep(2000);
		SaveButton.click();
		
	}

	
	public void clickoncancel() throws InterruptedException {
		
		Thread.sleep(2000);
		cancel.click();
	}
		
		
		public void Enabled_CheckBox(String Checkbox) throws InterruptedException {
			Thread.sleep(3000);
			String ValueCheckbox = driver.findElement(By.xpath("//*[@id=\"form-hotdeskinghost\"]/div[1]/div/div[1]/div/label/span")).getAttribute("checked");
			if (Checkbox.toUpperCase().equals("YES")) {
				if (ValueCheckbox == null) {
					System.out.println(ValueCheckbox);
					Thread.sleep(5000);
					EnabledCheckbox.click();
					System.out.println("Enabled CheckBox is checked");
				} else {
					System.err.println("Enabled CheckBox is Already checked");
					Assert.fail("Enabled CheckBox is Already checked");
				}
			} else if (Checkbox.toUpperCase().equals("NO")) {
				if (ValueCheckbox == "") {
					System.err.println("Enabled CheckBox is Already Uchecked");
					Assert.fail("Enabled CheckBox is Already Uchecked");
				} else {
					Thread.sleep(5000);
					EnabledCheckbox.click();
					System.out.println("Enabled CheckBox is Unchecked");
				}
			} else {
				System.out.println("There is no Change in Name of");
			}
		}
		
		
		
		public void EnforceAssociationLimit_Checkbox(String Checkbox2) throws InterruptedException {
			Thread.sleep(3000);
			String ValueCheckbox = driver.findElement(By.xpath("//*[@id=\"form-hotdeskinghost\"]/div[1]/div/div[2]/div/label/span")).getAttribute("checked");
			if (Checkbox2.toUpperCase().equals("YES")) {
				if (ValueCheckbox == null) {
					Thread.sleep(5000);
					Enforceassociation.click();
					System.out.println("Enforce Association CheckBox is checked");
				} else {
					System.err.println("Enforce Association CheckBox is Already checked");
					Assert.fail("Enforce Association CheckBox is Already checked");
				}
			} else if (Checkbox2.toUpperCase().equals("NO")) {
				if (ValueCheckbox == "") {
					System.err.println("Enforce Association CheckBox is Already Uchecked");
					Assert.fail("Enforce Association CheckBox is Already Uchecked");
				} else {
					Thread.sleep(5000);
					Enforceassociation.click();
					System.out.println("Enforce Association CheckBox is Unchecked");
				}
			} else {
				System.out.println("There is no Change in Name of");
			}
		}
		
		
		
	
	
	/************************** Validation **************************/
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement saveval;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement AssociationDurationlimitValidation;
	
	String savevalidation = "Saved successfully";
	String AssociationDurationLimit_Val = "Association Limit Cannot Be Empty";
	
	
	
	
	public void AssociationDurationLimit_Val() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = AssociationDurationLimit_Val;
		String getValiadtion = AssociationDurationlimitValidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
   
	
	public void savevalidation() throws InterruptedException 
    {
	Thread.sleep(12000);
	String setvalidation = savevalidation;
	String getvalidtion = saveval.getText();
	this.Validation(getvalidtion, setvalidation);
    }
	
	
	public void serviceList(String Servicename) throws InterruptedException {
		Thread.sleep(15000);
		String Getservicename = driver.findElement(By.linkText(Servicename)).getText();
		if (Servicename.equals(Getservicename)) {
			System.out.println("Service is listed in Serivce config page of client : " + Getservicename);
			Thread.sleep(4000);
			driver.findElement(By.linkText(Servicename)).click();
			Thread.sleep(4000);
			// this.checkingAssingornot(Servicename); xpath is not working
		} else {
			System.out.println("Expected :" + Servicename + " Result : " + Getservicename + "(Service is not listed)");
			Assert.fail("There is issues in service config client page" + "(Expected :" + Servicename + " Result : "
					+ Getservicename + ")");
		}

	}
	
	public void Association_Duration_Limit(String associationlimit) throws InterruptedException {
		
		Thread.sleep(2000);
		Associationdurationlimit.clear();
		Thread.sleep(2000);
		Associationdurationlimit.sendKeys(associationlimit);
		
	}
	
	
	public void validation( ) throws InterruptedException {
		
		Thread.sleep(2000);
		Associationdurationlimit.clear();
		this.SaveButton();
		this.AssociationDurationLimit_Val();
		this.clickoncancel();
	}
	
	public void Servicemethod(String servicename,String Checkbox,String Checkbox2,String associationlimit) throws InterruptedException {
		
	
		this.serviceList(servicename);
		this.Enabled_CheckBox(Checkbox);
		this.EnforceAssociationLimit_Checkbox(Checkbox2);
		this.Association_Duration_Limit(associationlimit);
		this.SaveButton();
		Thread.sleep(4000);
		this.savevalidation();
		Thread.sleep(7000);
//		
	}
	
//	public void Servicemethod2(String servicename,String Checkbox1, String Checkbox3,String associationlimit) throws InterruptedException {
//	
//		this.serviceList(servicename);
//		this.Enabled_CheckBox(Checkbox1);
//		this.EnforceAssociationLimit_Checkbox(Checkbox3);
//		this.Association_Duration_Limit(associationlimit);
//		this.SaveButton();
//		
//	}
	
	public void servicConfig_Validation(String servicename) throws InterruptedException 
	{
		this.servicConfigmenu();
		this.serviceList(servicename);
		this.validation();
		
//		this.ServiceMethod(Checkbox);
//		this.SaveButton();
//		this.savevalidation();
	}

	
	
	
	
	
	
	
	/**************************************
	 * Common method
	 ************************************************************/
	// Validation

	public void Validation(String GetValiadtion, String Setvalidation) 
	{
		PageFactory.initElements(driver, this);
		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.err.println("Validation is incorrect: " + GetValiadtion);
			Assert.fail(
					"Test fail for chceking validation : (Aspect : " + Setvalidation + " Result : " + GetValiadtion);
		}

	}

}



