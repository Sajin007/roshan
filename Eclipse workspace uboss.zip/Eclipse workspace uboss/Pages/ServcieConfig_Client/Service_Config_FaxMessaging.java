package ServcieConfig_Client;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Oct 16, 2020 , 11:40:37 AM
-- Description	: Service_Config_FaxMessaging.java
-- Modified by	: 
-- Modified Date:
-- Project		: Uboss-5-0-5
-- =============================================*/
public class Service_Config_FaxMessaging {
	WebDriver driver;

	@FindBy(xpath = "//*[@id=\"main-wrapper\"]/header/nav/div[2]/ul[1]/li[5]/a")
	WebElement serviceConf_Menu;

	@FindBy(xpath = "//*[@id=\"btncancel\"]")
	WebElement cancel;

	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/form/div/div[1]/div/label/span")
	WebElement enable;
	
	@FindBy(id = "ddlFaxNumber")
	WebElement faxNumber;
	
	@FindBy(xpath = "/html/body[@class='fix-header fix-sidebar card-no-border']/div[@id='main-wrapper']/div[@id='ajaxcontent']/div[@class='page-wrapper']/div[@class='container-fluid']/div[@class='card']/div[@class='card-body']/form[@id='form-faxmessaging']/div[@class='col-md-12']/div[@class='row form-group'][3]/div[@class='col-md-4'][1]/input[@id='txtExtension']")
	WebElement faxextn;
	
	@FindBy(id = "nextextension")
	WebElement nextextnbtn;

	@FindBy(id = "btnconfigure")
	WebElement save;
	
	public Service_Config_FaxMessaging(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String url) {
		driver.get(url);
	}

	public void servicConfigmenu() throws InterruptedException {
		Thread.sleep(12000);
		serviceConf_Menu.click();
	}

	public void serviceList(String Servicename) throws InterruptedException {
		Thread.sleep(17000);
		String Getservicename = driver.findElement(By.linkText(Servicename)).getText();
		if (Servicename.equals(Getservicename)) {
			System.out.println("Service is listed in Serivce config page of client : " + Getservicename);
			Thread.sleep(4000);
			driver.findElement(By.linkText(Servicename)).click();
			Thread.sleep(4000);

		} else {
			System.out.println("Expected :" + Servicename + " Result : " + Getservicename + "(Service is not listed)");
			Assert.fail("There is issues in service config client page" + "(Expected :" + Servicename + " Result : "
					+ Getservicename + ")");
		}
	}
	public void Enableservice(String EnbaleCheckbox) throws InterruptedException {
		Thread.sleep(5000);
		String ValueCheckbox = driver.findElement(By.id("IsActive")).getAttribute("checked");
		if (EnbaleCheckbox.toUpperCase().equals("YES")) {
			if (ValueCheckbox == null) {
				enable.click();
				System.out.println("Enable CheckBox is checked");
			} else {
				System.err.println("Enable CheckBox is Already checked");
				Assert.fail("Enable CheckBox is Already checked");
			}
		} else if (EnbaleCheckbox.toUpperCase().equals("NO")) {
			if (ValueCheckbox == null) {
				System.err.println("Enable CheckBox is Already Uchecked");
				Assert.fail("Enable CheckBox is Already Uchecked");
			} else {
				enable.click();
				System.out.println("Enable CheckBox is Unchecked");
			}
		} else {
			System.out.println("There is no Change in Enable CheckBox");
		}
	}
	
	public void Faxnumber(String faxnum) throws InterruptedException {
		Thread.sleep(3000);
		if (faxnum.equals(" ")) {
			System.out.println("There is no value  given to select in Fax Number Drop-Down");
		} else {
			Select dropdown1 = new Select(faxNumber);
			dropdown1.selectByVisibleText(faxnum);
			System.out.println("The Value is selected in Fax Number Drop-Down is " +faxnum);
		}
	}
	

	public void Faxextn(String faxExtn) throws InterruptedException {
		Thread.sleep(3000);
		if (faxExtn.equals("")) {
			Thread.sleep(1000);
			faxextn.clear();
			Thread.sleep(4000);
			this.NextExtn();
			Thread.sleep(1000);
		}
		else if(faxExtn.toUpperCase().equals("CLEAR")) {
			Thread.sleep(1000);
			faxextn.clear();
			Thread.sleep(1000);
		}
		else {
			Thread.sleep(1000);
			faxextn.clear();
			Thread.sleep(1000);
			faxextn.sendKeys(faxExtn);
			System.out.println("The Input value in Fax Extension is : " +faxExtn);
		}
	}
	public void FaxMessaging(String EnbaleCheckbox, String faxnum, String faxExtn) throws InterruptedException {
		Thread.sleep(3000);
		this.Enableservice(EnbaleCheckbox);
		Thread.sleep(3000);
		this.Faxnumber(faxnum);
		Thread.sleep(3000);
		this.Faxextn(faxExtn);
		Thread.sleep(3000);
	}
	
	public void NextExtn() throws InterruptedException {
		Thread.sleep(1000);
		nextextnbtn.click();
		Thread.sleep(1000);
		String extention=faxextn.getAttribute("value");
		System.out.println("Extention button click and value in extention is : "+extention);
	}
	
	public void Save() throws InterruptedException {
		Thread.sleep(1000);
		save.click();
	}

	public void cancel() throws InterruptedException {
		Thread.sleep(1000);
		cancel.click();
		Thread.sleep(17000);
	}
	
	public void FaxMessagingservice(String EnbaleCheckbox, String faxnum,String faxExtn)
			throws InterruptedException {
		Thread.sleep(3000);
		this.Enableservice(EnbaleCheckbox);
		this.Faxnumber(faxnum);
		Thread.sleep(3000);
		this.Faxextn(faxExtn);
		Thread.sleep(5000);
		this.Save();
		Thread.sleep(8000);

	}

	/************************** Validation **************************/

	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement saveval;
	@FindBy(id = "ddlFaxNumber-error")
	WebElement Faxnumval;
	@FindBy(id = "txtExtension-error")
	WebElement Faxextnval;

	String savevalidation = "Saved successfully";
	String Faxnumvali = "This service requires a phone number to turn the service on";
	String Faxextnvali01 = "The extension cannot be empty";
	String Faxextnvali02 = "Please enter a valid number";
	
	
	public void FaxMessagingvalservice(String EnbaleCheckbox, String faxnum, String faxExtn)
			throws InterruptedException {
		this.Enableservice(EnbaleCheckbox);
		this.Faxnumber(faxnum);
		this.Faxextn(faxExtn);
		this.Save();
		Thread.sleep(5000);

	}
	
	
	public void FaxNumvalidation() throws InterruptedException {
		Thread.sleep(5000);
		String setvalidation = Faxnumvali;
		String getvalidtion = Faxnumval.getText();
		this.Validation(getvalidtion, setvalidation);
	}

	public void FaxExtnvalidation1() throws InterruptedException {
		Thread.sleep(5000);
		String setvalidation = Faxextnvali01;
		String getvalidtion = Faxextnval.getText();
		this.Validation(getvalidtion, setvalidation);
	}
	

	public void FaxExtnvalidation2() throws InterruptedException {
		Thread.sleep(5000);
		String setvalidation = Faxextnvali02;
		String getvalidtion = Faxextnval.getText();
		this.Validation(getvalidtion, setvalidation);
	}

	public void savevalidation() throws InterruptedException {
		Thread.sleep(15000);
		String setvalidation = savevalidation;
		String getvalidtion = saveval.getText();
		this.Validation(getvalidtion, setvalidation);
	}

	/****************************** Main Method *******************************/

	public void servicConfigValidation(String Servicename, String EnbaleCheckbox, String faxnum, String faxExtn,String faxExtn1)
			throws InterruptedException {
		Thread.sleep(8000);
		this.servicConfigmenu();
		Thread.sleep(8000);
		this.serviceList(Servicename);
		Thread.sleep(8000);
		this.FaxMessagingvalservice(EnbaleCheckbox, faxnum, faxExtn);
		Thread.sleep(8000);
		this.FaxNumvalidation();
		this.FaxExtnvalidation1();
		Thread.sleep(1000);
		this.Faxextn(faxExtn1);
		Thread.sleep(5000);
		this.Save();
		Thread.sleep(8000);
		this.FaxNumvalidation();
		this.FaxExtnvalidation2();
		Thread.sleep(4000);
		this.cancel();
	}

	public void servicConfig(String Servicename, String EnbaleCheckbox, String faxnum,String faxExtn)
			throws InterruptedException {
		Thread.sleep(18000);
		this.servicConfigmenu();
		Thread.sleep(12000);
		this.serviceList(Servicename);
		Thread.sleep(12000);
		this.FaxMessagingservice(EnbaleCheckbox, faxnum,faxExtn);
		Thread.sleep(8000);
		this.savevalidation();
		Thread.sleep(3000);
	}

	/**************************************
	 * Common method
	 ************************************************************/
	// Validation

	public void Validation(String GetValiadtion, String Setvalidation) {
		PageFactory.initElements(driver, this);
		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.err.println("Validation is incorrect: " + GetValiadtion);
			Assert.fail(
					"Test fail for chceking validation : (Aspect : " + Setvalidation + " Result : " + GetValiadtion);
		}

	}


}
