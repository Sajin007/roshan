package MisMatchDeviceReport;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.drd.uboss5.keywords.keywords;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : May 22, 2020,8:32:47 AM
-- Description	: MisMatchDeviceReport.java
-- Modified by	: dennu.thomas
-- Modified Date: 27-Jan-2021
-- Project		: UBOSS-5-0-0-Dennu
-- =============================================*/
public class MisMatchDeviceReport  extends keywords {
	WebDriver driver;
	@FindBy(id = "search_data")
	WebElement Searchtext;
	
	@FindBy(xpath = "/html/body[@class='fix-header fix-sidebar card-no-border']/div[@id='main-wrapper']/div[@id='ajaxcontent']/div[@class='page-wrapper']/div[@class='container-fluid']/div[@class='card']/div[@class='card-body']/div[@class='row'][1]/div[@class='col-8']/div[@class='form-inline float-right']/div[@class='input-group mr-1 searchbox']/div[@class='input-group-append']/button[@id='search_btn']/i[@class='fas fa-search hidemsg']")
	WebElement Searchbtn;
	
	@FindBy(xpath = "/html/body[@class='fix-header fix-sidebar card-no-border']/div[@id='main-wrapper']/div[@id='ajaxcontent']/div[@class='page-wrapper']/div[@class='container-fluid']/div[@class='card']/div[@class='card-body']/div[@class='row'][1]/div[@class='col-8']/div[@class='form-inline float-right']/div[@class='input-group mr-1 searchbox']/span[@id='clear_btn']/i[@class='fa fa-times hidemsg']")
	WebElement Clear;
	
	@FindBy(xpath = "/html/body[@class='fix-header fix-sidebar card-no-border']/div[@id='main-wrapper']/div[@id='ajaxcontent']/div[@class='page-wrapper']/div[@class='container-fluid']/div[@class='card']/div[@class='card-body']/div[@class='row'][1]/div[@class='col-8']/div[@class='form-inline float-right']/button[@id='btn_download']")
	WebElement Download;
	
	@FindBy(xpath = "/html/body[@class='fix-header fix-sidebar card-no-border']/div[@id='main-wrapper']/div[@id='ajaxcontent']/div[@class='page-wrapper']/div[@class='container-fluid']/div[@class='card']/div[@class='card-body']/div[@class='row'][1]/div[@class='col-8']/div[@class='form-inline float-right show']/ul[@class='dropdown-menu multi-level dropdown-menu-right show']/li[1]/a[@id='excel']")
	
	WebElement Excel;
	
	@FindBy(xpath = "/html/body[@class='fix-header fix-sidebar card-no-border']/div[@id='main-wrapper']/div[@id='ajaxcontent']/div[@class='page-wrapper']/div[@class='container-fluid']/div[@class='card']/div[@class='card-body']/div[@class='row'][1]/div[@class='col-8']/div[@class='form-inline float-right show']/ul[@class='dropdown-menu multi-level dropdown-menu-right show']/li[2]/a[@id='csv']")
	WebElement CSV;
	
	public MisMatchDeviceReport(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void GoToUrl(String Url) {
		driver.get(Url);
	}
public void Clickonsearchtext(String searchs) throws InterruptedException {
		
		
		Thread.sleep(3000);
		Searchtext.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(3000);
		Searchtext.sendKeys(searchs);
	}
	

	public void Clickonsearchbtn() throws InterruptedException {
		Thread.sleep(1000);
		Searchbtn.click();
	}
		
	public void Clickonclear() throws InterruptedException {
		Thread.sleep(1000);
		Clear.click();
	}
	public void Export(String[] FileTpye) throws InterruptedException {
		System.out.println("Export Checking :");
			for (int i = 1; i <= FileTpye.length; i++) {
				String Records = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr/td")).getText();
				if(Records.equals("No data available in table")) {
					Thread.sleep(2000);
					Download.click();
					String text1 = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div[1]/div[2]/div/ul/li[" + i + "]/a")).getText();					
					if (FileTpye[i-1].equals(text1)) {
					driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div[1]/div[2]/div/ul/li[" + i + "]/a")).click();
					String Validation = driver.findElement(By.xpath("//*[@id=\"messenger\"]/div/div/p")).getText();
					if(Validation.equals("No records to export")) {
						System.out.println("Validation is correct : " +Validation);
						Thread.sleep(4000);
						assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
					}
					else {
						System.out.println("Validation is wrong");
						Thread.sleep(4000);
						assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
					}
				}
				}
				else if(!"No data available in table".equals(Records)) {
					Thread.sleep(2000);
					Download.click();
					String text = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div[1]/div[2]/div/ul/li[" + i + "]/a")).getText();					
					if (FileTpye[i-1].equals(text)) {
						driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div[1]/div[2]/div/ul/li[" + i + "]/a")).click();
						System.out.println("File type found");
						Thread.sleep(4000);
						assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
					}

					else {
						System.out.println("Export file type is not found: (Aspect : "+FileTpye[i-1]+" Result : "+text);
					}
					
				}
				else {
					System.err.println("Exporting has some issues");
				}

			}
		}
	public void showingrecords() throws InterruptedException
	{
		Thread.sleep(4000);
		
		int total = driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")).size();
		System.out.println("Total Number of records = " + total);

		for (int i = 1; i <= total; i++) 
		{

			String mpath = "//*[@id='datagrid']/tbody/tr[" + i + "]/td[1]";
			String fullXpath = String.format(mpath);

			String RPtext = driver.findElement(By.xpath(fullXpath)).getText();
			System.out.println("data  " + i + " is - " + RPtext);
		}
		
		}
	public void view_data() throws InterruptedException, AWTException
	{
		Thread.sleep(2000);
		ScrollPage(driver, "0,200");
		// Get all the table row elements from the table
		List<WebElement> allRows= driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div[2]/div/div/div[2]/table/tbody/tr")); 
		System.out.println("Mis Match Device Report View list :");
		for(WebElement row : allRows)
		{
			List<WebElement> allColumnsInRow=row.findElements(By.tagName("td"));
		for(WebElement cell : allColumnsInRow)
		{
			System.out.print(cell.getText()+ "|");
		}
		System.out.println();
		}
	}
	
	/*********************************************
	 * Main Method
	 * @throws AWTException 
	 ***************************************/
	public void mismatchdevicereport_view(String[] filetype,String searchs) throws InterruptedException, AWTException
	{

		Thread.sleep(4000);
		System.out.println("Mis-Match Device Report viewed Successfully");
		Thread.sleep(4000);
		this.Clickonsearchtext(searchs);
		Thread.sleep(5000);
		this.Clickonsearchbtn();
		Thread.sleep(5000);
		this.Clickonclear();
		Thread.sleep(4000);
		this.Export(filetype);
		Thread.sleep(4000);	
		this.view_data();
		Thread.sleep(4000);	
		this.ListTable();									
	}
	

	/*********************************************
	 * Common Method
	 ***************************************/
	public void ListTable() throws InterruptedException {

		String[] headers = { "DEVICE NAME", "DEVICE NAME IN UBOSS","DEVICE NAME IN PA","MAC ADDRESS","DISTRIBUTOR","RESELLER","BUSINESS","SITE","USER" };
		listpage(driver, headers, "");
	}
}


