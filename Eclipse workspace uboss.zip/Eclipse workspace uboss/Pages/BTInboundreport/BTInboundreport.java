package BTInboundreport;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/*-- =============================================
-- Author		:Roshan Raju
-- Created Date : 12- May-2020
-- Description	:BT inboundreport 
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class BTInboundreport {
	
	
	WebDriver driver;
	@FindBy(id="billcycleid")
	WebElement Callsperioddropdown;
	@FindBy(id="COMMONA034")
	WebElement Viewbutton;
	@FindBy(id="exporthidden")
	WebElement Exportbuttn;
	@FindBy(id="excel")
	WebElement excel;
	@FindBy(id="csv")
	WebElement csv;
	@FindBy(id="pdf")
	WebElement pdf;
	

	public BTInboundreport(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	
	
	public void callsperioddropdown(String applyDate) throws InterruptedException {
        Thread.sleep(11000);                       
        Select select = new Select(Callsperioddropdown);
		select.selectByVisibleText(applyDate);
} 


	public void clickonviewbutton() throws InterruptedException {
		
		Thread.sleep(10000);
		Viewbutton.click();
}

	public void view_data() throws InterruptedException, AWTException
	{
		Thread.sleep(90000);
		//this.ScrollPage("0,200");
		// Get all the table row elements from the table
		List<WebElement> allRows= driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")); 
		System.out.println("BT inbound Report View list :");
		for(WebElement row : allRows)
		{
			List<WebElement> allColumnsInRow=row.findElements(By.tagName("td"));
		for(WebElement cell : allColumnsInRow)
		{
			System.out.print(cell.getText()+ "|");
		}
		System.out.println();
		}
	}
	////html/body/div[2]/div/div/div/div[3]/div/div[1]/div/div/div[4]/div/ul/li[1]/a
	public void Export(String[] FileTpye) throws InterruptedException {
		Thread.sleep(5000);
		for (int i = 1; i <= FileTpye.length; i++) {
			Exportbuttn.click();
			String text = driver
					.findElement(By
							.xpath("//*[@id=\"ajaxcontent\"]/div/div/div[3]/div/div[1]/div/div/div[4]/div/ul/li[" + i + "]/a"))
					.getText();
			System.out.println(text);
			if (FileTpye[i-1].equals(text)) {
				driver.findElement(
						By.xpath("//*[@id=\"ajaxcontent\"]/div/div/div[3]/div/div[1]/div/div/div[4]/div/ul/li[" + i + "]/a"))
						.click();
				System.out.println("File type found");
				Thread.sleep(4000);
                assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
			}

			else {

				System.out.println("File type not found");

			}

		}
	}
	

	
	
	public void BTinboundreport(String Apply_Date,String [] FileTpye) throws InterruptedException, AWTException {
		
		this.callsperioddropdown(Apply_Date);
		this.clickonviewbutton();
		this.view_data();
		this.Export(FileTpye);
	
		
		
	}
	
	


}
