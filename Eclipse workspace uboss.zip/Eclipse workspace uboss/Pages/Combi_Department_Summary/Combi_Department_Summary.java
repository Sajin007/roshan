package Combi_Department_Summary;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : May 27, 2020,6:37:55 PM
-- Description	: Combi_Department_Summary.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-ROSHAN_RAJU
-- =============================================*/
public class Combi_Department_Summary {
	
	
	WebDriver driver;
	@FindBy(id="billcycle")
	WebElement invoicemonthdropdown;
	@FindBy(id="viewdtable")
	WebElement viewbutton;
	@FindBy(xpath="//*[@id=\"ajaxcontent\"]/div/div/div[3]/div/div[1]/div[3]/div/button")
	WebElement Exportbuttn;
	
	
	
	
	public Combi_Department_Summary(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	
	
	public void invoicemonthdropdown(String invoicemonth) throws InterruptedException {
        Thread.sleep(2000);
        if(invoicemonth.equals(null)) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(invoicemonthdropdown);
		select.selectByVisibleText(invoicemonth);
		
		}
	} 
	
	public void clickonviewbutton() throws InterruptedException {
		
		Thread.sleep(5000);
		viewbutton.click();
	}

	
	public void view_data() throws InterruptedException, AWTException
	{
		Thread.sleep(50000);
		//this.ScrollPage("0,200");
		// Get all the table row elements from the table
		List<WebElement> allRows= driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")); 
		System.out.println("Combi Department Summary Report View list :");
		for(WebElement row : allRows)
		{
			List<WebElement> allColumnsInRow=row.findElements(By.tagName("td"));
		for(WebElement cell : allColumnsInRow)
		{
			System.out.print(cell.getText()+ "|");
		}
		System.out.println();
		}
	}
	
	
	public void Export(String[] FileTpye) throws InterruptedException {
		System.out.println("Export Checking :");
			for (int i = 1; i <= FileTpye.length; i++) {
				String Records = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr[1]/td[1]")).getText();
				if(Records.equals("No data available in table")) {
					Thread.sleep(3000);
					Exportbuttn.click();
					String text1 = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div[1]/div[3]/div/ul/li[" + i + "]/a")).getText();					
					if (FileTpye[i-1].equals(text1)) {
					driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div[1]/div[3]/div/ul/li[" + i + "]/a")).click();
					String Validation = driver.findElement(By.xpath("//*[@id=\"messenger\"]/div/div/p")).getText();
					if(Validation.equals("No records to export")) {
						System.out.println("Validation is correct : " +Validation);
						Thread.sleep(4000);
						assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
					}
					else {
						System.out.println("Validation is wrong");
						Thread.sleep(4000);
						assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
					}
				}
				}
				else if(!"No data available in table".equals(Records)) {
					Thread.sleep(3000);
					Exportbuttn.click();
					String text = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div[1]/div[3]/div/ul/li[" + i + "]/a")).getText();					
					if (FileTpye[i-1].equals(text)) {
						driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div[1]/div[3]/div/ul/li[" + i + "]/a")).click();
						System.out.println("File type found");
						Thread.sleep(4000);
						assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
					}

					else {

						System.out.println("File type not found");

					}
				}
				else {
					System.err.println("There is an issues in page");
				}

			}
		}
	
	/*******************************************
	 * Main Methods
	 ***************************************/
	
	
	
	
	public void Combi_Department_Summary_report(String invoicemonth,String [] FileTpye) throws InterruptedException, AWTException {
		
		this.invoicemonthdropdown(invoicemonth);
		this.clickonviewbutton();
		this.view_data();
		this.Export(FileTpye);
	}

}
