package TariifExemptions;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Aug 4, 2020
-- Description	: Exceptions.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-WORKSPACE
-- =============================================*/
public class Exceptions {

	
	
	WebDriver driver;
	
	@FindBy(xpath="/html/body/div[2]/div/div/div/div[3]/div/form[1]/div[1]/div[1]/a")
	WebElement CDRAdd;
	@FindBy(xpath="(//a[@class='btn waves-effect waves-light btn btn-info'])[2]")
	WebElement SDRAdd;
	@FindBy(xpath="//*[@id=\"form-cdrexception\"]/div[1]/div[2]/label[1]/div/ins")
	WebElement cdrradiobutton;//*[@id="form-sdrexception"]/div[1]/div[2]/label[1]/div/ins
	//*[@id="form-sdrexception"]/div[1]/div[2]/label[1]/div/ins
	//*[@id=\"form-cdrexception\"]/div[1]/div[2]/label[1]/div/ins
	
	
	@FindBy(xpath="//*[@id=\"form-cdrexception\"]/div[1]/div[2]/label[2]/div/ins")
	WebElement sdrradiobutton;
	@FindBy(xpath="//*[@id=\"form-cdrexception\"]/div[1]/div[2]/label[1]/div/ins")
	WebElement cdrradiobuttonselected;//*[@id="form-cdrexception"]/div[1]/div[2]/label[1]/div/ins
	@FindBy(xpath="//*[@id=\"form-cdrexception\"]/div[1]/div[2]/label[3]/div/ins")
	WebElement sdroverrideradiobutton;//*[@id="form-sdrexception"]/div[1]/div[2]/label[1]/div/ins
	@FindBy(xpath = "//*[@id=\"btn_download\"]")//*[@id="btn_download"]
	WebElement Exportbutton;
	@FindBy(id = "btn_sdr_download")//*[@id="btn_download"]
	WebElement ExportbuttonSDR;
	@FindBy(xpath = "//*[@id=\"btn_upload\"]")
	WebElement importbutton;
	@FindBy(id = "btn_sdr_upload")
	WebElement importbuttonSDR;
	@FindBy(id="cdrimport")
	WebElement CDRUpload;
	@FindBy(id="sdrimport")
	WebElement SDRUpload;
	@FindBy(id="importfile")
	WebElement CDRBrowse;
	@FindBy(id="importsdrfile")
	WebElement SDRBrowse;
	@FindBy(xpath="//*[@id=\"form-sdrexception\"]/div[1]/div[2]/label[1]/div/ins")
	WebElement sdrradiobuttonselected;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement Tariffimportedvalidation;
	
	
	public Exceptions(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	
	
	public void CDRImport(String FilePath) throws InterruptedException, AWTException {
		
		Thread.sleep(3000);
		importbutton.click();
		Thread.sleep(2000);
		CDRBrowse.click();
		Thread.sleep(4000);
		this.UploadFile(FilePath);
		Thread.sleep(2000);
		CDRUpload.click();
		
	}
	
	public void SDRImport(String FilePath) throws InterruptedException, AWTException {
		
		Thread.sleep(3000);
		importbuttonSDR.click();
		Thread.sleep(2000);
		SDRBrowse.click();
		Thread.sleep(4000);
		this.UploadFile(FilePath);
		Thread.sleep(2000);
		SDRUpload.click();
		this.Tariffimported_validation();
		Thread.sleep(3000);
		sdrradiobuttonselected.click();
		
	}
	
	public void Radiobuttonclick(String Radiobutton,String linetype,String Chargecode, String nominalcode,  String Gateway, String Carrier,String apply_Date, String ratepeak,String rateoffpeak,String rateweekend,String Busns, String Radiobutton1, String name, String Setupcharge,String Recurringcharge, String SetupchargeNC, String RecurringchargeNC,String prorata, String singlerate,String qf, String qt, String rc) throws InterruptedException, AWTException
	{
		
		
		if (Radiobutton.equals("CDR"))
		{
			Thread.sleep(3000);
			cdrradiobutton.click();
			Thread.sleep(6000);
			CDRAdd.click();
			CDRTariffExemptions TE = PageFactory.initElements(driver, CDRTariffExemptions.class);
			TE.CDRTariff_Exemption_ADD(linetype, Chargecode, nominalcode,  Gateway, Carrier, apply_Date, ratepeak, rateoffpeak,rateweekend);
			
		}
		
		else if(Radiobutton.equals("SDR-Exemption"))
		{
			
			
		
  			Thread.sleep(4000);
  			//cdrradiobuttonselected.click();
			Thread.sleep(6000);
			sdrradiobutton.click();
			Thread.sleep(4000);
			SDRAdd.click();
			SDRTariffExemption STE = PageFactory.initElements(driver, SDRTariffExemption.class);
			STE.SDRtariffexemption_add(Busns,Radiobutton1,name,Setupcharge,Recurringcharge,SetupchargeNC,RecurringchargeNC,prorata, singlerate,qf, qt, rc);
				
			
				
			}
			
		
		}
		
	
	
	
	
	public void Export(String[] FileTpye) throws InterruptedException {
	
		System.out.println("Export Checking :");
			for (int i = 1; i <= FileTpye.length; i++) {
				String Records = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr/td")).getText();
				if(Records.equals("No data available in table")) {
					Thread.sleep(2000);
					Exportbutton.click();
					String text1 = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form[1]/div[1]/div[3]/div/ul/li[" + i + "]/a")).getText();					
					if (FileTpye[i-1].equals(text1)) {
					driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form[1]/div[1]/div[3]/div/ul/li[" + i + "]/a")).click();
					String Validation = driver.findElement(By.xpath("//*[@id=\"messenger\"]/div/div/p")).getText();
					if(Validation.equals("No records to export")) {
						System.out.println("Validation is correct : " +Validation);
						Thread.sleep(4000);
						assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
					}
					else {
						System.out.println("Validation is wrong");
						Thread.sleep(4000);
						assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
					}
				}
				}
				else if(!"No data available in table".equals(Records)) {
					Thread.sleep(2000);
					Exportbutton.click();
					String text = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form[1]/div[1]/div[3]/div/ul/li[" + i + "]/a")).getText();					
					if (FileTpye[i-1].equals(text)) {
						driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form[1]/div[1]/div[3]/div/ul/li[" + i + "]/a")).click();
						System.out.println("File type found");
						Thread.sleep(4000);
						assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
					}

					else {

						System.out.println("File type not found");

					}
				}
				else {
					System.err.println("There is an issues in page");
				}

			}
		}
	
	
	public void ExportSDR(String[] FileTpye) throws InterruptedException {
		Thread.sleep(5000);
		for (int i = 1; i <= FileTpye.length; i++) {
			Thread.sleep(2000);
			ExportbuttonSDR.click();
			String text = driver
					.findElement(By
							.xpath("/html/body/div[2]/div/div/div/div[3]/div/form[2]/div[1]/div[3]/div/ul/li[" + i + "]/a"))
					.getText();
			if (FileTpye[i-1].equals(text)) {
				driver.findElement(
						By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form[2]/div[1]/div[3]/div/ul/li[" + i + "]/a"))
						.click();
				System.out.println("File type found");
				Thread.sleep(4000);
				assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
			}

			else {

				System.out.println("File type not found");

			}

		}
	}
	
	
	public void Exemption_selection(String Radiobutton,String linetype,String Chargecode,String nominalcode, String Gateway, String Carrier,String apply_Date, String ratepeak,String rateoffpeak,String rateweekend,String Busns, String Radiobutton1, String name, String Setupcharge,String Recurringcharge, String SetupchargeNC, String RecurringchargeNC,String prorata, String singlerate,String qf, String qt, String rc) throws InterruptedException, AWTException {
		
		this.Radiobuttonclick(Radiobutton,linetype, Chargecode, nominalcode, Gateway, Carrier,  apply_Date, ratepeak, rateoffpeak,rateweekend,Busns,Radiobutton1,name,Setupcharge,Recurringcharge,SetupchargeNC,RecurringchargeNC,prorata, singlerate,qt,qf,rc);
			
	}

	public void File_Export_Import(String [] FileTpye,String Filepath) throws InterruptedException, AWTException {
		
		this.Export(FileTpye);
		Thread.sleep(10000);
		this.CDRImport(Filepath);
	}
	
	public void CDR_Exemption_Add(String Radiobutton,String linetype,String Chargecode,String nominalcode, String Gateway, String Carrier,String apply_Date, String ratepeak,String rateoffpeak,String rateweekend,String [] FileTpye,String Filepath,String Busns, String Radiobutton1, String name, String Setupcharge,String Recurringcharge, String SetupchargeNC, String RecurringchargeNC,String prorata, String singlerate,String qf, String qt, String rc) throws InterruptedException, AWTException {
		
		this.Exemption_selection(Radiobutton, linetype, Chargecode, nominalcode, Gateway, Carrier, apply_Date, ratepeak, rateoffpeak, rateweekend,Busns,Radiobutton1,name,Setupcharge,Recurringcharge,SetupchargeNC,RecurringchargeNC,prorata, singlerate,qt,qf,rc);
		this.File_Export_Import(FileTpye, Filepath);
		this.Tariffimported_validation();
	}
	
	
	public void SDR_Exemption(String Radiobutton,String linetype,String Chargecode, String nominalcode,  String Gateway, String Carrier,String apply_Date, String ratepeak,String rateoffpeak,String rateweekend,String Busns, String Radiobutton1, String name, String Setupcharge,String Recurringcharge, String SetupchargeNC, String RecurringchargeNC,String prorata, String singlerate,String qf, String qt, String rc,String [] FileTpye,String Filepath) throws InterruptedException, AWTException {
		
		this.Radiobuttonclick(Radiobutton,linetype, Chargecode, nominalcode,  Gateway, Carrier, apply_Date, ratepeak, rateoffpeak,rateweekend,Busns,Radiobutton1,name,Setupcharge,Recurringcharge,SetupchargeNC,RecurringchargeNC,prorata, singlerate,qt,qf,rc);
		this.ExportSDR(FileTpye);
		this.SDRImport(Filepath);
		
		
	}
	
	
	
	
	
	

	/***********************************
	 * Validation elements
	 *****************************************/


	String TariffimpVal = "Tariffs Imported";
	
	
	
	
	public void TariffimportedVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = TariffimpVal;
		String getValiadtion = Tariffimportedvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	
	public void Tariffimported_validation() throws InterruptedException {
		this.TariffimportedVal();
	}
	
	
	
	
	
	

	public void UploadFile(String FilePath) throws InterruptedException, AWTException {
		String filePath = System.getProperty("user.dir") +"\\src\\main\\java\\com\\drd\\uboss5\\attachments\\"+FilePath;
		driver.switchTo().activeElement().sendKeys(filePath);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_CONTROL);
	}
	


	
	
	
	/****************************************
	 * Common Method
 	**************************************************/

	public void Validation(String GetValiadtion, String Setvalidation) {
		PageFactory.initElements(driver, this);
		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.out.println("Validation is incorrect: " + GetValiadtion);
				Assert.fail("Test Fail");
		}

	}
	


	
	}




