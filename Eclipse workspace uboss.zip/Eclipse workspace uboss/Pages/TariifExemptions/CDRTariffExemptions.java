package TariifExemptions;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : May 29, 2020,5:22:35 PM
-- Description	: TariffExemptions.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-ROSHAN_RAJU
-- =============================================*/
public class CDRTariffExemptions {
	
	
	WebDriver driver;
	
	@FindBy(xpath="//*[@id=\"form-cdrexception\"]/div[1]/div[1]/a")
	WebElement Add;
	
	@FindBy(id="view")
	WebElement viewbutton;
	@FindBy(id="btn_download")
	WebElement Exportbuttn;
	@FindBy(id="btn_upload")
	WebElement Upload;
	@FindBy(id="linetype")
	WebElement Linetype;
	@FindBy(id="chargecode")
	WebElement chargecode;
	@FindBy(id="nominal")
	WebElement nominal_code;
	@FindBy(id="carrierid")
	WebElement carrier;
	@FindBy(id="gatewayid")
	WebElement gateway;
	@FindBy(id="codec")
	WebElement codec;
	@FindBy(id="txt_future_apply_date")
	WebElement Apply_Date;
	@FindBy(id="add")
	WebElement save;
	@FindBy(id="txt_minutepeak_sell")
	WebElement Minute_RatePeak;
	@FindBy(id="txt_minuteoffpeak_sell")
	WebElement Minute_RateOffPeak;
	@FindBy(id="txt_minuteweekend_sell")
	WebElement Minute_RateWeekend;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDeletemessenger;
	@FindBy(xpath = "//*[@id=\"btn_upload\"]")
	WebElement importbutton;
	

	
	
	
	
	public CDRTariffExemptions(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	
	
	
	public void linetypedropdown(String linetype) throws InterruptedException {
        Thread.sleep(2000);
        if(linetype.equals("")) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(Linetype);
		select.selectByVisibleText(linetype);
		
		}
	} 
	
	
	public void chargecodedropdown(String Chargecode) throws InterruptedException {
        Thread.sleep(3000);
        if(Chargecode.equals("")) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(chargecode);
		select.selectByVisibleText(Chargecode);
		
		}
	} 
	
	public void nominalcodedropdown(String nominalcode) throws InterruptedException {
        Thread.sleep(3000);
        if(nominalcode.equals("")) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(nominal_code);
		select.selectByVisibleText(nominalcode);
		
		}
	} 
	
	public void gatewaydropdown(String Gateway) throws InterruptedException {
        Thread.sleep(2000);
        if(Gateway.equals("")) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(gateway);
		select.selectByVisibleText(Gateway);
		
		}
	} 
	
	public void carrierdropdown(String Carrier) throws InterruptedException {
        Thread.sleep(2000);
        if(Carrier.equals("")) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(carrier);
		select.selectByVisibleText(Carrier);
		
		}
        
     
        
	} 
	
	public void Apply_Date(String apply_Date) throws InterruptedException {
		String DATE;
        Thread.sleep(3000); 
        if(apply_Date.toUpperCase().equals("CURRENT DATE")) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-yyyy");  
        LocalDate  now = LocalDate.now();  
        DATE= dtf.format(now);
        }else {
        	DATE=apply_Date;
        }
        
        
        String a ="document.getElementById('txt_future_apply_date').";

        String b = "value='"+DATE+"'";

        JavascriptExecutor js = (JavascriptExecutor)driver;

        js.executeScript(a+b);

} 
	public void minuteratepeak(String ratepeak) throws InterruptedException {
		
		Thread.sleep(3000); 
		Minute_RatePeak.sendKeys(ratepeak);
	}
	
	
	public void minuterateoffpeak(String rateoffpeak) throws InterruptedException {
		
		Thread.sleep(3000); 
		Minute_RateOffPeak.sendKeys(rateoffpeak);
	}

	public void minuterateweekend(String rateweekend) throws InterruptedException {
		
		Thread.sleep(3000); 
		Minute_RateWeekend.sendKeys(rateweekend);
	}


	public void clickonsave() throws InterruptedException {
		
		Thread.sleep(3000);
		save.click();
	}
	

	
	
	
	/***********************************
	 * Validation elements
	 *****************************************/


	String SaveVal = "Saved successfully";
	
	
	
	public void SaveVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = SaveVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	
	public void Save_validation() throws InterruptedException {
		this.SaveVal();
	}
	
	

	public void CDRTariff_Exemption_ADD(String linetype,String Chargecode,String nominalcode,String Gateway,String Carrier,String apply_Date, String ratepeak,String rateoffpeak,String rateweekend) throws InterruptedException, AWTException {
		
		
		this.linetypedropdown(linetype);
		this.chargecodedropdown(Chargecode);
		this.nominalcodedropdown(nominalcode);
		this.gatewaydropdown(Gateway);
		this.carrierdropdown(Carrier);
		this.Apply_Date(apply_Date);
		this.minuteratepeak(ratepeak);
		this.minuterateoffpeak(rateoffpeak);
		this.minuterateweekend(rateweekend);
		this.clickonsave();
		this.Save_validation();
	
	
	}
	



















	/****************************************
	 * Common Method
 	**************************************************/

	public void Validation(String GetValiadtion, String Setvalidation) {
		PageFactory.initElements(driver, this);
		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.out.println("Validation is incorrect: " + GetValiadtion);
				Assert.fail("Test Fail");
		}

	}
	
	

	}
