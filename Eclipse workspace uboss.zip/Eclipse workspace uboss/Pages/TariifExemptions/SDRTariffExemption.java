package TariifExemptions;

import java.awt.AWTException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Jun 16, 2020
-- Description	: SDRTariffExemption.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-WORKSPACE
-- =============================================*/
public class SDRTariffExemption {
	
	
	
	
	WebDriver driver;
	@FindBy(xpath="(//a[@class='btn waves-effect waves-light btn btn-info'])[2]")
	WebElement SDRAdd;
	@FindBy(id="ddlbusiness")
	WebElement Business;
	@FindBy(id="ddlobject")
	WebElement Name;
	@FindBy(id="applydate")
	WebElement Applydate;
	@FindBy(id="setupcharge")
	WebElement setupcharge;
	@FindBy(id="recurringcharge")
	WebElement recurringcharge;
	@FindBy(id="ceasecharge")
	WebElement ceasecharge;
	@FindBy(id="setupchargenominalcode")
	WebElement setupchargenominalcode;
	@FindBy(id="recurringchargenominalcode")
	WebElement recurringchargenominalcode;
	@FindBy(id="ceasechargenominalcode")
	WebElement ceasechargenominalcodecode;
	@FindBy(xpath="//span[@class='ml-1'][contains(.,'Services')]")
	WebElement serviceradiobutton;//html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div/div[1]/div/div[1]/label/span[2]
	//html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div/div[2]/div/div[1]/label/span[2]
	@FindBy(xpath="//span[@class='ml-1'][contains(.,'Devices/Accessories')]")
	WebElement deviceradiobutton;
	@FindBy(xpath="//span[@class='ml-1'][contains(.,'Package')]")
	WebElement packageradiobutton;
	@FindBy(xpath="//span[@class='ml-1'][contains(.,'Number Category')]")
	WebElement numbercategoryradiobutton;
	@FindBy(xpath="//*[@id=\"formsdrtarifrate\"]/div[9]/div/div/div/div/div[1]/label/span[2]")
	WebElement noneradiobutton;
	@FindBy(xpath="//*[@id=\"formsdrtarifrate\"]/div[9]/div/div/div/div/div[2]/label/span[2]")
	WebElement prorataradiobutton;
	@FindBy(xpath="//*[@id=\"formsdrtarifrate\"]/div[9]/div/div/div/div/div[3]/label/span[2]")
	WebElement singlerateradiobutton;
	@FindBy(id="quantityfrom")
	WebElement Quantityfrom;
	@FindBy(id="quantityto")
	WebElement Quantityto;
	@FindBy(id="slabrecurringcharge")
	WebElement Recurringcharge;
	
	@FindBy(id="btnadd")
	WebElement save;
	@FindBy(id="COMMONA081")
	WebElement Addnew;
	@FindBy(id="btnaddtolist")
	WebElement slabsave;
	
	@FindBy(xpath="//*[@id=\"form-sdrexception\"]/div[1]/div[2]/label[1]/div/ins")
	WebElement sdrradiobuttonselected;
	@FindBy(xpath="//*[@id=\"form-cdrexception\"]/div[1]/div[2]/label[2]/div/ins")
	WebElement sdrradiobutton;
	@FindBy(xpath="//*[@id=\"formsdrtarifrate\"]/div[17]/div/a")
	WebElement cancel;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDeletemessenger;
	
	
	
	
	
	
	
	
	public SDRTariffExemption(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	
	public void Radiobuttonclick(String Radiobutton1) throws InterruptedException, AWTException
	{
		
		
		if (Radiobutton1.equals("Services"))
		{
			Thread.sleep(5000);
			serviceradiobutton.click();
		}
			
		else if (Radiobutton1.equals("Devices/Accessories")) 
		
		{
			Thread.sleep(4000);
			deviceradiobutton.click();	
			
		}
		
		else if (Radiobutton1.equals("Package")) 
			
		{
			Thread.sleep(6000);
			packageradiobutton.click();	
			
		}
		
		
		else if (Radiobutton1.equals("Number Category")) 
			
		{
			Thread.sleep(6000);
			numbercategoryradiobutton.click();	
			
		}
			
		}
	
	
	
	public void business(String Busns) throws InterruptedException {
		Thread.sleep(2000);
	    if(Busns.equals("")) {
		System.out.println("Drop Down is not selected");
		}
	    else {
		Thread.sleep(3000);
			Select select = new Select(Business);
			select.selectByVisibleText(Busns);
			
			}
	}
	

	
	
	
	public void Name(String name) throws InterruptedException {
		
		Thread.sleep(2000);
	    if(name.equals("")) {
		System.out.println("Drop Down is not selected");
		}
		else {
		Select select = new Select(Name);
		select.selectByVisibleText(name);
			
			}
	}
	
	
	public void Setupcharge(String Setupcharge) throws InterruptedException {
		
		Thread.sleep(2000);
		setupcharge.sendKeys(Setupcharge);
		
	}
	
	
	public void Recurringcharge(String Recurringcharge) throws InterruptedException {
		
		Thread.sleep(2000);
		recurringcharge.sendKeys(Recurringcharge);
		
	}

	public void Ceasecharge(String Ceasecharge) throws InterruptedException {
		
		Thread.sleep(2000);
		ceasecharge.sendKeys(Ceasecharge);
		
	}
	
	
	public void SetupchargeNC(String SetupchargeNC) throws InterruptedException {
		
		Thread.sleep(2000);
	    if(SetupchargeNC.equals("")) {
		System.out.println("Drop Down is not selected");
		}
		else {
		Select select = new Select(setupchargenominalcode);
		select.selectByVisibleText(SetupchargeNC);
			
			}
		
	}
	
	
	public void RecurringchargeNC(String RecurringchargeNC) throws InterruptedException {
		
		Thread.sleep(2000);
	    if(RecurringchargeNC.equals("")) {
		System.out.println("Drop Down is not selected");
		}
		else {
		Select select = new Select(recurringchargenominalcode);
		select.selectByVisibleText(RecurringchargeNC);
			
			}
		
	}

	public void CeasechargeNC(String CeasechargeNC) throws InterruptedException {
		
		Thread.sleep(2000);
	    if(CeasechargeNC.equals("")) {
		System.out.println("Drop Down is not selected");
		}
		else {
		Select select = new Select(ceasechargenominalcodecode);
		select.selectByVisibleText(CeasechargeNC);
			
			}
		
	}
	
	
	public void Thresholdradiobuttonclick(String proratavalue, String singleratevalue) throws InterruptedException, AWTException {
		String prorata = proratavalue.toUpperCase();
		String singlerate = singleratevalue.toUpperCase();
		if (prorata.equals("YES")) {
			Thread.sleep(3000);
			this.ScrollPage("0,+300");
			prorataradiobutton.click();
			
		}
		
		else if(singlerate.equals("YES")) {
			
			Thread.sleep(3000);
			this.ScrollPage("0,+600");
			singlerateradiobutton.click();
		}
	
	
	}
	
	
	public void slabdetails(String qf, String qt, String rc) throws InterruptedException {
		
		Thread.sleep(3000);
		Addnew.click();
		Thread.sleep(2000);
		Quantityfrom.sendKeys(qf);
		Thread.sleep(2000);
		Quantityto.sendKeys(qt);
		Thread.sleep(2000);
		Recurringcharge.sendKeys(rc);
		slabsave.click();
	}
	
	
	
	public void clickonsave() throws InterruptedException {
		
		Thread.sleep(4000);
		save.click();
	}
	
	
	public void SDRtariffexemption_add(String Busns, String Radiobutton1, String name, String Setupcharge,String Recurringcharge, String SetupchargeNC, String RecurringchargeNC,String prorata, String singlerate,String qf, String qt, String rc) throws InterruptedException, AWTException {
		
		this.business(Busns);
		this.Radiobuttonclick(Radiobutton1);
		this.Name(name);
		this.Setupcharge(Setupcharge);
		this.Recurringcharge(Recurringcharge);
		this.SetupchargeNC(SetupchargeNC);
		this.RecurringchargeNC(RecurringchargeNC);
		this.Thresholdradiobuttonclick(prorata, singlerate);
		this.slabdetails(qf, qt, rc);
		this.clickonsave();
		Thread.sleep(2000);
		this.Save_validation();
		Thread.sleep(4000);
		
		//driver.navigate().refresh();
	}
	
	
	
	
	
	
	
	
	/***********************************
	 * Validation elements
	 *****************************************/

	@FindBy(id = "ddlobject-error")
	WebElement Namevalidation;
	@FindBy(id = "quantityfrom-error")
	WebElement quantityfromvalidation;
	@FindBy(id = "quantityto-error")
	WebElement quantitytovalidation;
	@FindBy(id = "slabrecurringcharge-error")
	WebElement recurringchargevalidation;
	@FindBy(id = "freedays-error")
	WebElement freedaysvalidation;
	
	

	
	
	String Nameval = "Name cannot be empty";
	String quantityfromval = "Quantity From Cannot be empty";
	String quantitytoVal = "Quantity To Cannot be empty";
	String recurringchargeval = "Recurring charge cannot be empty";
	String FreedaysVal = "Saved successfully";
	String SaveVal = "Saved successfully";
	
	
	
	
	
	public void NameVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = Nameval;
		String getValiadtion = Namevalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void QuantityfromVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = quantityfromval;
		String getValiadtion = quantityfromvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void QuantitytoVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = quantitytoVal;
		String getValiadtion = quantitytovalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void RecurringchargeVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = recurringchargeval;
		String getValiadtion = recurringchargevalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	
	public void SaveVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = SaveVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	
	public void Save_validation() throws InterruptedException {
		this.SaveVal();
	}
	
	
	public void thresholdradiobuttonclick() throws InterruptedException {
		
		Thread.sleep(3000);
		prorataradiobutton.click();
		Thread.sleep(3000);
		Addnew.click();
		Thread.sleep(3000);
		slabsave.click();
		
		
	}
	
	
	
	public void namevalidation() throws InterruptedException, AWTException {
		
		this.ScrollPage("0,+700");
		this.clickonsave();
	}
	
	public void Thresholdvalidation() throws InterruptedException {
		
		this.thresholdradiobuttonclick();
	}
	
	public void SDRtariffexemption_validation() throws InterruptedException, AWTException {
		
		Thread.sleep(4000);
		sdrradiobutton.click();
		Thread.sleep(2000);
		SDRAdd.click();
		Thread.sleep(10000);
		this.namevalidation();
		this.NameVal();
		driver.navigate().refresh();
		this.thresholdradiobuttonclick();
		this.QuantitytoVal();
		this.QuantityfromVal();
		this.RecurringchargeVal();
		cancel.click();
		Thread.sleep(2000);
		sdrradiobuttonselected.click();
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/****************************************
	 * Common Method
	 **************************************************/

	public void Validation(String GetValiadtion, String Setvalidation) {
		PageFactory.initElements(driver, this);
		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.out.println("Validation is incorrect: " + GetValiadtion);
			Assert.fail("Test Fail");
		}

	}
	
	
	public void ScrollPage(String ScrollBy) throws AWTException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + ScrollBy + ")");

	}
	
}
