package TariifExemptions;

import java.awt.AWTException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Aug 4, 2020
-- Description	: SDRTariffExemption_Edit.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-WORKSPACE
-- =============================================*/
public class SDRTariffExemption_Edit {
	
	
	WebDriver driver;
	@FindBy(id="setupcharge")
	WebElement setupcharge;
	@FindBy(id="recurringcharge")
	WebElement recurringcharge;
	@FindBy(id="ceasecharge")
	WebElement ceasecharge;
	@FindBy(id="setupchargenominalcode")
	WebElement setupchargenominalcode;
	@FindBy(id="recurringchargenominalcode")
	WebElement recurringchargenominalcode;
	@FindBy(id="ceasechargenominalcode")
	WebElement ceasechargenominalcodecode;
	@FindBy(xpath="//*[@id=\"row1\"]/td[1]/a/u")
	WebElement Editlink;
	@FindBy(id="quantityfrom")
	WebElement Quantityfrom;
	@FindBy(id="quantityto")
	WebElement Quantityto;
	@FindBy(id="slabrecurringcharge")
	WebElement Recurringcharge;
	@FindBy(id="btnaddtolist")
	WebElement slabsaveedit;
	@FindBy(id="btnupdate")
	WebElement save;
	@FindBy(id="delete")
	WebElement delete;
	@FindBy(xpath="/html/body/div[4]/div/div/div[3]/button[1]")
	WebElement Deletepop_up;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDeletemessenger;
	@FindBy(id="cancelBtn")
	WebElement cancel;
	@FindBy(xpath="(//a[@class='btn waves-effect waves-light btn btn-info'])[2]")
	WebElement SDRAdd;
	@FindBy(xpath="//*[@id=\"form-cdrexception\"]/div[1]/div[2]/label[2]/div/ins")
	WebElement sdrradiobutton;
	@FindBy(xpath="//*[@id=\"formsdrtarifrate\"]/div[17]/div/a")
	WebElement Cancel;
	
	
	
	
	
	public SDRTariffExemption_Edit(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	
	
	public void ClickToLink(String link) throws InterruptedException 
	{
			Thread.sleep(5000);//*[@id="cdr_data"]/tbody/tr[2]/td[1]/a/u
			int Counts = driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form[2]/div[3]/div/div/div[2]/table/tbody/tr")).size();
			//System.out.println(Counts);//*[@id="sdr_data"]/tbody/tr[2]/td[1]/a/u
			for (int i = 1; i <= Counts; i++) 
				//*[@id="sdr_data"]/tbody/tr[2]/td[1]/a/u
	                      {
				
				Thread.sleep(2000);
				String text = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form[2]/div[3]/div/div/div[2]/table/tbody/tr["+i+"]/td[1]/a/u")).getText();
				//System.out.println(text);
				if (link.equals(text)) 
	                       {
					
					Thread.sleep(3000);
					driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form[2]/div[3]/div/div/div[2]/table/tbody/tr["+i+"]/td[1]/a/u")).click();
					System.out.println("Tariff exemption type is selected");
					Thread.sleep(2000);
					//Compare String
				
					break;   
				}
				
				else {
					
					System.out.println("Tariff exemption type not selected");
					
				}


			
		  }
			}
	
//	public void Available_Data_selection(String[] DataList, String Counts) throws InterruptedException {
//
//
//		ArrayList<String> ListData = new ArrayList<String>();
//
//		for (int j = 0; j <= DataList.length - 1; j++) {
//			ListData.add(DataList[j]);
//		}
//
//		for (int i = 1; i <= ListData.size(); i++) {
//			
//			
//			
//			String text = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form[2]/div[3]/div/div/div[2]/table/tbody/tr["+i+"]/td[1]/a/u")).getText();
//			System.out.println(text);
//			if (ListData.contains(text)) {
//				Thread.sleep(1000);
//				driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form[2]/div[3]/div/div/div[2]/table/tbody/tr["+i+"]/td[1]/a/u")).click();
//				Thread.sleep(1000);
//
//				
//
//			}
//
//		}
//
//	}
//
//	public void DataSelection(String[] dataSelection) throws InterruptedException {
//
//		String Count = "/html/body/div[2]/div/div/div/div[3]/div/form[2]/div[3]/div/div/div[2]/table/tbody/tr";
//		//String Text = "/html/body/div[2]/div/div/div/div[3]/div/form[2]/div[3]/div/div/div[2]/table/tbody/tr[1]/td[1]/a/u";
//		              
//		 System.out.println(driver.findElements(By.xpath(Count)).size());
//		// System.out.println(driver.findElement(By.xpath(text)).getText());
//		this.Available_Data_selection(dataSelection, Count);
//
//	}
//	
//	
	
	
	
	
	

	
	
	public void Setupcharge(String Setupcharge) throws InterruptedException {
		
		Thread.sleep(2000);
		setupcharge.clear();
		Thread.sleep(2000);
		setupcharge.sendKeys(Setupcharge);
		
	}
	
	
	public void Recurringcharge(String Recurringcharge) throws InterruptedException {
		
		Thread.sleep(2000);
		recurringcharge.clear();
		Thread.sleep(2000);
		recurringcharge.sendKeys(Recurringcharge);
		
	}
	
	
	public void SetupchargeNC(String SetupchargeNC) throws InterruptedException {
		
		Thread.sleep(2000);
	    if(SetupchargeNC.equals("")) {
		System.out.println("Drop Down is not selected");
		}
		else {
		Select select = new Select(setupchargenominalcode);
		select.selectByVisibleText(SetupchargeNC);
			
			}
		
	}
	
	
	public void RecurringchargeNC(String RecurringchargeNC) throws InterruptedException {
		
		Thread.sleep(2000);
	    if(RecurringchargeNC.equals("")) {
		System.out.println("Drop Down is not selected");
		}
		else {
		Select select = new Select(recurringchargenominalcode);
		select.selectByVisibleText(RecurringchargeNC);
			
			}
		
	}
	
	
	
	public void slabdetailsedit(String qf, String qt, String rc) throws InterruptedException {
		
		Thread.sleep(3000);
		Editlink.click();
		Thread.sleep(2000);
		Quantityfrom.clear();
		Thread.sleep(2000);
		Quantityfrom.sendKeys(qf);
		Thread.sleep(2000);
		Quantityto.clear();
		Thread.sleep(2000);
		Quantityto.sendKeys(qt);
		Thread.sleep(2000);
		Recurringcharge.clear();
		Thread.sleep(2000);
		Recurringcharge.sendKeys(rc);
		slabsaveedit.click();
	}
	

	public void clickonsave() throws InterruptedException {
		
		Thread.sleep(4000);
		save.click();
	}
	
	
	public void delete() throws InterruptedException, AWTException {

		Thread.sleep(8000);
		this.ScrollPage("0,+600");
		delete.click();
		Thread.sleep(3000);
		Deletepop_up.click();

	}
	
	public void clickoncancelslab() throws InterruptedException {
		
		Thread.sleep(3000);
		cancel.click();
	}
	
	public void clickoncancelbuttn() throws InterruptedException {
		
		Thread.sleep(3000);
		Cancel.click();
	}
	
	public void SDRTariffexception_Edit(String link, String Setupcharge,String Recurringcharge, String SetupchargeNC, String RecurringchargeNC,String qf, String qt, String rc) throws InterruptedException {
		Thread.sleep(4000);
		this.ClickToLink(link);
		this.Setupcharge(Setupcharge);
		this.Recurringcharge(Recurringcharge);
		this.SetupchargeNC(SetupchargeNC);
		this.RecurringchargeNC(RecurringchargeNC);
		this.slabdetailsedit(qf, qt, rc);
		this.clickonsave();
		
	}
	
	
	public void SDRTariffexception_delete(String link) throws InterruptedException, AWTException {
		
		this.ClickToLink(link);
		this.delete();
		this.Delete_validation();
	}
	
	
	
	
	
	
	
	
	/***********************************
	 * Validation elements
	 *****************************************/
	
	
	
	
	@FindBy(id = "quantityfrom-error")
	WebElement quantityfromvalidation;
	@FindBy(id = "quantityto-error")
	WebElement quantitytovalidation;
	@FindBy(id = "slabrecurringcharge-error")
	WebElement recurringchargevalidation;


	String SaveVal = "Saved successfully";
	String DeletVal = "Deleted successfully";
	String quantityfromval = "Quantity From Cannot be empty";
	String quantitytoVal = "Quantity To Cannot be empty";
	String recurringchargeval = "Recurring charge cannot be empty";
	
	
	public void QuantityfromVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = quantityfromval;
		String getValiadtion = quantityfromvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void QuantitytoVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = quantitytoVal;
		String getValiadtion = quantitytovalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void RecurringchargeVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = recurringchargeval;
		String getValiadtion = recurringchargevalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	
	
	public void SaveVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = SaveVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	
	public void DeleteVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = DeletVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void Save_validation() throws InterruptedException {
		this.SaveVal();
	}
	
	public void Delete_validation() throws InterruptedException {
		this.DeleteVal();
	}
	
	
	
	
	public void slabdetails_validation_Edit() throws InterruptedException, AWTException {
		
		Thread.sleep(2000);
		this.ScrollPage("0,+600");
		Editlink.click();
		Thread.sleep(2000);
		Quantityfrom.clear();
		Thread.sleep(2000);
		Quantityto.clear();
		Thread.sleep(2000);
		Recurringcharge.clear();
		slabsaveedit.click();
	}
	
	
	public void _Validation_Edit() throws InterruptedException {
		
		this.QuantitytoVal();
		this.QuantityfromVal();
		this.RecurringchargeVal();
	}
	
	
	
	public void SDRTaiffexception_validation_Edit(String link) throws InterruptedException, AWTException {
		
		Thread.sleep(4000);
		sdrradiobutton.click();
		this.ClickToLink(link);
		this.slabdetails_validation_Edit();
		this._Validation_Edit();
		this.clickoncancelslab();
		this.clickoncancelbuttn();
	}
	
	

	
	
	
	
	
	
	
	/****************************************
	 * Common Method
 	**************************************************/

	public void Validation(String GetValiadtion, String Setvalidation) {
		PageFactory.initElements(driver, this);
		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.out.println("Validation is incorrect: " + GetValiadtion);
				Assert.fail("Test Fail");
		}

	}
	
	
	public void ScrollPage(String ScrollBy) throws AWTException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + ScrollBy + ")");

	}
	
}
