package TariifExemptions;

import java.awt.AWTException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Jun 12, 2020
-- Description	: CDRTariffExemption_Edit.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-WORKSPACE
-- =============================================*/
public class CDRTariffExemption_Edit {
	
	
	
	
	
	
	WebDriver driver;
	@FindBy(id="linetype")
	WebElement Linetype;
	@FindBy(id="chargecode")
	WebElement chargecode;
	@FindBy(id="gatewayid")
	WebElement gateway;
	@FindBy(id="nominal")
	WebElement nominal_code;
	@FindBy(id="carrierid")
	WebElement carrier;
	@FindBy(id="update")
	WebElement save;
	@FindBy(id="delete")
	WebElement Delete;
	@FindBy(xpath="/html/body/div[4]/div/div/div[3]/button[1]")
	WebElement Deletepop_up;
	@FindBy(id="txt_minutepeak_sell")
	WebElement Minute_RatePeak;
	@FindBy(id="txt_minuteoffpeak_sell")
	WebElement Minute_RateOffPeak;
	@FindBy(id="txt_minuteweekend_sell")
	WebElement Minute_RateWeekend;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDeletemessenger;
	
	
	
	
	
	
	
	
	public CDRTariffExemption_Edit(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	
	
	
	public void ClickToLink(String link) throws InterruptedException 
	{
			Thread.sleep(12000);//*[@id="cdr_data"]/tbody/tr[2]/td[1]/a/u
			int Counts = driver.findElements(By.xpath("//*[@id=\"cdr_data\"]/tbody/tr")).size();
			//System.out.println(Counts);//*[@id="sdr_data"]/tbody/tr[2]/td[1]/a/u
			for (int i = 1; i <= Counts; i++) 
				//*[@id="sdr_data"]/tbody/tr[2]/td[1]/a/u
	                      {
				
				Thread.sleep(5000);
				String text = driver.findElement(By.xpath("//*[@id=\"cdr_data\"]/tbody/tr["+i+"]/td[1]/a/u")).getText();
				//System.out.println(text);
				if (link.equals(text)) 
	                       {
					
					Thread.sleep(6000);
					driver.findElement(By.xpath("//*[@id=\"cdr_data\"]/tbody/tr["+i+"]/td[1]/a/u")).click();
					System.out.println("Tariff exemption type is selected");
					Thread.sleep(2000);
					//Compare String
				
					break;   
				}
				
				else {
					
					System.out.println("Tariff exemption type not selected");
					
				}


			
		  }
			}

	public void linetypedropdown(String linetype) throws InterruptedException {
        Thread.sleep(2000);
        if(linetype.equals("")) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(Linetype);
		select.selectByVisibleText(linetype);
		
		}
	} 
	
	
	public void chargecodedropdown(String Chargecode) throws InterruptedException {
        Thread.sleep(2000);
        if(Chargecode.equals("")) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(chargecode);
		select.selectByVisibleText(Chargecode);
		
		}
	} 
	
	public void nominalcodedropdown(String nominalcode) throws InterruptedException {
        Thread.sleep(2000);
        if(nominalcode.equals("")) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(nominal_code);
		select.selectByVisibleText(nominalcode);
		
		}
	} 
	
	public void carrierdropdown(String Carrier) throws InterruptedException {
        Thread.sleep(2000);
        if(Carrier.equals("")) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(carrier);
		select.selectByVisibleText(Carrier);
		
		}
	} 
	
	
	public void gatewaydropdown(String Gateway) throws InterruptedException {
        Thread.sleep(2000);
        if(Gateway.equals("")) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(gateway);
		select.selectByVisibleText(Gateway);
		}
		
		}
	
	public void minuteratepeak(String ratepeak) throws InterruptedException {
		
		Thread.sleep(3000); 
		Minute_RatePeak.clear();
		Thread.sleep(3000); 
		Minute_RatePeak.sendKeys(ratepeak);
	}
	
	
	public void minuterateoffpeak(String rateoffpeak) throws InterruptedException {
		
		Thread.sleep(3000);
		Minute_RateOffPeak.clear();
		Thread.sleep(3000); 
		Minute_RateOffPeak.sendKeys(rateoffpeak);
	}

	public void minuterateweekend(String rateweekend) throws InterruptedException {
		
		Thread.sleep(3000);
		Minute_RateWeekend.clear();
		Thread.sleep(3000); 
		Minute_RateWeekend.sendKeys(rateweekend);
	}

	public void clickonsave() throws InterruptedException {
		
		Thread.sleep(3000);
		save.click();
	}
	

	
	public void delete() throws InterruptedException, AWTException {

		Thread.sleep(7000);
		Delete.click();
		Thread.sleep(7000);
		Deletepop_up.click();

	}
	
	
	
	/***********************************
	 * Validation elements
	 *****************************************/


	String SaveVal = "Saved successfully";
	String DeletVal = "Deleted successfully";
	
	
	public void SaveVal() throws InterruptedException {
		Thread.sleep(5000);
		String setvalidation = SaveVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	
	public void DeleteVal() throws InterruptedException {
		Thread.sleep(3000);
		String setvalidation = DeletVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void Save_validation() throws InterruptedException {
		this.SaveVal();
	}
	
	public void Delete_validation() throws InterruptedException {
		this.DeleteVal();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void CDRtariffExemption_Edit(String link,String linetype,String Chargecode,String nominalcode,String Carrier,String Gateway,String ratepeak,String rateoffpeak,String rateweekend) throws InterruptedException, AWTException {
		
		this.ClickToLink(link);
		this.linetypedropdown(linetype);
		this.chargecodedropdown(Chargecode);
		this.nominalcodedropdown(nominalcode);
		this.carrierdropdown(Carrier);
		this.gatewaydropdown(Gateway);
		this.minuteratepeak(ratepeak);
		this.minuterateoffpeak(rateoffpeak);
		this.minuterateweekend(rateweekend);
		this.clickonsave();
		this.Save_validation();
	}
	
	
	public void CDRtariffexemptiondelete(String link) throws InterruptedException, AWTException {
		
		this.ClickToLink(link);
		this.delete();
		this.Delete_validation();
		
		
	}
	
	
	
	
	
	
	
	
	
	/****************************************
	 * Common Method
 	**************************************************/

	public void Validation(String GetValiadtion, String Setvalidation) {
		PageFactory.initElements(driver, this);
		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.out.println("Validation is incorrect: " + GetValiadtion);
				Assert.fail("Test Fail");
		}

	}
	
}
