package TariifExemptions;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Aug 8, 2020
-- Description	: SDR_Override.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-WORKSPACE
-- =============================================*/
public class SDR_Override {
	
	
	WebDriver driver;
	@FindBy(id = "btn_sdr_override_download")//*[@id="btn_download"]
	WebElement Exportbutton;
	@FindBy(id = "search_data")
	WebElement Search;
	@FindBy(id = "search_btn")
	WebElement Search_Button;
	@FindBy(id = "btn_sdr_override_settings")
	WebElement settingsbutton;
	@FindBy(xpath = "//*[@id=\"exceptionsettings\"]/div/div/label/span")
	WebElement removedoverridechckbox;
	@FindBy(xpath="//*[@id=\"form-cdrexception\"]/div[1]/div[2]/label[3]/div/ins")
	WebElement sdroverrideradiobutton;
	@FindBy(xpath="//*[@id=\"datagrid\"]/tbody/tr/td[4]/a/u")
	WebElement searchlinkdisti;
	@FindBy(xpath="//*[@id=\"datagrid\"]/tbody/tr/td[3]/a/u")
	WebElement searchlinkrslr;
	@FindBy(xpath="//*[@id=\"datagrid\"]/tbody/tr/td[2]/a/u")
	WebElement searchlinkbusns;
	@FindBy(xpath="//*[@id=\"datagrid\"]/tbody/tr/td[1]/a/u")
	WebElement searchlinksite;
	@FindBy(id="pagetitle")
	WebElement Header_NextTab;
	
	
	
	public SDR_Override(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	
	
	
	public void clickonsdroverridebutton() throws InterruptedException 
	{
	
		Thread.sleep(9000);
		sdroverrideradiobutton.click();
	}
	
	public void view_data() throws InterruptedException, AWTException
	{
		Thread.sleep(5000);
		//this.ScrollPage("0,200");
		// Get all the table row elements from the table//*[@id="datagrid"]/tbody/tr[1]/td[1]
		List<WebElement> allRows= driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")); 
		System.out.println("SDR override report list :");
		for(WebElement row : allRows)
		{
			List<WebElement> allColumnsInRow=row.findElements(By.tagName("td"));
		for(WebElement cell : allColumnsInRow)
		{
			System.out.print(cell.getText()+ "|");
		}
		System.out.println();
		}
	}
	
	public void Exportfile(String[] FileTpye) throws InterruptedException {
		Thread.sleep(5000);
		for (int i = 1; i <= FileTpye.length; i++) {
			Thread.sleep(2000);
			Exportbutton.click();
			String text = driver
					.findElement(By
							.xpath("/html/body/div[2]/div/div/div/div[3]/div/div/div[1]/div/ul/li[" + i + "]/a"))
					.getText();
			if (FileTpye[i-1].equals(text)) {
				driver.findElement(
						By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div/div[1]/div/ul/li[" + i + "]/a"))
						.click();
				System.out.println("File type found");
				Thread.sleep(4000);
				assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
			}

			else {

				System.out.println("File type not found");

			}

		}
	}
	

	
	public void clickonsettings() throws InterruptedException {
		
		Thread.sleep(2000);
		settingsbutton.click();
		Thread.sleep(2000);
		removedoverridechckbox.click();
		Thread.sleep(2000);
		removedoverridechckbox.click();
	}
	
	
	public void Searchdata(String search) throws InterruptedException, AWTException {
		Thread.sleep(4000);
		Search.sendKeys(search);
		Thread.sleep(4000);
		Search_Button.click();
	}

	public void textlinkdisti() throws InterruptedException, AWTException {
		Thread.sleep(1000);
		searchlinkdisti.click();

	}

	
	public void textlinkrslr() throws InterruptedException, AWTException {
		Thread.sleep(1000);
		searchlinkrslr.click();
	}
	
	public void textlinkbusns() throws InterruptedException, AWTException {
		Thread.sleep(1000);
		searchlinkbusns.click();
	}
	
	public void textlinksite() throws InterruptedException, AWTException {
		Thread.sleep(1000);
		searchlinksite.click();
	}
	
	
	public void CompareString(String text) throws InterruptedException 
	
	{
		Thread.sleep(4000);
		String HeaderBusns = Header_NextTab.getText();
		System.out.println(HeaderBusns);
		System.out.println("Header :" + text);
		Thread.sleep(2000);
		if (HeaderBusns.equals(text)) {
			System.out.println("Header is :" + HeaderBusns);
			System.out.println("Page is navigated to correctly");
		}
		
		else {
			
			System.out.println("Page is navigated to wrong");
		}
	}

			
	
	
	public void SDROverride_disti(String []FileTpye, String search, String text ) throws InterruptedException, AWTException {
		
		this.clickonsdroverridebutton();
		this.view_data();
		this.Exportfile(FileTpye);
		this.clickonsettings();
		this.Searchdata(search);
		this.textlinkdisti();
		this.CompareString(text);
	}
	

	public void SDROverride_reslr(String []FileTpye, String srch, String text ) throws InterruptedException, AWTException {
	
		this.clickonsdroverridebutton();
		this.view_data();
		this.Exportfile(FileTpye);
		this.clickonsettings();
		this.Searchdata(srch);
		this.textlinkrslr();
		this.CompareString(text);
	}


	public void SDROverride_busns(String []FileTpye, String srch, String text ) throws InterruptedException, AWTException {
	
		this.clickonsdroverridebutton();
		this.view_data();
		this.Exportfile(FileTpye);
		this.clickonsettings();
		this.Searchdata(srch);
		this.textlinkbusns();
		this.CompareString(text);
	}


	public void SDROverride_site(String []FileTpye, String srch, String text ) throws InterruptedException, AWTException {
	
		this.clickonsdroverridebutton();
		this.view_data();
		this.Exportfile(FileTpye);
		this.clickonsettings();
		this.Searchdata(srch);
		this.textlinksite();
		this.CompareString(text);
	}

}
