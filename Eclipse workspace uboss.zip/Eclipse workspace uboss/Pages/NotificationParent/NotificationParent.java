package NotificationParent;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : May 28, 2020,9:34:32 AM
-- Description	: NotificationParent.java
-- Modified by	: 
-- Modified Date: 
-- Project		: UBOSS-5-0-0-Dennu
-- =============================================*/
public class NotificationParent {
	WebDriver driver;
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div[3]/div/button")
	WebElement DeleteAll;
	
	@FindBy(xpath = "/html/body/div[3]/div/div/div[3]/button[1]")
	WebElement DeleteAll_confirm;
	
	public NotificationParent(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	public void Usernotradiobtn() throws InterruptedException {
		Thread.sleep(2000);
		WebElement usernot;
		usernot = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div[2]/label/span[1]"));
		if(!usernot.isSelected()){
			Thread.sleep(2000);
			usernot.click();	
		}
		else
		{
			Thread.sleep(2000);
			System.out.println("Already it is true");
		}
	}
	public void Systemnotradiobtn() throws InterruptedException {
		Thread.sleep(2000);
		WebElement systemnot;
		systemnot = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div[3]/label/span[2]"));
		if(!systemnot.isSelected()){
			Thread.sleep(2000);
			systemnot.click();	
			Thread.sleep(2000);
		}
		else
		{
			Thread.sleep(2000);
			System.out.println("Already it is true");
		}
	}
	
	
	
	
	 public void Delete_button_details(String Delete_Visibility) throws InterruptedException
		{
			
			if (Delete_Visibility.equals("Yes"))
			{
				Thread.sleep(5000);
				DeleteAll.click();
				
				
			}
			else
			{
				System.out.println("Delete button is not visible");
			}
		}
	 
	 public void Deletepopup_button_details(String Deletepopup) throws InterruptedException
		{
			
			if (Deletepopup.equals("Yes"))
			{
				Thread.sleep(8000);
				DeleteAll_confirm.click();
				Thread.sleep(8000);
				this.deleteval();
				
			}
			else
			{
				System.out.println("Delete confirm popup is not visible");
			}
		}

	public void Button_Click( String DataList) throws InterruptedException {
		Thread.sleep(5000);
	int counts = driver.findElements(By.xpath("//*[@id='datagrid']/tbody/tr")).size();
		Thread.sleep(5000);
		if (counts==1) {
			Thread.sleep(5000);
			System.out.println("Delete button is not visible");
			
		}
		else if(counts>=1) {
			{
		for (int i = 1; i <= counts; i++) {
			Thread.sleep(5000);
			String inputvalue=driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[2]/div[2]/table/tbody/tr["+i+"]/td/fieldset/p")).getText();
			Thread.sleep(5000);
			if(inputvalue.equals(DataList)) {
				Thread.sleep(5000);
				driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[2]/div[2]/table/tbody/tr["+i+"]/td/fieldset/button")).click();
				Thread.sleep(5000);
			}
			else  {
			

				System.out.println("No elements to delete");
				}
				
			}
			}
		
				
			}
			
			
		
	}
	
		public void showingrecords() throws InterruptedException
		{
		Thread.sleep(4000);
		
		int total = driver.findElements(By.xpath("//*[@id='datagrid']/tbody/tr")).size();
		System.out.println("Total Number of records = " + total);
		
		for (int i = 1; i <= total; i++) 
		{
		
			String mpath = "//*[@id='datagrid']/tbody/tr[" + i + "]/td[1]";
			String fullXpath = String.format(mpath);
		
			String RPtext = driver.findElement(By.xpath(fullXpath)).getText();
			System.out.println("data  " + i + " is - " + RPtext);
		}
		}
		
		
		
		 public void view_data() throws InterruptedException, AWTException
			{
				Thread.sleep(2000);
				this.ScrollPage("0,200");
				// Get all the table row elements from the table
				List<WebElement> allRows= driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[2]/div[2]/table/tbody/tr")); 
				System.out.println("Notification Parent Viewed :");
				for(WebElement row : allRows)
				{
					List<WebElement> allColumnsInRow=row.findElements(By.tagName("td"));
				for(WebElement cell : allColumnsInRow)
				{
					System.out.print(cell.getText()+ "|");
				}
				System.out.println();
				}
			}
			
		/***************************************************************
		 * Validation Elements
		 ***********************************/
		 @FindBy(xpath = "/html/body/div[2]/div/div/div/div[2]/div/div/p")
			WebElement Delete_Validation;

			String deleteval="Deleted successfully";
			
			public void deleteval() throws InterruptedException {
				Thread.sleep(2000);
				String setvalidation = deleteval;
				String getValiadtion = Delete_Validation.getText();
				this.Validation(setvalidation, getValiadtion);
			}
			public void Delete_validation() throws InterruptedException {
				this.deleteval();
			}
			
		/*********************************************
		 * Main Method
		 * @throws AWTException 
		 ***************************************/
		public void notificationparent(String data,String delete) throws InterruptedException, AWTException
		{
			Thread.sleep(5000);
			this.Systemnotradiobtn();
			Thread.sleep(5000);
			this.view_data();
			Thread.sleep(5000);
			this.Usernotradiobtn();
			Thread.sleep(5000);
			this.view_data();
			this.ScrollPage("0,-700");
			Thread.sleep(15000);
			this.Button_Click(data);
			Thread.sleep(15000);
			this.ScrollPage("0,-700");
			this.Deletepopup_button_details(delete);
			
		}

		/*********************************************
		 * Common Method
		 ***************************************/

		public void Validation(String GetValiadtion, String Setvalidation) {

			if (GetValiadtion.equals(Setvalidation)) {
				System.out.println("Validation is correct as  " + GetValiadtion);
			} else {
				System.err.println("Validation is incorrect : "+GetValiadtion);
				Assert.fail("Test Fail for checking validation:(Aspect:"+Setvalidation+"Result:"+GetValiadtion);
			}

		}
		public void ScrollPage(String ScrollBy) throws AWTException {

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(" + ScrollBy + ")");

		}

		String Text0;
		String Text4;
		String Xpath1;
		String Xpath2;

		/**********************/


		public void Available_Data_selection( String[] DataList, String Counts, String Text, String Apply)
				throws InterruptedException {

			String[] SPLITTEXT = Text.split("0", 2);
			String Text1 = SPLITTEXT[0];
			String Text2 = SPLITTEXT[1];
			Text4 = Text2;
			Text0 = Text1;

			ArrayList<String> ListData = new ArrayList<String>();

			for (int j = 0; j <= DataList.length - 1; j++) {
				ListData.add(DataList[j]);
			}
				int Count = driver.findElements(By.xpath(Counts)).size();
				System.out.println(Count);
				for (int i = 1; i <= Count; i++) {
					String text = driver.findElement(By.xpath(Text0 + i + Text4)).getText();
					Thread.sleep(5000);
					System.out.println(text);
					Thread.sleep(5000);
					if (ListData.contains(text)) {
						driver.findElement(By.xpath(Text0 + i + Text4)).click();
						Thread.sleep(5000);
						driver.findElement(By.xpath(Apply)).click();
						Thread.sleep(5000);

					}
					Count = driver.findElements(By.xpath(Counts)).size();
				}
			

			}


}
		

