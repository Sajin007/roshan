package Report_Summary;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : May 22, 2020,11:06:45 AM
-- Description	: Report_Summary.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-ROSHAN_RAJU
-- =============================================*/
public class Report_Summary {
	
	
	WebDriver driver;
	@FindBy(id="billcycle")
	WebElement invoicemonthdropdown;
	@FindBy(id="view")
	WebElement viewbutton;
	@FindBy(id="divotherExport")
	WebElement Exportbuttn;
	@FindBy(id="divexport")
	WebElement Exportbuttn2;
	@FindBy(xpath="//*[@id=\"invoice\"]/div[1]/div[2]/div/ul/li[1]/a")
	WebElement excel;
	@FindBy(xpath="//*[@id=\"invoice\"]/div[1]/div[2]/div/ul/li[2]/a")
	WebElement csv;
	@FindBy(xpath="//span[@class='hidden-xs-down'][contains(.,'SERVICE')]")
	WebElement Servicetab;
	@FindBy(xpath="//*[@id=\"tabs\"]/li[1]/a")
	WebElement packagetab;
	@FindBy(id="breadcrumb")
	WebElement Breadcrumb_NextTab;
	@FindBy(id="pagetitle")
	WebElement Header_NextTab;
	@FindBy(id="cancel")
	WebElement cancel;
	@FindBy(xpath="//*[@id=\"settings\"]/div/div/label[1]/span")
	WebElement Distributorcheckbox;
	@FindBy(xpath="//*[@id=\"settings\"]/div/div/label[2]/span")
	WebElement Resellercheckbox;
	@FindBy(xpath="//*[@id=\"settings\"]/div/div/label/span")
	WebElement Resellercheckboxdisti;
	@FindBy(xpath="//*[@id=\"settings\"]/div/div/label/span")
	WebElement Businesscheckbox;
	@FindBy(xpath="//*[@id=\"settings\"]/div/div/label/span")
	WebElement Sitecheckbox;
	@FindBy(id="btn_settings")
	WebElement settingsbutton;
	
	
	public Report_Summary(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	
	
	public void invoicemonthdropdown(String invoicemonth) throws InterruptedException {
        Thread.sleep(15000);
        if(invoicemonth.equals(null)) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(invoicemonthdropdown);
		select.selectByVisibleText(invoicemonth);
		
		}
	} 
	
	public void clickonviewbutton() throws InterruptedException {
		
		Thread.sleep(9000);
		viewbutton.click();
	}
	
	public void servicetab() throws InterruptedException {
		
		Thread.sleep(8000);
		Servicetab.click();
		
	}
	
	public void packagetab(String Packagetab) throws InterruptedException {
		if(Packagetab.equals("PACKAGE"))
		{
		Thread.sleep(5000);
		packagetab.click();
		}
		
	}
	
	
	
	public void clickdistributorcheckbox(String checkboxvaluedisti) throws InterruptedException {
		String distributorcheckbox = checkboxvaluedisti.toUpperCase();
		String distributorcheckbox1 = checkboxvaluedisti.toUpperCase();
		if (distributorcheckbox.equals("YES")) {
			Thread.sleep(7000);
			Distributorcheckbox.click();
		}
	}
	
	public void clickdistributorcheckbox1(String checkboxvaluedisti) throws InterruptedException {
		String distributorcheckbox1 = checkboxvaluedisti.toUpperCase();
		if (distributorcheckbox1.equals("YES")) {
			Thread.sleep(9000);
			Distributorcheckbox.click();
		}
	}

	public void clickresellercheckbox(String checkboxvaluereseller) throws InterruptedException {
		String resellercheckbox = checkboxvaluereseller.toUpperCase();
		if (resellercheckbox.equals("YES")) {
			Thread.sleep(7000);
			Resellercheckbox.click();
		}
	}
	
	public void clickresellercheckbox1(String checkboxvaluereseller) throws InterruptedException {
		String resellercheckbox1 = checkboxvaluereseller.toUpperCase();
		if (resellercheckbox1.equals("YES")) {
			Thread.sleep(6000);
			Resellercheckbox.click();
		}
	}
	
	public void clickresellercheckboxdisti(String checkboxvalueresellerdisti) throws InterruptedException {
		String resellercheckboxdisti = checkboxvalueresellerdisti.toUpperCase();
		if (resellercheckboxdisti.equals("YES")) {
			Thread.sleep(8000);
			Resellercheckboxdisti.click();
		}
	}
	
	public void clickresellercheckboxdisti1(String checkboxvalueresellerdisti) throws InterruptedException {
		String resellercheckboxdisti1 = checkboxvalueresellerdisti.toUpperCase();
		if (resellercheckboxdisti1.equals("YES")) {
			Thread.sleep(8000);
			Resellercheckboxdisti.click();
		}
	}
	
	public void clickbusinesscheckbox(String checkboxvaluebusiness) throws InterruptedException {
		String businesscheckbox = checkboxvaluebusiness.toUpperCase();
		if (businesscheckbox.equals("YES")) {
			Thread.sleep(3000);
			Businesscheckbox.click();
		}
	}	
	
	public void clickbusinesscheckbox1(String checkboxvaluebusiness) throws InterruptedException {
		String businesscheckbox1 = checkboxvaluebusiness.toUpperCase();
		if (businesscheckbox1.equals("YES")) {
			Thread.sleep(5000);
			Businesscheckbox.click();
		}
	}				

	public void clicksitecheckbox(String checkboxvaluesite) throws InterruptedException {
		String sitecheckbox = checkboxvaluesite.toUpperCase();
		if (sitecheckbox.equals("YES")) {
			Thread.sleep(2000);
			Sitecheckbox.click();
		}
	}	
	
	public void clicksitecheckbox1(String checkboxvaluesite) throws InterruptedException {
		String sitecheckbox1 = checkboxvaluesite.toUpperCase();
		if (sitecheckbox1.equals("YES")) {
			Thread.sleep(2000);
			Sitecheckbox.click();
		}
	}	
	
	
	
	public void clickonsettingsbutton(String checkboxvaluedisti,String checkboxvaluereseller,String checkboxvalueresellerdisti,String checkboxvaluebusiness,String checkboxvaluesite) throws InterruptedException {
		
		Thread.sleep(8000);
		settingsbutton.click();
		this.clickdistributorcheckbox(checkboxvaluedisti);	
		this.clickresellercheckbox(checkboxvaluereseller);
		this.clickdistributorcheckbox1(checkboxvaluedisti);
		this.clickresellercheckbox1(checkboxvaluereseller);
		this.clickresellercheckboxdisti(checkboxvalueresellerdisti);
		this.clickresellercheckboxdisti1(checkboxvalueresellerdisti);
		this.clickbusinesscheckbox(checkboxvaluebusiness);
		this.clickbusinesscheckbox1(checkboxvaluebusiness);
		this.clicksitecheckbox(checkboxvaluesite);
		this.clicksitecheckbox1(checkboxvaluesite);
		Thread.sleep(12000);
		settingsbutton.click();
	}
	
	

	public void view_data_package() throws InterruptedException, AWTException
	{
		Thread.sleep(50000);
		//this.ScrollPage("0,200");
		// Get all the table row elements from the table
		List<WebElement> allRows= driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")); 
		System.out.println("Report summary Report View list :");
		for(WebElement row : allRows)
		{
			List<WebElement> allColumnsInRow=row.findElements(By.tagName("td"));
		for(WebElement cell : allColumnsInRow)
		{
			System.out.print(cell.getText()+ "|");
		}
		System.out.println();
		}
	}
	

	public void view_data_service() throws InterruptedException, AWTException
	{
		Thread.sleep(50000);
		//this.ScrollPage("0,200");
		// Get all the table row elements from the table
		List<WebElement> allRows= driver.findElements(By.xpath("//*[@id=\"datagrid2\"]/tbody/tr")); 
		System.out.println("Report summary Report View list :");
		for(WebElement row : allRows)
		{
			List<WebElement> allColumnsInRow=row.findElements(By.tagName("td"));
		for(WebElement cell : allColumnsInRow)
		{
			System.out.print(cell.getText()+ "|");
		}
		System.out.println();
		}
	}
	
	
	
	public void Tabclick1(String TAB,String link,String [] FileTpye) throws InterruptedException, AWTException
	{
		
		
		if (TAB.equals("PACKAGE"))
		{
			Thread.sleep(9000);
			packagetab.click();
			System.out.println("********package Tab is Listing*********");
			Thread.sleep(2000);
			this.view_data_package();
			this.Export(FileTpye);
			this.ClickToLink_Packagetab(link);
			
		}
		
		
		
		
		else if(TAB.equals("SERVICE"))
		{
			Thread.sleep(9000);
			Servicetab.click();
			System.out.println("********Service Tab is Listing*********");
			Thread.sleep(2000);
			this.view_data_service();
			this.Export(FileTpye);
			this.ClickToLink_Servicetab(link);
			
			
		}
		
	}
	
	public void Tabclick(String TAB,String link,String [] FileTpye) throws InterruptedException, AWTException
	{
		
		
		if (TAB.equals("PACKAGE"))
		{
			Thread.sleep(8000);
			packagetab.click();
			System.out.println("********package Tab is Listing*********");
			Thread.sleep(2000);
			this.view_data_package();
			this.Export2(FileTpye);
			this.ClickToLink_Packagetab(link);
			
		}
		
		
		
		
		else if(TAB.equals("SERVICE"))
		{
			Thread.sleep(8000);
			Servicetab.click();
			System.out.println("********Service Tab is Listing*********");
			Thread.sleep(2000);
			this.view_data_service();
			this.Export2(FileTpye);
			this.ClickToLink_Servicetab(link);
			
			
		}
		
	}


	
	

	public void Export(String[] FileTpye) throws InterruptedException {
		System.out.println("Export Checking :");
		Thread.sleep(5000);
		for (int i = 1; i <= FileTpye.length; i++) {
			Thread.sleep(2000);
			Exportbuttn.click();
			String text = driver
					.findElement(By
							.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div[2]/div/ul/li[" + i + "]/a"))
					.getText();
			if (FileTpye[i-1].equals(text)) {
				driver.findElement(
						By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div[2]/div/ul/li[" + i + "]/a"))
						.click();
				System.out.println("File type found");
				Thread.sleep(4000);
				assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
			}

			else {

				System.out.println("File type not found");

			}

		}
	}
	
	
	public void Export2(String[] FileTpye) throws InterruptedException {
		System.out.println("Export Checking :");
		Thread.sleep(5000);
		for (int i = 1; i <= FileTpye.length; i++) {
			Thread.sleep(2000);
			Exportbuttn2.click();
			String text = driver
					.findElement(By
							.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div[2]/div/ul/li[" + i + "]/a"))
					.getText();
			if (FileTpye[i-1].equals(text)) {
				driver.findElement(
						By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div[2]/div/ul/li[" + i + "]/a"))
						.click();
				System.out.println("File type found");
				Thread.sleep(4000);
				assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
			}

			else {

				System.out.println("File type not found");

			}

		}
	}
	
	public void ClickToLink_Packagetab(String link) throws InterruptedException 
{
		Thread.sleep(5000);
		int Counts = driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")).size();
		System.out.println(Counts);
		for (int i = 1; i < Counts; i++) 

                      {
			Thread.sleep(4000);
			
			String text = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr["+i+"]/td[1]/a/u")).getText();
			
			System.err.println(link);
			System.err.println(text);
			
			if (link.equals(text)) 
                       {
				
				Thread.sleep(8000);
				driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr["+i+"]/td[1]/a/u")).click();
				System.out.println("Report is selected");
				Thread.sleep(2000);
				//Compare String
				this.CompareString(text);
				break;
			}

			else if(link.equals(""))
                        {

				System.out.println("Report is not selected");

			}
		
	  }

}


	
	public void ClickToLink_Servicetab(String link) throws InterruptedException 
{
		Thread.sleep(6000);
		int Counts = driver.findElements(By.xpath("//*[@id=\"datagrid2\"]/tbody/tr")).size();
		System.out.println(Counts);
		for (int i = 1; i < Counts; i++) 

                      {
			Thread.sleep(6000);
			
			String text = driver.findElement(By.xpath("//*[@id=\"datagrid2\"]/tbody/tr["+i+"]/td[1]/a/u")).getText();
			
			System.err.println(link);
			System.err.println(text);
			
			if (link.equals(text)) 
                       {
				
				Thread.sleep(6000);
				driver.findElement(By.xpath("//*[@id=\"datagrid2\"]/tbody/tr["+i+"]/td[1]/a/u")).click();
				System.out.println("Report is selected");
				Thread.sleep(2000);
				//Compare String
				this.CompareString(text);
				break;
			}

			else if(link.equals(""))
				{

				System.out.println("Report is not selected");

			}
		
	  }

}
	

	/*******************************************
	 * String Compare
	 *****************************************/

	public void CompareString(String text) throws InterruptedException 
	
	{
		String HeaderBusns = Header_NextTab.getText();
		System.out.println("Header1 :" + text);
		if (HeaderBusns.contains(text)) {
			System.out.println("Header is :" + HeaderBusns);
			System.out.println("Page is navigated to correctly");		
		driver.navigate().back();
		}
		else {			
	    ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
	    driver.switchTo().window(tabs2.get(1));
		Thread.sleep(4000);
		String Header = Breadcrumb_NextTab.getText();
		System.out.println("Header2 :" + text);
		if (Header.contains(text)) {
			System.out.println("Header is :" + Header);
			System.out.println("Page is navigated to correctly");
			
		} else {
			System.out.println("Header is :" + Header);
			System.err.println("Page is navigated to wrong");
			
		}
		 Thread.sleep(2000);
		 driver.switchTo().window(tabs2.get(1)).close();
		 Thread.sleep(2000);
		driver.switchTo().window(tabs2.get(0));
		}
		  
		}  
		
			 
	
	
	public void Report_Summary_report(String invoicemonth,String TAB,String [] FileTpye,String link,String checkboxvaluedisti,String checkboxvaluereseller,String checkboxvalueresellerdisti,String checkboxvaluebusiness,String checkboxvaluesite) throws InterruptedException, AWTException {
		
		this.invoicemonthdropdown(invoicemonth);
		this.clickonviewbutton();
		this.Tabclick1(TAB,link,FileTpye);
		this.clickonsettingsbutton(checkboxvaluedisti,checkboxvaluereseller,checkboxvalueresellerdisti,checkboxvaluebusiness,checkboxvaluesite);
	
		
	
		

	}
	
	public void Report_Summary_report2(String invoicemonth,String TAB,String link,String [] filetype) throws InterruptedException, AWTException {
		
		this.invoicemonthdropdown(invoicemonth);
		this.clickonviewbutton();
		this.Tabclick(TAB,link,filetype);
		

		

	}
	



	

}
