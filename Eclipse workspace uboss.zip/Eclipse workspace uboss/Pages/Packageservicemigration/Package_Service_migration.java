package Packageservicemigration;

import java.awt.AWTException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : May 18, 2020,11:35:28 AM
-- Description	: Package_service_migration.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-ROSHAN_RAJU
-- =============================================*/
public class Package_Service_migration {
	
	
	
	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"clientresellerid\"]")
	WebElement clientreseller;

	@FindBy(xpath = "//*[@id=\"clientbusinessid\"]")
	WebElement clientbusiness;

	@FindBy(xpath = "//*[@id=\"ddloldpacandser\"]")
	WebElement ddloldpacandser;

	@FindBy(xpath = "//*[@id=\"ddlnewpacandser\"]")
	WebElement ddlnewpacandser;

	@FindBy(xpath = "//*[@id=\"tblmigration\"]/tbody/tr/td[1]/label/span")
	WebElement userSelect;

	@FindBy(xpath = "//*[@id=\"btn_migrate\"]")
	WebElement btn_migrate;
	@FindBy(xpath = "/html/body/div[3]/div/div/div[3]/button[1]")
	WebElement btn_migrateyes;
	
	
	
	
	
	public Package_Service_migration(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	
	public void reseller(String reseller) throws InterruptedException {
		Thread.sleep(8000);
		if (reseller.equals("")) {
			
			Thread.sleep(2000);

			System.out.println("element not selected");
		}
		

		
		else
		{
		
		Select select = new Select(clientreseller);
		select.selectByVisibleText(reseller);
	}
	}
	
	public void business(String business) throws InterruptedException {
		Thread.sleep(7000);
		
		if (business.equals("")) {
			
			Thread.sleep(2000);

			System.out.println("element not selected");
		}
		
		else
		{
		
		Select select = new Select(clientbusiness);
		select.selectByVisibleText(business);
		}
	}
	
	public void oldpacandser(String oldpacandser) throws InterruptedException {
		Thread.sleep(12000);
		Select select = new Select(ddloldpacandser);
		select.selectByVisibleText(oldpacandser);
	}
	
	public void newpacandser(String newpacandser) throws InterruptedException {
		Thread.sleep(12000);
		Select select = new Select(ddlnewpacandser);
		select.selectByVisibleText(newpacandser);
	}
	

	public void userSelect() throws InterruptedException, AWTException {
		Thread.sleep(4000);
		userSelect.click();
	}
	
	public void btn_migrate() throws InterruptedException, AWTException {
		Thread.sleep(7000);
		btn_migrate.click();
	}
	public void btn_migrateyes() throws InterruptedException, AWTException {
		Thread.sleep(7000);
		btn_migrateyes.click();
	}
	

	
	
	
	/*******************************************
	 * Main Methods
	 ********************************/

	public void Pkg_Service_migration(String reseller,String business,String oldpacandser,String newpacandser) throws InterruptedException, AWTException {
		this.reseller( reseller);
		this.business(business);
		this.oldpacandser( oldpacandser);
		this.newpacandser( newpacandser);
		this.userSelect();
		this. btn_migrate();
		this.btn_migrateyes();
		Thread.sleep(25000);
		
		

	}
	

	
	
	/****************************************
	 * Common Method
	 **************************************************/
	
	public void Validation(String GetValiadtion, String Setvalidation,String res) {
		PageFactory.initElements(driver, this);
		if (res.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + res);
		} else {
			System.out.println("Validation is incorrect: " + GetValiadtion);
			Assert.fail("Test Fail");
		}

	}


}
