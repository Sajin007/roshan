package Services;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Sep 28, 2020 , 10:52:36 AM
-- Description	: Third_Party_User_Edit.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class Third_Party_User_Edit {
	
	
	
	
	
	
	WebDriver driver;
    @FindBy(id="btn_add")
    WebElement ADD;
    @FindBy(id="ddlServiceType")
    WebElement Service_Type;
    @FindBy(id="txtName")
    WebElement Name;
    @FindBy(id="txtOSSName")
    WebElement OSSName;
    @FindBy(id="txtDecription")
    WebElement Description;
    @FindBy(id="txtEmail")
    WebElement Emailnotification;
    @FindBy(id="ddlCountry")
    WebElement Country;
    @FindBy(id="ddlSuppliers")
    WebElement Supplier;
    @FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[7]/div/label/span")
    WebElement Can_Be_Assigned;
    @FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[8]/div/label/span")
    WebElement Mandatory_Assignment;
    @FindBy(xpath="//*[@id=\"general\"]/div/div/div/div[9]/div/label/span")
    WebElement Allowed_In_Child_Level_Packages;
    @FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[10]/div/label/span")
    WebElement Can_Be_Explicitly_Assigned;
    @FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[11]/div/label/span")
    WebElement Multiple_Instances_Allowed;
    @FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[12]/div/label/span")
    WebElement Can_Change_Start_Date;
    @FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[13]/div/label/span")
    WebElement Can_Change_Tariff_Rate;
    
    @FindBy(id="ddlPrimaryPackage")
    WebElement Dependent_package;
    @FindBy(id="ddlDependentService")
    WebElement Dependent_Service;
    @FindBy(id="txtSupplierPartNumber")
    WebElement Supplier_Part_Number;
    @FindBy(id="ddlServiceGroupId")
    WebElement UserService_Group;
    
    @FindBy(id = "search_data")
	WebElement search;
	@FindBy(id = "search_btn")
	WebElement searchbtn;
    
    
    
    //***************** Contract Rule***********************//
    
    
    @FindBy(id="minimumduration")
    WebElement Min_Duration;
    @FindBy(id="txtnotificationperiod")
    WebElement Notification_Period;
    @FindBy(id="quarantineperiod")
    WebElement Qurentine_Period;
    
    @FindBy(id="txtRollingContractTerm")
    WebElement RollingContract_P;
    @FindBy(id="txtCancellationPeriod")
    WebElement Cancellation_P;
    
    
    
    @FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[18]/div/label[1]/span[2]")
    WebElement Standard_Radio;
    @FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[18]/div/label[2]/span[2]")
    WebElement Rolling_Contract_radio;
    
    @FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[19]/div[4]/div/label/span[2]")
    WebElement NotificationPeriod_Check;
    
    @FindBy(id="save_btn")
	WebElement save;
    
    @FindBy(id = "COMMONA215")
	WebElement cancel;
    

	@FindBy(id = "btn_settings")
	WebElement settings;

	@FindBy(xpath = "//*[@id=\"settings\"]/div/div/label/span")
	WebElement includeremovedcheck;


	@FindBy(id = "search_data")
	WebElement SearchField;

	@FindBy(id = "search_btn")
	WebElement SearchField_Button;

	@FindBy(xpath = "//*[@id=\"datagrid\"]/tbody/tr/td[1]/a/u")
	WebElement Edit_Service_link;
	
	@FindBy(xpath = "//*[@id=\"contactrule\"]/span[2]")
	WebElement contractrule;
	@FindBy(xpath = "//*[@id=\"datagrid\"]/tbody/tr/td")
	WebElement Header_NextTab;

	

	@FindBy(xpath = "//*[@id=\"usagelist\"]/span[2]")
	WebElement serviceusage;
	
	@FindBy(xpath = "//*[@id=\"general\"]/span[2]")
	WebElement generaltab;
	
	@FindBy(id = "deletedetails")
	WebElement Delete_Button;

	@FindBy(xpath = "/html/body/div[3]/div/div/div[3]/button[1]")
	WebElement Delete_Button_Link;
	                  
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[3]/div[4]/div/button")
	WebElement savecontractruleroll;
	
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[2]/div[5]/div/button")
	WebElement savecontractrulStandard;
	
	@FindBy(xpath = "//*[@id=\"divNormalContractRule\"]/div[4]/div/label/span[2]")
	WebElement combinetruecheckboxedit;
	
	@FindBy(xpath = "/html/body/div[3]/div/div/div[3]/button[1]")
	WebElement saveconfirm;


	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div/form/div[1]/label[2]/span")
	WebElement Rolling;

    
    
    
    public Third_Party_User_Edit(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
 }
 
 
 public void GoToUrl(String Url) {
        driver.get(Url);
        }

 
   public void clickoncancel() throws InterruptedException

		{
			Thread.sleep(4000);
			cancel.click();
		}
        
        public void clickonsave() throws InterruptedException

    	{
    		Thread.sleep(4000);
    		save.click();
    	}
        
        
        public void clickonsavecontractrule() throws InterruptedException

    	{
    				
    			Thread.sleep(9000);
    			savecontractrulStandard.click();
    				

    	}
        
        public void clickonsavecontractruleST() throws InterruptedException

    	{
    				
    			Thread.sleep(9000);
    			savecontractrulStandard.click();
    				

    	}
        
        public void ClickinsavecontractruleRO() throws InterruptedException
        {
        	    Thread.sleep(9000);
    			savecontractruleroll.click();
        }
        

    	public void GoTogeneraltab() throws InterruptedException {
    		Thread.sleep(3000);
    		generaltab.click();

    	}
        
        
        public void Contract_RuleTab() throws InterruptedException

    	{
    		Thread.sleep(6000);
    		contractrule.click();
    	}

        
        public void Service_UsageTab() throws InterruptedException

    	{
    		Thread.sleep(4000);
    		serviceusage.click();
    	}
        
        
        public void GoToEdit_Link(String Servicename) throws InterruptedException {
        	Thread.sleep(2000);
    		SearchField.clear();
    		Thread.sleep(2000);
    		SearchField.sendKeys(Servicename);
    		Thread.sleep(2000);
    		SearchField_Button.click();
    		Thread.sleep(2000);
    		Edit_Service_link.click();

    	

    	}
        
     // scroll page
    	public void ScrollPage(String ScrollBy) throws AWTException 
    	{
    		JavascriptExecutor js = (JavascriptExecutor) driver;
    		js.executeScript("window.scrollBy(" + ScrollBy + ")");

    	}
        
        
        
    	public void name(String name) throws InterruptedException {

    		Thread.sleep(2000);
    		Name.sendKeys(name);
    	}

    	public void NameClear() throws InterruptedException {
    		Thread.sleep(2000);
    		Name.clear();

    	}
    	
    	
    	
    	  public void Description(String description) throws InterruptedException {
               
               if (description.equals("")) {
                     
                     Thread.sleep(2000);

                     System.out.println("Description is empty");
               }
               
               
               else {
                     
                     Thread.sleep(2000);
                     Description.clear();
                     Thread.sleep(2000);
                     Description.sendKeys(description);
        }
               
        }
    	  

          public void country(String country) throws InterruptedException {
                 
                 Thread.sleep(2000);
           if(country.equals("")) {
                       System.out.println("Drop Down is not selected");
                 }
                 else {
           Select select = new Select(Country);
                 select.selectByVisibleText(country);
                 
                 }
          }
        
        
        public void Email(String emailValid) throws InterruptedException {
        	
        	String email = emailValid;
               
               if (email.equals("")) {
                     
                     Thread.sleep(2000);

                     System.out.println("Email notification field is empty");
               }
               
               
               else {
                     
                     Thread.sleep(2000);
                     Emailnotification.clear();
                     Thread.sleep(2000);
                     Emailnotification.sendKeys(email);
        }
               
        }
        
        public void Delete() throws InterruptedException, AWTException {
    		
    		Thread.sleep(2000);
    		this.ScrollPage("0,-900");
    		Delete_Button.click();
    		Thread.sleep(2000);
    		Delete_Button_Link.click();

    	}
        
        
        

    	public void Service_DELETE(String search) throws InterruptedException, AWTException {
    		this.GoToEdit_Link(search);
    		this.Delete();
    		Thread.sleep(4000);
    		this.DelVal();
    		Thread.sleep(6000);
    		//this.includeremovedcheck(search);
    	}
    	
    	
    	public void Service_DELETE_Rolling(String search2) throws InterruptedException, AWTException {
    		this.GoToEdit_Link(search2);
    		this.Delete();
    		Thread.sleep(4000);
    		this.DelVal();
    		Thread.sleep(6000);
    		//this.includeremovedcheck(search2);
    	}
 
 
        
        /******************
         * Assignment Rules Checkboxes
         * 
         * 
         ***************************/
        
        
        public void clickoncanbeassignedcheckbox(String checkbox1) throws InterruptedException {
   		 
   		 if (checkbox1.equals("yes")) {
   				Thread.sleep(2000);
   				Can_Be_Assigned.click();
   			}
   		 else {
   		 Thread.sleep(2000);
   		 System.out.println("Can be assigned check box not selected");
   	 }
   	 }

   	 
   	 
   	 public void clickonmandatoryassignmentcheckbox(String checkbox2) throws InterruptedException {
   		 
   		 if (checkbox2.equals("yes")) {
   		 
   			 Thread.sleep(2000);
   		 Thread.sleep(2000);
   		 Mandatory_Assignment.click();
   		 }
   		 else {
   			 Thread.sleep(2000);
   			 System.out.println("Mandatory assignment check box not selected");
   	 }
   	 }
   	
   	 public void clickonallowedinchildlevelpackagescheckbox(String checkbox3) throws InterruptedException {
   		 
   		 if (checkbox3.equals("yes")) {
   			 
   			 Thread.sleep(2000);
   		 Allowed_In_Child_Level_Packages.click();
   		 }
   		 else {
   			 Thread.sleep(2000);
   			 System.out.println("Allowed in child level package check box not selected");
   	 } 
   	 }
   	 
   	 public void clickoncanbeexplicitlyassignedcheckbox(String checkbox4) throws InterruptedException {
   		
   		 if (checkbox4.equals("yes")) {
   			  
   		 Thread.sleep(2000);
   		 Can_Be_Explicitly_Assigned.click();
   		 }
   		 else {
   			 Thread.sleep(2000);
   			 System.out.println("Can be explicitily assigned check box not selected");
   	 } 
   	 }
   	 
   	 
   	 public void clickonmultipleinstancesallowedcheckbox(String checkbox5) throws InterruptedException {
   		 
   		 if (checkbox5.equals("yes")) {
   			  
   		 Thread.sleep(2000);
   		 Multiple_Instances_Allowed.click();
   		 }
   		 else {
   			 Thread.sleep(2000);
   			 System.out.println("Multiple instances allowed check box not selected");
   	 } 
   	 }
   	 
   	 public void clickoncanchangestartdatecheckbox(String checkbox6) throws InterruptedException {
   		 
   		 if (checkbox6.equals("yes")) {
   		 Thread.sleep(2000);
   		 Can_Change_Start_Date.click();
   		 }
   		 else {
   			 Thread.sleep(2000);
   			 System.out.println("Can change start date check box not selected");
   	 } 
   	 }
   	 
   	 
   	 public void clickoncanchangetariffratecheckbox(String checkbox7) throws InterruptedException {
   		 
   		 if (checkbox7.equals("yes")) {
   		 Thread.sleep(2000);
   		 Can_Change_Tariff_Rate.click();
   		 }
   		 else {
   			 Thread.sleep(2000);
   			 System.out.println("Can chage tariff rate check box not selected");
   	 } 
   	 }
   	 
   	 
   	 
   	 /******************************
   	  * Additional Information
   	 * @throws InterruptedException 
   	  * 
   	  * 
   	  **************************/
   	 
   	 
   	 
   	 public void Supplier_PartNumber(String suppnum) throws InterruptedException
   	 {
   		 if (suppnum.equals("")) {
				
				Thread.sleep(2000);

				System.out.println("Supplier part number field is empty");
			}
				
				
			else {
					
				Thread.sleep(2000);
				Supplier_Part_Number.clear();
				Thread.sleep(2000);
				Supplier_Part_Number.sendKeys(suppnum);
		}	
   	 }
   	 
   	
   	 
   	 public void Dependentant_Service(String DepService) throws InterruptedException
     {
     	 Thread.sleep(2000);
          if(DepService.equals("")) {
                      System.out.println("Drop Down is not selected");
                }
                else {
          Select select = new Select(Dependent_Service);
                select.selectByVisibleText(DepService);
                
                }
     }
   	 
   	public void User_Service(String UsrService) throws InterruptedException
    {
    	 Thread.sleep(2000);
         if(UsrService.equals("")) {
                     System.out.println("Drop Down is not selected");
               }
               else {
         Select select = new Select(UserService_Group);
               select.selectByVisibleText(UsrService);
               
               }
    }
   	
   	
	public void Dependant_Package(String DepPack) throws InterruptedException
    {
    	 Thread.sleep(2000);
         if(DepPack.equals("")) {
                     System.out.println("Drop Down is not selected");
               }
               else {
         Select select = new Select(Dependent_package);
               select.selectByVisibleText(DepPack);
               
               }
    }
	
	public void clickoncombinetruecheckboxedit(String combinetrue) throws InterruptedException {

		if (combinetrue.equals("yes")) {
			Thread.sleep(2000);
			combinetruecheckboxedit.click();
		} else {
			Thread.sleep(2000);
			System.out.println("Combine true checkbox check box not selected");
		}
	}
	
	public void clickonsavecontractruleconfirm() throws InterruptedException

	{
		Thread.sleep(2000);
		saveconfirm.click();
	}

	
	/*************************
	 * CONTRACT RULE
	 * 
	 * ************************/
	
	
	
	
	public void minimumduration(String mdvalid) throws InterruptedException {
		Thread.sleep(2000);
		String md = mdvalid;
		Min_Duration.sendKeys(md);
	}

	public void notificationperiod(String npvalid) throws InterruptedException {
		Thread.sleep(2000);
		String np = npvalid;
		Notification_Period.sendKeys(np);
	}

	public void quarantineperiod(String qpvalid) throws InterruptedException {
		Thread.sleep(2000);
		String qp = qpvalid ;
		Qurentine_Period.sendKeys(qp);
	}
	
	public void RollingContract_period(String RP) throws InterruptedException {
		Thread.sleep(2000);
		RollingContract_P.sendKeys(RP);
		
	}
	
	public void Cancellation_Period(String CP) throws InterruptedException
	{
		Thread.sleep(2000);
		Cancellation_P.sendKeys(CP);
	}
	
	
	public void Rolling_Contactrule(String RP,String CP) throws InterruptedException
	{
		this.RollingContract_period(RP);
		
		this.Cancellation_Period(CP);
	}
	
	public void Standard_Contactrule(String md,String np,String qp) throws InterruptedException
	{
		this.minimumduration(md);
		this.notificationperiod(np);
		this.quarantineperiod(qp);
	}
	
	
	
	// CONTRACT TYPE
	
	@FindBy(xpath = "\r\n" + 
			"/html/body/div[2]/div[2]/div/div/div[3]/div/div/div/div/form/div[1]/label[2]/span")
	WebElement contracttype_label;
	
	
	public void Contract_type(String mdvalid,String npvalid,String qpvalid,String RP,String CP) throws InterruptedException, AWTException
	{
		String getContract;
		try {
		 getContract = contracttype_label.getText();
		}
		catch (org.openqa.selenium.NoSuchElementException e) {
			
			getContract = Rolling.getText();
			
		}
		
		
		
		
		if (getContract.contentEquals("Standard"))
		{
			//System.out.println("Contract type is Standard");
			this.Standard_Contactrule(mdvalid, npvalid, qpvalid);
			this.ScrollPage("0,+900");
			this.clickonsavecontractruleST();
			
		}
		else
		{
			//System.out.println("Contract type is Rolling Contract ");
			this.Rolling_Contactrule(RP, CP);
			this.ScrollPage("0,+900");
			this.ClickinsavecontractruleRO();
			
			
		}
	 }
	
	public void ContractType_Clearing() throws InterruptedException, AWTException
	{
		String getContract;
		try {
		 getContract = contracttype_label.getText();
		}
		catch (org.openqa.selenium.NoSuchElementException e) {
			
			getContract = Rolling.getText();
			
		}
		//System.err.println("Contract Type is " + getContract);
		
		if (getContract.contentEquals("Standard")) {
			
			Min_Duration.clear();
			Notification_Period.clear();
			Qurentine_Period.clear();
			this.ScrollPage("0,+900");
			this.clickonsavecontractruleST();
			
			
		}else {
			
			Rollingvalid.clear();
			CancellationValid.clear();
			this.ScrollPage("0,+900");
			this.ClickinsavecontractruleRO();
			
		}
	}
	
	public void Contract_Validation_Checking() throws InterruptedException
	{
		String getContract;
		try {
		 getContract = contracttype_label.getText();
		}
		catch (org.openqa.selenium.NoSuchElementException e) {
			
			getContract = Rolling.getText();
			
		}
		
		

		//System.out.println("Contract Type is " + getContract);
		
		if (getContract.contentEquals("Standard")) {
			
			this.mindurationVal();
			this.notificationperiodval();
			this.quarantineperiodval();
			
			
		}else {
			
			
			this.Roll_Val();
			this.Cancel_val();
			
		}
		
	}
	
	public void Searchbutton(String searc) throws InterruptedException, AWTException {
		Thread.sleep(2000);
		search.sendKeys(searc);
		Thread.sleep(4000);
		searchbtn.click();
	}


	public void clickonserviceusage() throws InterruptedException

	{
		Thread.sleep(6000);
		serviceusage.click();
	}
	
	
	public void CompareString(String text) throws InterruptedException 
	
	{
		String HeaderBusns = Header_NextTab.getText();
		System.out.println(HeaderBusns);
		if (HeaderBusns.contains(text)) {
	
			System.out.println("No data available in table");
			
		}
	}
	//*[@id="datagrid"]/tbody/tr[1]/td[1]/a/u
	public void includeremovedcheck(String deletedValue) throws InterruptedException {
		settings.click();
		Thread.sleep(4000);//*[@id="datagrid"]/tbody/tr[1]/td[1]/a/u //*[@id="datagrid"]/tbody/tr[71]/td[1]
		includeremovedcheck.click();
		int Counts = driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")).size();// *[@id="datagrid"]/tbody/tr[1]/td
		Thread.sleep(4000);
		for (int i = 1; i <= Counts; i++) {
			String inputvalue = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr[" + i + "]/td[1]")).getText();
			System.out.println(inputvalue);
			if (inputvalue.equals(deletedValue)) {
				String color = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr[" + i + "]/td[1]"))
						.getCssValue("color");

				String[] hexValue = color.replace("rgba(", "").replace(")", "").split(",");

				int hexValue1 = Integer.parseInt(hexValue[0]);
				hexValue[1] = hexValue[1].trim();
				int hexValue2 = Integer.parseInt(hexValue[1]);
				hexValue[2] = hexValue[2].trim();
				int hexValue3 = Integer.parseInt(hexValue[2]);

				String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);

				Assert.assertEquals("#fc4b6c", actualColor);
				System.out.println(deletedValue + " is deleted and also listed in include removed");

			}
		}
	}



	
	

	
	
/***************************
 * 
 * Edit Validation
 * 
 * *************************/
	
	@FindBy(id = "txtRollingContractTerm")
	WebElement Rollingvalid;
	
	@FindBy(id = "txtCancellationPeriod")
	WebElement CancellationValid;
	
	
	@FindBy(id = "txtName-error")
	WebElement namevalidation;
	
	@FindBy(id = "txtEmail-error")
	WebElement emailvalidation;
	
	
	@FindBy(id = "minimumduration-error")
	WebElement mindurationvalidation;
	@FindBy(id = "txtnotificationperiod-error")
	WebElement notificationperiodvalidation;
	@FindBy(id = "quarantineperiod-error")
	WebElement quarantineperiodvalidation;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDeletemessenger;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement Delete_Sucessfull_msg;
	
	@FindBy(id = "txtRollingContractTerm-error")
	WebElement Rollingvalidation;
	@FindBy(id = "txtCancellationPeriod-error")
	WebElement CancelPeriodvalidation;
	
	
	
	String nameval = "Name cannot be empty";
	String emailval = "Email ID is in incorrect format";
	String mindurationVal = "Minimum duration cannot be empty";
	String notificationperiodval = "Notification period cannot be empty";
	String quarantineperiodval = "Quarantine period cannot be empty/zero";
	String SaveVal = "Saved successfully";
	String DelVal = "Deleted successfully";
	String rollval = "Rolling contract term cannot be empty";
	String Cancellationperiod_val = "Cancellation period cannot be empty";
	
	
	
	
	public void nameval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = nameval;
		String getValiadtion = namevalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void emailval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = emailval;
		String getValiadtion = emailvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	
	public void mindurationVal() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = mindurationVal;
		String getValiadtion = mindurationvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void notificationperiodval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = notificationperiodval;
		String getValiadtion = notificationperiodvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void quarantineperiodval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = quarantineperiodval;
		String getValiadtion = quarantineperiodvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void saveVal() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = SaveVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void DelVal() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = DelVal;
		String getValiadtion = Delete_Sucessfull_msg.getText();
		this.Validation(getValiadtion, setvalidation);
	}
	
	public void Roll_Val() throws InterruptedException
	{
		Thread.sleep(2000);
		String setvalidation = rollval;
		String getValiadtion = Rollingvalidation.getText();
		this.Validation(getValiadtion, setvalidation);
	}
	
	public void Cancel_val() throws InterruptedException {
		
		Thread.sleep(2000);
		String setvalidation = Cancellationperiod_val;
		String getValiadtion = CancelPeriodvalidation.getText();
		this.Validation(getValiadtion, setvalidation);
		
	}
	
	public void Save_validation() throws InterruptedException 
	{
		this.saveVal();
	}
	
	

	
	
	/*****************************
	 * 
	 * MAIN METHODS 
	 * @throws InterruptedException 
	 * @throws AWTException 
	 * 
	 */
	
	
	
	public void Service_Edit_Validation(String Servicename,String email) throws InterruptedException, AWTException
	{
		this.GoToEdit_Link(Servicename);
		this.NameClear();
		this.Email(email);
		this.ScrollPage("0,+900");
		this.clickonsave();
		this.nameval();
		this.emailval();
		
		
		
		this.ScrollPage("0,-900");
		this.Contract_RuleTab();
		
		this.ContractType_Clearing();
		
		
		
		this.Contract_Validation_Checking();
		
		
		this.ScrollPage("0,-900");
		this.GoTogeneraltab();
		this.clickoncancel();
	}
	
	
	
	public void Service_Edit(String Servicename, String name1, String Description1, String Email1, String country, String checkbox1,String checkbox2 ,String checkbox3,String checkbox4,String checkbox5, String checkbox6,String checkbox7,String DepPack, String DepService, String suppnum, String UsrService, String mdvalid, String npvalid, String qpvalid, String combinetrue,String search,String RP,String CP,String deletedvalue,String text) throws InterruptedException, AWTException
	{
		this.GoToEdit_Link(Servicename);
		this.NameClear();
		this.name(name1);

		this.Description(Description1);
		this.Email(Email1);
		this.country(country);
		
		this.clickoncanbeassignedcheckbox(checkbox1);
		this.clickonmandatoryassignmentcheckbox(checkbox2);
		this.clickonallowedinchildlevelpackagescheckbox(checkbox3);
		this.clickoncanbeexplicitlyassignedcheckbox(checkbox4);
		this.clickonmultipleinstancesallowedcheckbox(checkbox5);
		this.clickoncanchangestartdatecheckbox(checkbox6);
		this.clickoncanchangetariffratecheckbox(checkbox7);
		
		
		this.Dependant_Package(DepPack);
		this.Dependentant_Service(DepService);
		this.Supplier_PartNumber(suppnum);
		this.User_Service(UsrService);
		
		this.ScrollPage("0,-900");
		this.Contract_RuleTab();
		this.ContractType_Clearing();
		this.Contract_type(mdvalid,npvalid,qpvalid,RP,CP);
		this.clickonsavecontractruleconfirm();
		this.Save_validation();
		this.clickonserviceusage();
		this.Searchbutton(search);
		//this.includeremovedcheck(deletedvalue);
		this.CompareString(text);
		this.GoTogeneraltab();
		this.ScrollPage("0,+700");
		this.clickonsave();
		
				
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
				
				
			/***********************************************
			 * COMMON METHOD
			 **********************************************/

			// Validation

			public void Validation(String GetValiadtion, String Setvalidation) {
				PageFactory.initElements(driver, this);
				if (GetValiadtion.equals(Setvalidation)) {
					System.out.println("Validation is correct as  " + GetValiadtion);
				} else {
					System.out.println("Validation is incorrect: " + GetValiadtion);
					Assert.fail("Test Fail");
				}

			}
		       
			// scroll page
	    	public void ScrollPage2(String ScrollBy) throws AWTException 
	    	{
	    		JavascriptExecutor js = (JavascriptExecutor) driver;
	    		js.executeScript("window.scrollBy(" + ScrollBy + ")");

	    	}

	}

