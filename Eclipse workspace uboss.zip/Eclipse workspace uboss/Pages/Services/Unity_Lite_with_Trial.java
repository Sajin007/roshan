package Services;

import java.awt.AWTException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Oct 6, 2020 , 5:57:29 PM
-- Description	: Unity_Lite_with_Trial.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class Unity_Lite_with_Trial {
	
	
	WebDriver driver;
	@FindBy(id="btn_add")
	WebElement ADD;
	@FindBy(id="ddlServiceType")
	WebElement Service_Type;
	@FindBy(id="txtName")
	WebElement Name;
	@FindBy(id="txtOSSName")
	WebElement OSSName;
	@FindBy(id="txtDecription")
	WebElement Description;
	@FindBy(id="txtEmail")
	WebElement Emailnotification;
	@FindBy(id="ddlCountry")
	WebElement Country;
	@FindBy(id="ddlSuppliers")
	WebElement Supplier;
	@FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[7]/div/label/span")
	WebElement Can_Be_Assigned;
	@FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[8]/div/label/span")
	WebElement Mandatory_Assignment;
	@FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[9]/div/label/span")
	WebElement Allowed_In_Child_Level_Packages;
	@FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[10]/div/label/span")
	WebElement Can_Be_Explicitly_Assigned;
	@FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[11]/div/label/span")
	WebElement Multiple_Instances_Allowed;
	@FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[12]/div/label/span")
	WebElement Can_Change_Start_Date;
	@FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[13]/div/label/span")
	WebElement Can_Change_Tariff_Rate;
	
    
    @FindBy(id="ddlPrimaryPackage")
    WebElement Dependent_package;
    @FindBy(id="ddlDependentService")
    WebElement Dependent_Service;
    @FindBy(id="txtSupplierPartNumber")
    WebElement Supplier_Part_Number;
    @FindBy(id="ddlServiceGroupId")
    WebElement UserService_Group;
    
    
    
    //***************** Contract Rule***********************//
    
    
    @FindBy(id="txtMinimumDuration")
    WebElement Min_Duration;
    @FindBy(id="txtNotificationPeriod")
    WebElement Notification_Period;
    @FindBy(id="txtQuarantinePeriod")
    WebElement Qurentine_Period;
    
    @FindBy(id="txtRollingContractTerm")
    WebElement RollingContract_P;
    @FindBy(id="txtCancellationPeriod")
    WebElement Cancellation_P;
    
    
    
    @FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[18]/div/label[1]/span[2]")
    WebElement Standard_Radio;
    @FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[18]/div/label[2]/span[2]")
    WebElement Rolling_Contract_radio;
    
    @FindBy(xpath="//*[@id=\"form-general\"]/div[1]/div/div[19]/div[4]/div/label/span[2]")
    WebElement NotificationPeriod_Check;
    
    @FindBy(id="save_btn")
    WebElement save;
    
    @FindBy(id = "COMMONA215")
    WebElement cancel;
    
    
    
    
    public Unity_Lite_with_Trial(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	public void GoToUrl(String Url) {
		driver.get(Url);
		}


		
	  public void clickonADDbutton() throws InterruptedException {
          
          Thread.sleep(2000);
          ADD.click();
   }
   
   public void clickoncancel() throws InterruptedException

	{
		Thread.sleep(4000);
		cancel.click();
	}
   
   public void clickonsave() throws InterruptedException

	{
		Thread.sleep(4000);
		save.click();
	}
   
   
   public void servicetypedropdown(String servicetype1) throws InterruptedException {
          
          Thread.sleep(2000);
    if(servicetype1.equals("")) {
                System.out.println("Drop Down is not selected");
          }
          else {
    Select select = new Select(Service_Type);
          select.selectByVisibleText(servicetype1);
          
          }
   } 
   
   
   public void name(String name) throws InterruptedException {
          
          Thread.sleep(2000);
          Name.sendKeys(name);
   }
   
   

   public void Description(String description) throws InterruptedException {
          
          if (description.equals("")) {
                
                Thread.sleep(2000);

                System.out.println("Description is empty");
          }
          
          
          else {
                
                Thread.sleep(2000);
                Description.sendKeys(description);
   }
          
   }
   
   
   public void Email(String emailValid) throws InterruptedException {
	   	
	   	String email = emailValid;
	          
	          if (email.equals("")) {
	                
	                Thread.sleep(2000);

	                System.out.println("Email notification field is empty");
	          }
	          
	          
	          else {
	                
	                Thread.sleep(2000);
	                Emailnotification.sendKeys(email);
	   }
	          
	   }


	   public void country(String country) throws InterruptedException {
	          
	          Thread.sleep(2000);
	    if(country.equals("")) {
	                System.out.println("Drop Down is not selected");
	          }
	          else {
	    Select select = new Select(Country);
	          select.selectByVisibleText(country);
	          
	          }
	   }

	   public void Supplier(String supplier) throws InterruptedException
	   {
	   	 Thread.sleep(2000);
	        if(supplier.equals("")) {
	                    System.out.println("Drop Down is not selected");
	              }
	              else {
	        Select select = new Select(Supplier);
	              select.selectByVisibleText(supplier);
	              
	              }
	   }
	   
	   
	   
	   /******************
	    * Assignment Rules Checkboxes
	    * 
	    * 
	    ***************************/
	   
	   
	   public void clickoncanbeassignedcheckbox(String checkbox1) throws InterruptedException {
			 
			 if (checkbox1.equals("yes")) {
					Thread.sleep(2000);
					Can_Be_Assigned.click();
				}
			 else {
			 Thread.sleep(2000);
			 System.out.println("Can be assigned check box not selected");
		 }
		 }

		 
		 
		 public void clickonmandatoryassignmentcheckbox(String checkbox2) throws InterruptedException {
			 
			 if (checkbox2.equals("yes")) {
			 
				 Thread.sleep(2000);
			 Thread.sleep(2000);
			 Mandatory_Assignment.click();
			 }
			 else {
				 Thread.sleep(2000);
				 System.out.println("Mandatory assignment check box not selected");
		 }
		 }
		
		 public void clickonallowedinchildlevelpackagescheckbox(String checkbox3) throws InterruptedException {
			 
			 if (checkbox3.equals("yes")) {
				 
				 Thread.sleep(2000);
			 Allowed_In_Child_Level_Packages.click();
			 }
			 else {
				 Thread.sleep(2000);
				 System.out.println("Allowed in child level package check box not selected");
		 } 
		 }
		 
		 public void clickoncanbeexplicitlyassignedcheckbox(String checkbox4) throws InterruptedException {
			
			 if (checkbox4.equals("yes")) {
				  
			 Thread.sleep(2000);
			 Can_Be_Explicitly_Assigned.click();
			 }
			 else {
				 Thread.sleep(2000);
				 System.out.println("Can be explicitily assigned check box not selected");
		 } 
		 }
		 
		 
		 public void clickonmultipleinstancesallowedcheckbox(String checkbox5) throws InterruptedException {
			 
			 if (checkbox5.equals("yes")) {
				  
			 Thread.sleep(2000);
			 Multiple_Instances_Allowed.click();
			 }
			 else {
				 Thread.sleep(2000);
				 System.out.println("Multiple instances allowed check box not selected");
		 } 
		 }
		 
		 public void clickoncanchangestartdatecheckbox(String checkbox6) throws InterruptedException {
			 
			 if (checkbox6.equals("yes")) {
			 Thread.sleep(2000);
			 Can_Change_Start_Date.click();
			 }
			 else {
				 Thread.sleep(2000);
				 System.out.println("Can change start date check box not selected");
		 } 
		 }
		 
		 
		 public void clickoncanchangetariffratecheckbox(String checkbox7) throws InterruptedException {
			 
			 if (checkbox7.equals("yes")) {
			 Thread.sleep(2000);
			 Can_Change_Tariff_Rate.click();
			 }
			 else {
				 Thread.sleep(2000);
				 System.out.println("Can chage tariff rate check box not selected");
		 } 
		 }
		 
		 
		 
		 
		 /******************************
		  * Additional Information
		 * @throws InterruptedException 
		  * 
		  * 
		  **************************/
		 
		 
		 
		 public void Supplier_PartNumber(String suppnum) throws InterruptedException
		 {
			 if (suppnum.equals("")) {
				
				Thread.sleep(2000);

				System.out.println("Supplier part number field is empty");
			}
				
				
			else {
					
				Thread.sleep(2000);
				Supplier_Part_Number.sendKeys(suppnum);
		}	
		 }
		 
		
		 
		 public void Dependentant_Service(String DepService) throws InterruptedException
	{
		 Thread.sleep(2000);
	     if(DepService.equals("")) {
	                 System.out.println("Drop Down is not selected");
	           }
	           else {
	     Select select = new Select(Dependent_Service);
	           select.selectByVisibleText(DepService);
	           
	           }
	}
		 
		public void User_Service(String UsrService) throws InterruptedException
	{
		 Thread.sleep(2000);
	    if(UsrService.equals("")) {
	                System.out.println("Drop Down is not selected");
	          }
	          else {
	    Select select = new Select(UserService_Group);
	          select.selectByVisibleText(UsrService);
	          
	          }
	}
		
		public void Dependentant_Service_Select(String DepService1) throws InterruptedException
	{
		 Thread.sleep(2000);
	    if(DepService1.equals("")) {
	                System.out.println("Drop Down is not selected");
	          }
	          else {
	    Select select = new Select(Dependent_Service);
	          select.selectByVisibleText(DepService1);
	          
	          }
	}
		 
		public void Dependant_Package_Select(String DepPack1) throws InterruptedException
	{
		 Thread.sleep(2000);
	    if(DepPack1.equals("")) {
	                System.out.println("Drop Down is not selected");
	          }
	          else {
	    Select select = new Select(Dependent_package);
	          select.selectByVisibleText(DepPack1);
	          
	          }
	}

		
	public void Dependant_Package(String DepPack) throws InterruptedException
	{
		 Thread.sleep(2000);
	    if(DepPack.equals("")) {
	                System.out.println("Drop Down is not selected");
	          }
	          else {
	    Select select = new Select(Dependent_package);
	          select.selectByVisibleText(DepPack);
	          
	          }
	}




	/******************************
	* 
	* Contract Rule
	* 
	* ********************************/


	public void minimumduration(String mdvalid) throws InterruptedException {
		Thread.sleep(2000);
		String md = mdvalid;
		Min_Duration.sendKeys(md);
	}

	public void notificationperiod(String npvalid) throws InterruptedException {
		Thread.sleep(2000);
		String np = npvalid;
		Notification_Period.sendKeys(np);
	}

	public void quarantineperiod(String qpvalid) throws InterruptedException {
		Thread.sleep(2000);
		String qp = qpvalid ;
		Qurentine_Period.sendKeys(qp);
	}


	public void RollingContract_period(String RP) throws InterruptedException {
		Thread.sleep(2000);
		RollingContract_P.sendKeys(RP);
		
	}

	public void Cancellation_Period(String CP) throws InterruptedException
	{
		Thread.sleep(2000);
		Cancellation_P.sendKeys(CP);
	}


	public void Rolling_Contactrule(String RP,String CP) throws InterruptedException
	{
		this.RollingContract_period(RP);
		
		this.Cancellation_Period(CP);
	}

	public void Standard_Contactrule(String md,String np,String qp) throws InterruptedException
	{
		this.minimumduration(md);
		this.notificationperiod(np);
		this.quarantineperiod(qp);
	}



	public void Contract_type_selection(String Contracttype,String md,String np,String qp,String RP,String CP,String DepService1,String DepPack1) throws InterruptedException
	{
		if (Contracttype.equals("Standard"))
		{
			System.out.println("Standard Contract is selected");
			Standard_Radio.click();
			this.Standard_Contactrule(md, np, qp);
			
		}
		else if(Contracttype.equals("Rolling")){
			
			System.out.println("rolling Contract is selected");
			Rolling_Contract_radio.click();
			this.Rolling_Contactrule(RP, CP);
			
			this.Dependentant_Service_Select(DepService1);
			this.Dependant_Package_Select(DepPack1);
			
		}
		else {
			System.out.println("...No Radio buttons are selected ,hence Standard contact is set as default");
		}
	}




	/***********************************
	* Validation elements
	*****************************************/


	@FindBy(id = "txtName-error")
	WebElement namevalidation;
	@FindBy(id = "txtMinimumDuration-error")
	WebElement mindurationvalidation;
	@FindBy(id = "txtNotificationPeriod-error")
	WebElement notificationperiodvalidation;
	@FindBy(id = "txtQuarantinePeriod-error")
	WebElement quarantineperiodvalidation;
	@FindBy(id = "ddlCountry-error")
	WebElement CountryValid;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDeletemessenger;
	@FindBy(id="txtEmail-error")
	WebElement Emailnotificationvalidation;
	@FindBy(id = "txtRollingContractTerm-error")
	WebElement rollingcontractdurationvalidation;
	@FindBy(id = "txtCancellationPeriod-error")
	WebElement cancellationperiodvalidation;


	String nameval = "Name cannot be empty";
	String mindurationVal = "Minimum duration cannot be empty";
	String notificationperiodval = "Notification period cannot be empty";
	String quarantineperiodval = "Quarantine period cannot be empty/zero";
	String rollingcontractval = "Rolling contract term cannot be empty";
	String cancellationperiodval = "Cancellation period cannot be empty";


	String SaveVal = "Saved successfully";
	String Emailval = "Email ID is in incorrect format";
	String invalidnumberfieldval = "Please enter a valid Number";

	String countryValid = "Select Country";



	public void nameval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = nameval;
		String getValiadtion = namevalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void mindurationVal() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = mindurationVal;
		String getValiadtion = mindurationvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void notificationperiodval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = notificationperiodval;
		String getValiadtion = notificationperiodvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void quarantineperiodval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = quarantineperiodval;
		String getValiadtion = quarantineperiodvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void CountryValidation() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = countryValid;
		String getValiadtion = CountryValid.getText();
		this.Validation(setvalidation, getValiadtion);
	}


	public void saveVal() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = SaveVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		this.Validation(getValiadtion,setvalidation);
	}


	public void EmailVal() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = Emailval;
		String getValiadtion = Emailnotificationvalidation.getText();
		this.Validation(getValiadtion,setvalidation);
	}


	public void mindurationVal1() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = invalidnumberfieldval;
		String getValiadtion = mindurationvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void notificationperiodval1() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = invalidnumberfieldval;
		String getValiadtion = notificationperiodvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void quarantineperiodval1() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = invalidnumberfieldval;
		String getValiadtion = quarantineperiodvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}


	public void RollingcontractdurationValidation() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = rollingcontractval;
		String getValiadtion = rollingcontractdurationvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void CancellationperiodValidation() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = cancellationperiodval;
		String getValiadtion = cancellationperiodvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void Save_validation() throws InterruptedException 
	{
		this.saveVal();
	}

	// scroll page
			public void ScrollPage(String ScrollBy) throws AWTException {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("window.scrollBy(" + ScrollBy + ")");

			}

			
			
			
	/**************************************
	* 
	* MAIN METHOD 		
	*
	* *********************************/
			
			


	public void Service_Add_Validation(String servicetype1,String emailValid,String mdvalid, String npvalid,String qpvalid) throws InterruptedException, AWTException
	{
		


		Thread.sleep(2000);
		this.clickonADDbutton();
		this.servicetypedropdown(servicetype1);
		this.ScrollPage("0,+700");
		this.clickonsave();
		
		this.nameval();
		this.mindurationVal();
		this.notificationperiodval();
		this.quarantineperiodval();
		this.CountryValidation();
		this.ScrollPage("0,+600");
		Rolling_Contract_radio.click();
		this.clickonsave();
		
		this.RollingcontractdurationValidation();
		this.CancellationperiodValidation();
		
		this.Email(emailValid);
		
		Standard_Radio.click();
		Thread.sleep(2000);
		this.minimumduration(mdvalid);
		this.notificationperiod(npvalid);
		this.quarantineperiod(qpvalid);
		this.clickonsave();
		
		this.EmailVal();
		this.mindurationVal1();
		this.notificationperiodval1();
		this.quarantineperiodval1();
		
		this.clickoncancel();
	}


	public void Service_Add(String servicetype,String name1,String Description1,String Email1,String country,String supplier, String checkbox1, String checkbox2, String checkbox3, String checkbox4, String checkbox5, String checkbox6, String checkbox7
			,String DepPack ,String DepService ,String suppnum ,String UsrService ,String Contracttype ,String md ,String np ,String qp ,String RP ,String CP,String DepService1,String DepPack1) throws InterruptedException
	{
		this.clickonADDbutton();
		this.servicetypedropdown(servicetype);
		this.name(name1);
		this.Description(Description1);
		this.Email(Email1);
		this.country(country);
		this.Supplier(supplier);
		
		this.clickoncanbeassignedcheckbox(checkbox1);
		this.clickonmandatoryassignmentcheckbox(checkbox2);
		this.clickonallowedinchildlevelpackagescheckbox(checkbox3);
		this.clickoncanbeexplicitlyassignedcheckbox(checkbox4);
		this.clickonmultipleinstancesallowedcheckbox(checkbox5);
		this.clickoncanchangestartdatecheckbox(checkbox6);
		this.clickoncanchangetariffratecheckbox(checkbox7);
		
		
		
		
		this.Dependant_Package(DepPack);
		this.Dependentant_Service(DepService);
		this.Supplier_PartNumber(suppnum);
		this.User_Service(UsrService);
		
		this.Contract_type_selection(Contracttype, md, np, qp, RP, CP, DepService1, DepPack1);
		
		this.clickonsave();
		this.Save_validation();
		
	}






	/***********************************************
	* COMMON METHOD
	**********************************************/

	// Validation

	public void Validation(String GetValiadtion, String Setvalidation) {
		PageFactory.initElements(driver, this);
		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.out.println("Validation is incorrect: " + GetValiadtion);
			Assert.fail("Test Fail");
		}

	}


		

	}




