package Services;

import java.awt.AWTException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Aug 27, 2020
-- Description	: CallForwarding_Always.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-WORKSPACE
-- =============================================*/
public class CallForwarding_Always {
	
	
	
	WebDriver driver;
	@FindBy(id="btn_add")
	WebElement ADD;
	@FindBy(id="ddlServiceType")
	WebElement Service_Type;
	@FindBy(id="txtName")
	WebElement Name;
	@FindBy(id="txtOSSName")
	WebElement OSSName;
	@FindBy(id="txtDecription")
	WebElement Description;
	@FindBy(id="txtEmail")
	WebElement Emailnotification;
	@FindBy(id="ddlVersion")
	WebElement Version;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[7]/div/label/span")
	WebElement Can_Bulk_configure;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[8]/div/label/span")
	WebElement Is_mandatory_in_primary_package;
	@FindBy(id="txtSimultaneousCalls")
	WebElement Enable_Maximum_Number_of_Concurrent_Calls;
	@FindBy(id="txtSimultaneousVideoCalls")
	WebElement Enable_Maximum_Number_of_Concurrent_Video_Calls;
	@FindBy(id="txtMaxAnsweredCallDuration")
	WebElement Enable_Maximum_Duration_for_Answered_Calls;
	@FindBy(id="txtMaxUnansweredCallDuration")
	WebElement Enable_Maximum_Duration_for_Unanswered_Calls;
	@FindBy(id="txtMaxConcurrentRedirectedCalls")
	WebElement Enable_Maximum_Number_of_Concurrent_Redirected_Calls;
	@FindBy(id="txtMaxConcurrentFindMeFollowMeInvocations")
	WebElement Enable_Maximum_Number_of_Concurrent_Find_Me_Follow_Me_Invocations;
	@FindBy(id="txtEnableMaxFindMeFollowMeDepth")
	WebElement Enable_Maximum_Find_Me_Follow_Me_Depth;
	@FindBy(id="txtEnableMaxConcurrentTerminatingAlertingRequests")
	WebElement Enable_Maximum_Concurrent_Terminating_Alerting_Requests;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[17]/div/label/span")
	WebElement Include_Redirections_in_Maximum_Number_of_Concurrent_Calls;
	@FindBy(id="txtMaxRedirectionDepth")
	WebElement Maximum_Redirection_Depth;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[19]/div/label/span")
	WebElement Can_Be_Assigned;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[20]/div/label/span")
	WebElement Mandatory_Assignment;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[21]/div/label/span")
	WebElement Allowed_In_Child_Level_Packages;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[22]/div/label/span")
	WebElement Can_Be_Explicitly_Assigned;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[23]/div/label/span")
	WebElement Multiple_Instances_Allowed;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[24]/div/label/span")
	WebElement Can_Change_Start_Date;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[25]/div/label/span")
	WebElement Can_Change_Tariff_Rate;
	@FindBy(id="SupplierPartNumber")
	WebElement Supplier_Part_Number;
	@FindBy(id="txtClientDownloadPath")
	WebElement Client_Download_Path;
	@FindBy(id="ddlDependentService")
	WebElement Dependent_Service;
	@FindBy(id="ddlServiceGroupId")
	WebElement UserService_Group;
	@FindBy(id="ddlPrimaryPackage")
	WebElement Dependent_Package;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[31]/div/label[1]/span")
	WebElement callcentrechckbox;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[31]/div/label[2]/span")
	WebElement huntgroupchckbox;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[31]/div/label[3]/span")
	WebElement Trunkgroupchckbox;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[31]/div/label[4]/span")
	WebElement Autoattendantchckbox;
	@FindBy(xpath="//*[@id=\"form-broadworks\"]/div[1]/div/div[31]/div/label[5]/span")
	WebElement Meetmeconferencechckbox;
	@FindBy(id="txtMinimumDuration")
	WebElement Minimum_Duration;
	@FindBy(id="txtNotificationPeriod")
	WebElement Notification_Period;
	@FindBy(id="txtQuarantinePeriod")
	WebElement Quarantine_Period;
	@FindBy(id="save_btn")
	WebElement save;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[35]/div/label/span[2]")
	WebElement combinetruecheckbox;

	@FindBy(id = "COMMONA215")
	WebElement cancel;


	
	
	
	
	
	
	public CallForwarding_Always(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
	driver.get(Url);
	}


	

	
	public void clickonADDbutton() throws InterruptedException {
		
		Thread.sleep(2000);
		ADD.click();
	}
	
	
	public void servicetypedropdown(String servicetype) throws InterruptedException {
		
		Thread.sleep(2000);
        if(servicetype.equals("")) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(Service_Type);
		select.selectByVisibleText(servicetype);
		
		}
	} 
	
	
	public void name(String name) throws InterruptedException {
		
		Thread.sleep(2000);
		Name.sendKeys(name);
	}
	
	
	
	public void OSSName(String ossname) throws InterruptedException {
		
		if (ossname.equals("")) {
			
			Thread.sleep(2000);

			System.out.println("OSS Name is empty");
		}
		
		
		else {
			
			Thread.sleep(2000);
			OSSName.sendKeys(ossname);
	}
	}

	
	public void Description(String description) throws InterruptedException {
		
		if (description.equals("")) {
			
			Thread.sleep(2000);

			System.out.println("Description is empty");
		}
		
		
		else {
			
			Thread.sleep(2000);
			Description.sendKeys(description);
	}
		
	}
	
	
	public void Email(String email) throws InterruptedException {
		
		if (email.equals("")) {
			
			Thread.sleep(2000);

			System.out.println("Email notification field is empty");
		}
		
		
		else {
			
			Thread.sleep(2000);
			Emailnotification.sendKeys(email);
	}
		
	}
	
	
	public void versiondropdown(String version) throws InterruptedException {
		
		Thread.sleep(2000);
        if(version.equals("")) {
			System.out.println("Drop Down is not selected");
		}
		else {
        Select select = new Select(Version);
		select.selectByVisibleText(version);
		
		}
	} 
	
	public void clickoncanbulkconfigurecheckbox() throws InterruptedException {
		
		Thread.sleep(2000);	
		Can_Bulk_configure.click();
	}
	
	
	public void clickonismandatoryinprimarypackage() throws InterruptedException {
		
		Thread.sleep(2000);	
		Is_mandatory_in_primary_package.click();
	}
	
	
	public void EnableMaximumNumberofConcurrentCalls(String concurrentcalls) throws InterruptedException {
		
		if (concurrentcalls.equals("")) {
			
			Thread.sleep(2000);

			System.out.println("Enable Maximum Number of Concurrent Calls field is empty");
		}
		
		
		else {
			
			Thread.sleep(2000);
			Enable_Maximum_Number_of_Concurrent_Calls.sendKeys(concurrentcalls);
	}
	}
		
	public void EnableMaximumNumberofConcurrentvideoCalls(String concurrentvideocalls) throws InterruptedException {
			
		if (concurrentvideocalls.equals("")) {
				
			Thread.sleep(2000);

			System.out.println("Enable Maximum Number of Concurrent video Calls field is empty");
		}
			
			
		else {
				
			Thread.sleep(2000);
			Enable_Maximum_Number_of_Concurrent_Video_Calls.sendKeys(concurrentvideocalls);
	}
			
		
	}
	
	
	public void EnableMaximumDurationforAnsweredCalls(String answeredcalls) throws InterruptedException {
		
		if (answeredcalls.equals("")) {
				
			Thread.sleep(2000);

			System.out.println("Enable Maximum Duration for AnsweredCalls field is empty");
		}
			
			
		else {
				
			Thread.sleep(2000);
			Enable_Maximum_Duration_for_Answered_Calls.sendKeys(answeredcalls);
	}
			
		
	}
	
	
	public void EnableMaximumDurationforUnAnsweredCalls(String unansweredcalls) throws InterruptedException {
		
		if (unansweredcalls.equals("")) {
				
			Thread.sleep(2000);

			System.out.println("Enable Maximum Duration for UnAnsweredCalls field is empty");
		}
			
			
		else {
				
			Thread.sleep(2000);
			Enable_Maximum_Duration_for_Unanswered_Calls.sendKeys(unansweredcalls);
	}
			
		
	}
	
	public void EnableMaximumNumberofConcurrentRedirectedCalls(String concurrentredirectedcalls) throws InterruptedException {
		
		if (concurrentredirectedcalls.equals("")) {
				
			Thread.sleep(2000);

			System.out.println("Enable Maximum Number of Concurrent Redirected Calls field is empty");
		}
			
			
		else {
				
			Thread.sleep(2000);
			Enable_Maximum_Number_of_Concurrent_Redirected_Calls.sendKeys(concurrentredirectedcalls);
	}
			
		
	}
	
	public void EnableMaximumNumberofConcurrentfindmeinvocations(String invocations) throws InterruptedException {
		
		if (invocations.equals("")) {
				
			Thread.sleep(2000);

			System.out.println("Enable MaximumNumber of Concurrent findme invocations field is empty");
		}
			
			
		else {
				
			Thread.sleep(2000);
			Enable_Maximum_Number_of_Concurrent_Find_Me_Follow_Me_Invocations.sendKeys(invocations);
	}	
	}	
	
	public void EnableMaximumFindMeDepth(String findmedepth) throws InterruptedException {
		
		if (findmedepth.equals("")) {
				
			Thread.sleep(2000);

			System.out.println("Enable Maximum Find Me Depth field is empty");
		}
			
			
		else {
				
			Thread.sleep(2000);
			Enable_Maximum_Find_Me_Follow_Me_Depth.sendKeys(findmedepth);
	}	
	}	
	
	
	public void EnableMaximumConcurrentTerminatingAlertingRequests(String alertingrequests) throws InterruptedException {
		
		if (alertingrequests.equals("")) {
				
			Thread.sleep(2000);

			System.out.println("Enable Maximum Concurrent Terminatin gAlerting Requests field is empty");
		}
			
			
		else {
				
			Thread.sleep(2000);
			Enable_Maximum_Concurrent_Terminating_Alerting_Requests.sendKeys(alertingrequests);
	}	
	}	
	
	
	
	public void clickonIncludeRedirectionsinMaximumnumberofconcurrentCalls() throws InterruptedException {
		
		Thread.sleep(2000);
		Include_Redirections_in_Maximum_Number_of_Concurrent_Calls.click();
	}
	
	
	
	
	public void MaximumRedirectionDepth(String redirectiondepth) throws InterruptedException {
		
		if (redirectiondepth.equals("")) {
				
			Thread.sleep(2000);

			System.out.println("Maximum Redirection depth field is empty");
		}
			
			
		else {
				
			Thread.sleep(2000);
			Maximum_Redirection_Depth.sendKeys(redirectiondepth);
	}	
	}	
	
	 public void clickoncanbeassignedcheckbox(String checkbox1) throws InterruptedException {
		 
		 if (checkbox1.equals("yes")) {
				Thread.sleep(2000);
				Can_Be_Assigned.click();
			}
		 else {
		 Thread.sleep(2000);
		 System.out.println("Can be assigned check box not selected");
	 }
	 }

	 
	 
	 public void clickonmandatoryassignmentcheckbox(String checkbox2) throws InterruptedException {
		 
		 if (checkbox2.equals("yes")) {
		 
			 Thread.sleep(2000);
		 Thread.sleep(2000);
		 Mandatory_Assignment.click();
		 }
		 else {
			 Thread.sleep(2000);
			 System.out.println("Mandatory assignment check box not selected");
	 }
	 }
	
	 public void clickonallowedinchildlevelpackagescheckbox(String checkbox3) throws InterruptedException {
		 
		 if (checkbox3.equals("yes")) {
			 
			 Thread.sleep(2000);
		 Allowed_In_Child_Level_Packages.click();
		 }
		 else {
			 Thread.sleep(2000);
			 System.out.println("Allowed in child level package check box not selected");
	 } 
	 }
	 
	 public void clickoncanbeexplicitlyassignedcheckbox(String checkbox4) throws InterruptedException {
		
		 if (checkbox4.equals("yes")) {
			  
		 Thread.sleep(2000);
		 Can_Be_Explicitly_Assigned.click();
		 }
		 else {
			 Thread.sleep(2000);
			 System.out.println("Can be explicitily assigned check box not selected");
	 } 
	 }
	 
	 
	 public void clickonmultipleinstancesallowedcheckbox(String checkbox5) throws InterruptedException {
		 
		 if (checkbox5.equals("yes")) {
			  
		 Thread.sleep(2000);
		 Multiple_Instances_Allowed.click();
		 }
		 else {
			 Thread.sleep(2000);
			 System.out.println("Multiple instances allowed check box not selected");
	 } 
	 }
	 
	 public void clickoncanchangestartdatecheckbox(String checkbox6) throws InterruptedException {
		 
		 if (checkbox6.equals("yes")) {
		 Thread.sleep(2000);
		 Can_Change_Start_Date.click();
		 }
		 else {
			 Thread.sleep(2000);
			 System.out.println("Can change start date check box not selected");
	 } 
	 }
	 
	 
	 public void clickoncanchangetariffratecheckbox(String checkbox7) throws InterruptedException {
		 
		 if (checkbox7.equals("yes")) {
		 Thread.sleep(2000);
		 Can_Change_Tariff_Rate.click();
		 }
		 else {
			 Thread.sleep(2000);
			 System.out.println("Can chage tariff rate check box not selected");
	 } 
	 }
	 
	 public void supplierpartnumber(String suppnum) throws InterruptedException {
		
		 if (suppnum.equals("")) {
				
				Thread.sleep(2000);

				System.out.println("Supplier part number field is empty");
			}
				
				
			else {
					
				Thread.sleep(2000);
				Supplier_Part_Number.sendKeys(suppnum);
		}	
		}	
		 
	 
	 public void clientdownloadpath(String downloadpath) throws InterruptedException {
			
		 if (downloadpath.equals("")) {
				
				Thread.sleep(2000);

				System.out.println("Client download path field is empty");
			}
				
				
			else {
					
				Thread.sleep(2000);
				Client_Download_Path.sendKeys(downloadpath);
		}	
		}	
	 
	 public void dependentservice(String dependentservice1) throws InterruptedException {
			if (dependentservice1.equals("")) {
				System.out.println("Drop Down is not selected");
			} else {
				Thread.sleep(2000);
				Select select = new Select(Dependent_Service);
				select.selectByVisibleText(dependentservice1);
			}

		}

		public void userservicegroup(String userservicegroup1) throws InterruptedException {
			if (userservicegroup1.equals("")) {
				System.out.println("Drop Down is not selected");
			} else {
				Thread.sleep(2000);
				Select select = new Select(UserService_Group);
				select.selectByVisibleText(userservicegroup1);
			}

		}

		public void dependentpackage(String dependentpackage1) throws InterruptedException {
			if (dependentpackage1.equals("")) {
				System.out.println("Drop Down is not selected");
			} else {
				Thread.sleep(2000);
				Select select = new Select(Dependent_Package);
				select.selectByVisibleText(dependentpackage1);
			}

		}

		// ************************Multiple Check box ********************************//

		public void servicecheckbox(String[] service) throws InterruptedException {

			this.services(service);
		}

		public void services(String[] service) throws InterruptedException {
			Thread.sleep(2000);
			String count = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div[1]/div/div[31]/div/label";
			String Text = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div[1]/div/div[31]/div/label[x]";
			String CheckBox = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div[1]/div/div[31]/div/label[1]/span";
			this.Multiple_CheckBox_Selection(service, count, Text, CheckBox);
		}

		// ***********************Contract Rule********************************//

		public void minimumduration(String md) throws InterruptedException {
			Thread.sleep(2000);
			Minimum_Duration.sendKeys(md);
		}

		public void notificationperiod(String np) throws InterruptedException {
			Thread.sleep(2000);
			Notification_Period.sendKeys(np);
		}

		public void quarantineperiod(String qp) throws InterruptedException {
			Thread.sleep(2000);
			Quarantine_Period.sendKeys(qp);
		}

		public void clickoncombinetruecheckbox(String combinetrue) throws InterruptedException {

			if (combinetrue.equals("yes")) {
				Thread.sleep(2000);
				combinetruecheckbox.click();
			} else {
				Thread.sleep(2000);
				System.out.println("Combine true checkbox check box not selected");
			}
		}

		// ******************Click on save button*****************//

		public void clickonsave() throws InterruptedException

		{
			Thread.sleep(4000);
			save.click();
		}

		// ******************Click on cancel button*****************//

		public void clickoncancel() throws InterruptedException

		{
			Thread.sleep(4000);
			cancel.click();
		}
		
		
		
		
		
		
		public void Service_ADD_Validation(String servicetype,String email,String concurrentcalls,String concurrentvideocalls,String answeredcalls, String unansweredcalls,String concurrentredirectedcalls,String invocations,String findmedepth,String alertingrequests,String redirectiondepth,String md,String np,String qp) throws InterruptedException, AWTException {
			Thread.sleep(2000);
			this.clickonADDbutton();
			this.servicetypedropdown(servicetype);
			this.ScrollPage("0,+700");
			this.clickonsave();
			this.nameval();
			this.mindurationVal();
			this.notificationperiodval();
			this.quarantineperiodval();
			this.Email(email);
			this.EnableMaximumNumberofConcurrentCalls(concurrentcalls);
			this.EnableMaximumNumberofConcurrentvideoCalls(concurrentvideocalls);
			this.EnableMaximumDurationforAnsweredCalls(answeredcalls);
			this.EnableMaximumDurationforUnAnsweredCalls(unansweredcalls);
			this.EnableMaximumNumberofConcurrentRedirectedCalls(concurrentredirectedcalls);
			this.EnableMaximumNumberofConcurrentfindmeinvocations(invocations);
			this.EnableMaximumFindMeDepth(findmedepth);
			this.EnableMaximumConcurrentTerminatingAlertingRequests(alertingrequests);
			this.MaximumRedirectionDepth(redirectiondepth);
			this.minimumduration(md);
			this.notificationperiod(np);
			this.quarantineperiod(qp);
			this.clickonsave();
			this.EmailVal();
			this.ConcurrentcallsVal();
			this.ConcurrentvideocallsVal();
			this.answeredcallsVal();
			this.unansweredcallsVal();
			this.concurrentredirectedcallsVal();
			this.findmeinvocationVal();
			this.findmedepthVal();
			this.enableconcurrentterminatingalertVal();
			this.maximumredirectiondepthVal();
			
			//this.ScrollPage("0,+900");
			this.mindurationVal1();
			this.notificationperiodval1();
			this.quarantineperiodval1();
			
			
		
			this.clickoncancel();

		}	
		
		
		public void Service_ADD(String servicetypedropdown1,String name1,String OSSname1,String Description1,String Email1,String versiondropdown1,String concurrentcalls,String concurrentvideocalls,String answeredcalls, String unansweredcalls,String concurrentredirectedcalls,String invocations,String findmedepth,String alertingrequests,String redirectiondepth,String canbeassigned,String mandatoryassignment,String allowedinchildlevelpackages,String canbeexplicitlyassigned,String multipleinstancesallowed,String canchangestartdate,String canchangetariffrate,String partno,String downloadpath,String dependentservice1,String userservicegroup1,String dependentpackage1,String[] service,String md,String np,String qp,String combinetrue   ) throws InterruptedException, AWTException {
			Thread.sleep(2000);
			this.clickonADDbutton();
			this.servicetypedropdown(servicetypedropdown1);
			this.name(name1);
			this.OSSName(OSSname1);
			this.Description(Description1);
			this.Email(Email1);
			this.versiondropdown(versiondropdown1);
			this.clickoncanbulkconfigurecheckbox();
			this.clickonismandatoryinprimarypackage();
			this.EnableMaximumNumberofConcurrentCalls(concurrentcalls);
			this.EnableMaximumNumberofConcurrentvideoCalls(concurrentvideocalls);
			this.EnableMaximumDurationforAnsweredCalls(answeredcalls);
			this.EnableMaximumDurationforUnAnsweredCalls(unansweredcalls);
			this.EnableMaximumNumberofConcurrentRedirectedCalls(concurrentredirectedcalls);
			this.EnableMaximumNumberofConcurrentfindmeinvocations(invocations);
			this.EnableMaximumFindMeDepth(findmedepth);
			this.EnableMaximumConcurrentTerminatingAlertingRequests(alertingrequests);
			this.clickonIncludeRedirectionsinMaximumnumberofconcurrentCalls();
			this.MaximumRedirectionDepth(redirectiondepth);
			this.clickoncanbeassignedcheckbox(canbeassigned);
			this.clickonmandatoryassignmentcheckbox(mandatoryassignment);
			this.clickonallowedinchildlevelpackagescheckbox(allowedinchildlevelpackages);
			this.clickoncanbeexplicitlyassignedcheckbox(canbeexplicitlyassigned);
			this.clickonmultipleinstancesallowedcheckbox(multipleinstancesallowed);
			this.clickoncanchangestartdatecheckbox(canchangestartdate);
			this.clickoncanchangetariffratecheckbox(canchangetariffrate);
			
			this.supplierpartnumber(partno);
			this.clientdownloadpath(downloadpath);
			this.dependentservice(dependentservice1);
			this.userservicegroup(userservicegroup1);
			this.ScrollPage("0,+600");
			this.dependentpackage(dependentpackage1);
			this.servicecheckbox(service);
			this.minimumduration(md);
			this.notificationperiod(np);
			this.quarantineperiod(qp);
			this.clickoncombinetruecheckbox(combinetrue);
			this.clickonsave();
			
		}		

		
		
		
		
		
		
		
		
		
		/***********************************
		 * Validation elements
		 *****************************************/

		
		@FindBy(id = "txtName-error")
		WebElement namevalidation;
		@FindBy(id = "txtMinimumDuration-error")
		WebElement mindurationvalidation;
		@FindBy(id = "txtNotificationPeriod-error")
		WebElement notificationperiodvalidation;
		@FindBy(id = "txtQuarantinePeriod-error")
		WebElement quarantineperiodvalidation;
		@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
		WebElement SaveandDeletemessenger;
		@FindBy(id="txtEmail-error")
		WebElement Emailnotificationvalidation;
		@FindBy(id="txtSimultaneousCalls-error")
		WebElement Enable_Maximum_Number_of_Concurrent_Callsvalidation;
		@FindBy(id="txtSimultaneousVideoCalls-error")
		WebElement Enable_Maximum_Number_of_Concurrent_Video_Callsvalidation;
		@FindBy(id="txtMaxAnsweredCallDuration-error")
		WebElement Enable_Maximum_Duration_for_Answered_Callsvalidation;
		@FindBy(id="txtMaxUnansweredCallDuration-error")
		WebElement Enable_Maximum_Duration_for_Unanswered_Callsvalidation;
		@FindBy(id="txtMaxConcurrentRedirectedCalls-error")
		WebElement Enable_Maximum_Number_of_Concurrent_Redirected_Callsvalidation;
		@FindBy(id="txtMaxConcurrentFindMeFollowMeInvocations-error")
		WebElement Enable_Maximum_Number_of_Concurrent_Find_Me_Follow_Me_Invocationsvalidation;
		@FindBy(id="txtEnableMaxFindMeFollowMeDepth-error")
		WebElement Enable_Maximum_Find_Me_Follow_Me_Depthvalidation;
		@FindBy(id="txtEnableMaxConcurrentTerminatingAlertingRequests-error")
		WebElement Enable_Maximum_Concurrent_Terminating_Alerting_Requestsvalidation;
		@FindBy(id="txtMaxRedirectionDepth-error")
		WebElement Maximum_Redirection_Depthvalidation;

		
		
		
		String nameval = "Name cannot be empty";
		String mindurationVal = "Minimum duration cannot be empty";
		String notificationperiodval = "Notification period cannot be empty";
		String quarantineperiodval = "Quarantine period cannot be empty/zero";
		String SaveVal = "Saved successfully";
		String Emailval = "Email ID is in incorrect format";
		String invalidnumberfieldval = "Please enter a valid Number";
		
		
		
		
			
		
		
		
		public void nameval() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = nameval;
			String getValiadtion = namevalidation.getText();
			this.Validation(setvalidation, getValiadtion);
		}

		public void mindurationVal() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = mindurationVal;
			String getValiadtion = mindurationvalidation.getText();
			this.Validation(setvalidation, getValiadtion);
		}
		
		public void notificationperiodval() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = notificationperiodval;
			String getValiadtion = notificationperiodvalidation.getText();
			this.Validation(setvalidation, getValiadtion);
		}

		public void quarantineperiodval() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = quarantineperiodval;
			String getValiadtion = quarantineperiodvalidation.getText();
			this.Validation(setvalidation, getValiadtion);
		}
		
		
		public void saveVal() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = SaveVal;
			String getValiadtion = SaveandDeletemessenger.getText();
			this.Validation(getValiadtion,setvalidation);
		}
		
		
		public void EmailVal() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = Emailval;
			String getValiadtion = Emailnotificationvalidation.getText();
			this.Validation(getValiadtion,setvalidation);
		}
		
		public void ConcurrentcallsVal() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = invalidnumberfieldval;
			String getValiadtion = Enable_Maximum_Number_of_Concurrent_Callsvalidation.getText();
			this.Validation(getValiadtion,setvalidation);
		}
		
		
		public void ConcurrentvideocallsVal() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = invalidnumberfieldval;
			String getValiadtion = Enable_Maximum_Number_of_Concurrent_Video_Callsvalidation.getText();
			this.Validation(getValiadtion,setvalidation);
		}
		

		public void answeredcallsVal() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = invalidnumberfieldval;
			String getValiadtion = Enable_Maximum_Duration_for_Answered_Callsvalidation.getText();
			this.Validation(getValiadtion,setvalidation);
		}
		

		public void unansweredcallsVal() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = invalidnumberfieldval;
			String getValiadtion = Enable_Maximum_Duration_for_Unanswered_Callsvalidation.getText();
			this.Validation(getValiadtion,setvalidation);
		}
		

		public void concurrentredirectedcallsVal() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = invalidnumberfieldval;
			String getValiadtion = Enable_Maximum_Number_of_Concurrent_Redirected_Callsvalidation.getText();
			this.Validation(getValiadtion,setvalidation);
		}
		

		public void findmeinvocationVal() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = invalidnumberfieldval;
			String getValiadtion = Enable_Maximum_Number_of_Concurrent_Find_Me_Follow_Me_Invocationsvalidation.getText();
			this.Validation(getValiadtion,setvalidation);
		}
		
		
		public void findmedepthVal() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = invalidnumberfieldval;
			String getValiadtion = Enable_Maximum_Find_Me_Follow_Me_Depthvalidation.getText();
			this.Validation(getValiadtion,setvalidation);
		}
		
		
		public void enableconcurrentterminatingalertVal() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = invalidnumberfieldval;
			String getValiadtion = Enable_Maximum_Concurrent_Terminating_Alerting_Requestsvalidation.getText();
			this.Validation(getValiadtion,setvalidation);
		}
		
		public void maximumredirectiondepthVal() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = invalidnumberfieldval;
			String getValiadtion = Maximum_Redirection_Depthvalidation.getText();
			this.Validation(getValiadtion,setvalidation);
		}
		
		

		public void mindurationVal1() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = invalidnumberfieldval;
			String getValiadtion = mindurationvalidation.getText();
			this.Validation(setvalidation, getValiadtion);
		}
		
		public void notificationperiodval1() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = invalidnumberfieldval;
			String getValiadtion = notificationperiodvalidation.getText();
			this.Validation(setvalidation, getValiadtion);
		}

		public void quarantineperiodval1() throws InterruptedException {
			Thread.sleep(2000);
			String setvalidation = invalidnumberfieldval;
			String getValiadtion = quarantineperiodvalidation.getText();
			this.Validation(setvalidation, getValiadtion);
		}
		

		public void Save_validation() throws InterruptedException {
			this.saveVal();
		}

		public void validation() throws InterruptedException {
			this.nameval();
		}

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/***********************************************
		 * COMMON METHOD
		 **********************************************/

		// Validation

		public void Validation(String GetValiadtion, String Setvalidation) {
			PageFactory.initElements(driver, this);
			if (GetValiadtion.equals(Setvalidation)) {
				System.out.println("Validation is correct as  " + GetValiadtion);
			} else {
				System.out.println("Validation is incorrect: " + GetValiadtion);
				Assert.fail("Test Fail");
			}

		}
		
		
		
		
		

		// ****************************Multiple check box selection************************//
		/********************/

		String Text0;
		String Text4;
		String Xpath1;
		String Xpath2;

		/**********************/

		public void Multiple_CheckBox_Selection(String[] labels, String Count, String Text, String CheckBox)
				throws InterruptedException {

			if (Text.contains("table")) {
				String[] SPLITTEXT = Text.split("tr", 2);
				String Text1 = SPLITTEXT[0];
				String Text2 = SPLITTEXT[1];
				String[] Text3 = Text2.split("1", 2);
				Text4 = Text3[1];
				Text0 = Text1 + "tr[";
			} else {
				String[] SPLITTEXT = Text.split("x", 2);
				String Text1 = SPLITTEXT[0];
				String Text2 = SPLITTEXT[1];
				Text4 = Text2;
				//System.out.println(Text2);
				Text0 = Text1;
				//System.out.println(Text1);
			}
			if (CheckBox.contains("table")) {
				String[] SPLITCheckBox = CheckBox.split("tr", 2);
				String CheckBox1 = SPLITCheckBox[0];
				String CheckBox2 = SPLITCheckBox[1];
				String[] CheckBox3 = CheckBox2.split("1", 2);
				Xpath1 = CheckBox3[1];
				Xpath2 = CheckBox1 + "tr[";
			} else {
				String[] SPLITCheckBox = CheckBox.split("1", 2);
				String CheckBox1 = SPLITCheckBox[0];
				String CheckBox2 = SPLITCheckBox[1];
				Xpath1 = CheckBox2;
				Xpath2 = CheckBox1;

			}

			ArrayList<String> ListLabel = new ArrayList<String>();

			for (int j = 0; j < labels.length; j++) {
				ListLabel.add(labels[j]);
			}

			int Counts = driver.findElements(By.xpath(Count)).size();
			System.out.println(Counts);
			for (int i = 1; i <= Counts; i++) {
				String text = driver.findElement(By.xpath(Text0 + i + Text4)).getText();
				System.out.println(text);
				if (ListLabel.contains(text)) {
					System.out.println(ListLabel);
					Thread.sleep(7000);
					driver.findElement(By.xpath(Xpath2 + i + Xpath1)).click();
					System.out.println("Assignable to other services checkbox :" + text);
				}

				else {

					System.out.println("Assignable to other services checkbox found");

				}

			}
		}

		// scroll page
		public void ScrollPage(String ScrollBy) throws AWTException {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(" + ScrollBy + ")");

		}
}