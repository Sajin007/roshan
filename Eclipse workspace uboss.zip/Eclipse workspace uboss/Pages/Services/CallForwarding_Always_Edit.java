package Services;

import java.awt.AWTException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Aug 27, 2020
-- Description	: CallForwarding_Always_Edit.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-WORKSPACE
-- =============================================*/
public class CallForwarding_Always_Edit {
	
	
	
	
	WebDriver driver;

	@FindBy(id = "btn_add")
	WebElement ADD;
	@FindBy(id = "ddlServiceType")
	WebElement Service_Type;
	@FindBy(id = "txtName")
	WebElement Name;
	@FindBy(id = "txtOSSName")
	WebElement OSSName;
	@FindBy(id = "txtDecription")
	WebElement Description;
	@FindBy(id = "txtEmail")
	WebElement Emailnotification;
	@FindBy(id = "ddlVersion")
	WebElement Version;
	@FindBy(xpath = "//*[@id=\"general\"]/div/div/div/div[7]/div/label/span")
	WebElement Can_Bulk_configure;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[8]/div/label/span")
	WebElement Is_mandatory_in_primary_package;
	@FindBy(id = "txtSimultaneousCalls")
	WebElement Enable_Maximum_Number_of_Concurrent_Calls;
	@FindBy(id = "txtSimultaneousVideoCalls")
	WebElement Enable_Maximum_Number_of_Concurrent_Video_Calls;
	@FindBy(id = "txtMaxAnsweredCallDuration")
	WebElement Enable_Maximum_Duration_for_Answered_Calls;
	@FindBy(id = "txtMaxUnansweredCallDuration")
	WebElement Enable_Maximum_Duration_for_Unanswered_Calls;
	@FindBy(id = "txtMaxConcurrentRedirectedCalls")
	WebElement Enable_Maximum_Number_of_Concurrent_Redirected_Calls;
	@FindBy(id = "txtMaxConcurrentFindMeFollowMeInvocations")
	WebElement Enable_Maximum_Number_of_Concurrent_Find_Me_Follow_Me_Invocations;
	@FindBy(id = "txtEnableMaxFindMeFollowMeDepth")
	WebElement Enable_Maximum_Find_Me_Follow_Me_Depth;
	@FindBy(id = "txtEnableMaxConcurrentTerminatingAlertingRequests")
	WebElement Enable_Maximum_Concurrent_Terminating_Alerting_Requests;
	@FindBy(xpath = "//*[@id=\"general\"]/div/div/div/div[16]/div/label/span")
	WebElement Include_Redirections_in_Maximum_Number_of_Concurrent_Calls;
	@FindBy(id = "txtMaxRedirectionDepth")
	WebElement Maximum_Redirection_Depth;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[19]/div/label/span")
	WebElement Can_Be_Assigned;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[20]/div/label/span")
	WebElement Mandatory_Assignment;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[21]/div/label/span")
	WebElement Allowed_In_Child_Level_Packages;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[22]/div/label/span")
	WebElement Can_Be_Explicitly_Assigned;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[23]/div/label/span")
	WebElement Multiple_Instances_Allowed;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[24]/div/label/span")
	WebElement Can_Change_Start_Date;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[25]/div/label/span")
	WebElement Can_Change_Tariff_Rate;
	@FindBy(id = "SupplierPartNumber")
	WebElement Supplier_Part_Number;
	@FindBy(id = "txtClientDownloadPath")
	WebElement Client_Download_Path;
	@FindBy(id = "ddlDependentService")
	WebElement Dependent_Service;
	@FindBy(id = "ddlServiceGroupId")
	WebElement UserService_Group;
	@FindBy(id = "ddlPrimaryPackage")
	WebElement Dependent_Package;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[31]/div/label[1]/span")
	WebElement callcentrechckbox;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[31]/div/label[2]/span")
	WebElement huntgroupchckbox;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[31]/div/label[3]/span")
	WebElement Trunkgroupchckbox;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[31]/div/label[4]/span")
	WebElement Autoattendantchckbox;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[31]/div/label[5]/span")
	WebElement Meetmeconferencechckbox;
	@FindBy(id = "txtMinimumDuration")
	WebElement Minimum_Duration;
	@FindBy(id = "txtNotificationPeriod")
	WebElement Notification_Period;
	@FindBy(id = "txtQuarantinePeriod")
	WebElement Quarantine_Period;
	@FindBy(id = "save_btn")
	WebElement save;
	@FindBy(xpath = "//*[@id=\"form-broadworks\"]/div[1]/div/div[35]/div/label/span[2]")
	WebElement combinetruecheckbox;

	@FindBy(xpath = "//*[@id=\"divNormalContractRule\"]/div[4]/div/label/span[2]")
	WebElement combinetruecheckboxedit;

	@FindBy(id = "updatedetails")
	WebElement savecontractrule;

	@FindBy(id = "COMMONA215")
	WebElement cancel;

	@FindBy(id = "search_data")
	WebElement SearchField;

	@FindBy(id = "search_btn")
	WebElement SearchField_Button;

	@FindBy(xpath = "//*[@id=\"datagrid\"]/tbody/tr/td[1]/a/u")
	WebElement Edit_Service_link;

	@FindBy(xpath = "//*[@id=\"contactrule\"]/span[2]")
	WebElement contractrule;

	@FindBy(id = "minimumduration")
	WebElement minimumduration;

	@FindBy(id = "txtnotificationperiod")
	WebElement notificationperiod;

	@FindBy(id = "quarantineperiod")
	WebElement quarantineperiod;

	@FindBy(xpath = "/html/body/div[3]/div/div/div[3]/button[1]")
	WebElement saveconfirm;

	@FindBy(xpath = "//*[@id=\"usagelist\"]/span[2]")
	WebElement serviceusage;
	
	@FindBy(xpath = "//*[@id=\"datagrid\"]/tbody/tr/td")
	WebElement Header_NextTab;

	@FindBy(xpath = "//*[@id=\"general\"]/span[2]")
	WebElement generaltab;

	// Search
	@FindBy(id = "search_data")
	WebElement search;
	@FindBy(id = "search_btn")
	WebElement searchbtn;

	@FindBy(id = "btn_settings")
	WebElement settings;

	@FindBy(xpath = "//*[@id=\"settings\"]/div/div/label/span")
	WebElement includeremovedcheck;

	@FindBy(id = "btn_download")
	WebElement export;

	@FindBy(xpath = "//*[@id=\"datagrid\"]/tbody/tr/td[2]/a/u")
	WebElement link;

	@FindBy(id = "deletedetails")
	WebElement Delete_Button;

	@FindBy(xpath = "/html/body/div[3]/div/div/div[3]/button[1]")
	WebElement Delete_Button_Link;
	
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div[1]/div[3]/div/div/div/div[6]/div[2]/label/span")
	WebElement EnableMaximum_Number_of_Concurrent_Callscheckbox;
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div[1]/div[3]/div/div/div/div[7]/div[2]/label/span")
	WebElement EnableMaximum_Number_of_Concurrent_Video_Callscheckbox;@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div[1]/div[3]/div/div/div/div[6]/div[2]/label/span")
	WebElement Enable_Maximum_Number_of_Concurrent_Callscheckbox;
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div[1]/div[3]/div/div/div/div[7]/div[2]/label/span")
	WebElement Enable_Maximum_Number_of_Concurrent_Video_Callscheckbox;

	
	
	public CallForwarding_Always_Edit(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
	driver.get(Url);
	}
	/*
	 * *********************************
	 * 
	 * General ( Methods )
	 * 
	 ********************************/

	public void servicetypedropdown(String servicetype) throws InterruptedException {

		Thread.sleep(2000);
		if (servicetype.equals("")) {
			System.out.println("Drop Down is not selected");
		} else {
			Select select = new Select(Service_Type);
			select.selectByVisibleText(servicetype);

		}
	}

	public void GoToEdit_Link(String Servicename) throws InterruptedException {
		Thread.sleep(4000);
		SearchField.clear();
		Thread.sleep(4000);
		SearchField.sendKeys(Servicename);
		SearchField_Button.click();
		Thread.sleep(4000);
		Edit_Service_link.click();

	}

	public void name(String name) throws InterruptedException {

		Thread.sleep(2000);
		Name.sendKeys(name);
	}

	public void NameClear() throws InterruptedException {
		Thread.sleep(2000);
		Name.clear();

	}

	public void OSSName(String ossname) throws InterruptedException {

		if (ossname.equals("")) {

			Thread.sleep(2000);

			System.out.println("OSS Name is empty");
		}

		else {

			Thread.sleep(2000);
			OSSName.sendKeys(ossname);
		}
	}

	public void Description(String description) throws InterruptedException {

		if (description.equals("")) {

			Thread.sleep(2000);

			System.out.println("Description is empty");
		}

		else {
			Thread.sleep(2000);
			Description.clear();

			Thread.sleep(2000);
			Description.sendKeys(description);
		}

	}

	public void Email(String email) throws InterruptedException {

		if (email.equals("")) {

			Thread.sleep(2000);

			System.out.println("Email notification field is empty");
		}

		else {

			Thread.sleep(2000);
			Emailnotification.clear();

			Thread.sleep(2000);
			Emailnotification.sendKeys(email);
		}

	}

	public void versiondropdown(String version) throws InterruptedException {

		Thread.sleep(2000);
		if (version.equals("")) {
			System.out.println("Drop Down is not selected");
		} else {
			Select select = new Select(Version);
			select.selectByVisibleText(version);

		}
	}

	public void clickoncanbulkconfigurecheckbox() throws InterruptedException {

		Thread.sleep(2000);
		Can_Bulk_configure.click();
	}

	public void clickonismandatoryinprimarypackage() throws InterruptedException {

		Thread.sleep(2000);
		Is_mandatory_in_primary_package.click();
	}
	
	public void EnableMaximumNumberofConcurrentvideoCallscheckboxes() throws InterruptedException {

		Enable_Maximum_Number_of_Concurrent_Callscheckbox.click();
		Thread.sleep(2000);
		Enable_Maximum_Number_of_Concurrent_Video_Callscheckbox.click();
		
	}

	public void EnableMaximumNumberofConcurrentCalls(String concurrentcalls) throws InterruptedException {

		if (concurrentcalls.equals("")) {

			Thread.sleep(2000);

			System.out.println("Enable Maximum Number of Concurrent Calls field is empty");
		}

		else {

			Thread.sleep(2000);
			Enable_Maximum_Number_of_Concurrent_Calls.sendKeys(concurrentcalls);
		}
	}

	public void EnableMaximumNumberofConcurrentvideoCalls(String concurrentvideocalls) throws InterruptedException {

		if (concurrentvideocalls.equals("")) {

			Thread.sleep(2000);

			System.out.println("Enable Maximum Number of Concurrent video Calls field is empty");
		}

		else {

			Thread.sleep(2000);
			Enable_Maximum_Number_of_Concurrent_Video_Calls.clear();
			Thread.sleep(2000);
			Enable_Maximum_Number_of_Concurrent_Video_Calls.sendKeys(concurrentvideocalls);
		}

	}

	public void EnableMaximumDurationforAnsweredCalls(String answeredcalls) throws InterruptedException {

		if (answeredcalls.equals("")) {

			Thread.sleep(2000);

			System.out.println("Enable Maximum Duration for AnsweredCalls field is empty");
		}

		else {

			Thread.sleep(2000);
			Enable_Maximum_Duration_for_Answered_Calls.sendKeys(answeredcalls);
		}

	}

	public void EnableMaximumDurationforUnAnsweredCalls(String unansweredcalls) throws InterruptedException {

		if (unansweredcalls.equals("")) {

			Thread.sleep(2000);

			System.out.println("Enable Maximum Duration for UnAnsweredCalls field is empty");
		}

		else {

			Thread.sleep(2000);
			Enable_Maximum_Duration_for_Unanswered_Calls.sendKeys(unansweredcalls);
		}

	}

	public void EnableMaximumNumberofConcurrentRedirectedCalls(String concurrentredirectedcalls)
			throws InterruptedException {

		if (concurrentredirectedcalls.equals("")) {

			Thread.sleep(2000);

			System.out.println("Enable Maximum Number of Concurrent Redirected Calls field is empty");
		}

		else {

			Thread.sleep(2000);
			Enable_Maximum_Number_of_Concurrent_Redirected_Calls.sendKeys(concurrentredirectedcalls);
		}

	}

	public void EnableMaximumNumberofConcurrentfindmeinvocations(String invocations) throws InterruptedException {

		if (invocations.equals("")) {

			Thread.sleep(2000);

			System.out.println("Enable MaximumNumber of Concurrent findme invocations field is empty");
		}

		else {

			Thread.sleep(2000);
			Enable_Maximum_Number_of_Concurrent_Find_Me_Follow_Me_Invocations.sendKeys(invocations);
		}
	}

	public void EnableMaximumFindMeDepth(String findmedepth) throws InterruptedException {

		if (findmedepth.equals("")) {

			Thread.sleep(2000);

			System.out.println("Enable Maximum Find Me Depth field is empty");
		}

		else {

			Thread.sleep(2000);
			Enable_Maximum_Find_Me_Follow_Me_Depth.sendKeys(findmedepth);
		}
	}

	public void EnableMaximumConcurrentTerminatingAlertingRequests(String alertingrequests)
			throws InterruptedException {

		if (alertingrequests.equals("")) {

			Thread.sleep(2000);

			System.out.println("Enable Maximum Concurrent Terminatin gAlerting Requests field is empty");
		}

		else {

			Thread.sleep(2000);
			Enable_Maximum_Concurrent_Terminating_Alerting_Requests.sendKeys(alertingrequests);
		}
	}

	public void clickonIncludeRedirectionsinMaximumnumberofconcurrentCalls() throws InterruptedException {

		Thread.sleep(2000);
		Include_Redirections_in_Maximum_Number_of_Concurrent_Calls.click();
	}

	public void MaximumRedirectionDepth(String redirectiondepth) throws InterruptedException {

		if (redirectiondepth.equals("")) {

			Thread.sleep(2000);

			System.out.println("Maximum Redirection depth field is empty");
		}

		else {

			Thread.sleep(2000);
			Maximum_Redirection_Depth.sendKeys(redirectiondepth);
		}
	}

	public void clickoncanbeassignedcheckbox(String checkbox1) throws InterruptedException {

		if (checkbox1.equals("yes")) {
			Thread.sleep(2000);
			Can_Be_Assigned.click();
		} else {
			Thread.sleep(2000);
			System.out.println("Can be assigned check box not selected");
		}
	}

	public void clickonmandatoryassignmentcheckbox(String checkbox2) throws InterruptedException {

		if (checkbox2.equals("yes")) {

			Thread.sleep(2000);
			Thread.sleep(2000);
			Mandatory_Assignment.click();
		} else {
			Thread.sleep(2000);
			System.out.println("Mandatory assignment check box not selected");
		}
	}

	public void clickonallowedinchildlevelpackagescheckbox(String checkbox3) throws InterruptedException {

		if (checkbox3.equals("yes")) {

			Thread.sleep(2000);
			Allowed_In_Child_Level_Packages.click();
		} else {
			Thread.sleep(2000);
			System.out.println("Allowed in child level package check box not selected");
		}
	}

	public void clickoncanbeexplicitlyassignedcheckbox(String checkbox4) throws InterruptedException {

		if (checkbox4.equals("yes")) {

			Thread.sleep(2000);
			Can_Be_Explicitly_Assigned.click();
		} else {
			Thread.sleep(2000);
			System.out.println("Can be explicitily assigned check box not selected");
		}
	}

	public void clickonmultipleinstancesallowedcheckbox(String checkbox5) throws InterruptedException {

		if (checkbox5.equals("yes")) {

			Thread.sleep(2000);
			Multiple_Instances_Allowed.click();
		} else {
			Thread.sleep(2000);
			System.out.println("Multiple instances allowed check box not selected");
		}
	}

	public void clickoncanchangestartdatecheckbox(String checkbox6) throws InterruptedException {

		if (checkbox6.equals("yes")) {
			Thread.sleep(2000);
			Can_Change_Start_Date.click();
		} else {
			Thread.sleep(2000);
			System.out.println("Can change start date check box not selected");
		}
	}

	public void clickoncanchangetariffratecheckbox(String checkbox7) throws InterruptedException {

		if (checkbox7.equals("yes")) {
			Thread.sleep(2000);
			Can_Change_Tariff_Rate.click();
		} else {
			Thread.sleep(2000);
			System.out.println("Can chage tariff rate check box not selected");
		}
	}

	public void supplierpartnumber(String suppnum) throws InterruptedException {

		if (suppnum.equals("")) {

			Thread.sleep(2000);

			System.out.println("Supplier part number field is empty");
		}

		else {

			Thread.sleep(2000);
			Supplier_Part_Number.sendKeys(suppnum);
		}
	}

	public void clientdownloadpath(String downloadpath) throws InterruptedException {

		if (downloadpath.equals("")) {

			Thread.sleep(2000);

			System.out.println("Client download path field is empty");
		}

		else {

			Thread.sleep(2000);
			Client_Download_Path.sendKeys(downloadpath);
		}
	}

	public void dependentservice(String dependentservice1) throws InterruptedException {
		if (dependentservice1.equals("")) {
			System.out.println("Drop Down is not selected");
		} else {
			Thread.sleep(2000);
			Select select = new Select(Dependent_Service);
			select.selectByVisibleText(dependentservice1);
		}

	}

	public void userservicegroup(String userservicegroup1) throws InterruptedException {
		if (userservicegroup1.equals("")) {
			System.out.println("Drop Down is not selected");
		} else {
			Thread.sleep(2000);
			Select select = new Select(UserService_Group);
			select.selectByVisibleText(userservicegroup1);
		}

	}

	public void dependentpackage(String dependentpackage1) throws InterruptedException {
		if (dependentpackage1.equals("")) {
			System.out.println("Drop Down is not selected");
		} else {
			Thread.sleep(2000);
			Select select = new Select(Dependent_Package);
			select.selectByVisibleText(dependentpackage1);
		}

	}

	// ************************Multiple Check box ********************************//

	public void servicecheckbox(String[] service) throws InterruptedException {

		this.services(service);
	}

	public void services(String[] service) throws InterruptedException {
		Thread.sleep(2000);
		String count = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div[1]/div/div[31]/div/label";
		String Text = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div[1]/div/div[31]/div/label[x]";
		String CheckBox = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div[1]/div/div[31]/div/label[1]/span";
		this.Multiple_CheckBox_Selection(service, count, Text, CheckBox);
	}

	// ***********************Contract Rule********************************//

	public void minimumduration(String md) throws InterruptedException {
		Thread.sleep(2000);
		Minimum_Duration.sendKeys(md);
	}

	public void notificationperiod(String np) throws InterruptedException {
		Thread.sleep(2000);
		Notification_Period.sendKeys(np);
	}

	public void quarantineperiod(String qp) throws InterruptedException {
		Thread.sleep(2000);
		Quarantine_Period.sendKeys(qp);
	}

	public void clickoncombinetruecheckbox(String combinetrue) throws InterruptedException {

		if (combinetrue.equals("yes")) {
			Thread.sleep(2000);
			combinetruecheckbox.click();
		} else {
			Thread.sleep(2000);
			System.out.println("Combine true checkbox check box not selected");
		}
	}

	// ******************Click on save button*****************//

	public void clickonsave() throws InterruptedException

	{
		Thread.sleep(4000);
		save.click();
	}

	// ******************Click on cancel button*****************//

	public void clickoncancel() throws InterruptedException

	{
		Thread.sleep(4000);
		cancel.click();
	}

	// **************Click on contract rule*******************//

	public void clickoncontractrule() throws InterruptedException

	{
		Thread.sleep(4000);
		contractrule.click();
	}

	// ***********************Contract Rule********************************//

	public void minimumdurationedit(String md) throws InterruptedException {
		minimumduration.clear();
		Thread.sleep(2000);
		minimumduration.sendKeys(md);
	}

	public void notificationperiodedit(String np) throws InterruptedException {
		notificationperiod.clear();
		Thread.sleep(2000);
		notificationperiod.sendKeys(np);
	}

	public void quarantineperiodedit(String qp) throws InterruptedException {
		quarantineperiod.clear();
		Thread.sleep(2000);
		quarantineperiod.sendKeys(qp);
	}

	public void clickoncombinetruecheckboxedit(String combinetrue) throws InterruptedException {

		if (combinetrue.equals("yes")) {
			Thread.sleep(2000);
			combinetruecheckboxedit.click();
		} else {
			Thread.sleep(2000);
			System.out.println("Combine true checkbox check box not selected");
		}
	}

	// **************Click on contract rule save*******************//

	public void clickonsavecontractrule() throws InterruptedException

	{
		Thread.sleep(4000);
		savecontractrule.click();
	}

	// **************Click on contract rule save confirm*******************//

	public void clickonsavecontractruleconfirm() throws InterruptedException

	{
		Thread.sleep(2000);
		saveconfirm.click();
	}

	// **************Click on Service usage*******************//

	public void clickonserviceusage() throws InterruptedException

	{
		Thread.sleep(4000);
		serviceusage.click();
	}
	
	public void CompareString(String text) throws InterruptedException 
	
	{
		String HeaderBusns = Header_NextTab.getText();
		System.out.println(HeaderBusns);
		if (HeaderBusns.contains(text)) {
	
			System.out.println("No data available in table");
			
		}
	}

	public void Searchbutton(String searc) throws InterruptedException, AWTException {
		Thread.sleep(2000);
		search.sendKeys(searc);
		Thread.sleep(2000);
		searchbtn.click();
	}

	public void textlink() throws InterruptedException, AWTException {
		link.click();
		Thread.sleep(1000);

	}

	public void export() throws InterruptedException, AWTException {
		Thread.sleep(3000);
		export.click();
		Thread.sleep(1000);

	}

	public void Delete() throws InterruptedException {
		Thread.sleep(2000);
		Delete_Button.click();
		Thread.sleep(2000);
		Delete_Button_Link.click();

	}

	public void GoTogeneraltab() throws InterruptedException {
		Thread.sleep(4000);
		generaltab.click();

	}

//******************Main methods***********************//	

	public void Service_Edit_Validation(String Servicename,String email,String concurrentcalls,String concurrentvideocalls,String answeredcalls,String unansweredcalls,String concurrentredirectedcalls,String invocations,String findmedepth,String alertingrequests,String redirectiondepth ) throws InterruptedException, AWTException {
		Thread.sleep(2000);
		this.GoToEdit_Link(Servicename);
		this.NameClear();
		
		this.Email(email);
		//this.EnableMaximumNumberofConcurrentvideoCallscheckboxes();
		this.EnableMaximumNumberofConcurrentCalls(concurrentcalls);
		this.EnableMaximumNumberofConcurrentvideoCalls(concurrentvideocalls);
		this.EnableMaximumDurationforAnsweredCalls(answeredcalls);
		this.EnableMaximumDurationforUnAnsweredCalls(unansweredcalls);
		this.EnableMaximumNumberofConcurrentRedirectedCalls(concurrentredirectedcalls);
		this.EnableMaximumNumberofConcurrentfindmeinvocations(invocations);
		this.EnableMaximumFindMeDepth(findmedepth);
		this.EnableMaximumConcurrentTerminatingAlertingRequests(alertingrequests);
		this.MaximumRedirectionDepth(redirectiondepth);
		this.ScrollPage("0,+900");
		this.clickonsave();
		
		this.nameval();
		this.emailval();
		this.concurrentcallsval();
		this.concurrentvideocallsval();
		this.answeredcallsval();
		this.unansweredcallsval();
		this.concurrentredirectedcallsval();
		this.concurrentfindmeval();
		this.followmedepthval();
		this.concurrentterminatingalertingrequestsval();
		this.redirectiondepthval();
		
	    this.ScrollPage("0,-900");
		this.clickoncontractrule();
	    minimumduration.clear();
	    notificationperiod.clear();
	    quarantineperiod.clear();
		this.clickonsavecontractrule();
		this.mindurationVal();
		this.notificationperiodval();
		this.quarantineperiodval();
		this.ScrollPage("0,-900");
		this.GoTogeneraltab();
		this.clickoncancel();

	}




	public void Service_Edit(String Servicename, String name1, String OSSname1, String Description1, String Email1,
			String versiondropdown1, String concurrentcalls, String concurrentvideocalls, String answeredcalls,
			String unansweredcalls, String concurrentredirectedcalls, String invocations, String findmedepth,
			String alertingrequests, String redirectiondepth, String canbeassigned, String mandatoryassignment,
			String allowedinchildlevelpackages, String canbeexplicitlyassigned, String multipleinstancesallowed,
			String canchangestartdate, String canchangetariffrate, String partno, String downloadpath,
			String dependentservice1, String userservicegroup1, String dependentpackage1, String[] service, String md,
			String np, String qp, String combinetrue, String search, String deletedvalue, String text)
			throws InterruptedException, AWTException {
		Thread.sleep(2000);
		this.GoToEdit_Link(Servicename);
		this.NameClear();
		this.name(name1);

		this.Description(Description1);
		this.Email(Email1);
		// this.versiondropdown(versiondropdown1);
		this.clickoncanbulkconfigurecheckbox();
		// this.clickonismandatoryinprimarypackage();
		this.EnableMaximumNumberofConcurrentCalls(concurrentcalls);
		this.EnableMaximumNumberofConcurrentvideoCalls(concurrentvideocalls);
		this.EnableMaximumDurationforAnsweredCalls(answeredcalls);
		this.EnableMaximumDurationforUnAnsweredCalls(unansweredcalls);
		this.EnableMaximumNumberofConcurrentRedirectedCalls(concurrentredirectedcalls);
		this.EnableMaximumNumberofConcurrentfindmeinvocations(invocations);
		this.EnableMaximumFindMeDepth(findmedepth);
		this.EnableMaximumConcurrentTerminatingAlertingRequests(alertingrequests);
		this.clickonIncludeRedirectionsinMaximumnumberofconcurrentCalls();
		this.MaximumRedirectionDepth(redirectiondepth);

		this.clickoncanbeassignedcheckbox(canbeassigned);
		this.clickonmandatoryassignmentcheckbox(mandatoryassignment);
		this.clickonallowedinchildlevelpackagescheckbox(allowedinchildlevelpackages);
		this.clickoncanbeexplicitlyassignedcheckbox(canbeexplicitlyassigned);
		this.clickonmultipleinstancesallowedcheckbox(multipleinstancesallowed);
		this.clickoncanchangestartdatecheckbox(canchangestartdate);
		this.clickoncanchangetariffratecheckbox(canchangetariffrate);

		this.supplierpartnumber(partno);
		this.clientdownloadpath(downloadpath);
		this.dependentservice(dependentservice1);
		this.userservicegroup(userservicegroup1);
		this.dependentpackage(dependentpackage1);
		this.servicecheckbox(service);

		this.ScrollPage("0,-900");
		this.clickoncontractrule();
		this.minimumdurationedit(md);
		this.notificationperiodedit(np);
		this.quarantineperiodedit(qp);
		this.clickoncombinetruecheckboxedit(combinetrue);
		this.clickonsavecontractrule();
		this.clickonsavecontractruleconfirm();
		this.Save_validation();

		this.clickonserviceusage();
		Thread.sleep(4000);
		this.Searchbutton(search);
		this.includeremovedcheck(deletedvalue);
		this.CompareString(text);
		//this.export();
		// this.GoTogeneraltab();
	}

	public void Service_DELETE(String search) throws InterruptedException, AWTException {
		this.GoTogeneraltab();
		this.Delete();
		Thread.sleep(5000);
		this.DelVal();
	}

	/***********************************
	 * Validation elements
	 *****************************************/

	@FindBy(id = "txtName-error")
	WebElement namevalidation;
	
	@FindBy(id = "txtEmail-error")
	WebElement emailvalidation;
	@FindBy(id = "txtSimultaneousCalls-error")
	WebElement concurrentcallsvalidation;
	@FindBy(id = "txtSimultaneousVideoCalls-error")
	WebElement concurrentvideocallsvalidation;
	@FindBy(id = "txtMaxAnsweredCallDuration-error")
	WebElement answeredcallsvalidation;
	@FindBy(id = "txtMaxUnansweredCallDuration-error")
	WebElement unansweredcallsvalidation;
	
	@FindBy(id = "txtMaxConcurrentRedirectedCalls-error")
	WebElement redirectedcallsvalidation;
	@FindBy(id = "txtMaxConcurrentFindMeFollowMeInvocations-error")
	WebElement concurrentfindmevalidation;
	@FindBy(id = "txtEnableMaxFindMeFollowMeDepth-error")
	WebElement followmedepthvalidation;
	@FindBy(id = "txtEnableMaxConcurrentTerminatingAlertingRequests-error")
	WebElement ConcurrentTerminatingAlertingRequestsvalidation;
	@FindBy(id = "txtMaxRedirectionDepth-error")
	WebElement RedirectionDepthvalidation;
	
	
	@FindBy(id = "minimumduration-error")
	WebElement mindurationvalidation;
	@FindBy(id = "txtnotificationperiod-error")
	WebElement notificationperiodvalidation;
	@FindBy(id = "quarantineperiod-error")
	WebElement quarantineperiodvalidation;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDeletemessenger;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement Delete_Sucessfull_msg;

	String nameval = "Name cannot be empty";
	
	String emailval = "Email ID is in incorrect format";
	String concurrentcallsval = "Please enter a valid Number";
	String concurrentvideocallsval = "Please enter a valid Number";
	String answeredcallsval = "Please enter a valid Number";
	String unansweredcallsval = "Please enter a valid Number";
	String concurrentredirectedcallsval = "Please enter a valid Number";
	String concurrentfindmeval = "Please enter a valid Number";
	String followmedepthval = "Please enter a valid Number";
	String concurrentterminatingalertingrequestsval = "Please enter a valid Number";
	String redirectiondepthval = "Please enter a valid Number";
	
	String mindurationVal = "Minimum duration cannot be empty";
	String notificationperiodval = "Notification period cannot be empty";
	String quarantineperiodval = "Quarantine period cannot be empty/zero";
	String SaveVal = "Saved successfully";
	String DelVal = "Deleted successfully";

	public void nameval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = nameval;
		String getValiadtion = namevalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void emailval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = emailval;
		String getValiadtion = emailvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void concurrentcallsval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = concurrentcallsval;
		String getValiadtion = concurrentcallsvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void concurrentvideocallsval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = concurrentvideocallsval;
		String getValiadtion = concurrentvideocallsvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void answeredcallsval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = answeredcallsval;
		String getValiadtion = answeredcallsvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void unansweredcallsval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = unansweredcallsval;
		String getValiadtion = unansweredcallsvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void concurrentredirectedcallsval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = concurrentredirectedcallsval;
		String getValiadtion = redirectedcallsvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void concurrentfindmeval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = concurrentfindmeval;
		String getValiadtion = concurrentfindmevalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void followmedepthval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = followmedepthval;
		String getValiadtion = followmedepthvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void concurrentterminatingalertingrequestsval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = concurrentterminatingalertingrequestsval;
		String getValiadtion = ConcurrentTerminatingAlertingRequestsvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void redirectiondepthval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = redirectiondepthval;
		String getValiadtion = RedirectionDepthvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	
	
	public void mindurationVal() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = mindurationVal;
		String getValiadtion = mindurationvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void notificationperiodval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = notificationperiodval;
		String getValiadtion = notificationperiodvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void quarantineperiodval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = quarantineperiodval;
		String getValiadtion = quarantineperiodvalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void saveVal() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = SaveVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void DelVal() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = DelVal;
		String getValiadtion = Delete_Sucessfull_msg.getText();
		this.Validation(getValiadtion, setvalidation);
	}

	public void Save_validation() throws InterruptedException {
		this.saveVal();
	}

	public void validation() throws InterruptedException {
		this.nameval();
	}


	/***********************************************
	 * COMMON METHOD
	 **********************************************/

	// Validation

	public void Validation(String GetValiadtion, String Setvalidation) {
		PageFactory.initElements(driver, this);
		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as  " + GetValiadtion);
		} else {
			System.out.println("Validation is incorrect: " + GetValiadtion);
			Assert.fail("Test Fail");
		}

	}

	// ****************************Multiple check box
	// selection************************//
	/********************/

	String Text0;
	String Text4;
	String Xpath1;
	String Xpath2;

	/**********************/

	public void Multiple_CheckBox_Selection(String[] labels, String Count, String Text, String CheckBox)
			throws InterruptedException {

		if (Text.contains("table")) {
			String[] SPLITTEXT = Text.split("tr", 2);
			String Text1 = SPLITTEXT[0];
			String Text2 = SPLITTEXT[1];
			String[] Text3 = Text2.split("1", 2);
			Text4 = Text3[1];
			Text0 = Text1 + "tr[";
		} else {
			String[] SPLITTEXT = Text.split("x", 2);
			String Text1 = SPLITTEXT[0];
			String Text2 = SPLITTEXT[1];
			Text4 = Text2;
			// System.out.println(Text2);
			Text0 = Text1;
			// System.out.println(Text1);
		}
		if (CheckBox.contains("table")) {
			String[] SPLITCheckBox = CheckBox.split("tr", 2);
			String CheckBox1 = SPLITCheckBox[0];
			String CheckBox2 = SPLITCheckBox[1];
			String[] CheckBox3 = CheckBox2.split("1", 2);
			Xpath1 = CheckBox3[1];
			Xpath2 = CheckBox1 + "tr[";
		} else {
			String[] SPLITCheckBox = CheckBox.split("1", 2);
			String CheckBox1 = SPLITCheckBox[0];
			String CheckBox2 = SPLITCheckBox[1];
			Xpath1 = CheckBox2;
			Xpath2 = CheckBox1;

		}

		ArrayList<String> ListLabel = new ArrayList<String>();

		for (int j = 0; j < labels.length; j++) {
			ListLabel.add(labels[j]);
		}

		int Counts = driver.findElements(By.xpath(Count)).size();
		for (int i = 1; i <= Counts; i++) {
			String text = driver.findElement(By.xpath(Text0 + i + Text4)).getText();
			if (ListLabel.contains(text)) {
				Thread.sleep(1000);
				driver.findElement(By.xpath(Xpath2 + i + Xpath1)).click();
				System.out.println("Assignable to other services checkbox :" + text);
			}

			else {

				System.out.println("Assignable to other services checkbox found");

			}

		}
	}

	// scroll page
	public void ScrollPage(String ScrollBy) throws AWTException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + ScrollBy + ")");

	}

	public void includeremovedcheck(String deletedValue) throws InterruptedException {
		settings.click();
		Thread.sleep(3000);
		includeremovedcheck.click();
		int Counts = driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")).size();// *[@id="datagrid"]/tbody/tr[1]/td
		Thread.sleep(2000);
		for (int i = 1; i <= Counts; i++) {
			String inputvalue = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr[" + i + "]/td")).getText();
			if (inputvalue.equals(deletedValue)) {
				String color = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr[" + i + "]/td"))
						.getCssValue("color");

				String[] hexValue = color.replace("rgba(", "").replace(")", "").split(",");

				int hexValue1 = Integer.parseInt(hexValue[0]);
				hexValue[1] = hexValue[1].trim();
				int hexValue2 = Integer.parseInt(hexValue[1]);
				hexValue[2] = hexValue[2].trim();
				int hexValue3 = Integer.parseInt(hexValue[2]);

				String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);

				Assert.assertEquals("#fc4b6c", actualColor);
				System.out.println(deletedValue + " is deleted and also listed in include removed");

			}
		}
	}

}
