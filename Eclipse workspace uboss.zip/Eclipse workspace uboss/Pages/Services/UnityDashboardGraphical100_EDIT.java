package Services;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Sep 29, 2020 , 2:17:26 PM
-- Description	: UnityDashboardGraphical100_EDIT.java
-- Modified by	: 
-- Modified Date:
-- Project		: Uboss-5-0-5
-- =============================================*/
public class UnityDashboardGraphical100_EDIT {
WebDriver driver;
	
	@FindBy(xpath ="//*[@id=\"search_data\"]")
	WebElement search;
	
	@FindBy(xpath = "//*[@id=\"search_btn\"]")
	WebElement searchbutton;
	
	@FindBy(xpath = "//*[@id=\"datagrid\"]/tbody/tr[1]/td/a")
	WebElement clickEdit;
	
	@FindBy(id = "txtName")
	WebElement Name;
	
	@FindBy(id = "txtDecription")
	WebElement Description;
	
	@FindBy(id = "txtEmail")
	WebElement Emailnotif;
	
	@FindBy(id = "ddlCountry")
	WebElement Country;
	
	@FindBy(id = "ddlSuppliers")
	WebElement Supplier;
	
	@FindBy(xpath ="//*[@id=\"general\"]/div/div/div/div[7]/div/label/span")
	WebElement CanbeAssigned;
	
	@FindBy(xpath ="//*[@id=\"general\"]/div/div/div/div[8]/div/label/span")
	WebElement MandatoryAssign;
	
	@FindBy(xpath ="//*[@id=\"general\"]/div/div/div/div[9]/div/label/span")
	WebElement Allowinchildpack;
	
	@FindBy(xpath= "//*[@id=\"general\"]/div/div/div/div[10]/div/label/span")
	WebElement Canbeexplicitlyassign;
	
	@FindBy(xpath= "//*[@id=\"general\"]/div/div/div/div[11]/div/label/span")
	WebElement MultipleInstanceallowed;
	
	@FindBy(xpath= "//*[@id=\"general\"]/div/div/div/div[12]/div/label/span")
	WebElement CanchangedStartdate;
	
	@FindBy(xpath= "//*[@id=\"general\"]/div/div/div/div[13]/div/label/span")
	WebElement CanchangedTariffrate;
	
	
	@FindBy(id = "ddlDependentService")
	WebElement DependentService;
	
	@FindBy(id = "txtSupplierPartNumber")
	WebElement SupplierPartNumber;
	
	@FindBy(id = "ddlBusinessServiceGroupId")
	WebElement BusinessORSiteServiceGroup;
	
	@FindBy(id = "ddlServiceGroupId")
	WebElement UserServiceGroup;
	
	@FindBy(id = "StandardContract")
	WebElement ContractTypestandard;
	
	@FindBy(id = "minimumduration")
	WebElement MinDura;
	
	@FindBy(id = "txtnotificationperiod")
	WebElement NotiPeriod;
	
	@FindBy(id = "quarantineperiod")
	WebElement QuarPeriod;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div/form/div[2]/div[4]/div/label/span[2]")
	WebElement Combinenotiminperiod;
	
	@FindBy(xpath = "/html/body/div[2]/div[2]/div/div/div[3]/div/form/div[1]/div/div[18]/div/label[2]/span[2]")
	WebElement ContractTyperolling;
	
	@FindBy(id = "txtRollingContractTerm")
	WebElement Rollingcontract;
	
	@FindBy(id = "txtCancellationPeriod")
	WebElement Cancellationperiod;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div/form/div[3]/div[3]/div/label[1]/span")
	WebElement CancellationAtTheBeginning;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/div/div/div/form/div[3]/div[3]/div/label[2]/span")
	WebElement CancellationAtEnd;

	@FindBy(id = "save_btn")
	WebElement SAVE;
	
	@FindBy(xpath ="//*[@id=\"contactrule\"]/span[2]")
	WebElement tab1;
	
	@FindBy(xpath ="//*[@id=\"usagelist\"]/span[2]")
	WebElement tab2;
	
	@FindBy(xpath ="//*[@id=\"generaltab\"]/a")
	WebElement tab3;
	
	@FindBy(id = "COMMONA215")
	WebElement cancel1;
	
	@FindBy(id = "updatedetails")
	WebElement update;
	
	@FindBy(xpath = "//button[contains(@onclick,'ConfirmSave(2)')]")
	WebElement update1;
	
	@FindBy(xpath ="/html/body/div[3]/div/div/div[3]/button[1]")
	WebElement ok;
	

	@FindBy(id ="deletedetails")
	WebElement delete;
	
	@FindBy(xpath ="/html/body/div[3]/div/div/div[3]/button[1]")
	WebElement ys;
	
	@FindBy(xpath = "//*[@id=\"settings\"]/div/div/label/span")
	WebElement includeremovedcheck;
		
	@FindBy(xpath = "//*[@id=\"btn_settings\"]")
	WebElement settings;

	public UnityDashboardGraphical100_EDIT(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) throws IOException {
		driver.get(Url);

	}
	public void Clickonsearch(String searchs) throws InterruptedException {
		search.clear();
		Thread.sleep(1000);
		search.sendKeys(searchs);
	}
	public void Clickonsearchbtn() throws InterruptedException {
		Thread.sleep(1000);
		searchbutton.click();
	}
	public void Clickonsearchitem() throws InterruptedException {
		Thread.sleep(1000);
		clickEdit.click();
	}
	public void Save() throws InterruptedException {
		Thread.sleep(2000);
		SAVE.click();
	}
	
	
	public void Tab_clicl1() throws InterruptedException {
		Thread.sleep(2000);
		tab1.click();
	}
	public void Tab_clicl2() throws InterruptedException {
		Thread.sleep(2000);
		tab2.click();
	}
	public void Tab_clicl3() throws InterruptedException {
		Thread.sleep(2000);
		tab3.click();
	}
	public void save12() throws InterruptedException {
		Thread.sleep(2000);
		update.click();
	}
	public void save13() throws InterruptedException {
		Thread.sleep(2000);
		update1.click();
	}
	public void Cancel() throws InterruptedException {
		Thread.sleep(2000);
		cancel1.click();
	}
	public void name(String name) throws InterruptedException {
		Thread.sleep(1000);
		if (name.equals("")) {
			System.out.println("Name is not set for the srvice");
		}
	else {
		Name.sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
		Name.sendKeys(name);
	}
	}
	public void Descriptions(String descp) {
		if (descp.equals("")) {
			System.out.println("Description  is not set for the service");
		}
		else {
			Description.sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
			Description.sendKeys(descp);
		}
	}
	public void Mail(String email) {
		if (email.equals("")) {
			System.out.println("Mail ID is not set for the service");
		}
		else
		{
			Emailnotif.sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
			Emailnotif.sendKeys(email);
	}
	}
	public void country(String country) throws InterruptedException {
		if(country.equals(null)) {
			System.out.println("Country is not selected");
		}
		else {
			Thread.sleep(2000);
			Select select = new Select(Country);
			select.selectByVisibleText(country);
		}
		
	}
	
	public void supplier(String supplier) throws InterruptedException {
		if(supplier.equals(null)) {
			System.out.println("Supplier is not selected");
		}
		else {
			Thread.sleep(2000);
			Select select = new Select(Supplier);
			select.selectByVisibleText(supplier);
		}
		
	}
	

	public void ClickonCanbeAssigned(String canbeAssigned) throws InterruptedException {
		Thread.sleep(2000);
		if (canbeAssigned.equals("No")) {
			System.out.println("Can be assigned is not selected");
		}
		else if(canbeAssigned.equals("Yes")) {
			CanbeAssigned.click();
	}
	}
	public void ClickonMandatoryservice(String mandatoryAssign) throws InterruptedException {
		Thread.sleep(2000);
		if (mandatoryAssign.equals("No")) {
			System.out.println("Multipleinstance is not selected");
		}
		else if(mandatoryAssign.equals("Yes")) {
			MandatoryAssign.click();
	}
	}
	public void ClickonMultipleinstance(String multipleInstanceallowed) throws InterruptedException {
		Thread.sleep(2000);
		if (multipleInstanceallowed.equals("No")) {
			System.out.println("Multipleinstance is not selected");
		}
		else if(multipleInstanceallowed.equals("Yes")) {
		MultipleInstanceallowed.click();
	}
	}
	public void ClickonChildlevel(String allowinchildpack) throws InterruptedException {
		Thread.sleep(2000);
		if (allowinchildpack.equals("No")) {
			System.out.println("Childlevel  is not selected");
		}
		else if(allowinchildpack.equals("Yes")) {
			Allowinchildpack.click();
	}
	}
	public void ClickonExplicitly(String canbeexplicitlyassign) throws InterruptedException {
		Thread.sleep(2000);
		if (canbeexplicitlyassign.equals("No")) {
			System.out.println("Explicitly service  is not selected");
		}
		else if(canbeexplicitlyassign.equals("Yes")) 
		{
			Canbeexplicitlyassign.click();
	}
	}
	
	public void ClickonchngeStartDate(String canchangedStartdate) throws InterruptedException {
		Thread.sleep(2000);
		if (canchangedStartdate.equals("No")) {
			System.out.println("Childlevel  is not selected");
		}
		else if(canchangedStartdate.equals("Yes")) {
			CanchangedStartdate.click();
	}
	}
	public void ClickonchngeTariff(String canchangedTariffrate) throws InterruptedException {
		Thread.sleep(2000);
		if (canchangedTariffrate.equals("No")) {
			System.out.println("Explicitly service  is not selected");
		}
		else if(canchangedTariffrate.equals("Yes")) {
		
			CanchangedTariffrate.click();
	}
	}
	
	public void Dependantservice_Dropdwn(String dependant) throws InterruptedException {
		if(DependentService.equals(null)) {
			System.out.println("Drop Down is not selected");
		}
		else {
			
			Select select = new Select(DependentService);
			select.selectByVisibleText(dependant);
		}
		
	}
	public void SupplierPartNumber(String supp) {
		if (supp.equals("")) {
			System.out.println("suppler part number is not set in service");
		}
		else
		{
		SupplierPartNumber.sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
		SupplierPartNumber.sendKeys(supp);
	}
	}
	public void bussitserviceGroup_Dropdwn(String busservgrp) throws InterruptedException {
		if(BusinessORSiteServiceGroup.equals(null)) {
			System.out.println("Drop Down is not selected");
		}
		else {
			
			Select select = new Select(BusinessORSiteServiceGroup);
			select.selectByVisibleText(busservgrp);
		}
		
	}
	
	public void userserviceGroup_Dropdwn(String usrservgrp) throws InterruptedException {
		if(UserServiceGroup.equals(null)) {
			System.out.println("Drop Down is not selected");
		}
		else {
			
			Select select = new Select(UserServiceGroup);
			select.selectByVisibleText(usrservgrp);
		}
		
	}
	
	public void Clickonradbtnstd(String contractTypestandard) throws InterruptedException {
		Thread.sleep(2000);
		if (contractTypestandard.equals("No")) {
			System.out.println("ContractTypestandard  is not selected");
		}
		else if (contractTypestandard.equals("Yes")) 
		{
			ContractTypestandard.click();
	}
	}
	
	public void Clickonradbtnrol(String contractTyperolling) throws InterruptedException {
		Thread.sleep(2000);
		if (contractTyperolling.equals("No")) {
			System.out.println("ContractTyperolling  is not selected");
		}
		else if (contractTyperolling.equals("Yes")) 
		{
			Thread.sleep(2000);
			ContractTyperolling.click();
	}
	}
	public void mindura(String mindura) {
		if (mindura.equals("")) {
			System.out.println("Minimum duration is not set in service");
		}
		else
		{
		MinDura.sendKeys(mindura);
		}
	}
	
	public void notiprd(String notiprd) {
		if (notiprd.equals("")) {
			System.out.println("Notification period is not set in service");
		}
		else
		{
		NotiPeriod.sendKeys(notiprd);
		}
	}
	
	public void quarantdays(String quarantdays) {
		if (quarantdays.equals("")) {
			System.out.println("Quarantine days is not set in service");
		}
		else
		{
		QuarPeriod.sendKeys(quarantdays);
		}
	}
	
	public void ClickonCombinenotiminperiodchkbx(String combinenotiminperiod) throws InterruptedException {
		if (combinenotiminperiod.equals("No")) {
			System.out.println("Combine notification and minimum duration period is not set in service");
		}
		else  if (combinenotiminperiod.equals("Yes"))
		{
		Combinenotiminperiod.click();
	}
	}
	
	public void rollingcontract(String rollingcontract) {
		if (rollingcontract.equals("")) {
			System.out.println("Rolling contract duration is not set in service");
		}
		else
		{
		Rollingcontract.sendKeys(rollingcontract);
		}
	}
	
	
	public void cancellationperiod(String cancelper) {
		if (cancelper.equals("")) {
			System.out.println("Cancellation period  is not set in service");
		}
		else
		{
		Cancellationperiod.sendKeys(cancelper);
		}
	}
	public void Cancelbeginradiobtn() throws InterruptedException {
		Thread.sleep(2000);
		WebElement Isvisibleyes;
		Isvisibleyes = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div/div/div/form/div[3]/div[3]/div/label[1]/span"));
		if(!Isvisibleyes.isSelected()){
			Thread.sleep(2000);
			Isvisibleyes.click();	
		}
		else
		{
			Thread.sleep(2000);
			System.out.println("Already it is true");
		}
	}
	
	public void Cancelendradiobtn() throws InterruptedException {
		Thread.sleep(2000);
		WebElement Isvisibleyes;
		Isvisibleyes = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div/div/div/form/div[3]/div[3]/div/label[2]/span"));
		if(!Isvisibleyes.isSelected()){
			Thread.sleep(2000);
			Isvisibleyes.click();	
		}
		else
		{
			Thread.sleep(2000);
			System.out.println("Already it is true");
		}
	}
	public void popup() throws InterruptedException {
		Thread.sleep(2000);
		ok.click();
	}
	
	public void Delete() throws InterruptedException {
		Thread.sleep(2000);
		delete.click();
		Thread.sleep(2000);
		ys.click();
	}
	

	public void Clearfiledsgeneraltab() throws InterruptedException {
		Thread.sleep(3000);
		Name.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(2000);
		Emailnotif.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(2000);
		
	}
	
	
	
	
	public void Clearfiledscontractruletab() throws InterruptedException {
		Thread.sleep(3000);
		MinDura.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(2000);
		NotiPeriod.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(2000);
		QuarPeriod.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(3000);
	}
	
	public void Clearfiledscontractrulerollingtab() throws InterruptedException {
		Thread.sleep(3000);
		Rollingcontract.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(2000);
		Cancellationperiod.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(3000);
		
	}
	
	/*****************************************************
	 * Validation
	 ***********************************************/
	@FindBy(id = "txtName-error")
	WebElement ServiceNamevalidation;

	@FindBy(id = "txtEmail-error")
	WebElement EmailNotiValidation;
	
	@FindBy(id = "ddlCountry-error")
	WebElement CountryValidation;
	
	@FindBy(id = "minimumduration-error")
	WebElement MinDurValidation;
	
	@FindBy(id = "txtnotificationperiod-error")
	WebElement NotifperiodValidation;
	
	@FindBy(id = "quarantineperiod-error")
	WebElement QuarperiodValidation;
	
	@FindBy(id = "txtRollingContractTerm-error")
	WebElement RollingContractValidation;
	
	
	@FindBy(id = "txtCancellationPeriod-error")
	WebElement CancelperiodValidation;
	
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDeletemessenger;

	String ServicenameVal = "Name cannot be empty";
	String Emailval = "Email ID is in incorrect format";
	String Countryval = "Select Country";
	String SaveVal = "Saved successfully";
	String DeletVal = "Deleted successfully";
	String[] serverValidation1 = { "Minimum duration for service cannot be less than 30","Notification period for service cannot be less than 30"};
	String MinDurval="Minimum duration cannot be empty";
	String Notifperiodval="Notification period cannot be empty";
	String Quarperiodval="Quarantine period cannot be empty/zero";
	String RollingContractval="Rolling contract term cannot be empty";
	String Cancelperiodval="Cancellation period cannot be empty";
	String[] serverValidation2 = { "Rolling contract term cannot be less than 30 days.","Cancellation period cannot be greater than rolling contract duration"};

	
	public void nameval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = ServicenameVal;
		String getValiadtion = ServiceNamevalidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void emailval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = Emailval;
		String getValiadtion = EmailNotiValidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void countryval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = Countryval;
		String getValiadtion = CountryValidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void mindurval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = MinDurval;
		String getValiadtion = MinDurValidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void notifperiodval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = Notifperiodval;
		String getValiadtion = NotifperiodValidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	
	public void quarperiodval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = Quarperiodval;
		String getValiadtion = QuarperiodValidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	
	public void rollingcontractval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = RollingContractval;
		String getValiadtion = RollingContractValidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	
	public void cancelperiodval() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = Cancelperiodval;
		String getValiadtion = CancelperiodValidation.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	public void saveVal() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = SaveVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		this.Validation(setvalidation, getValiadtion);
	}

	public void Save_validation() throws InterruptedException {
		this.saveVal();
	}
	public void DeleVal() throws InterruptedException {
		Thread.sleep(2000);
		String setvalidation = DeletVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	public void Delete_validation() throws InterruptedException {
		this.DeleVal();
	}
	
	public void serverValidation1() throws InterruptedException {
		
		Thread.sleep(1000);
		String[] setvalidation = serverValidation1;
		

		ArrayList<String> Validationlist = new ArrayList<String>();
		for (int j = 0; j <= setvalidation.length - 1; j++) {
			Validationlist.add(setvalidation[j]);
		}
		
		

		int Counts = driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p")).size();
		for (int i = 1; i <= Counts; i++) {
			String text = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p["+i+"]"))
					.getText();
			if (Validationlist.contains(text)) {
				System.out.println("Validation is correct :  " + text);

			} else {

				System.out.println("Validation is incorrect : " + text);
				Assert.fail("Test Fail");

			}
		}
	}
	
public void serverValidation2() throws InterruptedException {
		
		Thread.sleep(1000);
		String[] setvalidation = serverValidation2;
		

		ArrayList<String> Validationlist = new ArrayList<String>();
		for (int j = 0; j <= setvalidation.length - 1; j++) {
			Validationlist.add(setvalidation[j]);
		}
		
		

		int Counts = driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p")).size();
		for (int i = 1; i <= Counts; i++) {
			String text = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div/p["+i+"]"))
					.getText();
			if (Validationlist.contains(text)) {
				System.out.println("Validation is correct :  " + text);

			} else {

				System.out.println("Validation is incorrect : " + text);
				Assert.fail("Test Fail");

			}
		}
	}
	public void validation() throws InterruptedException {
		
		List<WebElement> dynamicElement = driver.findElements(By.xpath("//*[@id=\"loginform\"]/div[1]/div/button"));
		if(dynamicElement.size() != 0){
		 //If list size is non-zero, element is present
		 System.out.println("Input Invalid Data");
		 this.serverValidation1();
		 
		}
		else{
		 //Else if size is 0, then element is not present
		 System.out.println("Input Correct Data");
			this.Save_validation();
		}
	}
	

	
	public void validation_page1() throws InterruptedException {
		this.nameval();
		Thread.sleep(3000);
		this.emailval();
		Thread.sleep(3000);
		this.countryval();
		Thread.sleep(3000);
		this.mindurval();
		Thread.sleep(3000);
		this.notifperiodval();
		Thread.sleep(3000);
		this.quarperiodval();
	}
	
	public void validation_page2() throws InterruptedException {
		this.nameval();
		this.emailval();
		this.countryval();
		this.rollingcontractval();
		this.cancelperiodval();
	}
	/*******************************************************************
	 * MAIN METHOD
	 ***********************************************/
	public void Service_Edit_ContractstdValidation(String searchService,String emails,String country,String mindura,String notiprd,String quarantdays ) throws InterruptedException, AWTException {
		// Step 1
	this.Clickonsearch(searchService);
	this.Clickonsearchbtn();
	this.Clickonsearchitem();
	Thread.sleep(3000);
	this.Clearfiledsgeneraltab();
	Thread.sleep(3000);
	this.Mail(emails);
	Thread.sleep(3000);
	this.country(country);
	Thread.sleep(3000);
	this.Save();	
	Thread.sleep(3000);
	this.nameval();
	Thread.sleep(3000);
	this.emailval();
	Thread.sleep(3000);
	this.countryval();
	Thread.sleep(3000);
	this.ScrollPage("0,-400");
	Thread.sleep(3000);
	this.Tab_clicl1();
	this.Clearfiledscontractruletab();
	this.save12();
	this.mindurval();
	Thread.sleep(3000);
	this.notifperiodval();
	Thread.sleep(3000);
	this.quarperiodval();
	Thread.sleep(3000);
	this.mindura(mindura);
	Thread.sleep(3000);
	this.notiprd(notiprd);
	Thread.sleep(3000);
	this.quarantdays(quarantdays);
	Thread.sleep(3000);
	this.save12();
	this.popup();
	Thread.sleep(3000);
	this.serverValidation1();
	Thread.sleep(3000);
	this.Tab_clicl3();
	Thread.sleep(3000);
	this.Cancel();
	}
	
	public void Service_Edit_ContractrollingValidation(String searchService,String emails,String country,String rollingcontract,String cancelper) throws InterruptedException, AWTException {
		// Step 1
	this.Clickonsearch(searchService);
	this.Clickonsearchbtn();
	this.Clickonsearchitem();
	Thread.sleep(3000);
	this.Clearfiledsgeneraltab();
	Thread.sleep(3000);
	this.Mail(emails);
	Thread.sleep(3000);
	this.country(country);
	Thread.sleep(3000);
	this.Save();	
	Thread.sleep(3000);
	this.nameval();
	Thread.sleep(3000);
	this.emailval();
	Thread.sleep(3000);
	this.countryval();
	Thread.sleep(3000);
	this.ScrollPage("0,-400");
	Thread.sleep(3000);
	this.Tab_clicl1();
	Thread.sleep(3000);
	this.Clearfiledscontractrulerollingtab();
	this.save13();
	Thread.sleep(3000);
	this.rollingcontractval();
	Thread.sleep(3000);
	this.cancelperiodval();
	Thread.sleep(3000);
	this.rollingcontract(rollingcontract);
	this.cancellationperiod(cancelper);
	Thread.sleep(3000);
	this.save13();
	this.popup();
	Thread.sleep(3000);
	this.serverValidation2();
	Thread.sleep(3000);
	this.Tab_clicl3();
	Thread.sleep(3000);
	this.Cancel();
	}
	public void Service_Edit_Contractstd(String searchService,String name,String des,String email,String country,String canbeAssigned,String mandatoryAssign,String allowinchildpack,String canbeexplicitlyassign,String multipleInstanceallowed,String canchangedStartdate,String canchangedTariffrate,String dependant,String supp,String busservgrp,String usrservgrp,String mindura,String notiprd,String quarantdays ,String combinenotiminperiod) throws InterruptedException, AWTException {
		// Step 1
	this.Clickonsearch(searchService);
	this.Clickonsearchbtn();
	this.Clickonsearchitem();
	Thread.sleep(3000);
	this.name(name);
	Thread.sleep(3000);
	this.Descriptions(des);
	Thread.sleep(3000);
	this.Mail(email);
	Thread.sleep(3000);
	this.country(country);
	Thread.sleep(3000);
	this.ScrollPage("0,400");
	Thread.sleep(3000);
	this.ClickonCanbeAssigned(canbeAssigned);
	Thread.sleep(3000);
	this.ClickonMandatoryservice(mandatoryAssign);
	Thread.sleep(3000);
	this.ClickonChildlevel(allowinchildpack);
	Thread.sleep(3000);
	this.ClickonExplicitly(canbeexplicitlyassign);
	Thread.sleep(3000);
	this.ClickonMultipleinstance(multipleInstanceallowed);
	Thread.sleep(3000);
	this.ClickonchngeStartDate(canchangedStartdate);
	Thread.sleep(3000);
	this.ClickonchngeTariff(canchangedTariffrate);
	Thread.sleep(3000);
	this.Dependantservice_Dropdwn(dependant);
	Thread.sleep(3000);
	this.SupplierPartNumber(supp);
	Thread.sleep(3000);
	this.bussitserviceGroup_Dropdwn(busservgrp);
	Thread.sleep(3000);
	this.userserviceGroup_Dropdwn(usrservgrp);
	Thread.sleep(3000);
	this.Save();	
	Thread.sleep(3000);
	this.saveVal();
	this.Clickonsearch(searchService);
	this.Clickonsearchbtn();
	this.Clickonsearchitem();
	Thread.sleep(3000);
	this.Tab_clicl1();
	Thread.sleep(2000);
	this.Clearfiledscontractruletab();
	this.mindura(mindura);
	Thread.sleep(3000);
	this.notiprd(notiprd);
	Thread.sleep(3000);
	this.quarantdays(quarantdays);
	Thread.sleep(3000);
	this.ClickonCombinenotiminperiodchkbx(combinenotiminperiod);
	this.save12();
	Thread.sleep(2000);
	this.popup();
	Thread.sleep(2000);
	this.saveVal();
	Thread.sleep(2000);
	this.ScrollPage("0,-700");
	Thread.sleep(2000);
	this.Tab_clicl2();
	Thread.sleep(4000);
	settings.click();
	Thread.sleep(4000);
	includeremovedcheck.click();
	Thread.sleep(2000);
	this.view_data();
	Thread.sleep(4000);
	this.ScrollPage("0,-700");
	this.Tab_clicl3();
	Thread.sleep(5000);
	this.Cancel();
	}
	
	public void Service_Edit_Contractrolling(String searchService,String name,String des,String email,String country,String canbeAssigned,String mandatoryAssign,String allowinchildpack,String canbeexplicitlyassign,String multipleInstanceallowed,String canchangedStartdate,String canchangedTariffrate,String dependant,String supp,String busservgrp,String usrservgrp,String rollingcontract,String cancelper ) throws InterruptedException, AWTException {
		// Step 1
	this.Clickonsearch(searchService);
	this.Clickonsearchbtn();
	this.Clickonsearchitem();
	Thread.sleep(3000);
	this.name(name);
	Thread.sleep(3000);
	this.Descriptions(des);
	Thread.sleep(3000);
	this.Mail(email);
	Thread.sleep(3000);
	this.country(country);
	Thread.sleep(3000);
	this.ScrollPage("0,400");
	Thread.sleep(3000);
	this.ClickonCanbeAssigned(canbeAssigned);
	Thread.sleep(3000);
	this.ClickonMandatoryservice(mandatoryAssign);
	Thread.sleep(3000);
	this.ClickonChildlevel(allowinchildpack);
	Thread.sleep(3000);
	this.ClickonExplicitly(canbeexplicitlyassign);
	Thread.sleep(3000);
	this.ClickonMultipleinstance(multipleInstanceallowed);
	Thread.sleep(3000);
	this.ClickonchngeStartDate(canchangedStartdate);
	Thread.sleep(3000);
	this.ClickonchngeTariff(canchangedTariffrate);
	Thread.sleep(3000);
	this.Dependantservice_Dropdwn(dependant);
	Thread.sleep(3000);
	this.SupplierPartNumber(supp);
	Thread.sleep(3000);
	this.bussitserviceGroup_Dropdwn(busservgrp);
	Thread.sleep(3000);
	this.userserviceGroup_Dropdwn(usrservgrp);
	Thread.sleep(3000);
	this.Save();	
	Thread.sleep(3000);
	this.saveVal();
	this.Clickonsearch(searchService);
	this.Clickonsearchbtn();
	this.Clickonsearchitem();
	Thread.sleep(3000);
	this.Tab_clicl1();
	Thread.sleep(2000);
	this.Clearfiledscontractrulerollingtab();
	this.rollingcontract(rollingcontract);
	Thread.sleep(3000);
	this.cancellationperiod(cancelper);
	Thread.sleep(3000);
	this.Cancelendradiobtn();
	this.save13();
	Thread.sleep(2000);
	this.popup();
	Thread.sleep(2000);
	this.saveVal();
	Thread.sleep(2000);
	this.ScrollPage("0,-700");
	Thread.sleep(2000);
	this.Tab_clicl2();
	Thread.sleep(4000);
	settings.click();
	Thread.sleep(4000);
	includeremovedcheck.click();
	Thread.sleep(2000);
	this.view_data();
	Thread.sleep(4000);
	this.ScrollPage("0,-700");
	this.Tab_clicl3();
	Thread.sleep(5000);
	this.Cancel();
	}
	
	public void Service_Delete(String searchService) throws InterruptedException, AWTException {
		this.Clickonsearch(searchService);
		this.Clickonsearchbtn();
		this.Clickonsearchitem();
		Thread.sleep(1000);
		this.Delete();
		Thread.sleep(1000);
		this.Delete_validation();
		Thread.sleep(3000);
		this.includeremovedcheck(searchService);
		

	}
	
	public void Servicecontractrolling_Delete(String searchService) throws InterruptedException, AWTException {
		Thread.sleep(3000);
		includeremovedcheck.click();
		Thread.sleep(3000);
		settings.click();
		this.Clickonsearch(searchService);
		this.Clickonsearchbtn();
		this.Clickonsearchitem();
		Thread.sleep(1000);
		this.Delete();
		Thread.sleep(1000);
		this.Delete_validation();
		Thread.sleep(3000);
		this.includeremovedcheck(searchService);
		

	}
	
	
	
	/***********************************************
	 * Common Code
	 ***************************************************/
			
			public void Validation(String GetValiadtion, String Setvalidation) {

				if (GetValiadtion.equals(Setvalidation)) {
					System.out.println("Validation is correct as  " + GetValiadtion);
				} else {
					System.err.println("Validation is incorrect: " + GetValiadtion);
					Assert.fail("Test fail for chceking validation : (Expected Result : "+Setvalidation+" Actual Result : "+GetValiadtion);
				}

			}

			
			public void ScrollPage(String ScrollBy) throws AWTException {

				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("window.scrollBy(" + ScrollBy + ")");

			}
			
			public void includeremovedcheck(String deletedValue) throws InterruptedException {
				settings.click();
				Thread.sleep(3000);
				includeremovedcheck.click();
				Thread.sleep(4000);
				
				int Counts = driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")).size();
				Thread.sleep(2000);
				for (int i = 1; i <= Counts; i++) {
					String inputvalue=driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr["+i+"]/td[1]/a/u")).getText();
					if(inputvalue.equals(deletedValue)) {
						String color = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr["+i+"]/td[1]/a/u")).getCssValue("color");


						String[] hexValue = color.replace("rgba(", "").replace(")", "").split(",");

						int hexValue1 = Integer.parseInt(hexValue[0]);
						hexValue[1] = hexValue[1].trim();
						int hexValue2 = Integer.parseInt(hexValue[1]);
						hexValue[2] = hexValue[2].trim();
						int hexValue3 = Integer.parseInt(hexValue[2]);

						String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);

						Assert.assertEquals("#fc4b6c", actualColor);
						System.out.println(deletedValue+" is deleted and also listed in include removed");

					}
				}
			}
			public void view_data() throws InterruptedException, AWTException
			{
				Thread.sleep(4000);
				
				// Get all the table row elements from the table
				List<WebElement> allRows= driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/div/div/div/div/div[3]/div/div/div[2]/table/tbody/tr")); 
				System.out.println("Service usage list page :");
				for(WebElement row : allRows)
				{
					List<WebElement> allColumnsInRow=row.findElements(By.tagName("td"));
				for(WebElement cell : allColumnsInRow)
				{
					System.out.print(cell.getText()+ "|");
				}
				System.out.println();
				}
			}


}
