/*-- =============================================
-- Author		: Dennu Thomas
-- Created Date : 20-Apr-20
-- Description	: MyBranding
-- Modified by	: Dennu Thomas
-- Modified Date: 24-Apr-20 
-- Project		: UBOSS-5-0-5
-- =============================================*/

package MyBranding;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;


public class MyBranding {
	WebDriver driver;

	@FindBy(xpath = "//input[contains(@name,'CompanyLogo')]")
	WebElement Companylogo;
	
	@FindBy(xpath = "//input[contains(@name,'CompanyBanner')]")
	WebElement Companybanner;
	
	@FindBy(xpath = "//input[contains(@name,'duration')]")
	WebElement HeaderVisiblityduration;
	
	@FindBy(xpath = "//input[contains(@name,'url')]")
	WebElement Externalurl;
	
	@FindBy(id = "save_brand_btn")
	WebElement Save;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/ul/li[2]/a/span[2]")
	WebElement DeviceBranding;
	
	@FindBy(xpath = "//input[contains(@name,'searchtxt')]")
	WebElement search;
	
	@FindBy(xpath = "//button[@onclick='searchDevice();']")
	WebElement searchbutton;
	
	@FindBy(xpath = "//input[contains(@type,'file')]")
	WebElement Devicelogobrowse;
	
	@FindBy(xpath = "//input[@type='button'][contains(@id,'btn')]")
	WebElement DevSave;
	
	@FindBy(xpath = "//input[contains(@value,'DELETE')]")
	WebElement Devlogodelete;
	
	@FindBy(xpath = "/html/body/div[3]/div/div/div[3]/button[1]")
	WebElement popupdelete;
	
	public MyBranding(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	public void UploadCompanylogo(String FilePath) throws InterruptedException, AWTException {
		Thread.sleep(1000);
		Companylogo.click();
		Thread.sleep(1000);
		this.UploadFile(FilePath);
		
	}
	public void UploadCompanybanner(String FilePath) throws InterruptedException, AWTException {
		Thread.sleep(1000);
		Companybanner.click();
		Thread.sleep(1000);
		this.UploadFile(FilePath);
		
	}
	public void HeaderVisiblityDuration(String dur) throws InterruptedException {
		Thread.sleep(2000);
		HeaderVisiblityduration.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(2000);
		HeaderVisiblityduration.sendKeys(dur);
	}
	public void ExternalURL(String exurl) throws InterruptedException {
		Thread.sleep(2000);
		Externalurl.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(2000);
		Externalurl.sendKeys(exurl);
	}
	public void ClickonSave() throws InterruptedException {
		Thread.sleep(3000);
		Save.click();
	}
	
	public void ClickonDevBranding() throws InterruptedException {
		Thread.sleep(3000);
		DeviceBranding.click();
	}
	public void Clickonsearch(String searchs) throws InterruptedException {
		search.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(3000);
		search.sendKeys(searchs);
	}

	public void Clickonsearchbtn() throws InterruptedException {
		Thread.sleep(1000);
		searchbutton.click();
	}

	public void UploadDevicelogo(String FilePath) throws InterruptedException, AWTException{
		Thread.sleep(2000);
		Devicelogobrowse.click();
		Thread.sleep(3000);
		this.UploadFile(FilePath);
	}
	
	public void ClickonSave1() throws InterruptedException {
		Thread.sleep(3000);
		DevSave.click();
	}
	
	public void ClickonDelete() throws InterruptedException {
		Thread.sleep(3000);
		Devlogodelete.click();
	}
	
	public void DeleteYesBtn() throws InterruptedException {
		Thread.sleep(1000);
		popupdelete.click();
	}
	/*******************************************************************
	 * Validation[page 1]
	 ***********************************************/
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SavedSuccess;
	@FindBy(xpath = "//p[contains(.,'Device Logo Deleted.')]")
	WebElement DeletedSuccess;
	
	String SavedSuccessfullyVal = "Saved successfully";
	String DeletedSuccessfullyVal= "Device Logo Deleted.";
	String[] serverValidation = { "Company Logo should be 205 x 90 px","Company Banner should be 500 x 90 px"};
	public void SavedSuccessfully_Validation() throws InterruptedException {
		Thread.sleep(1000);
		String setvalidation = SavedSuccessfullyVal;
		String getValiadtion = SavedSuccess.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	public void DeletedSuccessfully_Validation() throws InterruptedException {
		Thread.sleep(1000);
		String setvalidation = DeletedSuccessfullyVal;
		String getValiadtion = DeletedSuccess.getText();
		this.Validation(setvalidation, getValiadtion);
	}
	public void serverValidation() throws InterruptedException {
		
		Thread.sleep(1000);
		String[] setvalidation = serverValidation;

		ArrayList<String> Validationlist = new ArrayList<String>();
		for (int j = 0; j <= setvalidation.length - 1; j++) {
			Validationlist.add(setvalidation[j]);
		}

		int Counts = driver.findElements(By.xpath("/html/body/section/div[2]/div/div/form/div[1]/div/p")).size();
		for (int i = 1; i <= Counts; i++) {
			String text = driver.findElement(By.xpath("/html/body/section/div[2]/div/div/form/div[1]/div/p["+i+"]"))
					.getText();
			if (Validationlist.contains(text)) {
				System.out.println("Validation is correct :  " + text);

			} else {

				System.err.println("Validation is incorrect : " + text);
				Assert.fail("Test Fail for checking validation:(Aspect:"+setvalidation+"Result:"+text);

			}
		}
	}

public void validation() throws InterruptedException {
		
		List<WebElement> dynamicElement = driver.findElements(By.xpath("//*[@id=\"loginform\"]/div[1]/div/button"));
		if(dynamicElement.size() != 0){
		 //If list size is non-zero, element is present
		 System.out.println("Inputed Data is Invalid");
		 this.serverValidation();
		}
		else{
		 //Else if size is 0, then element is not present
		 System.out.println("Inputed Data is correct");
			this.SavedSuccessfully_Validation();
		}
	}


/*******************************************************************
 * MAIN METHOD
 ***********************************************/
	public void MyBranding_Page( String FilePath1,String FilePath2, String dur,String exurl)
			throws InterruptedException, AWTException {
		Thread.sleep(3000);
		// Step 1
		this.UploadCompanylogo(FilePath1);
		this.UploadCompanybanner(FilePath2);
		this.HeaderVisiblityDuration(dur);
		Thread.sleep(2000);
		this.ExternalURL(exurl);
		Thread.sleep(2000);
		this.ClickonSave();
		Thread.sleep(55000);
		this.validation();
		Thread.sleep(15000);
	}
	
	public void DeviceBranding_Page(String searchs, String FilePath3)throws InterruptedException, AWTException {
		this.ClickonDevBranding();
		Thread.sleep(2000);
		this.Clickonsearch(searchs);
		Thread.sleep(2000);
		this.Clickonsearchbtn();
		Thread.sleep(5000);
		this.UploadDevicelogo(FilePath3);
		Thread.sleep(10000);
		this.ClickonSave1();
		Thread.sleep(40000);
		this.validation();
		
	}
	public void DeviceBrandingDellogo_Page(String searchs)throws InterruptedException, AWTException {
		this.ClickonDevBranding();
		Thread.sleep(2000);
		this.Clickonsearch(searchs);
		Thread.sleep(2000);
		this.Clickonsearchbtn();
		Thread.sleep(8000);
		this.ClickonDelete();
		Thread.sleep(5000);
		this.DeleteYesBtn();
		Thread.sleep(5000);
		this.DeletedSuccessfully_Validation();
	}
	/***********************************************************
	 * CommonMethod
	 
	 ***************************************************************/

	public void Validation(String GetValiadtion, String Setvalidation) throws InterruptedException {

		if (GetValiadtion.equals(Setvalidation)) {
			System.out.println("Validation is correct as " + GetValiadtion);
		}
		
		else {
			System.err.println("Validation is incorrect : "+GetValiadtion);
			Assert.fail("Test Fail for checking validation:(Aspect:"+Setvalidation+"Result:"+GetValiadtion);
			this.validation();
		}
	}
	public void ScrollPage(String ScrollBy) throws AWTException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + ScrollBy + ")");

	}
	public void UploadFile(String FilePath) throws InterruptedException, AWTException{	
		String filePath = System.getProperty("user.dir") + "\\src\\main\\java\\com\\drd\\uboss5\\attachments\\"
				+ FilePath;
		driver.switchTo() .activeElement().sendKeys(filePath);
		Thread.sleep(1000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);	
		robot.keyRelease(KeyEvent.VK_CONTROL);	
	
	}


}
