package LiveHardwareOrders;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : May 21, 2020,11:58:26 AM
-- Description	: LiveHardwareOrders.java
-- Modified by	: 
-- Modified Date: 
-- Project		: UBOSS-5-0-0-Dennu
-- =============================================*/
public class LiveHardwareOrders {
	WebDriver driver;
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div/div[1]/div/div/input")
	WebElement  From_Date;

	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div/div[2]/div/div/input")
	WebElement To_Date;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/form/div[1]/div/div[3]/button")
	WebElement View;
	
	@FindBy(id = "search_data")
	WebElement Searchtext;
	
	@FindBy(id = "search_btn")
	WebElement Searchbtn;
	
	@FindBy(xpath = "/html/body[@class='fix-header fix-sidebar card-no-border']/div[@id='main-wrapper']/div[@id='ajaxcontent']/div[@class='page-wrapper']/div[@class='container-fluid']/div[@class='card']/div[@class='card-body']/form[@id='form-deviceorder']/div[@class='row'][1]/div[@class='col-8']/div[@class='form-inline float-right']/div[@class='input-group mr-1 searchbox']/span[@id='clear_btn']/i[@class='fa fa-times hidemsg']")
	WebElement Clear;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/form/div[2]/div[2]/div/button[1]")
	WebElement Settings;
	
	@FindBy(xpath = "/html/body/div[2]/div/div/div/div[3]/div/form/div[3]/div/div/div/label/span")
	WebElement FulfilmentChkbox;
	
	@FindBy(xpath = "/html/body[@class='fix-header fix-sidebar card-no-border']/div[@id='main-wrapper']/div[@id='ajaxcontent']/div[@class='page-wrapper']/div[@class='container-fluid']/div[@class='card']/div[@class='card-body']/form[@id='form-deviceorder']/div[@class='row'][1]/div[@class='col-8']/div[@class='form-inline float-right']/button[@id='btn_download']")
	WebElement Download;
	
	@FindBy(xpath = "/html/body[@class='fix-header fix-sidebar card-no-border']/div[@id='main-wrapper']/div[@id='ajaxcontent']/div[@class='page-wrapper']/div[@class='container-fluid']/div[@class='card']/div[@class='card-body']/form[@id='form-deviceorder']/div[@class='row'][1]/div[@class='col-8']/div[@class='form-inline float-right show']/ul[@class='dropdown-menu multi-level dropdown-menu-right show']/li[1]/a[@class='dropdown-item export']")
	
	WebElement Excel;
	
	@FindBy(xpath = "/html/body[@class='fix-header fix-sidebar card-no-border']/div[@id='main-wrapper']/div[@id='ajaxcontent']/div[@class='page-wrapper']/div[@class='container-fluid']/div[@class='card']/div[@class='card-body']/form[@id='form-deviceorder']/div[@class='row'][1]/div[@class='col-8']/div[@class='form-inline float-right show']/ul[@class='dropdown-menu multi-level dropdown-menu-right show']/li[2]/a[@class='dropdown-item export']")
	WebElement CSV;

	
	public LiveHardwareOrders(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void GoToUrl(String Url) {
		driver.get(Url);
	}

	public void SetDateFrom(String DateFrom) throws InterruptedException {
		Thread.sleep(3000);
		String a = "document.getElementById('txtFromDate').";
		String b = "value='" + DateFrom + "'";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript(a + b);
	}

	public void SetDateTo(String DateTo) throws InterruptedException {
		Thread.sleep(3000);
		String a = "document.getElementById('txtToDate').";
		String b = "value='" +DateTo + "'";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript(a + b);
	}

	
	public void clickonviewbutton() throws InterruptedException {
		
		Thread.sleep(1000);
		View.click();
	}
	
	public void Clickonsearchtext(String searchs) throws InterruptedException {
		
		
		Thread.sleep(3000);
		Searchtext.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		Thread.sleep(3000);
		Searchtext.sendKeys(searchs);
	}
	

	public void Clickonsearchbtn() throws InterruptedException {
		Thread.sleep(6000);
		Searchbtn.click();
	}
		
	public void Clickonclear() throws InterruptedException {
		Thread.sleep(6000);
		Clear.click();
	}
	
   public void clickonsettingsbutton() throws InterruptedException {
		
		Thread.sleep(1000);
		Settings.click();
	}
   
   public void Fulfilmentcheckbox() throws InterruptedException {
	   Thread.sleep(3000);
		FulfilmentChkbox.click();
	}
   public void Settings_button_details(String SettingsButton_Visibility) throws InterruptedException
	{
		
		if (SettingsButton_Visibility.equals("Yes"))
		{
			Thread.sleep(5000);
			Settings.click();
			Thread.sleep(5000);
			FulfilmentChkbox.click();
			
		}
		else
		{
			System.out.println("Settings button is not visible");
		}
	}
   public void Export(String[] FileTpye) throws InterruptedException {
		System.out.println("Export Checking :");
			for (int i = 1; i <= FileTpye.length; i++) {
				String Records = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr/td")).getText();
				if(Records.equals("No data available in table")) {
					Thread.sleep(2000);
					Download.click();
					String text1 = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[2]/div[2]/div/ul/li[" + i + "]/a")).getText();					
					if (FileTpye[i-1].equals(text1)) {
					driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[2]/div[2]/div/ul/li[" + i + "]/a")).click();
					String Validation = driver.findElement(By.xpath("//*[@id=\"messenger\"]/div/div/p")).getText();
					if(Validation.equals("No records to export")) {
						System.out.println("Validation is correct : " +Validation);
						Thread.sleep(4000);
						assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
					}
					else {
						System.out.println("Validation is wrong");
						Thread.sleep(4000);
						assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
					}
				}
				}
				else if(!"No data available in table".equals(Records)) {
					Thread.sleep(2000);
					Download.click();
					String text = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[2]/div[2]/div/ul/li[" + i + "]/a")).getText();					
					if (FileTpye[i-1].equals(text)) {
						driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[2]/div[2]/div/ul/li[" + i + "]/a")).click();
						System.out.println("File type found");
						Thread.sleep(4000);
						assertEquals(true,driver.findElement(By.xpath("//*[@id=\"breadcrumb\"]/li[1]/a")).isDisplayed());
					}

					else {

						System.out.println("Export file type is not found: (Aspect : "+FileTpye[i-1]+" Result : "+text);
					}
					
				}
				else {
					System.err.println("Exporting has some issues");
				}

			}
		}

  
	public void showingrecords() throws InterruptedException
	{
		Thread.sleep(4000);
		
		int total = driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")).size();
		System.out.println("Total Number of records = " + total);

		for (int i = 1; i <= total; i++) 
		{

			String mpath = "//*[@id='datagrid']/tbody/tr[" + i + "]/td[1]";
			String fullXpath = String.format(mpath);

			String RPtext = driver.findElement(By.xpath(fullXpath)).getText();
			System.out.println("data  " + i + " is - " + RPtext);
		}
	}
		
	
	public void view_data() throws InterruptedException, AWTException
	{
		Thread.sleep(2000);
		this.ScrollPage("0,200");
		// Get all the table row elements from the table
		List<WebElement> allRows= driver.findElements(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/form/div[4]/div/div/div[2]/div/table/tbody/tr")); 
		System.out.println("Live Hardware Report View list :");
		for(WebElement row : allRows)
		{
			List<WebElement> allColumnsInRow=row.findElements(By.tagName("td"));
		for(WebElement cell : allColumnsInRow)
		{
			System.out.print(cell.getText()+ "|");
		}
		System.out.println();
		}
	}
		/*********************************************
		 * Main Method
		 * @throws AWTException 
		 ***************************************/
		public void livehardwareorders_View(String DateFrom,String DateTo,String SettingsButton_Visibility,String searchs,String[] filetype) throws InterruptedException, AWTException
		{
			Thread.sleep(2000);
			this.SetDateFrom(DateFrom);
			Thread.sleep(2000);
			this.SetDateTo(DateTo);
			Thread.sleep(2000);
			this.Settings_button_details(SettingsButton_Visibility);
			Thread.sleep(5000);
			this.clickonviewbutton();
			System.out.println("Live Hardware Order Report viewed Successfully");
			this.Clickonsearchtext(searchs);
			Thread.sleep(4000);
			this.Clickonsearchbtn();
			Thread.sleep(4000);
			this.Clickonclear();			
			Thread.sleep(4000);
			this.Export(filetype);
			Thread.sleep(4000);
			this.view_data();
			Thread.sleep(8000);	

		}
		
		
	/*********************************************
	 * Common Method
	 ***************************************/

	public void ScrollPage(String ScrollBy) throws AWTException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + ScrollBy + ")");

	}

}
