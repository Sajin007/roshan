package Mobilecallclass;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.drd.uboss5.keywords.keywords;

/*-- =============================================
-- Author		:Roshan Raju
-- Created Date : 15- April-2020
-- Description	:Mobilecallclas add page 
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/
public class Mobilecallclass_ADD extends keywords {

	WebDriver driver;
	@FindBy(id = "btn_add")
	WebElement Addbutton;
	@FindBy(id = "txtName")
	WebElement Name;
	@FindBy(id = "txtDescription")
	WebElement Description;
	@FindBy(id = "txtCallClass")
	WebElement Callclass;
	@FindBy(id = "ddlCarrier")
	WebElement CarrierName;
	@FindBy(id = "ddlEventType")
	WebElement Eventtype;
	@FindBy(id = "ddlDirection")
	WebElement Direction;
	@FindBy(xpath = "//*[@id=\"ddlChargeCode\"]")
	WebElement Chargecode;
	@FindBy(xpath = "//*[@id=\"txtChargeCode\"]")
	WebElement filter;

	@FindBy(id = "add")
	WebElement Save;
	@FindBy(id = "btn_cancel")
	WebElement Cancel;
	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDeletemessenger;

	public Mobilecallclass_ADD(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}

	public void clickonAdd() throws InterruptedException {

		Thread.sleep(3000);
		Addbutton.click();
	}

	public void Name(String name) throws InterruptedException {

		Thread.sleep(2000);
		Inputdata(Name, name, "Name");
	}

	public void Description(String description) throws InterruptedException {
		
		
//		if (description.equals("")) {
//			
//			Thread.sleep(2000);
//
//			System.out.println("Description is empty");
//		}
//		
//		
//		else {
			
			Thread.sleep(2000);
			Inputdata(Description, description, "Description");
	}
	

	public void Callclass(String callclass) throws InterruptedException {

		Thread.sleep(3000);
		Inputdata(Callclass, callclass, "Call Class");
	}

	public void Carriername(String carriername) throws InterruptedException {

		dropdown(CarrierName, carriername, "Carrier Name");

	}

	public void Eventtype(String eventtype) throws InterruptedException {
		
		dropdown(Eventtype, eventtype, "Event Type");

//		Select select = new Select(Eventtype);
//		select.selectByVisibleText(eventtype);
	}

	public void Direction(String direction) throws AWTException, InterruptedException {

		dropdown(Direction, direction, "Direction");
//		 Select select = new Select(Direction);
//		 select.selectByVisibleText(direction);
		ScrollPage(driver, "0,+600");
		}


	public void Chargecode(String chargecode, String chargecode2) throws InterruptedException {

		if (chargecode.equals("")) {

			System.out.println("Drop Down is not selected");
			Thread.sleep(5000);
			Inputdata(filter, chargecode2, "Filter Charge Code");
			//filter.sendKeys(chargecode2);

		} else {
			
			dropdown(Chargecode, chargecode, "Charge Code");
//			Select select = new Select(Chargecode);
//			select.selectByVisibleText(chargecode);

		}

	}

	public void clickonsave() throws InterruptedException {
		Thread.sleep(3000);
		Save.click();
	}

	public void clickoncancel() throws InterruptedException {

		Thread.sleep(3000);
		Cancel.click();

	}

	/***********************************
	 * Validation elements
	 *****************************************/

	@FindBy(id = "txtName-error")
	WebElement Namevalidation;
	@FindBy(id = "txtCallClass-error")
	WebElement Callclassvalidation;
	@FindBy(id = "ddlEventType-error")
	WebElement Eventtypevalidation;
	@FindBy(id = "ddlDirection-error")
	WebElement Directionvalidation;
	@FindBy(id = "ddlChargeCode-error")
	WebElement Chargecodevalidation;

	String[] Nameval = { "Name cannot be empty" };
	String[] Callclassval = { "Call Class cannot be empty" };
	String[] EventtypeVal = { "Select Event Type" };
	String[] Directionval = { "Select Direction" };
	String[] Chargecodeval = { "ChargeCode cannot be empty" };
	String[] SaveVal = { "Saved successfully" };

	public void NameVal() throws InterruptedException {
		Thread.sleep(3000);
		String[] setvalidation = Nameval;
		String getValiadtion = Namevalidation.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void CallclassVal() throws InterruptedException {
		Thread.sleep(3000);
		String[] setvalidation = Callclassval;
		String getValiadtion = Callclassvalidation.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void EventtypeVal() throws InterruptedException {
		Thread.sleep(3000);
		String[] setvalidation = EventtypeVal;
		String getValiadtion = Eventtypevalidation.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void DirectionVal() throws InterruptedException {
		Thread.sleep(3000);
		String[] setvalidation = Directionval;
		String getValiadtion = Directionvalidation.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void Chargecodeval() throws InterruptedException {
		Thread.sleep(3000);
		String[] setvalidation = Chargecodeval;
		String getValiadtion = Chargecodevalidation.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void SaveVal() throws InterruptedException {
		Thread.sleep(3000);
		String[] setvalidation = SaveVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void Save_validation() throws InterruptedException {
		this.SaveVal();
	}

	public void validation() throws InterruptedException {
		this.NameVal();
		this.CallclassVal();
		this.EventtypeVal();
		this.DirectionVal();
		this.Chargecodeval();

	}

	public void Mobilecallclass_validation() throws InterruptedException, AWTException {
		this.clickonAdd();
		ScrollPage(driver, "0,+600");
		this.clickonsave();
		this.validation();
		this.clickoncancel();
	}

	public void Mobilecallclass_add(String name, String Description, String Call_Class, String Carrier_Name,
			String Event_Type, String Direction, String Charge_Code, String Charge_Code2)
			throws InterruptedException, AWTException {

		this.clickonAdd();
		this.Name(name);
		this.Description(Description);
		this.Callclass(Call_Class);
		this.Carriername(Carrier_Name);
		this.Eventtype(Event_Type);
		this.Direction(Direction);
		this.Chargecode(Charge_Code,Charge_Code2);
		this.clickonsave();
	}


	

	
}
