package Mobilecallclass;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.drd.uboss5.keywords.keywords;

/*-- =============================================
-- Author		:Roshan Raju
-- Created Date : 17- April-2020
-- Description	:Mobilecallclass edit page 
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class Mobilecallclass_Edit extends keywords {
	
	
	
	WebDriver driver;
	@FindBy(id = "btn_add")
	WebElement Addbutton;
	@FindBy(id = "txtName")
	WebElement Name;
	@FindBy(id = "txtDescription")
	WebElement Description;
	@FindBy(id = "txtCallClass")
	WebElement Callclass;
	@FindBy(id = "ddlCarrier")
	WebElement CarrierName;
	@FindBy(id = "ddlEventType")
	WebElement Eventtype;
	@FindBy(id = "ddlDirection")
	WebElement Direction;
	@FindBy(id = "ddlChargeCode")
	WebElement Chargecode;
	@FindBy(xpath = "//button[contains(@id,'update')]")
	WebElement Save;
	@FindBy(id = "delete")
	WebElement Delete;
	@FindBy(xpath = "//BUTTON[@data-bb-handler='confirm']")
	WebElement popup;

	@FindBy(xpath = "//*[@id=\"messenger\"]/div/div/p")
	WebElement SaveandDeletemessenger;
	
	
	@FindBy(id = "search_data")
	WebElement Search;

	@FindBy(xpath = "//*[@id=\"datagrid\"]/tbody/tr/td[1]/a/u")
	WebElement searchlink;

	@FindBy(id = "search_btn")
	WebElement Search_Button;
	
	@FindBy(id = "btn_cancel")
	WebElement Cancel;
	
	@FindBy(xpath = "//*[@id=\"settings\"]/div/div/label/span")
	WebElement includeremovedcheck;
		
	@FindBy(xpath = "//*[@id=\"btn_settings\"]/i")
	WebElement settings;
	
	
	
	
	
	public Mobilecallclass_Edit(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void GoToUrl(String Url) {
		driver.get(Url);

	}
	
	
	public void Searchbutton(String srch) throws InterruptedException, AWTException {
		Thread.sleep(3000);
		Search.sendKeys(srch);
		Thread.sleep(3000);
		Search_Button.click();
	}

	public void textlink() throws InterruptedException, AWTException {
		Thread.sleep(3000);
		searchlink.click();

	}

	public void Name_Edit(String name) throws InterruptedException {

		Thread.sleep(2000);
		Name.clear();
		Thread.sleep(2000);
		Name.sendKeys(name);
	}
	
	public void Description_Edit(String description) throws InterruptedException {

		Thread.sleep(2000);
		Description.clear();
		
		if (description.equals("")) {
			
			Thread.sleep(2000);

			System.out.println("Description is empty");
		}
		
		
		else {
			
			Thread.sleep(2000);
			Description.sendKeys(description);
	}
	}
	
	
	public void Callclass_Edit(String callclass) throws InterruptedException {

		Thread.sleep(2000);
		Callclass.clear();
		Thread.sleep(2000);
		Callclass.sendKeys(callclass);
	}
	
	public void Eventtype_Edit(String eventtype) {

		Select select = new Select(Eventtype);
		select.selectByVisibleText(eventtype);
	}
	
	public void Direction_Edit(String direction) throws AWTException {


		Select select = new Select(Direction);
		select.selectByVisibleText(direction);
		this.ScrollPage("0,+600");
			
	}
			
	public void clickonsave() throws InterruptedException {

		Thread.sleep(2000);
		Save.click();

	}
	
	public void delete() throws InterruptedException, AWTException {

		Thread.sleep(4000);
		Delete.click();
		Thread.sleep(4000);
		popup.click();

	}
	
	public void includeremovedcheck(String deletedValue) throws InterruptedException {
		settings.click();
		Thread.sleep(1000);
		includeremovedcheck.click();
		Thread.sleep(4000);
		int Counts = driver.findElements(By.xpath("//*[@id=\"datagrid\"]/tbody/tr")).size();
		System.out.println(Counts);
		Thread.sleep(2000);
		for (int i = 1; i <=Counts; i++) {
			String inputvalue=driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr["+i+"]/td[1]")).getText();
			System.out.println(inputvalue);
			if(inputvalue.equals(deletedValue)) {
				
				String color = driver.findElement(By.xpath("//*[@id=\"datagrid\"]/tbody/tr["+i+"]/td[1]")).getCssValue("color");
				String[] hexValue = color.replace("rgba(", "").replace(")", "").split(",");

				int hexValue1 = Integer.parseInt(hexValue[0]);
				hexValue[1] = hexValue[1].trim();
				int hexValue2 = Integer.parseInt(hexValue[1]);
				hexValue[2] = hexValue[2].trim();
				int hexValue3 = Integer.parseInt(hexValue[2]);

				String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);
				System.out.println(actualColor);
				Assert.assertEquals("#fc4b6c", actualColor);
				System.out.println(deletedValue+" is deleted and also listed in include removed");

			}
		}
	}

	
	public void clickoncancel() throws InterruptedException {

		Thread.sleep(2000);
		Cancel.click();

	}
	
	
	
	
	/***********************************
	 * Validation elements
	 *****************************************/

	@FindBy(id="txtName-error")
	WebElement Namevalidation;
	@FindBy(id = "txtCallClass-error")
	WebElement Callclassvalidation;
	@FindBy(id = "ddlEventType-error")
	WebElement Eventtypevalidation;
	@FindBy(id = "ddlDirection-error")
	WebElement Directionvalidation;
	@FindBy(id = "ddlChargeCode-error")
	WebElement Chargecodevalidation;
	
	
	
	
	String[] Nameval = { "Name cannot be empty" };
	String[] Callclassval = { "Call Class cannot be empty" };
	String[] EventtypeVal ={ "Select Event Type" };
	String[] Directionval ={ "Select Direction" };
	String[] Chargecodeval = { "ChargeCode cannot be empty" };
	String[] SaveVal = { "Saved successfully" };
	String[] DeletVal = { "Deleted successfully" };
	
	
	public void name_Edit() throws InterruptedException {

		Thread.sleep(3000);
		Name.clear();
	}
	
	public void callclass_Edit() throws InterruptedException {

		Thread.sleep(3000);
		Callclass.clear();
	}
	
	public void eventtype_Edit(String eventtype) {

		Select select = new Select(Eventtype);
		select.selectByVisibleText(eventtype);
	}
	
	public void direction_Edit(String direction) {

		Select select = new Select(Direction);
		select.selectByVisibleText(direction);
	}
	
	public void NameVal() throws InterruptedException {
		Thread.sleep(3000);
		String[] setvalidation = Nameval;
		String getValiadtion = Namevalidation.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void CallclassVal() throws InterruptedException {
		Thread.sleep(3000);
		String[] setvalidation = Callclassval;
		String getValiadtion = Callclassvalidation.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void EventtypeVal() throws InterruptedException {
		Thread.sleep(3000);
		String[] setvalidation = EventtypeVal;
		String getValiadtion = Eventtypevalidation.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void DirectionVal() throws InterruptedException {
		Thread.sleep(3000);
		String[] setvalidation = Directionval;
		String getValiadtion = Directionvalidation.getText();
		Validation(getValiadtion, setvalidation);
	}
	
	public void SaveVal() throws InterruptedException {
		Thread.sleep(3000);
		String[] setvalidation = SaveVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		Validation(getValiadtion, setvalidation);
	}
	
	public void DeleteVal() throws InterruptedException {
		Thread.sleep(3000);
		String[] setvalidation = DeletVal;
		String getValiadtion = SaveandDeletemessenger.getText();
		Validation(getValiadtion, setvalidation);
	}

	public void Save_validation() throws InterruptedException {
		this.SaveVal();
	}
	
	public void Delete_validation() throws InterruptedException {
		this.DeleteVal();
	}
	
	public void validation_Edit() throws InterruptedException {
		
		this.NameVal();
		this.CallclassVal();
		this.EventtypeVal();
		this.DirectionVal();
	
	}
	/***********************************
	 * Main Method
	 *****************************************/	
	
	public void Mobilecallclass_Edit_Validation(String Search, String Event_Type, String Phone_Numbers) throws InterruptedException, AWTException {
		
		this.Searchbutton(Search);
		this.textlink();
		this.name_Edit();
		this.callclass_Edit();
		this.eventtype_Edit(Event_Type);
		this.direction_Edit(Phone_Numbers);
		this.ScrollPage("0,+600");
		this.clickonsave();
		this.clickonsave();
		this.validation_Edit();
		this.clickoncancel();
		
	}

	
	
	public void Mobilecallclass_edit(String srch, String name, String description, String callclass, String eventtype,String direction ) throws InterruptedException, AWTException {
		
		this.Searchbutton(srch);
		this.textlink();
		this.Name_Edit(name);
		this.Description_Edit(description);
		this.Callclass_Edit(callclass);
		this.Eventtype_Edit(eventtype);
		this.Direction_Edit(direction);
		this.clickonsave();
		this.Save_validation();
		
	}
	
	public void Mobilecallclass_delete(String srch) throws InterruptedException, AWTException {
		
		this.Searchbutton(srch);
		this.textlink();
		this.delete();
		this.Delete_validation();
		Thread.sleep(3000);
		this.includeremovedcheck(srch);
	}
	
	
	
	
	
	
	
	
	/****************************************
	 * Common Method
	 **************************************************/
	

//	public void Validation(String GetValiadtion, String Setvalidation) {
//		PageFactory.initElements(driver, this);
//		if (GetValiadtion.equals(Setvalidation)) {
//			System.out.println("Validation is correct as  " + GetValiadtion);
//		} else {
//			System.out.println("Validation is incorrect: " + GetValiadtion);
//			Assert.fail("Test Fail");
//		}
//		
//
//}
	
	public void ScrollPage(String ScrollBy) throws AWTException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + ScrollBy + ")");

	}
}
