package TariffExemptions;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;
import TariifExemptions.CDRTariffExemption_Edit;
import TariifExemptions.SDRTariffExemption_Edit;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Aug 4, 2020
-- Description	: Testcase_SDRTariffexemption_Reseller_Edit.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-WORKSPACE
-- =============================================*/
public class Testcase_SDRTariffexemption_Reseller_Edit extends TestBase {
	
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Tariff_Exemptions;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\TariffExemptions\\CommonData_TariffExemption.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\TariffExemptions\\Datalist_SDRTariffExemption_Reslr_Edit.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Tariff_Exemptions = Repository.getProperty("Tariff_Exemption_Reseller");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		init();
	}

	@Test(priority = 102, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}

	@Test(priority = 103, enabled = true)
	public void TC_TaiffExemptions_Url() throws InterruptedException, IOException {
		SDRTariffExemption_Edit STE = PageFactory.initElements(driver, SDRTariffExemption_Edit.class);
		this.CommonData();
		STE.GoToUrl(Tariff_Exemptions);
	
	}
	
	
	@Test(priority = 104, enabled = true)
	public void TC_SDRTariffExemption_Validation() throws InterruptedException, IOException, AWTException {
		SDRTariffExemption_Edit STE = PageFactory.initElements(driver, SDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		String link =  Repository.getProperty("link");
		
		STE.SDRTaiffexception_validation_Edit(link);
		
	}
		
	@Test(priority = 105, enabled = true)
	public void TC_SDRTariffExemption_Service_Edit() throws InterruptedException, IOException, AWTException {
		SDRTariffExemption_Edit STE = PageFactory.initElements(driver, SDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link =  Repository.getProperty("link");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");
		
		STE.SDRTariffexception_Edit(link,setupcharge,recurringcharge,setupnc,recurringnc,Quantityfrom,Quantityto,Recurringcharge);
		
	}
	
	
	@Test(priority = 106, enabled = true)
	public void TC_SDRTariffExemption_Service_Delete() throws InterruptedException, IOException, AWTException {
		SDRTariffExemption_Edit STE = PageFactory.initElements(driver, SDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link =  Repository.getProperty("link");
	
		STE.SDRTariffexception_delete(link);
		
	}
	
	
	
	@Test(priority = 107, enabled = true)
	public void TC_SDRTariffExemption_Devices_Accessories_Edit() throws InterruptedException, IOException, AWTException {
		SDRTariffExemption_Edit STE = PageFactory.initElements(driver, SDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link2 =  Repository.getProperty("link2");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");
		
		STE.SDRTariffexception_Edit(link2,setupcharge,recurringcharge,setupnc,recurringnc,Quantityfrom,Quantityto,Recurringcharge);
		
	}
	
	
	@Test(priority = 108, enabled = true)
	public void TC_SDRTariffExemption_Devices_Acccessories_Delete() throws InterruptedException, IOException, AWTException {
		SDRTariffExemption_Edit STE = PageFactory.initElements(driver, SDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link2 =  Repository.getProperty("link2");
	
		STE.SDRTariffexception_delete(link2);
		
	}
	
	
	@Test(priority = 109, enabled = true)
	public void TC_SDRTariffExemption_Package_Edit() throws InterruptedException, IOException, AWTException {
		SDRTariffExemption_Edit STE = PageFactory.initElements(driver, SDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link3 =  Repository.getProperty("link3");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");
		
		STE.SDRTariffexception_Edit(link3,setupcharge,recurringcharge,setupnc,recurringnc,Quantityfrom,Quantityto,Recurringcharge);
		
	}
	
	
	@Test(priority = 110, enabled = true)
	public void TC_SDRTariffExemption_Package_Delete() throws InterruptedException, IOException, AWTException {
		SDRTariffExemption_Edit STE = PageFactory.initElements(driver, SDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link3 =  Repository.getProperty("link3");
	
		STE.SDRTariffexception_delete(link3);
		
	}
	
	
	
	@Test(priority = 111, enabled = true)
	public void TC_SDRTariffExemption_Numbercategory_Edit() throws InterruptedException, IOException, AWTException {
		SDRTariffExemption_Edit STE = PageFactory.initElements(driver, SDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link4 =  Repository.getProperty("link4");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");
		
		STE.SDRTariffexception_Edit(link4,setupcharge,recurringcharge,setupnc,recurringnc,Quantityfrom,Quantityto,Recurringcharge);
		
	}
	
	
	@Test(priority = 112, enabled = true)
	public void TC_SDRTariffExemption_Numbercategory_Delete() throws InterruptedException, IOException, AWTException {
		SDRTariffExemption_Edit STE = PageFactory.initElements(driver, SDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link4 =  Repository.getProperty("link4");
	
		STE.SDRTariffexception_delete(link4);
		
	}
	
	
	@AfterClass
	public void quit() {
		this.after();
	}
	
	

	
	
	

}
