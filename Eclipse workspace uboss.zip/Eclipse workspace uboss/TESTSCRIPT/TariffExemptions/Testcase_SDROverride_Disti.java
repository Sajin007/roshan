package TariffExemptions;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

import TariifExemptions.SDR_Override;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Aug 8, 2020
-- Description	: Testcase_SDROverride_Disti.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-WORKSPACE
-- =============================================*/
public class Testcase_SDROverride_Disti extends TestBase {
	
	
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Tariff_Exemptions;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\TariffExemptions\\CommonData_TariffExemption.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\TariffExemptions\\Datalist_SDROverride_Disti.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Tariff_Exemptions = Repository.getProperty("Tariff_Exemption_Disti");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		init();
	}

	@Test(priority = 149, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}

	@Test(priority = 150, enabled = true)
	public void TC_TaiffExemptions_Url() throws InterruptedException, IOException {
		SDR_Override OTE = PageFactory.initElements(driver, SDR_Override.class);
		this.CommonData();
		OTE.GoToUrl(Tariff_Exemptions);
	
	}
	
	@Test(priority = 151, enabled = true)
	public void TC_SDR_Over_Ride() throws InterruptedException, IOException, AWTException {
		SDR_Override OTE = PageFactory.initElements(driver, SDR_Override.class);
		this.CommonData();
		this.DataList();
		String []filetype = {"CSV","PDF","EXCEL"};
		String search = Repository.getProperty("search");
		String text = Repository.getProperty("text");
		OTE.SDROverride_disti(filetype,search,text);
		
	}
	
	@AfterClass
	public void quit() {
		this.after();
	}
}
