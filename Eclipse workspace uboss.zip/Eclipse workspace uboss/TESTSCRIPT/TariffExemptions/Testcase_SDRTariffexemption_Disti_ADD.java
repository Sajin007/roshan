package TariffExemptions;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;
import TariifExemptions.CDRTariffExemptions;
import TariifExemptions.Exceptions;

import TariifExemptions.SDRTariffExemption;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Jul 21, 2020
-- Description	: Testcase_SDRTariffexemption_Disti_ADD.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-WORKSPACE
-- =============================================*/
public class Testcase_SDRTariffexemption_Disti_ADD extends TestBase {
	
	
	
	
	
	
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Tariff_Exemptions;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\TariffExemptions\\CommonData_TariffExemption.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\TariffExemptions\\Datalist_SDRTariffExemption_Disti.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Tariff_Exemptions = Repository.getProperty("Tariff_Exemption_Disti");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		init();
	}

	@Test(priority = 77, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}

	@Test(priority = 78, enabled = true)
	public void TC_TaiffExemptions_Url() throws InterruptedException, IOException {
		SDRTariffExemption STE = PageFactory.initElements(driver, SDRTariffExemption.class);
		this.CommonData();
		STE.GoToUrl(Tariff_Exemptions);
	
	}
	
	@Test(priority = 79, enabled = true)
	public void TC_SDRTaiffExemptions_Validation() throws InterruptedException, IOException, AWTException {
		SDRTariffExemption STE = PageFactory.initElements(driver, SDRTariffExemption.class);
		this.CommonData();
		STE.SDRtariffexemption_validation();
	
	}
	
	@Test(priority = 80, enabled = true)
	public void TC_SDRTaiffExemptions_Service() throws InterruptedException, IOException, AWTException {
		Exceptions STE = PageFactory.initElements(driver, Exceptions.class);
		this.CommonData();
		this.DataList();
		String Radiobutton = Repository.getProperty("Radiobutton");
		String LineType = Repository.getProperty("LineType");
		String ChargeCode = Repository.getProperty("ChargeCode");
		String NominalCode = Repository.getProperty("NominalCode");
		String Gateway = Repository.getProperty("Gateway");
		String Carrier = Repository.getProperty("Carrier");
		
		String ApplyDate = Repository.getProperty("ApplyDate");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
		
		String Busns = Repository.getProperty("Busns");
		String Radiobutton1 = Repository.getProperty("Radiobutton1");
		
		String Name = Repository.getProperty("Name");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String prorata = Repository.getProperty("prorata");
		String singlerate = Repository.getProperty("singlerate");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");
		String []filetype = {"EXCEL","CSV"};
		String importfile  = Repository.getProperty("importfile");
		
		
		STE.SDR_Exemption(Radiobutton, LineType, ChargeCode, NominalCode, Gateway, Carrier, ApplyDate, MinuteRatePeak, MinuteRateoffPeak, MinuteRateweekend,Busns,Radiobutton1,Name,setupcharge,recurringcharge,setupnc,recurringnc,prorata, singlerate,Quantityto,Quantityfrom,Recurringcharge,filetype,importfile);
	
	}
	
	
	@Test(priority = 81, enabled = true)
	public void TC_SDRTaiffExemptions_Device_Accessories() throws InterruptedException, IOException, AWTException {
		Exceptions STE = PageFactory.initElements(driver, Exceptions.class);
		this.CommonData();
		this.DataList();
		String Radiobutton = Repository.getProperty("Radiobutton");
		String LineType = Repository.getProperty("LineType");
		String ChargeCode = Repository.getProperty("ChargeCode");
		String NominalCode = Repository.getProperty("NominalCode");
		String Gateway = Repository.getProperty("Gateway");
		String Carrier = Repository.getProperty("Carrier");
		
		String ApplyDate = Repository.getProperty("ApplyDate");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
		
		String Busns = Repository.getProperty("Busns");
		String Radiobutton2 = Repository.getProperty("Radiobutton2");
		
		String Name2 = Repository.getProperty("Name2");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String prorata = Repository.getProperty("prorata");
		String singlerate = Repository.getProperty("singlerate");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");
		String []filetype = {"EXCEL","CSV"};
		String importfile  = Repository.getProperty("importfile");
		
		
		STE.SDR_Exemption(Radiobutton, LineType, ChargeCode, NominalCode, Gateway, Carrier, ApplyDate, MinuteRatePeak, MinuteRateoffPeak, MinuteRateweekend,Busns,Radiobutton2,Name2,setupcharge,recurringcharge,setupnc,recurringnc,prorata, singlerate,Quantityto,Quantityfrom,Recurringcharge,filetype,importfile);
	
	}
	
	
	@Test(priority = 82, enabled = true)
	public void TC_SDRTaiffExemptions_Package() throws InterruptedException, IOException, AWTException {
		Exceptions STE = PageFactory.initElements(driver, Exceptions.class);
		this.CommonData();
		this.DataList();
		String Radiobutton = Repository.getProperty("Radiobutton");
		String LineType = Repository.getProperty("LineType");
		String ChargeCode = Repository.getProperty("ChargeCode");
		String NominalCode = Repository.getProperty("NominalCode");
		String Gateway = Repository.getProperty("Gateway");
		String Carrier = Repository.getProperty("Carrier");
		
		String ApplyDate = Repository.getProperty("ApplyDate");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
		
		String Busns = Repository.getProperty("Busns");
		String Radiobutton3 = Repository.getProperty("Radiobutton3");
		
		String Name3 = Repository.getProperty("Name3");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String prorata = Repository.getProperty("prorata");
		String singlerate = Repository.getProperty("singlerate");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");
		String []filetype = {"EXCEL","CSV"};
		String importfile  = Repository.getProperty("importfile");
		
		
		STE.SDR_Exemption(Radiobutton, LineType, ChargeCode, NominalCode, Gateway, Carrier, ApplyDate, MinuteRatePeak, MinuteRateoffPeak, MinuteRateweekend,Busns,Radiobutton3,Name3,setupcharge,recurringcharge,setupnc,recurringnc,prorata, singlerate,Quantityto,Quantityfrom,Recurringcharge,filetype,importfile);
	
	}

	@Test(priority = 83, enabled = true)
	public void TC_SDRTaiffExemptions_Numbercategory() throws InterruptedException, IOException, AWTException {
		Exceptions STE = PageFactory.initElements(driver, Exceptions.class);
		this.CommonData();
		this.DataList();
		String Radiobutton = Repository.getProperty("Radiobutton");
		String LineType = Repository.getProperty("LineType");
		String ChargeCode = Repository.getProperty("ChargeCode");
		String NominalCode = Repository.getProperty("NominalCode");
		String Gateway = Repository.getProperty("Gateway");
		String Carrier = Repository.getProperty("Carrier");
		
		String ApplyDate = Repository.getProperty("ApplyDate");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
		
		String Busns = Repository.getProperty("Busns");
		String Radiobutton4 = Repository.getProperty("Radiobutton4");
		
		String Name4 = Repository.getProperty("Name4");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String prorata = Repository.getProperty("prorata");
		String singlerate = Repository.getProperty("singlerate");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");
		String []filetype = {"EXCEL","CSV"};
		String importfile  = Repository.getProperty("importfile");
		
		
		STE.SDR_Exemption(Radiobutton, LineType, ChargeCode, NominalCode, Gateway, Carrier, ApplyDate, MinuteRatePeak, MinuteRateoffPeak, MinuteRateweekend,Busns,Radiobutton4,Name4,setupcharge,recurringcharge,setupnc,recurringnc,prorata, singlerate,Quantityto,Quantityfrom,Recurringcharge,filetype,importfile);
	
	}
	
	@AfterClass
	public void quit() {
		this.after();
	}
}
