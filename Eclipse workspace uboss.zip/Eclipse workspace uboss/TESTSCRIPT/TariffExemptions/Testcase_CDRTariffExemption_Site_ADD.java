package TariffExemptions;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;
import TariifExemptions.CDRTariffExemptions;
import TariifExemptions.Exceptions;


/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Jun 12, 2020
-- Description	: Testcase_TariffExemption_Site_ADD.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-WORKSPACE
-- =============================================*/
public class Testcase_CDRTariffExemption_Site_ADD extends TestBase {
	
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Tariff_Exemptions;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\TariffExemptions\\CommonData_TariffExemption.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\TariffExemptions\\Datalist_CDRTariffRxemption_Site.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Tariff_Exemptions = Repository.getProperty("Tariff_Exemption_Site");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		init();
	}

	@Test(priority = 58, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}

	@Test(priority = 59, enabled = true)
	public void TC_TaiffExemptions_Url() throws InterruptedException, IOException {
		CDRTariffExemptions TE = PageFactory.initElements(driver, CDRTariffExemptions.class);
		this.CommonData();
		TE.GoToUrl(Tariff_Exemptions);
	
	}
	
	@Test(priority = 60, enabled = true)
	public void TC_CDRTariffExemption_Hosin_ADD() throws InterruptedException, IOException, AWTException {
		Exceptions TE = PageFactory.initElements(driver, Exceptions.class);
		this.CommonData();
		this.DataList();
		
		String Radiobutton = Repository.getProperty("Radiobutton");
		String LineType = Repository.getProperty("LineType");
		String ChargeCode = Repository.getProperty("ChargeCode");
		String NominalCode = Repository.getProperty("NominalCode");
		String Gateway = Repository.getProperty("Gateway");
		String Carrier = Repository.getProperty("Carrier");
		
		String ApplyDate = Repository.getProperty("ApplyDate");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
		String []filetype = {"EXCEL","CSV"};
		String importfile  = Repository.getProperty("importfile");
		String Busns = Repository.getProperty("Busns");
		String Radiobutton1 = Repository.getProperty("Radiobutton1");
		
		String Name = Repository.getProperty("Name");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String prorata = Repository.getProperty("prorata");
		String singlerate = Repository.getProperty("singlerate");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");
		
		
		TE.CDR_Exemption_Add(Radiobutton,LineType, ChargeCode, NominalCode, Gateway, Carrier, ApplyDate, MinuteRatePeak, MinuteRateoffPeak,MinuteRateweekend,filetype,importfile,Busns,Radiobutton1,Name,setupcharge,recurringcharge,setupnc,recurringnc,prorata, singlerate,Quantityto,Quantityfrom,Recurringcharge);
	
	}
	
	
	
	@Test(priority = 61, enabled = true)
	public void TC_CDRTariffExemption_Hosout_ADD() throws InterruptedException, IOException, AWTException {
		Exceptions TE = PageFactory.initElements(driver, Exceptions.class);
		this.CommonData();
		this.DataList();
		String Radiobutton = Repository.getProperty("Radiobutton");
		String LineType1 = Repository.getProperty("LineType1");
		String ChargeCode1 = Repository.getProperty("ChargeCode1");
		String NominalCode1 = Repository.getProperty("NominalCode1");
		String Gateway1 = Repository.getProperty("Gateway1");
		String Carrier1 = Repository.getProperty("Carrier1");
		
		String ApplyDate = Repository.getProperty("ApplyDate");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
		String []filetype = {"EXCEL","CSV"};
		String importfile  = Repository.getProperty("importfile");
		String Busns = Repository.getProperty("Busns");
		String Radiobutton1 = Repository.getProperty("Radiobutton1");
		
		String Name = Repository.getProperty("Name");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String prorata = Repository.getProperty("prorata");
		String singlerate = Repository.getProperty("singlerate");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");
		
		
		TE.CDR_Exemption_Add(Radiobutton,LineType1, ChargeCode1, NominalCode1, Gateway1, Carrier1, ApplyDate, MinuteRatePeak, MinuteRateoffPeak,MinuteRateweekend,filetype,importfile,Busns,Radiobutton1,Name,setupcharge,recurringcharge,setupnc,recurringnc,prorata, singlerate,Quantityto,Quantityfrom,Recurringcharge);
	
	}
	
	
	@Test(priority = 62, enabled = true)
	public void TC_CDRTariffExemption_Batchin_ADD() throws InterruptedException, IOException, AWTException {
		Exceptions TE = PageFactory.initElements(driver, Exceptions.class);
		this.CommonData();
		this.DataList();
		String Radiobutton = Repository.getProperty("Radiobutton");
		String LineType2 = Repository.getProperty("LineType2");
		String ChargeCode2 = Repository.getProperty("ChargeCode2");
		String NominalCode2 = Repository.getProperty("NominalCode2");
		String Gateway2 = Repository.getProperty("Gateway2");
		String Carrier2 = Repository.getProperty("Carrier2");
		
		String ApplyDate = Repository.getProperty("ApplyDate");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
		String []filetype = {"EXCEL","CSV"};
		String importfile  = Repository.getProperty("importfile");
		String Busns = Repository.getProperty("Busns");
		String Radiobutton1 = Repository.getProperty("Radiobutton1");
		
		String Name = Repository.getProperty("Name");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String prorata = Repository.getProperty("prorata");
		String singlerate = Repository.getProperty("singlerate");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");
		
		
		TE.CDR_Exemption_Add(Radiobutton,LineType2, ChargeCode2, NominalCode2, Gateway2, Carrier2, ApplyDate, MinuteRatePeak, MinuteRateoffPeak,MinuteRateweekend,filetype,importfile,Busns,Radiobutton1,Name,setupcharge,recurringcharge,setupnc,recurringnc,prorata, singlerate,Quantityto,Quantityfrom,Recurringcharge);
	
	}
	
	
	
	@Test(priority = 63, enabled = true)
	public void TC_CDRTariffExemption_Batchout_ADD() throws InterruptedException, IOException, AWTException {
		Exceptions TE = PageFactory.initElements(driver, Exceptions.class);
		this.CommonData();
		this.DataList();
		String Radiobutton = Repository.getProperty("Radiobutton");
		String LineType3 = Repository.getProperty("LineType3");
		String ChargeCode3 = Repository.getProperty("ChargeCode3");
		String NominalCode3 = Repository.getProperty("NominalCode3");
		String Gateway3 = Repository.getProperty("Gateway3");
		String Carrier3 = Repository.getProperty("Carrier3");
		
		String ApplyDate = Repository.getProperty("ApplyDate");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
		String []filetype = {"EXCEL","CSV"};
		String importfile  = Repository.getProperty("importfile");
		String Busns = Repository.getProperty("Busns");
		String Radiobutton1 = Repository.getProperty("Radiobutton1");
		
		String Name = Repository.getProperty("Name");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String prorata = Repository.getProperty("prorata");
		String singlerate = Repository.getProperty("singlerate");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");

		
		TE.CDR_Exemption_Add(Radiobutton,LineType3, ChargeCode3, NominalCode3, Gateway3, Carrier3, ApplyDate, MinuteRatePeak, MinuteRateoffPeak,MinuteRateweekend,filetype,importfile,Busns,Radiobutton1,Name,setupcharge,recurringcharge,setupnc,recurringnc,prorata, singlerate,Quantityto,Quantityfrom,Recurringcharge);
	
	}
	
	
	@Test(priority = 64, enabled = true)
	public void TC_CDRTariffExemption_Mobile_ADD() throws InterruptedException, IOException, AWTException {
		Exceptions TE = PageFactory.initElements(driver, Exceptions.class);
		this.CommonData();
		this.DataList();
		String Radiobutton = Repository.getProperty("Radiobutton");
		String LineType4 = Repository.getProperty("LineType4");
		String ChargeCode4 = Repository.getProperty("ChargeCode4");
		String NominalCode4 = Repository.getProperty("NominalCode4");
		String Gateway4 = Repository.getProperty("Gateway4");
		String Carrier4 = Repository.getProperty("Carrier4");
		
		String ApplyDate = Repository.getProperty("ApplyDate");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
		String []filetype = {"EXCEL","CSV"};
		String importfile  = Repository.getProperty("importfile");
		String Busns = Repository.getProperty("Busns");
		String Radiobutton1 = Repository.getProperty("Radiobutton1");
		
		String Name = Repository.getProperty("Name");
		String setupcharge = Repository.getProperty("setupcharge");
		String recurringcharge = Repository.getProperty("recurringcharge");
		String setupnc = Repository.getProperty("setupnc");
		String recurringnc = Repository.getProperty("recurringnc");
		String prorata = Repository.getProperty("prorata");
		String singlerate = Repository.getProperty("singlerate");
		String Quantityfrom = Repository.getProperty("Quantityfrom");
		String Quantityto = Repository.getProperty("Quantityto");
		String Recurringcharge = Repository.getProperty("Recurringcharge");
	
		
		TE.CDR_Exemption_Add(Radiobutton,LineType4, ChargeCode4, NominalCode4, Gateway4, Carrier4, ApplyDate, MinuteRatePeak, MinuteRateoffPeak,MinuteRateweekend,filetype,importfile,Busns,Radiobutton1,Name,setupcharge,recurringcharge,setupnc,recurringnc,prorata, singlerate,Quantityto,Quantityfrom,Recurringcharge);
	
	}

	@AfterClass
	public void quit() {
		this.after();
	}
}
