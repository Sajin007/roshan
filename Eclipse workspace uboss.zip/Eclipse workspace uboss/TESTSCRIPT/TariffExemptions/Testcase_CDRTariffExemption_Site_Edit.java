package TariffExemptions;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;
import TariifExemptions.CDRTariffExemption_Edit;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Jun 15, 2020
-- Description	: Testcase_TariffExemption_Site_Edit.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-WORKSPACE
-- =============================================*/
public class Testcase_CDRTariffExemption_Site_Edit extends TestBase {
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Tariff_Exemptions;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\TariffExemptions\\CommonData_TariffExemption.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\TariffExemptions\\Datalist_CDRTariffexemptions_site_Edit.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Tariff_Exemptions = Repository.getProperty("Tariff_Exemption_Site");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		init();
	}

	@Test(priority = 65, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}
	
	@Test(priority = 66, enabled = true)
	public void TC_TaiffExemptions_Url() throws InterruptedException, IOException {
		CDRTariffExemption_Edit TE = PageFactory.initElements(driver, CDRTariffExemption_Edit.class);
		this.CommonData();
		TE.GoToUrl(Tariff_Exemptions);
	
	}
	
	@Test(priority = 67, enabled = true)
	public void TC_CDRTariffExemption_Hosin_EDIT() throws InterruptedException, IOException, AWTException {
		CDRTariffExemption_Edit TE = PageFactory.initElements(driver, CDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link =  Repository.getProperty("link");
		String LineType = Repository.getProperty("LineType");
		String ChargeCode = Repository.getProperty("ChargeCode");
		String NominalCode = Repository.getProperty("NominalCode");
		String Carrier = Repository.getProperty("Carrier");
		String Gateway = Repository.getProperty("Gateway");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
	
		TE.CDRtariffExemption_Edit(link, LineType, ChargeCode, NominalCode, Carrier, Gateway,MinuteRatePeak, MinuteRateoffPeak, MinuteRateweekend);
	}
	
	@Test(priority = 68, enabled = true)
	public void TC_CDRTariffExemption_Hosin_DELETE() throws InterruptedException, IOException, AWTException {
		CDRTariffExemption_Edit TE = PageFactory.initElements(driver, CDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link =  Repository.getProperty("link");
		TE.CDRtariffexemptiondelete(link);
	}
		
	@Test(priority = 69, enabled = true)
	public void TC_CDRTariffExemption_Hosout_EDIT() throws InterruptedException, IOException, AWTException {
		CDRTariffExemption_Edit TE = PageFactory.initElements(driver, CDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link1 =  Repository.getProperty("link1");
		String LineType1 = Repository.getProperty("LineType1");
		String ChargeCode1 = Repository.getProperty("ChargeCode1");
		String NominalCode = Repository.getProperty("NominalCode");
		String Carrier = Repository.getProperty("Carrier");
		String Gateway1 = Repository.getProperty("Gateway1");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
	
		TE.CDRtariffExemption_Edit(link1, LineType1, ChargeCode1, NominalCode, Carrier, Gateway1,MinuteRatePeak, MinuteRateoffPeak, MinuteRateweekend);
	}
	
	@Test(priority = 70, enabled = true)
	public void TC_CDRTariffExemption_Hosout_DELETE() throws InterruptedException, IOException, AWTException {
		CDRTariffExemption_Edit TE = PageFactory.initElements(driver, CDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link1 =  Repository.getProperty("link1");
		
		TE.CDRtariffexemptiondelete(link1);
	}
	
	@Test(priority = 71, enabled = true)
	public void TC_CDRTariffExemption_Batchin_EDIT() throws InterruptedException, IOException, AWTException {
		CDRTariffExemption_Edit TE = PageFactory.initElements(driver, CDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link2 =  Repository.getProperty("link2");
		String LineType2 = Repository.getProperty("LineType2");
		String ChargeCode2 = Repository.getProperty("ChargeCode2");
		String NominalCode = Repository.getProperty("NominalCode");
		String Carrier = Repository.getProperty("Carrier");
		String Gateway2 = Repository.getProperty("Gateway2");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
	
		TE.CDRtariffExemption_Edit(link2, LineType2, ChargeCode2, NominalCode, Carrier, Gateway2,MinuteRatePeak, MinuteRateoffPeak, MinuteRateweekend);
	}
	
	@Test(priority = 72, enabled = true)
	public void TC_CDRTariffExemption_Batchin_DELETE() throws InterruptedException, IOException, AWTException {
		CDRTariffExemption_Edit TE = PageFactory.initElements(driver, CDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link2 =  Repository.getProperty("link2");
		
		TE.CDRtariffexemptiondelete(link2);
	}
	
	@Test(priority = 73, enabled = true)
	public void TC_CDRTariffExemption_Batchout_EDIT() throws InterruptedException, IOException, AWTException {
		CDRTariffExemption_Edit TE = PageFactory.initElements(driver, CDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link3 =  Repository.getProperty("link3");
		String LineType3 = Repository.getProperty("LineType3");
		String ChargeCode3 = Repository.getProperty("ChargeCode3");
		String NominalCode = Repository.getProperty("NominalCode");
		String Carrier = Repository.getProperty("Carrier");
		String Gateway3 = Repository.getProperty("Gateway3");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
	
		TE.CDRtariffExemption_Edit(link3, LineType3, ChargeCode3, NominalCode, Carrier, Gateway3,MinuteRatePeak, MinuteRateoffPeak, MinuteRateweekend);
	}
	
	@Test(priority = 74, enabled = true)
	public void TC_CDRTariffExemption_Batchout_DELETE() throws InterruptedException, IOException, AWTException {
		CDRTariffExemption_Edit TE = PageFactory.initElements(driver, CDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link3 =  Repository.getProperty("link3");
		
		TE.CDRtariffexemptiondelete(link3);
	}
	
	@Test(priority = 75, enabled = true)
	public void TC_CDRTariffExemption_Mobile_EDIT() throws InterruptedException, IOException, AWTException {
		CDRTariffExemption_Edit TE = PageFactory.initElements(driver, CDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link4 =  Repository.getProperty("link4");
		String LineType4 = Repository.getProperty("LineType4");
		String ChargeCode4 = Repository.getProperty("ChargeCode4");
		String NominalCode = Repository.getProperty("NominalCode");
		String Carrier = Repository.getProperty("Carrier");
		String Gateway4 = Repository.getProperty("Gateway4");
		String MinuteRatePeak = Repository.getProperty("MinuteRatePeak");
		String MinuteRateoffPeak = Repository.getProperty("MinuteRateoffPeak");
		String MinuteRateweekend = Repository.getProperty("MinuteRateweekend");
	
		TE.CDRtariffExemption_Edit(link4, LineType4, ChargeCode4, NominalCode, Carrier, Gateway4, MinuteRatePeak, MinuteRateoffPeak, MinuteRateweekend);
	}
	
	@Test(priority = 76, enabled = true)
	public void TC_CDRTariffExemption_Mobile_DELETE() throws InterruptedException, IOException, AWTException {
		CDRTariffExemption_Edit TE = PageFactory.initElements(driver, CDRTariffExemption_Edit.class);
		this.CommonData();
		this.DataList();
		
		String link4 =  Repository.getProperty("link4");
		
		TE.CDRtariffexemptiondelete(link4);
	}
	
	
	@AfterClass
	public void quit() {
		this.after();
	}

}
