package NotificationParent;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : May 28, 2020,9:35:28 AM
-- Description	: Test_Case_NotificationParent_SP_Page.java
-- Modified by	: 
-- Modified Date: 
-- Project		: UBOSS-5-0-0-Dennu
-- =============================================*/
public class Test_Case_NotificationParent_SP_Page extends TestBase {
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Notifparentpage;

	/*******************************/
	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\NotificationParent\\CommonData_NotificationParent.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {

		f = new File(System.getProperty("user.dir") + "\\DataList\\NotificationParent\\Datalist_NotificationParent_SP_Page.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		Notifparentpage = Repository.getProperty("NotifparentpageSP");
	}

	public void DataList() throws IOException {
		loadDataList();

	}

	/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		description("Testing All Scenarios In Notification Parent Page in SP");
		init();
	}
	@BeforeMethod
	public void Sleep() throws IOException, AWTException, InterruptedException {
		Thread.sleep(4000);
	}
	@Test(priority = 1, enabled = true)
	public void Login() throws InterruptedException, AWTException {
		description("Login to Uboss");
		Thread.sleep(3000);
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("dennuthomas@drd.co.in","P@ss12345");
		Thread.sleep(3000);
	}

	@Test(priority = 2, enabled = true)
	public void TC_NotificationParent_Url() throws InterruptedException, IOException {
		description("Navigating to Notification Parent Page in SP");
		NotificationParent NP = PageFactory.initElements(driver, NotificationParent.class);
		this.CommonData();
		NP.GoToUrl(Notifparentpage);

	}
	
	@Test(priority = 3, enabled = true)
	public void TC_NotificationParent_SP() throws InterruptedException, IOException, AWTException {
		description("Test cases in Notification Parent for get records in the table and delete scenarios in SP");
		this.DataList();
		String data= ("");
		String delete = Repository.getProperty("delete");
		NotificationParent NP = PageFactory.initElements(driver, NotificationParent.class);
		NP.notificationparent(data,delete);

	}
	@AfterClass
	public void quit() {
	this.after();	

	}
}
