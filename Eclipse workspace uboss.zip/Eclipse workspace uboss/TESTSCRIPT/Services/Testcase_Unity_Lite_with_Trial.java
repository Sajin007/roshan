package Services;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Oct 7, 2020 , 3:39:50 PM
-- Description	: Testcase_Unity_Lite_with_Trial.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class Testcase_Unity_Lite_with_Trial extends TestBase{
	
	
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Unity_Lite_with_trial;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Services\\CommonData_Unity_Lite_with_Trial.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\Services\\Datalist_BW_Unity_Lite_with_Trial.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		Unity_Lite_with_trial = Repository.getProperty("Unity_Lite_with_trial");
	}

	public void DataList() throws IOException {
		loadDataList();

	}
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/

	
	@BeforeClass
	public void setUP() throws IOException {
		Description("Testing all scenarios in Unity_Lite_with_trial_ADD page");
		init();
		// loadPropertiesFile();
	}

	@Test(priority = 1, enabled = true)
	public void TC_login() throws InterruptedException {
		Description("Login with correct username and password");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");
	}

	@Test(priority = 2, enabled = true)
	public void TC_Unity_Lite_with_trial_ADD_Url() throws InterruptedException, IOException {
		
		Description("Navigate to Unity_Lite_with_trial_ADD page");
		Unity_Lite_with_Trial UPS = PageFactory.initElements(driver, Unity_Lite_with_Trial.class);
		this.CommonData();
		UPS.GoToUrl(Unity_Lite_with_trial);
		Thread.sleep(2000);
	}
	
	
	@Test(priority = 3, enabled = true)
	public void TC_Unity_Lite_with_trial_ADD_Validation_Standard() throws InterruptedException, AWTException, IOException
	{
		Description("Checking all the mandatory validations in Unity_Lite_with_trial_ADD page");
		Unity_Lite_with_Trial UPS = PageFactory.initElements(driver, Unity_Lite_with_Trial.class);
		this.loadDataList();
		
		String servicetype1 = Repository.getProperty("servicetype");
		
		String emailValid = Repository.getProperty("email1");
		String mdvalid = Repository.getProperty("md1");
		String npvalid = Repository.getProperty("np1");
		String qpvalid = Repository.getProperty("qp1");
		
		
		
		UPS.Service_Add_Validation(servicetype1,emailValid,mdvalid,npvalid,qpvalid);
		
		
	}
	
	
	@Test(priority = 4, enabled = true)
	public void TC_Service_ADD() throws InterruptedException, IOException {
		
		Description("Checking all the scenarios in Unity_Lite_with_trial_ADD_standard_page");
		Unity_Lite_with_Trial UPS = PageFactory.initElements(driver, Unity_Lite_with_Trial.class);
		this.loadDataList();
		
		String servicetype = Repository.getProperty("servicetype");
		String name1 = Repository.getProperty("name1");
		String Description1 = Repository.getProperty("Description1");
		String Email1 = Repository.getProperty("Email1");
		String country = Repository.getProperty("country");
		String supplier = Repository.getProperty("supplier");
		
		String checkbox1 = Repository.getProperty("checkbox1");
		String checkbox2 = Repository.getProperty("checkbox2");
		String checkbox3 = Repository.getProperty("checkbox3");
		String checkbox4 = Repository.getProperty("checkbox4");
		String checkbox5 = Repository.getProperty("checkbox5");
		String checkbox6 = Repository.getProperty("checkbox6");
		String checkbox7 = Repository.getProperty("checkbox7");
		
		String DepPack = Repository.getProperty("DepPack");
		String DepService = Repository.getProperty("DepService");
		String suppnum = Repository.getProperty("suppnum");
		String UsrService = Repository.getProperty("UsrService");
		String Contracttype = Repository.getProperty("Contracttype");
		
		String md = Repository.getProperty("md");
		String np = Repository.getProperty("np");
		String qp = Repository.getProperty("qp");
		String RP = Repository.getProperty("RP");
		String CP = Repository.getProperty("CP");
		String DepPack1 = Repository.getProperty("DepPack1");
		String DepService1 = Repository.getProperty("DepService1");
		
		
		
		UPS.Service_Add(servicetype,name1,Description1,Email1,country,supplier,checkbox1,checkbox2,checkbox3
				,checkbox4,checkbox5,checkbox6,checkbox7,DepPack,DepService,suppnum,UsrService,Contracttype
				,md,np,qp,RP,CP,DepPack1,DepService1);
	}
	
	
	@Test(priority = 5, enabled = true)
	public void TC_Service_ADD_Rolling() throws InterruptedException, IOException {
		
		Description("Checking all the scenarios in Unity_Lite_with_trial_ADD_rolling_page");
		Unity_Lite_with_Trial TPS = PageFactory.initElements(driver, Unity_Lite_with_Trial.class);
		this.loadDataList();
		
		String servicetype = Repository.getProperty("servicetype");
		String name1 = Repository.getProperty("name2");
		String Description1 = Repository.getProperty("Description1");
		String Email1 = Repository.getProperty("Email1");
		String country = Repository.getProperty("country");
		String supplier = Repository.getProperty("supplier");
		
		String checkbox1 = Repository.getProperty("checkbox1");
		String checkbox2 = Repository.getProperty("checkbox2");
		String checkbox3 = Repository.getProperty("checkbox3");
		String checkbox4 = Repository.getProperty("checkbox4");
		String checkbox5 = Repository.getProperty("checkbox5");
		String checkbox6 = Repository.getProperty("checkbox6");
		String checkbox7 = Repository.getProperty("checkbox7");
		
		String DepPack = Repository.getProperty("DepPack");
		String DepService = Repository.getProperty("DepService");
		String suppnum = Repository.getProperty("suppnum");
		String UsrService = Repository.getProperty("UsrService");
		String Contracttype = Repository.getProperty("Contracttype2");
		
		String md = Repository.getProperty("md");
		String np = Repository.getProperty("np");
		String qp = Repository.getProperty("qp");
		String RP = Repository.getProperty("RP");
		String CP = Repository.getProperty("CP");
		String DepPack1 = Repository.getProperty("DepPack1");
		String DepService1 = Repository.getProperty("DepService1");
		
		
		
		TPS.Service_Add(servicetype,name1,Description1,Email1,country,supplier,checkbox1,checkbox2,checkbox3
				,checkbox4,checkbox5,checkbox6,checkbox7,DepPack,DepService,suppnum,UsrService,Contracttype
				,md,np,qp,RP,CP,DepPack1,DepService1);
	}
}







