package Services;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

public class Testcase_CallForwarding_Always_Edit extends TestBase {
	
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Call_Forwarding_Always;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Services\\CommonData_CallForwarding_Always.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\Services\\DataList_BW_CallForwarding_Always_EDIT.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		Call_Forwarding_Always = Repository.getProperty("CallForwarding_Always");
	}

	public void DataList() throws IOException {
		loadDataList();

	}
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/

	@BeforeClass
	public void setUP() throws IOException {
		Description("Testing all scenarios in BW_Call Forwarding Always_EDIT page");
		init();
		// loadPropertiesFile();
	}

	
	
	@Test(priority = 5, enabled = true)
	public void TC_login() throws InterruptedException {
		Description("Login with correct username and password");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");
	}
	
	
	@Test(priority = 6, enabled = true)
	public void TC_BW_Busy_callforwardingalways_ADD_Url() throws InterruptedException, IOException {
		Description("Navigate to BW_Call Forwarding Always_EDIT page");
		CallForwarding_Always_Edit bsc = PageFactory.initElements(driver, CallForwarding_Always_Edit.class);
		this.CommonData();
		bsc.GoToUrl(Call_Forwarding_Always);
		Thread.sleep(2000);
	}
	
	
	@Test(priority = 7, enabled = true)
	public void TC_Service_EDIT_Validation() throws InterruptedException, IOException, AWTException {
		Description("Checking all the mandatory validations in BW_Call Forwarding Always_EDIT page");
		this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		String email = Repository.getProperty("email");
		String concurrentcallsval = Repository.getProperty("concurrentcallsval");
		String concurrentvideocallsval = Repository.getProperty("concurrentvideocallsval");
		String answeredcallsval = Repository.getProperty("answeredcallsval");
		String unansweredcallsval = Repository.getProperty("unansweredcallsval");
		String concurrentredirectedcallsval = Repository.getProperty("concurrentredirectedcallsval");
		String invocationsval = Repository.getProperty("invocationsval");
		String findmedepthval = Repository.getProperty("findmedepthval");
		String alertingrequestsval = Repository.getProperty("alertingrequestsval");
		String redirectiondepthval = Repository.getProperty("redirectiondepthval");

		CallForwarding_Always_Edit cfa = PageFactory.initElements(driver, CallForwarding_Always_Edit.class);
		cfa.Service_Edit_Validation(Servicename,email,concurrentcallsval,concurrentvideocallsval,answeredcallsval,unansweredcallsval,concurrentredirectedcallsval,invocationsval,findmedepthval,alertingrequestsval,redirectiondepthval);
	}

	
	@Test(priority = 8, enabled = true)
	public void TC_Service_EDIT() throws InterruptedException, IOException, AWTException {
		Description("Checking all the scenarios in BW_Call Forwarding Always_EDIT page");
		this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		//String servicetypedropdown1 = Repository.getProperty("servicetypedropdown1");
		String name1 = Repository.getProperty("name1");
		String OSSname1 = Repository.getProperty("OSSname1");
		String Description1 = Repository.getProperty("Description1");
		String Email1 = Repository.getProperty("Email1");
		String versiondropdown1 = Repository.getProperty("versiondropdown1");
		String concurrentcalls = Repository.getProperty("concurrentcalls");
		String concurrentvideocalls = Repository.getProperty("concurrentvideocalls");
		String answeredcalls = Repository.getProperty("answeredcalls");
		String unansweredcalls = Repository.getProperty("unansweredcalls");
		String concurrentredirectedcalls = Repository.getProperty("concurrentredirectedcalls");
		String invocations = Repository.getProperty("invocations");
		String findmedepth = Repository.getProperty("findmedepth");
		String alertingrequests = Repository.getProperty("alertingrequests");
		String redirectiondepth = Repository.getProperty("redirectiondepth");
		String canbeassigned = Repository.getProperty("canbeassigned");
		String mandatoryassignment = Repository.getProperty("mandatoryassignment");
		String allowedinchildlevelpackages = Repository.getProperty("allowedinchildlevelpackages");
		String canbeexplicitlyassigned = Repository.getProperty("canbeexplicitlyassigned");
		String multipleinstancesallowed = Repository.getProperty("multipleinstancesallowed");
		String canchangestartdate = Repository.getProperty("canchangestartdate");
		String canchangetariffrate = Repository.getProperty("canchangetariffrate");
		String partno = Repository.getProperty("partno");
		String downloadpath = Repository.getProperty("downloadpath");
		String dependentservice1 = Repository.getProperty("dependentservice1");
		String userservicegroup1 = Repository.getProperty("userservicegroup1");
		String dependentpackage1 = Repository.getProperty("dependentpackage1");
		String[] service = {"Call Centre"};
		String minduration = Repository.getProperty("minduration");
		String notificationperiod = Repository.getProperty("notificationperiod");
		String quarantineperiod = Repository.getProperty("quarantineperiod");
		String combinetrue = Repository.getProperty("combinetrue");
		String search = Repository.getProperty("search");
		
		String deletedvalue = Repository.getProperty("deletedvalue");
		String text  = Repository.getProperty("text");
		
		CallForwarding_Always_Edit cfa = PageFactory.initElements(driver, CallForwarding_Always_Edit.class);
		cfa.Service_Edit(Servicename,name1,OSSname1,Description1,Email1,versiondropdown1,concurrentcalls,concurrentvideocalls,answeredcalls,unansweredcalls,concurrentredirectedcalls,invocations,findmedepth,alertingrequests,redirectiondepth,canbeassigned,mandatoryassignment,allowedinchildlevelpackages,canbeexplicitlyassigned,multipleinstancesallowed,canchangestartdate,canchangetariffrate,partno,downloadpath,dependentservice1,userservicegroup1,dependentpackage1,service,minduration,notificationperiod,quarantineperiod,combinetrue,search,deletedvalue,text); 
	}
	
	
	@Test(priority = 9, enabled = true)
	public void TC_Service_DELETE() throws InterruptedException, IOException, AWTException {
		Description("Checking all the mandatory validations in BW_Call Forwarding Always_delete");
		this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		CallForwarding_Always_Edit cfa = PageFactory.initElements(driver, CallForwarding_Always_Edit.class);
		cfa.Service_DELETE(Servicename);
	}	
		
	
	@AfterClass()
	public void quit() {
		this.after();
	}

	
}


	
	
	


