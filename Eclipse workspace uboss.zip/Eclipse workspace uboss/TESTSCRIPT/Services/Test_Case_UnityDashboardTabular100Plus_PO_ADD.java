package Services;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Oct 5, 2020 , 3:32:36 PM
-- Description	: Test_Case_UnityDashboardTabular100Plus_PO_ADD.java
-- Modified by	: 
-- Modified Date:
-- Project		: Uboss-5-0-5
-- =============================================*/
public class Test_Case_UnityDashboardTabular100Plus_PO_ADD extends TestBase{
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Service;

	/*******************************/
	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Services\\CommonData_UnityDashboardTabular100Plus.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {

		f = new File(
		System.getProperty("user.dir") + "\\DataList\\Services\\Datalist_UnityDashboardTabular100Plus_PO_ADD.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		Service = Repository.getProperty("UnityDashboardTabular100Plus_POcreation");
	}

	public void DataList() throws IOException {
		loadDataList();

	}
	/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		description("Testing All Scenarios In Unity Dashboard Tabular 100+ Service in PO");
		init();
	}
	@BeforeMethod
	public void Sleep() throws IOException, AWTException, InterruptedException {
		Thread.sleep(4000);
	}
	@Test(priority = 66, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		description("Login to Uboss");
		Thread.sleep(3000);
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("dennuthomas@drd.co.in", "P@ss12345");
		Thread.sleep(3000);
	}

	@Test(priority = 67, enabled = true)
	public void TC_ServicePage_Url() throws InterruptedException, IOException {
		description("Navigating to Service Page in PO");
		UnityDashboardGraphical100_ADD ALNP = PageFactory.initElements(driver, UnityDashboardGraphical100_ADD.class);
		this.CommonData();
		ALNP.GoToUrl(Service);

	}
	
	@Test(priority = 68, enabled = true)
	public void TC_UnityDashboardTabular100PlusContractstd_ADD_Validation() throws InterruptedException, IOException, AWTException {
		description("Test cases in Unity Dashboard Tabular 100+ Service Page Creation with contract standard Validation in PO");
		this.DataList();
		String servicetype=Repository.getProperty("servicetype");
		String emails = Repository.getProperty("emails");
		String name = Repository.getProperty("name");
		String email = Repository.getProperty("email");
		String country = Repository.getProperty("country");
		String mindura = Repository.getProperty("mindura1");
		String notiprd = Repository.getProperty("notiprd1");
		String quarantdays = Repository.getProperty("quarantdays1");
		UnityDashboardTabular100Plus_ADD ALNP = PageFactory.initElements(driver, UnityDashboardTabular100Plus_ADD.class);
		ALNP.Service_ADD_ContractstdValidation(servicetype,emails,name,email,country,mindura,notiprd,quarantdays);
	}
	
	@Test(priority = 69, enabled = true)
	public void TC_UnityDashboardTabular100PlusContractsrolling_ADD_Validation() throws InterruptedException, IOException, AWTException {
		description("Test cases in Unity Dashboard Tabular 100+ Service Page Creation with contract rolling Validation in PO");
		this.DataList();
		String servicetype=Repository.getProperty("servicetype");
		String emails = Repository.getProperty("emails");
		String contractTyperolling = Repository.getProperty("contractTyperolling");
		String name = Repository.getProperty("name1");
		String email = Repository.getProperty("email");
		String country = Repository.getProperty("country");
		String rollingcontract = Repository.getProperty("rollingcontract1");
		String cancelper = Repository.getProperty("cancelper1");
		UnityDashboardTabular100Plus_ADD ALNP = PageFactory.initElements(driver, UnityDashboardTabular100Plus_ADD.class);
		ALNP.Service_ADD_ContractrollingValidation(servicetype,emails,contractTyperolling,name,email,country,rollingcontract,cancelper);
	}
	
	@Test(priority = 70, enabled = true)
	public void TC_UnityDashboardTabular100PlusContractstd_Add() throws InterruptedException, IOException, AWTException {
		description("Test cases in Unity Dashboard Tabular 100+ Service with Contract Standard Creation in PO");
		this.DataList();
		String servicetype=Repository.getProperty("servicetype");
		String name = Repository.getProperty("name");
		String des = Repository.getProperty("des");
		String email = Repository.getProperty("email");
		String country = Repository.getProperty("country");
		String supplier = Repository.getProperty("supplier");		
		String canbeAssigned=Repository.getProperty("canbeAssigned");
		String mandatoryAssign=Repository.getProperty("mandatoryAssign");
		String allowinchildpack = Repository.getProperty("allowinchildpack");
		String canbeexplicitlyassign = Repository.getProperty("canbeexplicitlyassign");
		String multipleInstanceallowed=Repository.getProperty("multipleInstanceallowed");
		String canchangedStartdate = Repository.getProperty("canchangedStartdate");
		String canchangedTariffrate = Repository.getProperty("canchangedTariffrate");
		String dependant = Repository.getProperty("dependant");
		String supp = Repository.getProperty("supp");
		String busservgrp = Repository.getProperty("busservgrp");
		String usrservgrp = Repository.getProperty("usrservgrp");
		String mindura = Repository.getProperty("mindura");
		String notiprd = Repository.getProperty("notiprd");
		String quarantdays = Repository.getProperty("quarantdays");
		String combinenotiminperiod = Repository.getProperty("combinenotiminperiod");
		UnityDashboardTabular100Plus_ADD ALNP = PageFactory.initElements(driver, UnityDashboardTabular100Plus_ADD.class);
		ALNP.Service_ADD_Contractstd(servicetype,name,des,email,country,supplier,canbeAssigned,mandatoryAssign,allowinchildpack,canbeexplicitlyassign,multipleInstanceallowed,canchangedStartdate,canchangedTariffrate,dependant,supp,busservgrp,usrservgrp,mindura,notiprd,quarantdays,combinenotiminperiod);
	}
	
	@Test(priority = 71, enabled = true)
	public void TC_UnityDashboardTabular100PlusContractrolling_Add() throws InterruptedException, IOException, AWTException {
		description("Test cases in Unity Dashboard Tabular 100+ Service with Contract rolling Creation in PO");
		this.DataList();
		String servicetype=Repository.getProperty("servicetype");
		String name = Repository.getProperty("name1");
		String des = Repository.getProperty("des");
		String email = Repository.getProperty("email");
		String country = Repository.getProperty("country");
		String supplier = Repository.getProperty("supplier");
		String canbeAssigned=Repository.getProperty("canbeAssigned");
		String mandatoryAssign=Repository.getProperty("mandatoryAssign");
		String allowinchildpack = Repository.getProperty("allowinchildpack");
		String canbeexplicitlyassign = Repository.getProperty("canbeexplicitlyassign");
		String multipleInstanceallowed=Repository.getProperty("multipleInstanceallowed");
		String canchangedStartdate = Repository.getProperty("canchangedStartdate");
		String canchangedTariffrate = Repository.getProperty("canchangedTariffrate");
		String dependant = Repository.getProperty("dependant");
		String supp = Repository.getProperty("supp");
		String busservgrp = Repository.getProperty("busservgrp");
		String usrservgrp = Repository.getProperty("usrservgrp");
		String contractTyperolling = Repository.getProperty("contractTyperolling");
		String rollingcontract = Repository.getProperty("rollingcontract");
		String cancelper = Repository.getProperty("cancelper");
		UnityDashboardTabular100Plus_ADD ALNP = PageFactory.initElements(driver, UnityDashboardTabular100Plus_ADD.class);
		ALNP.Service_ADD_Contractrolling(servicetype,name,des,email,country,supplier,canbeAssigned,mandatoryAssign,allowinchildpack,canbeexplicitlyassign,multipleInstanceallowed,canchangedStartdate,canchangedTariffrate,dependant,supp,busservgrp,usrservgrp,contractTyperolling,rollingcontract,cancelper);
	}
	@AfterClass
	public void quit() {
	this.after();	
	
	}

}
