package Services;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Sep 22, 2020 , 6:48:54 PM
-- Description	: Testcase_Third_Party_User.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class Testcase_Third_Party_User extends TestBase {
	
	
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Third_party_user;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Services\\CommonData_Third_Party_user.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\Services\\Datalist_BW_Thirdparty_User_ADD.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		Third_party_user = Repository.getProperty("Third_party_user");
	}

	public void DataList() throws IOException {
		loadDataList();

	}
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/

	
	@BeforeClass
	public void setUP() throws IOException {
		Description("Testing all scenarios in Third_party_user_ADD page");
		init();
		// loadPropertiesFile();
	}

	@Test(priority = 19, enabled = true)
	public void TC_login() throws InterruptedException {
		Description("Login with correct username and password");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");
	}

	@Test(priority = 20, enabled = true)
	public void TC_ThirdParty_user_ADD_ADD_Url() throws InterruptedException, IOException {
		
		Description("Navigate to Third_party_user_ADD page");
		Third_Party_User_Add TPS = PageFactory.initElements(driver, Third_Party_User_Add.class);
		this.CommonData();
		TPS.GoToUrl(Third_party_user);
		Thread.sleep(2000);
	}
	
	
	@Test(priority = 21, enabled = true)
	public void TC_ThirdParty_user_ADD_Validation_Standard() throws InterruptedException, AWTException, IOException
	{
		Description("Checking all the mandatory validations in Third_party_user_ADD page");
		Third_Party_User_Add TPS = PageFactory.initElements(driver, Third_Party_User_Add.class);
		this.loadDataList();
		
		String servicetype1 = Repository.getProperty("servicetype");
		
		String emailValid = Repository.getProperty("email1");
		String mdvalid = Repository.getProperty("md1");
		String npvalid = Repository.getProperty("np1");
		String qpvalid = Repository.getProperty("qp1");
		
		
		
		TPS.Service_Add_Validation(servicetype1,emailValid,mdvalid,npvalid,qpvalid);
		
		
	}
	
	
	@Test(priority = 22, enabled = true)
	public void TC_Service_ADD() throws InterruptedException, IOException {
		
		Description("Checking all the scenarios in Third_party_user_ADD_standard_page");
		Third_Party_User_Add TPS = PageFactory.initElements(driver, Third_Party_User_Add.class);
		this.loadDataList();
		
		String servicetype = Repository.getProperty("servicetype");
		String name1 = Repository.getProperty("name1");
		String Description1 = Repository.getProperty("Description1");
		String Email1 = Repository.getProperty("Email1");
		String country = Repository.getProperty("country");
		String supplier = Repository.getProperty("supplier");
		
		String checkbox1 = Repository.getProperty("checkbox1");
		String checkbox2 = Repository.getProperty("checkbox2");
		String checkbox3 = Repository.getProperty("checkbox3");
		String checkbox4 = Repository.getProperty("checkbox4");
		String checkbox5 = Repository.getProperty("checkbox5");
		String checkbox6 = Repository.getProperty("checkbox6");
		String checkbox7 = Repository.getProperty("checkbox7");
		
		String DepPack = Repository.getProperty("DepPack");
		String DepService = Repository.getProperty("DepService");
		String suppnum = Repository.getProperty("suppnum");
		String UsrService = Repository.getProperty("UsrService");
		String Contracttype = Repository.getProperty("Contracttype");
		
		String md = Repository.getProperty("md");
		String np = Repository.getProperty("np");
		String qp = Repository.getProperty("qp");
		String RP = Repository.getProperty("RP");
		String CP = Repository.getProperty("CP");
		String DepPack1 = Repository.getProperty("DepPack1");
		String DepService1 = Repository.getProperty("DepService1");
		
		
		
		TPS.Service_Add(servicetype,name1,Description1,Email1,country,supplier,checkbox1,checkbox2,checkbox3
				,checkbox4,checkbox5,checkbox6,checkbox7,DepPack,DepService,suppnum,UsrService,Contracttype
				,md,np,qp,RP,CP,DepPack1,DepService1);
	}
	
	
	@Test(priority = 23, enabled = true)
	public void TC_Service_ADD_Rolling() throws InterruptedException, IOException {
		
		Description("Checking all the scenarios in Third_party_user_ADD_rolling_page");
		Third_Party_User_Add TPS = PageFactory.initElements(driver, Third_Party_User_Add.class);
		this.loadDataList();
		
		String servicetype = Repository.getProperty("servicetype");
		String name1 = Repository.getProperty("name2");
		String Description1 = Repository.getProperty("Description1");
		String Email1 = Repository.getProperty("Email1");
		String country = Repository.getProperty("country");
		String supplier = Repository.getProperty("supplier");
		
		String checkbox1 = Repository.getProperty("checkbox1");
		String checkbox2 = Repository.getProperty("checkbox2");
		String checkbox3 = Repository.getProperty("checkbox3");
		String checkbox4 = Repository.getProperty("checkbox4");
		String checkbox5 = Repository.getProperty("checkbox5");
		String checkbox6 = Repository.getProperty("checkbox6");
		String checkbox7 = Repository.getProperty("checkbox7");
		
		String DepPack = Repository.getProperty("DepPack");
		String DepService = Repository.getProperty("DepService");
		String suppnum = Repository.getProperty("suppnum");
		String UsrService = Repository.getProperty("UsrService");
		String Contracttype = Repository.getProperty("Contracttype2");
		
		String md = Repository.getProperty("md");
		String np = Repository.getProperty("np");
		String qp = Repository.getProperty("qp");
		String RP = Repository.getProperty("RP");
		String CP = Repository.getProperty("CP");
		String DepPack1 = Repository.getProperty("DepPack1");
		String DepService1 = Repository.getProperty("DepService1");
		
		
		
		TPS.Service_Add(servicetype,name1,Description1,Email1,country,supplier,checkbox1,checkbox2,checkbox3
				,checkbox4,checkbox5,checkbox6,checkbox7,DepPack,DepService,suppnum,UsrService,Contracttype
				,md,np,qp,RP,CP,DepPack1,DepService1);
	}
	

	@AfterClass()
	public void quit() 
	{
	  	this.after();
	}
}




