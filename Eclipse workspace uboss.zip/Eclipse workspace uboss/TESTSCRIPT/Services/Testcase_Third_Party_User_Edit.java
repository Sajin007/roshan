package Services;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Sep 30, 2020 , 6:54:15 PM
-- Description	: Testcase_Third_Party_User_Edit.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class Testcase_Third_Party_User_Edit extends TestBase {
	
	

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Third_party_user;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Services\\CommonData_Third_Party_user.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\Services\\DataList_BW_Thirdparty_User_Edit.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		Third_party_user = Repository.getProperty("Third_party_user");
	}

	public void DataList() throws IOException {
		loadDataList();

	}
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/

	
	@BeforeClass
	public void setUP() throws IOException {
		Description("Testing all scenarios in Third_party_user_Edit page");
		init();
		// loadPropertiesFile();
	}

	@Test(priority = 24, enabled = true)
	public void TC_login() throws InterruptedException {
		Description("Login with correct username and password");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");
	}


	@Test(priority = 25, enabled = true)
	public void TC_ThirdParty_user_ADD_ADD_Url() throws InterruptedException, IOException {
	
		Third_Party_User_Add TPS = PageFactory.initElements(driver, Third_Party_User_Add.class);
		this.CommonData();
		TPS.GoToUrl(Third_party_user);
		Thread.sleep(2000);
	}
	
	
	@Test(priority = 26, enabled = true)
	public void TC_ThirdParty_user_Edit_Validation_Standard() throws IOException, InterruptedException, AWTException
	{
		Description("Checking all the scenarios in ThirdParty_user_Edit_Validation_Standard");
		Third_Party_User_Edit TPS = PageFactory.initElements(driver, Third_Party_User_Edit.class);
		
		this.loadDataList();
		
		String Servicename = Repository.getProperty("Servicename");
		String email = Repository.getProperty("email");
		
		TPS.Service_Edit_Validation(Servicename,email);
		
			
	}
	
	
	
	
	
	@Test(priority = 27, enabled = true)
	public void TC_ThirdParty_user_Edit_Standard() throws InterruptedException, IOException, AWTException {
		
		Description("Checking all the scenarios in ThirdParty_user_Edit page");
		Third_Party_User_Edit TPS = PageFactory.initElements(driver, Third_Party_User_Edit.class);
		
		this.loadDataList();
		
		String Servicename = Repository.getProperty("Servicename");
		String name1 = Repository.getProperty("name1");
		String Description1 = Repository.getProperty("Description1");
		String Email1 = Repository.getProperty("Email1");
		String country = Repository.getProperty("country");
		String checkbox1 = Repository.getProperty("checkbox1");
		String checkbox2 = Repository.getProperty("checkbox2");
		String checkbox3 = Repository.getProperty("checkbox3");
		String checkbox4 = Repository.getProperty("checkbox4");
		String checkbox5 = Repository.getProperty("checkbox5");
		String checkbox6 = Repository.getProperty("checkbox6");
		String checkbox7 = Repository.getProperty("checkbox7");
		String DepPack = Repository.getProperty("DepPack");
		String DepService = Repository.getProperty("DepService");
		String suppnum = Repository.getProperty("suppnum");
		String UsrService = Repository.getProperty("UsrService");
		String mdvalid = Repository.getProperty("mdvalid");
		String npvalid = Repository.getProperty("npvalid");
		String qpvalid = Repository.getProperty("qpvalid");
		String combinetrue = Repository.getProperty("combinetrue");
		String search = Repository.getProperty("search");
		String RP = Repository.getProperty("RP");
		String CP = Repository.getProperty("CP");
		
		String deletedvalue = Repository.getProperty("deletedvalue");
		String text = Repository.getProperty("text");
		
		
		TPS.Service_Edit(Servicename,name1,Description1, Email1,country,checkbox1,checkbox2 ,checkbox3,checkbox4,checkbox5, checkbox6,checkbox7,DepPack,DepService, suppnum, UsrService,mdvalid,npvalid, qpvalid,combinetrue,search,RP,CP,deletedvalue,text);
		
	}

	
	@Test(priority = 28, enabled = true)
	public void TC_Service_DELETE_Standard() throws InterruptedException, IOException, AWTException {
		Description("Checking Delete scenario in ThirdParty_user_Edit_Standard");
   	this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		Third_Party_User_Edit TPS = PageFactory.initElements(driver, Third_Party_User_Edit.class);
		TPS.Service_DELETE(Servicename);
	}	
	
	@Test(priority = 29, enabled = true)
	public void TC_ThirdParty_user_Edit_Validation_Rolling() throws IOException, InterruptedException, AWTException
	{
		Description("Checking all the scenarios in ThirdParty_user_Edit_Validation_Rolling");
		Third_Party_User_Edit TPS = PageFactory.initElements(driver, Third_Party_User_Edit.class);
		
		this.loadDataList();
		
		String Servicename = Repository.getProperty("Servicename2");
		String email = Repository.getProperty("email");
		
		TPS.Service_Edit_Validation(Servicename,email);
		
			
	}
	

	@Test(priority = 30, enabled = true)
	public void TC_ThirdParty_user_Edit_Rolling() throws InterruptedException, IOException, AWTException {
		
		Description("Checking all the scenarios in ThirdParty_user_Edit_page");
		Third_Party_User_Edit TPS = PageFactory.initElements(driver, Third_Party_User_Edit.class);
		
		this.loadDataList();
		
		String Servicename = Repository.getProperty("Servicename2");
		
		String name1 = Repository.getProperty("name2");
		String Description1 = Repository.getProperty("Description1");
		String Email1 = Repository.getProperty("Email1");
		String country = Repository.getProperty("country");
		String checkbox1 = Repository.getProperty("checkbox1");
		String checkbox2 = Repository.getProperty("checkbox2");
		String checkbox3 = Repository.getProperty("checkbox3");
		String checkbox4 = Repository.getProperty("checkbox4");
		String checkbox5 = Repository.getProperty("checkbox5");
		String checkbox6 = Repository.getProperty("checkbox6");
		String checkbox7 = Repository.getProperty("checkbox7");
		String DepPack = Repository.getProperty("DepPack");
		String DepService = Repository.getProperty("DepService");
		String suppnum = Repository.getProperty("suppnum");
		String UsrService = Repository.getProperty("UsrService");
		String mdvalid = Repository.getProperty("mdvalid");
		String npvalid = Repository.getProperty("npvalid");
		String qpvalid = Repository.getProperty("qpvalid");
		String combinetrue = Repository.getProperty("combinetrue");
		String search = Repository.getProperty("search2");
		String RP = Repository.getProperty("RP");
		String CP = Repository.getProperty("CP");
		String deletedvalue = Repository.getProperty("deletedvalue");
		String text = Repository.getProperty("text");
		
		TPS.Service_Edit(Servicename,name1,Description1, Email1,country,checkbox1,checkbox2 ,checkbox3,checkbox4,checkbox5, checkbox6,checkbox7,DepPack,DepService, suppnum, UsrService,mdvalid,npvalid, qpvalid,combinetrue,search,RP,CP,deletedvalue,text);
		
	}
	
	

	@Test(priority = 31, enabled = true)
	public void TC_Service_DELETE() throws InterruptedException, IOException, AWTException {
		Description("Checking Delete scenario in ThirdParty_user_Edit_Rolling");
   	this.DataList();
		String Servicename2 = Repository.getProperty("Servicename2");
		Third_Party_User_Edit TPS = PageFactory.initElements(driver, Third_Party_User_Edit.class);
		TPS.Service_DELETE_Rolling(Servicename2);
	}	

	@AfterClass()
	public void quit() 
	{
	  	this.after();
	}
	
}
	

