package Services;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Oct 12, 2020 , 3:09:46 PM
-- Description	: Testcase_Unity_Lite_with_Trial_Edit.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class Testcase_Unity_Lite_with_Trial_Edit extends TestBase {
	
	
	
	
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Unity_Lite_with_trial;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Services\\CommonData_Unity_Lite_with_Trial.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\Services\\Datalist_BW_Unity_Lite_with_Trial_EDIT.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		Unity_Lite_with_trial = Repository.getProperty("Unity_Lite_with_trial");
	}

	public void DataList() throws IOException {
		loadDataList();

	}
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/

	
	@BeforeClass
	public void setUP() throws IOException {
		Description("Testing all scenarios in Unity_Lite_with_trial_EDIT page");
		init();
		// loadPropertiesFile();
	}

	@Test(priority = 1, enabled = true)
	public void TC_login() throws InterruptedException {
		Description("Login with correct username and password");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");
	}
	
	
	
	
	@Test(priority = 2, enabled = true)
	public void TC_Unity_Lite_with_trial_ADD_Url() throws InterruptedException, IOException {
		
		Description("Navigate to Unity_Lite_with_trial_ADD page");
		Unity_Lite_with_Trial_Edit UPS = PageFactory.initElements(driver, Unity_Lite_with_Trial_Edit.class);
		this.CommonData();
		UPS.GoToUrl(Unity_Lite_with_trial);
		Thread.sleep(2000);
	}

	
	
	@Test(priority = 3, enabled = true)
	public void TC_Unity_Lite_with_trial_Edit_Validation_Standard() throws IOException, InterruptedException, AWTException
	{
		Description("Checking all the scenarios in Unity_Lite_with_trial_Edit_Validation_Standard");
		Unity_Lite_with_Trial_Edit UPS = PageFactory.initElements(driver, Unity_Lite_with_Trial_Edit.class);
		
		this.loadDataList();
		
		String Servicename = Repository.getProperty("Servicename");
		String email = Repository.getProperty("email");
		
		UPS.Service_Edit_Validation(Servicename,email);			
	}
	
	
	@Test(priority = 4, enabled = true)
	public void TC_Unity_Lite_with_trial_Edit_Standard() throws InterruptedException, IOException, AWTException {
		
		Description("Checking all the scenarios in Unity_Lite_with_trial_Edit page");
		Unity_Lite_with_Trial_Edit TPS = PageFactory.initElements(driver, Unity_Lite_with_Trial_Edit.class);
		
		this.loadDataList();
		
		String Servicename = Repository.getProperty("Servicename");
		String name1 = Repository.getProperty("name1");
		String Description1 = Repository.getProperty("Description1");
		String Email1 = Repository.getProperty("Email1");
		String country = Repository.getProperty("country");
		String checkbox1 = Repository.getProperty("checkbox1");
		String checkbox2 = Repository.getProperty("checkbox2");
		String checkbox3 = Repository.getProperty("checkbox3");
		String checkbox4 = Repository.getProperty("checkbox4");
		String checkbox5 = Repository.getProperty("checkbox5");
		String checkbox6 = Repository.getProperty("checkbox6");
		String checkbox7 = Repository.getProperty("checkbox7");
		String DepPack = Repository.getProperty("DepPack");
		String DepService = Repository.getProperty("DepService");
		String suppnum = Repository.getProperty("suppnum");
		String UsrService = Repository.getProperty("UsrService");
		String mdvalid = Repository.getProperty("mdvalid");
		String npvalid = Repository.getProperty("npvalid");
		String qpvalid = Repository.getProperty("qpvalid");
		String combinetrue = Repository.getProperty("combinetrue");
		String search = Repository.getProperty("search");
		String RP = Repository.getProperty("RP");
		String CP = Repository.getProperty("CP");
		
		String deletedvalue = Repository.getProperty("deletedvalue");
		String text = Repository.getProperty("text");
		
		
		TPS.Service_Edit(Servicename,name1,Description1, Email1,country,checkbox1,checkbox2 ,checkbox3,checkbox4,checkbox5, checkbox6,checkbox7,DepPack,DepService, suppnum, UsrService,mdvalid,npvalid, qpvalid,combinetrue,search,RP,CP,deletedvalue,text);
		
	}

	
	@Test(priority = 5, enabled = true)
	public void TC_Service_DELETE_Standard() throws InterruptedException, IOException, AWTException {
		Description("Checking Delete scenario in Unity_Lite_with_trial_Edit_Standard");
   	this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		Unity_Lite_with_Trial_Edit TPS = PageFactory.initElements(driver, Unity_Lite_with_Trial_Edit.class);
		TPS.Service_DELETE(Servicename);
	}	
	
	@Test(priority = 6, enabled = true)
	public void TC_Unity_Lite_with_trial_Edit_Validation_Rolling() throws IOException, InterruptedException, AWTException
	{
		Description("Checking all the scenarios in Unity_Lite_with_trial_Edit_Validation_Rolling");
		Unity_Lite_with_Trial_Edit TPS = PageFactory.initElements(driver, Unity_Lite_with_Trial_Edit.class);
		
		this.loadDataList();
		
		String Servicename = Repository.getProperty("Servicename2");
		String email = Repository.getProperty("email");
		
		TPS.Service_Edit_Validation(Servicename,email);
		
			
	}
	

	@Test(priority = 7, enabled = true)
	public void TC_Unity_Lite_with_trial_Edit_Rolling() throws InterruptedException, IOException, AWTException {
		
		Description("Checking all the scenarios in Unity_Lite_with_trial_Edit_page");
		Unity_Lite_with_Trial_Edit TPS = PageFactory.initElements(driver, Unity_Lite_with_Trial_Edit.class);
		
		this.loadDataList();
		
		String Servicename = Repository.getProperty("Servicename2");
		
		String name1 = Repository.getProperty("name2");
		String Description1 = Repository.getProperty("Description1");
		String Email1 = Repository.getProperty("Email1");
		String country = Repository.getProperty("country");
		String checkbox1 = Repository.getProperty("checkbox1");
		String checkbox2 = Repository.getProperty("checkbox2");
		String checkbox3 = Repository.getProperty("checkbox3");
		String checkbox4 = Repository.getProperty("checkbox4");
		String checkbox5 = Repository.getProperty("checkbox5");
		String checkbox6 = Repository.getProperty("checkbox6");
		String checkbox7 = Repository.getProperty("checkbox7");
		String DepPack = Repository.getProperty("DepPack");
		String DepService = Repository.getProperty("DepService");
		String suppnum = Repository.getProperty("suppnum");
		String UsrService = Repository.getProperty("UsrService");
		String mdvalid = Repository.getProperty("mdvalid");
		String npvalid = Repository.getProperty("npvalid");
		String qpvalid = Repository.getProperty("qpvalid");
		String combinetrue = Repository.getProperty("combinetrue");
		String search = Repository.getProperty("search2");
		String RP = Repository.getProperty("RP");
		String CP = Repository.getProperty("CP");
		String deletedvalue = Repository.getProperty("deletedvalue");
		String text = Repository.getProperty("text");
		
		TPS.Service_Edit(Servicename,name1,Description1, Email1,country,checkbox1,checkbox2 ,checkbox3,checkbox4,checkbox5, checkbox6,checkbox7,DepPack,DepService, suppnum, UsrService,mdvalid,npvalid, qpvalid,combinetrue,search,RP,CP,deletedvalue,text);
		
	}
	
	

	@Test(priority = 8, enabled = true)
	public void TC_Service_DELETE() throws InterruptedException, IOException, AWTException {
		Description("Checking Delete scenario in Unity_Lite_with_trial_Edit_Rolling");
   	this.DataList();
		String Servicename2 = Repository.getProperty("Servicename2");
		Unity_Lite_with_Trial_Edit TPS = PageFactory.initElements(driver, Unity_Lite_with_Trial_Edit.class);
		TPS.Service_DELETE_Rolling(Servicename2);
	}	

	@AfterClass()
	public void quit() 
	{
	  	this.after();
	}
}
