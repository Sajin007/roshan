package Services;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Sep 29, 2020 , 2:21:02 PM
-- Description	: Test_Case_UnityDashboardGraphical100_PO_EDIT.java
-- Modified by	: 
-- Modified Date:
-- Project		: Uboss-5-0-5
-- =============================================*/
public class Test_Case_UnityDashboardGraphical100_PO_EDIT extends TestBase{
	String Service;

	/*******************************/
	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Services\\CommonData_UnityDashboardGraphical100.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {

		f = new File(
		System.getProperty("user.dir") + "\\DataList\\Services\\Datalist_UnityDashboardGraphical100_PO_EDIT.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		Service = Repository.getProperty("UnityDashboardGraphical100_POcreation");
	}

	public void DataList() throws IOException {
		loadDataList();

	}
	/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		description("Testing All Scenarios In Unity Dashboard Graphical 100 Service in PO");
		init();
	}
	@BeforeMethod
	public void Sleep() throws IOException, AWTException, InterruptedException {
		Thread.sleep(4000);
	}
	@Test(priority = 58, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		description("Login to Uboss");
		Thread.sleep(3000);
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("dennuthomas@drd.co.in", "P@ss12345");
		Thread.sleep(3000);
	}

	@Test(priority = 59, enabled = true)
	public void TC_ServicePage_Url() throws InterruptedException, IOException {
		description("Navigating to Service Page in PO");
		UnityDashboardGraphical100_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardGraphical100_EDIT.class);
		this.CommonData();
		ALNP.GoToUrl(Service);

	}
	@Test(priority = 60, enabled = true)
	public void TC_UnityDashboardGraphical100Contractstd_EDIT_Validation() throws InterruptedException, IOException, AWTException {
		description("Test cases in Unity Dashboard Graphical 100 Service Page Edit  with contract standard Validation in PO");
		this.DataList();
		String searchs=Repository.getProperty("searchscontractstd");
		String emails = Repository.getProperty("emails");
		String country = Repository.getProperty("country1");
		String mindura = Repository.getProperty("mindura1");
		String notiprd = Repository.getProperty("notiprd1");
		String quarantdays = Repository.getProperty("quarantdays1");
		UnityDashboardGraphical100_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardGraphical100_EDIT.class);
		ALNP.Service_Edit_ContractstdValidation(searchs,emails,country,mindura,notiprd,quarantdays);
	}
	
	@Test(priority = 61, enabled = true)
	public void TC_UnityDashboardGraphical100Contractrolling_EDIT_Validation() throws InterruptedException, IOException, AWTException {
		description("Test cases in Unity Dashboard Graphical 100 Service Page Edit  with contract rolling Validation in PO");
		this.DataList();
		String searchs=Repository.getProperty("searchscontractrolling");
		String emails = Repository.getProperty("emails");
		String country = Repository.getProperty("country1");
		String rollingcontract = Repository.getProperty("rollingcontract1");
		String cancelper = Repository.getProperty("cancelper1");
		UnityDashboardGraphical100_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardGraphical100_EDIT.class);
		ALNP.Service_Edit_ContractrollingValidation(searchs,emails,country,rollingcontract,cancelper);
	}
	
	@Test(priority = 62, enabled = true)
	public void TC_UnityDashboardGraphical100Contractstd_EDIT() throws InterruptedException, IOException, AWTException {
		description("Test cases in Unity Dashboard Graphical 100 Service Page Edit  with contract Standard  in PO");
		this.DataList();
		String searchs=Repository.getProperty("searchscontractstd");
		String name = Repository.getProperty("name");
		String des = Repository.getProperty("des");
		String email = Repository.getProperty("email");
		String country = Repository.getProperty("country");
		String canbeAssigned=Repository.getProperty("canbeAssigned");
		String mandatoryAssign=Repository.getProperty("mandatoryAssign");
		String allowinchildpack = Repository.getProperty("allowinchildpack");
		String canbeexplicitlyassign = Repository.getProperty("canbeexplicitlyassign");
		String multipleInstanceallowed=Repository.getProperty("multipleInstanceallowed");
		String canchangedStartdate = Repository.getProperty("canchangedStartdate");
		String canchangedTariffrate = Repository.getProperty("canchangedTariffrate");
		String dependant = Repository.getProperty("dependant");
		String supp = Repository.getProperty("supp");
		String busservgrp = Repository.getProperty("busservgrp");
		String usrservgrp = Repository.getProperty("usrservgrp");
		String mindura = Repository.getProperty("mindura");
		String notiprd = Repository.getProperty("notiprd");
		String quarantdays = Repository.getProperty("quarantdays");
		String combinenotiminperiod = Repository.getProperty("combinenotiminperiod");
		UnityDashboardGraphical100_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardGraphical100_EDIT.class);
		ALNP.Service_Edit_Contractstd(searchs,name,des,email,country,canbeAssigned,mandatoryAssign,allowinchildpack,canbeexplicitlyassign,multipleInstanceallowed,canchangedStartdate,canchangedTariffrate,dependant,supp,busservgrp,usrservgrp,mindura,notiprd,quarantdays,combinenotiminperiod);
	}
	
	@Test(priority = 63, enabled = true)
	public void TC_UnityDashboardGraphical100Contractrolling_EDIT() throws InterruptedException, IOException, AWTException {
		description("Test cases in Unity Dashboard Graphical 100 Service Page Edit  with contract rolling in PO");
		this.DataList();
		String searchs=Repository.getProperty("searchscontractrolling");
		String name = Repository.getProperty("name1");
		String des = Repository.getProperty("des");
		String email = Repository.getProperty("email");
		String country = Repository.getProperty("country");
		String canbeAssigned=Repository.getProperty("canbeAssigned");
		String mandatoryAssign=Repository.getProperty("mandatoryAssign");
		String allowinchildpack = Repository.getProperty("allowinchildpack");
		String canbeexplicitlyassign = Repository.getProperty("canbeexplicitlyassign");
		String multipleInstanceallowed=Repository.getProperty("multipleInstanceallowed");
		String canchangedStartdate = Repository.getProperty("canchangedStartdate");
		String canchangedTariffrate = Repository.getProperty("canchangedTariffrate");
		String dependant = Repository.getProperty("dependant");
		String supp = Repository.getProperty("supp");
		String busservgrp = Repository.getProperty("busservgrp");
		String usrservgrp = Repository.getProperty("usrservgrp");
		String rollingcontract = Repository.getProperty("rollingcontract");
		String cancelper = Repository.getProperty("cancelper");
		UnityDashboardGraphical100_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardGraphical100_EDIT.class);
		ALNP.Service_Edit_Contractrolling(searchs,name,des,email,country,canbeAssigned,mandatoryAssign,allowinchildpack,canbeexplicitlyassign,multipleInstanceallowed,canchangedStartdate,canchangedTariffrate,dependant,supp,busservgrp,usrservgrp,rollingcontract,cancelper);
	}
	
	@Test(priority = 64, enabled = true)
	public void TC_UnityDashboardGraphical100Contractstd_delete() throws InterruptedException, IOException, AWTException
	{
		description("Test cases in Unity Dashboard Graphical 100 Service Page with contract standard Deletion and Include removed checkbox in PO");
		this.DataList();
		String searchs = Repository.getProperty("searchstddeletename");
		UnityDashboardGraphical100_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardGraphical100_EDIT.class);
		ALNP.Service_Delete(searchs);
	}
	
	@Test(priority = 65, enabled = true)
	public void TC_UnityDashboardGraphical100Contractrolling_delete() throws InterruptedException, IOException, AWTException
	{
		description("Test cases in Unity Dashboard Graphical 100 Service Page with contract rolling Deletion and Include removed checkbox in PO");
		this.DataList();
		String searchs = Repository.getProperty("searchrollingdeletename");
		UnityDashboardGraphical100_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardGraphical100_EDIT.class);
		ALNP.Servicecontractrolling_Delete(searchs);
	}
	
	
	@AfterClass
	public void quit() {
	this.after();	
	
	}
}
