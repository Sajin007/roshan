/*-- =============================================
-- Author		: Oommen K Raju
-- Created Date : 9-04-2020
-- Description	: Package Edit Billing business level
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

package Package;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.drd.uboss5.testbase.TestBase;

import Login.Login;

public class Test_Case_Package_BillingBusiness_Edit extends TestBase {

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Package_Creation_BillingBusiness;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Package\\CommonData_Package.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir")+ "\\DataList\\Package\\DATALIST_PACKAGE_BILLINGBUSINESSEDIT.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		Package_Creation_BillingBusiness = Repository.getProperty("Package_Creation_BillingBusiness");
	}

	public void DataList() throws IOException {
		loadDataList();

	}

	/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("Testing scenario for editing package in Billing business level");
		init();
	}

	@Test(priority = 91, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("Login to Uboss");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("oommen.raju@drd.co.in", "P@ss12345678");

	}

	@Test(priority = 92, enabled = true)
	public void TC_Package_Billingbusiness_Url() throws InterruptedException, IOException {
		Description("Naviagate to package list page in billing business level for editing");
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		this.CommonData();
		pkg.GoToUrl(Package_Creation_BillingBusiness);

	}

	@Test(priority = 93, enabled = true)
	public void TC_Package_Billingbusiness_Validation() throws InterruptedException, IOException, AWTException {
		Description("Checking the validations of package edit in billing business level");
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		this.DataList();
		String listsearch1 = Repository.getProperty("listsearch1");
		String invalidData = Repository.getProperty("invalidData");
		pkg.Package_Edit_Validation(listsearch1,invalidData);

	}
	
	@Test(priority = 94, enabled = true)
	public void TC_UserPackage_Billingbusiness_Edit() throws InterruptedException, IOException, AWTException {
		Description("Checking the package recreation edit in billing business level");
		this.DataList();
		String listsearch1 = Repository.getProperty("listsearch1");
		String name = Repository.getProperty("name");
		String description = Repository.getProperty("description");
		String packageCode = Repository.getProperty("packageCode");
		String minimumDuration = Repository.getProperty("minimumDuration");
		String notificationPeriod = Repository.getProperty("notificationPeriod");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod");
		String searchUsageInstancewise = Repository.getProperty("searchUsageInstancewise");
		String search = Repository.getProperty("search");
		String includeremovedValue=Repository.getProperty("includeremovedValue");
		String commisionCategory=Repository.getProperty("commisionCategory");
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
	}
	
	
	@Test(priority = 95, enabled = true)
	 public void TC_UserPackage_Billingbusiness_Delete() throws InterruptedException, IOException, AWTException {	
		Description("Check in the Senarios of package  recreation  edit in Billing business level:Delete,List Page,Export");
		this.DataList();
		String listsearch1 = Repository.getProperty("listsearch1");
		String []filetype = {"EXCEL","CSV" };
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Delete(listsearch1,filetype);
	}
	
	
	@Test(priority = 96, enabled = true)
	public void TC_SitePackage_Billingbusiness_Edit() throws InterruptedException, IOException, AWTException {
		Description("Checking the site package recreation edit in billing business level");
		this.DataList();
		String listsearch1 = Repository.getProperty("SitePackagelistsearch1");
		String name = Repository.getProperty("SitePackagename");
		String description = Repository.getProperty("SitePackagedescription");
		String packageCode = Repository.getProperty("SitePackagepackageCode");
		String minimumDuration = Repository.getProperty("SitePackageminimumDuration");
		String notificationPeriod = Repository.getProperty("SitePackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("SitePackagequarantinePeriod");
		String searchUsageInstancewise = Repository.getProperty("SitePackagesearchUsageInstancewise");
	
		String search = Repository.getProperty("search");
		String includeremovedValue=Repository.getProperty("includeremovedValue");
		String commisionCategory=Repository.getProperty("commisionCategory");
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
	}
	
	@Test(priority = 97, enabled = true)
	 public void TC_SitePackage_Billingbusiness_Delete() throws InterruptedException, IOException, AWTException {	
		Description("Check in the Senarios of site package recreation edit in Billing business level:Delete,List Page,Export");
		this.DataList();
		String listsearch1 = Repository.getProperty("SitePackagelistsearch1");
		String []SitePackagefiletype = {"EXCEL","CSV" };
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Delete(listsearch1,SitePackagefiletype);
	}
	
	
	
	@Test(priority = 98, enabled = true)
	public void TC_BusinessSitePackage_Billingbusiness_Edit() throws InterruptedException, IOException, AWTException {
		Description("Checking the business site package edit recreation in billing business level");
		this.DataList();
		String listsearch1 = Repository.getProperty("BusinessSitePackagelistsearch1");
		String name = Repository.getProperty("BusinessSitePackagename");
		String description = Repository.getProperty("BusinessSitePackagedescription");
		String packageCode = Repository.getProperty("BusinessSitePackagepackageCode");
		String minimumDuration = Repository.getProperty("BusinessSitePackageminimumDuration");
		String notificationPeriod = Repository.getProperty("BusinessSitePackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("BusinessSitePackagequarantinePeriod");
		String searchUsageInstancewise = Repository.getProperty("BusinessSitePackagesearchUsageInstancewise");
		String search = Repository.getProperty("search");
		String includeremovedValue=Repository.getProperty("includeremovedValue");
		String commisionCategory=Repository.getProperty("commisionCategory");
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
	}
		
	
	@Test(priority = 99, enabled = true)
	 public void TC_BusinessSitePackage_Billingbusiness_Delete() throws InterruptedException, IOException, AWTException {	
		Description("Check in the Senarios of business site package recreation edit in Billing business level:Delete,List Page,Export");
		this.DataList();
		String listsearch1 = Repository.getProperty("BusinessSitePackagelistsearch1");
		String []BusinessSitePackagefiletype = {"EXCEL","CSV" };
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Delete(listsearch1,BusinessSitePackagefiletype);
	}
	
	
	@Test(priority = 100, enabled = true)
	public void TC_OWNSecondaryPackage_Edit() throws InterruptedException, IOException, AWTException {
		Description("check whether there is an option for editing own secondary package in business without any parent package");
		this.DataList();
		String listsearch1 = Repository.getProperty("BusinessOwnSecondaryPackagelistsearch1");
		String name = Repository.getProperty("BusinessOwnSecondaryPackagename");
		String description = Repository.getProperty("BusinessOwnSecondaryPackagedescription");
		String packageCode = Repository.getProperty("BusinessOwnSecondaryPackagepackageCode");
		String minimumDuration = Repository.getProperty("BusinessOwnSecondaryPackageminimumDuration");
		String notificationPeriod = Repository.getProperty("BusinessOwnSecondaryPackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("BusinessOwnSecondaryPackagequarantinePeriod");
		String searchUsageInstancewise = Repository.getProperty("BusinessOwnSecondaryPackagesearchUsageInstancewise");
		String search = Repository.getProperty("search");
		String includeremovedValue=Repository.getProperty("includeremovedValue");
		String commisionCategory=Repository.getProperty("commisionCategory");
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
	}
	
	@Test(priority = 101, enabled = true)
	 public void TC_OWNSecondaryPackage__Delete() throws InterruptedException, IOException, AWTException {	
		Description("Check in the Senarios of business own secondary package recreation edit in Billing business level:Delete,List Page,Export");
		this.DataList();
		String listsearch1 = Repository.getProperty("BusinessOwnSecondary_Packagelistsearch1");
		String []BusinessOWNSECONDARYPackagefiletype = {"EXCEL","CSV" };
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Delete(listsearch1,BusinessOWNSECONDARYPackagefiletype);
	}
	
	@Test(priority = 102, enabled = true)
	public void TC_OWNSecondaryPackage_ContainsBothBWAndWebexService_Edit() throws InterruptedException, IOException, AWTException {
		Description("check whether there is an option for editing own secondary package in business having both webex and bw service ,without any parent package");
		this.DataList();
		String listsearch1 = Repository.getProperty("BusinessOwnSecondaryBothWebexAndBW_Packagelistsearch1");
		String name = Repository.getProperty("BusinessOwnSecondaryBothWebexAndBWPackagename");
		String description = Repository.getProperty("BusinessOwnSecondaryBothWebexAndBWPackagedescription");
		String packageCode = Repository.getProperty("BusinessOwnSecondaryBothWebexAndBWPackagepackageCode");
		String minimumDuration = Repository.getProperty("BusinessOwnSecondaryBothWebexAndBWPackageminimumDuration");
		String notificationPeriod = Repository.getProperty("BusinessOwnSecondaryBothWebexAndBWPackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("BusinessOwnSecondaryBothWebexAndBWPackagequarantinePeriod");
		String searchUsageInstancewise = Repository.getProperty("BusinessOwnSecondaryBothWebexAndBWPackagesearchUsageInstancewise");
		String search = Repository.getProperty("search");
		String includeremovedValue=Repository.getProperty("includeremovedValue");
		String commisionCategory=Repository.getProperty("commisionCategory");
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
	}
	
	@Test(priority = 103, enabled = true)
	 public void TC_OWNSecondaryPackage_ContainsBothBWAndWebexService__Delete() throws InterruptedException, IOException, AWTException {	
		Description("Check in the Senarios of business own secondary package having both bw and webex service recreation edit in Billing business level:Delete,List Page,Export");
		this.DataList();
		String listsearch1 = Repository.getProperty("BusinessOwnSecondaryBothWebexAndBW_Packagelistsearch1");
		String []BusinessOWNSECONDARYPackageBothWebexAndBWfiletype = {"EXCEL","CSV" };
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Delete(listsearch1,BusinessOWNSECONDARYPackageBothWebexAndBWfiletype);
	}
	
	
	@Test(priority = 104, enabled = true)
	public void TC_RecreatedOWNSecondaryPackage_BothBWAndWebexService_Edit() throws InterruptedException, IOException, AWTException {
		Description("check whether there is an option for editing recreated own secondary package in business having both webex and bw service ");
		this.DataList();
		String listsearch1 = Repository.getProperty("BusinessRecreatedOwnSecondaryBothWebexAndBW_Packagelistsearch1");
		String name = Repository.getProperty("BusinessRecreatedOwnSecondaryBothWebexAndBWPackagename");
		String description = Repository.getProperty("BusinessRecreatedOwnSecondaryBothWebexAndBWPackagedescription");
		String packageCode = Repository.getProperty("BusinessRecreatedOwnSecondaryBothWebexAndBWPackagepackageCode");
		String minimumDuration = Repository.getProperty("BusinessRecreatedOwnSecondaryBothWebexAndBWPackageminimumDuration");
		String notificationPeriod = Repository.getProperty("BusinessRecreatedOwnSecondaryBothWebexAndBWPackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("BusinessRecreatedOwnSecondaryBothWebexAndBWPackagequarantinePeriod");
		String searchUsageInstancewise = Repository.getProperty("BusinessRecreatedOwnSecondaryBothWebexAndBWPackagesearchUsageInstancewise");
		String search = Repository.getProperty("search");
		String includeremovedValue=Repository.getProperty("includeremovedValue");
		String commisionCategory=Repository.getProperty("commisionCategory");
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
	}
	
	@Test(priority = 105, enabled = true)
	 public void TC_RecreatedOWNSecondaryPackage_BothBWAndWebexService__Delete() throws InterruptedException, IOException, AWTException {	
		Description("Check in the Senarios of business recreated own secondary package having both bw and webex service recreation edit in Billing business level:Delete,List Page,Export");
		this.DataList();
		String listsearch1 = Repository.getProperty("BusinessRecreatedOwnSecondaryBothWebexAndBW_Packagelistsearch1");
		String []BusinessReecreatedOWNSECONDARYPackageBothWebexAndBWfiletype = {"EXCEL","CSV" };
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Delete(listsearch1,BusinessReecreatedOWNSECONDARYPackageBothWebexAndBWfiletype);
	}
	
	
	@Test(priority = 106, enabled = true)
	public void TC_OWNSecondaryPackage_Edit_Withdevice() throws InterruptedException, IOException, AWTException {
		Description("check whether there is an option for editing recreated own secondary package having device in business level  ");
		this.DataList();
		String listsearch1 = Repository.getProperty("OwnSecondaryWithDevice_Packagelistsearch1");
		String name = Repository.getProperty("OwnSecondaryWithDevicePackagename");
		String description = Repository.getProperty("OwnSecondaryWithDevicePackagedescription");
		String packageCode = Repository.getProperty("OwnSecondaryWithDevicePackagepackageCode");
		String minimumDuration = Repository.getProperty("OwnSecondaryWithDevicePackageminimumDuration");
		String notificationPeriod = Repository.getProperty("OwnSecondaryWithDevicePackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("OwnSecondaryWithDevicePackagequarantinePeriod");
		String searchUsageInstancewise = Repository.getProperty("OwnSecondaryWithDevicePackagesearchUsageInstancewise");
		String search = Repository.getProperty("search");
		String includeremovedValue=Repository.getProperty("includeremovedValue");
		String commisionCategory=Repository.getProperty("commisionCategory");
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
	}
	
	@Test(priority = 107, enabled = true)
	 public void TC_OWNSecondaryPackage_Delete_Withdevice() throws InterruptedException, IOException, AWTException {	
		Description("Check in the Senarios of business recreated own secondary package having both bw and webex service recreation edit in Billing business level:Delete,List Page,Export");
		this.DataList();
		String listsearch1 = Repository.getProperty("OwnSecondaryWithDevice_Packagelistsearch1");
		String []BusinessReecreatedOWNSECONDARYPackageBothWebexAndBWfiletype = {"EXCEL","CSV" };
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Delete(listsearch1,BusinessReecreatedOWNSECONDARYPackageBothWebexAndBWfiletype);
	}
	
	
//	@Test(priority = 108, enabled = false)
//	public void TC_Package_Edit_NoPackage() throws InterruptedException, IOException, AWTException {
//		Description("check whether there is an option for editing recreated No package in business level  ");
//		System.out.println("Bug raised , bradworks error is showing while saving  recreated no package in billing business level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("NoPackageSearch");
//		String name = Repository.getProperty("NoPackagename");
//		String description = Repository.getProperty("NoPackagedescription");
//		String packageCode = Repository.getProperty("NoPackageCode");
//		String minimumDuration = Repository.getProperty("NoPackageminimumDuration");
//		String notificationPeriod = Repository.getProperty("NoPackagenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("NoPackagequarantinePeriod");
//		String searchUsageInstancewise = Repository.getProperty("NoPackageUsageInstancewise");
//		String search = Repository.getProperty("search");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 109, enabled = true)
//	 public void TC_Package_Delete_NoPackage() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Scenarios of business recreated own secondary package having both bw and webex service recreation edit in Billing business level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("NoPackageSearch");
//		String []NoPackagefiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,NoPackagefiletype);
//	}
	
	
	@Test(priority = 110, enabled = true)
	public void TC_Package_Edit_NoPackage_WithOwnLevelService() throws InterruptedException, IOException, AWTException {
		Description("check whether there is an option for editing recreated No package in business level  ");
		this.DataList();
		String listsearch1 = Repository.getProperty("NoPackageSearch1");
		String name = Repository.getProperty("NoPackagename1");
		String description = Repository.getProperty("NoPackagedescription1");
		String packageCode = Repository.getProperty("NoPackageCode1");
		String minimumDuration = Repository.getProperty("NoPackageminimumDuration1");
		String notificationPeriod = Repository.getProperty("NoPackagenotificationPeriod1");
		String quarantinePeriod = Repository.getProperty("NoPackagequarantinePeriod1");
		String searchUsageInstancewise = Repository.getProperty("NoPackageUsageInstancewise1");
		String search = Repository.getProperty("search1");
		String includeremovedValue=Repository.getProperty("includeremovedValue1");
		String commisionCategory=Repository.getProperty("commisionCategory1");
		String[] ownlevelService={"Test Bundle"};
		String[] ownlevelServiceCheckbox={"NO"};
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
	}
	

	@Test(priority = 111, enabled = true)
	 public void TC_Package_Delete_NoPackage() throws InterruptedException, IOException, AWTException {	
		Description("Check in the Scenarios of business recreated package having both bw and webex service recreation edit in Billing business level:Delete,List Page,Export");
		this.DataList();
		String listsearch1 = Repository.getProperty("NoPackageSearch1");
		String []NoPackagefiletype = {"EXCEL","CSV" };
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Delete(listsearch1,NoPackagefiletype);
	}
	
		@Test(priority = 112, enabled = false)
		public void TC_UserPackage_Billingbusiness_Edit_WithUcOneService() throws InterruptedException, IOException, AWTException {
		Description("Checking the package recreation edit in billing business level WithUcOne service");
		this.DataList();
		String listsearch1 = Repository.getProperty("listsearch1_WithUcOneService");
		String name = Repository.getProperty("name_WithUcOneService");
		String description = Repository.getProperty("description_WithUcOneService");
		String packageCode = Repository.getProperty("packageCode_WithUcOneService");
		String minimumDuration = Repository.getProperty("minimumDuration_WithUcOneService");
		String notificationPeriod = Repository.getProperty("notificationPeriod_WithUcOneService");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_WithUcOneService");
		String searchUsageInstancewise = Repository.getProperty("searchUsageInstancewise_WithUcOneService");
		String search = Repository.getProperty("search_WithUcOneService");
		String includeremovedValue=Repository.getProperty("includeremovedValue_WithUcOneService");
		String commisionCategory=Repository.getProperty("commisionCategory_WithUcOneService");
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
	}
	
	
	@Test(priority = 113, enabled = true)
	 public void TC_UserPackage_Billingbusiness_Delete_WithUcOneService() throws InterruptedException, IOException, AWTException {	
		Description("Check in the Senarios of package  recreation  edit in Billing business level:Delete,List Page,Export");
		this.DataList();
		String listsearch1 = Repository.getProperty("listsearch1_WithUcOneService");
		String []filetype = {"EXCEL","CSV" };
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Delete(listsearch1,filetype);
	}
	
	
//
//@AfterClass 
//public void quit() {
//	this.after();
//}
}
