/*-- =============================================
-- Author		: Oommen K Raju
-- Created Date : 6-04-2020
-- Description	: Package Recreation Distibutor level
-- Modified by	: Oommen K Raju
-- Modified Date: 14-05-2020
-- Project		: UBOSS-5-0-5
-- =============================================*/

package Package;
import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.drd.uboss5.testbase.TestBase;

import Login.Login;

public class Test_Case_Package_Distibutor_ADD extends TestBase {

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String PackageReCreation_Distributor;
	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Package\\CommonData_Package.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\DataList\\Package\\DATALIST_PACKAGE_CREATION_DISTIBUTOR.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		PackageReCreation_Distributor = Repository.getProperty("Package_Creation_Distributor");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("Testing scenario for creating package in Distributor level");
		init();
	}

	@Test(priority = 21, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("Login to Uboss");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("oommen.raju@drd.co.in","P@ss12345678");
	}


	@Test(priority = 22, enabled = true)
	public void TC_Package_Distributor_Url() throws InterruptedException, IOException {
		Description("Naviagate to Pacakge creation page in Distributor level");
		Package_ADD pkgr = PageFactory.initElements(driver, Package_ADD.class);
		this.CommonData();
		pkgr.GoToUrl(PackageReCreation_Distributor);
		
	}
	
	@Test(priority = 23, enabled = true)
	public void TC_Package_Distributor_Validation() throws InterruptedException, IOException, AWTException {	
		Description("Checking the validations of  pacakge recreation page in Distributor level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo");
		String name = Repository.getProperty("name");
		String description = Repository.getProperty("description");
		String packagecode = Repository.getProperty("packagecode");
		String country = Repository.getProperty("country");
		String packageType = Repository.getProperty("packageType");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValue");
		String primaryPackage = Repository.getProperty("primaryPackage");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue= {""};
		String[]ServiceCheckbox= {"YES"};
		String[] Serivces={"BW-Call Waiting [July 7 Package]"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue");
		String freeDays = Repository.getProperty("freeDays");
		String setupCharge = Repository.getProperty("setupCharge");
		String recurringCharge = Repository.getProperty("recurringCharge");
		String ceaseCharge = Repository.getProperty("ceaseCharge");
		String rebateValue = Repository.getProperty("rebateValue");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("setupCostBuy");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost");
		String ApplyallSDRTariffValue = Repository.getProperty("ApplyallSDRTariffValue");
		String minimumDuration = Repository.getProperty("minimumDuration");
		String notificationPeriodCheckboxvalue = Repository.getProperty("notificationPeriodCheckboxvalue");
		String notificationPeriod = Repository.getProperty("notificationPeriod");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod");
		String InvalidData_Test= Repository.getProperty("InvalidData_Test");
		String assignmentType = Repository.getProperty("assignmentType");
		String availableToReseller=Repository.getProperty("availableToReseller");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue=Repository.getProperty("canAlterPackageCheckboxValue");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String [] parentServiceCheckbox= {};
	    String []  parentService={"Automation_WebexMeeting251"};
	 	Package_ADD pkgr = PageFactory.initElements(driver, Package_ADD.class);
		pkgr.Package_PlatformOwner_ADD_Validation(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,quarantinePeriod,notificationPeriodCheckboxvalue,notificationPeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,parentService,secondaryPackageCheckboxValue,InvalidData_Test);
			
	}
	  

	@Test(priority = 24, enabled = true)
	public void TC_UserPackage_Distributor_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of user package without selecting secondary package in Distributor level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo");
		String name = Repository.getProperty("name");
		String description = Repository.getProperty("description");
		String packagecode = Repository.getProperty("packagecode");
		String country = Repository.getProperty("country");
		String packageType = Repository.getProperty("packageType");
		String primaryPackage = Repository.getProperty("primaryPackage");
		String multipleInstancesValue = Repository.getProperty("multipleInstancesAllowedValue");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue= {""};
		String[] ParentPackageCheckbox= {""};
		String[] parentPackge={"Automation HostedOnly Site Pkg [ Hosted ]"};
		String[]ServiceCheckbox= {"YES"};
		String[] Service={"BW-Call Waiting [July 7 Package]"};
		String[]  parentService={"Automation_WebexMeeting251"};
		
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		
	    String freeDays = Repository.getProperty("freeDays");
		String setupCharge = Repository.getProperty("setupCharge");
		String recurringCharge = Repository.getProperty("recurringCharge");
		String ceaseCharge = Repository.getProperty("ceaseCharge");
		String rebateValue = Repository.getProperty("rebateValue");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("setupCostBuy");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost");
		String ApplyallSDRTariffValue = Repository.getProperty("ApplyallSDRTariffValue");
		String minimumDuration = Repository.getProperty("minimumDuration");
		String notificationPeriod = Repository.getProperty("notificationPeriod");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod");
		String availableToReseller = Repository.getProperty("availableToReseller");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("nopackageValue");
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue");
		String [] parentServiceCheckbox= {};
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
				
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Service,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,parentPackge,parentServiceCheckbox,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	@Test(priority = 25, enabled = true)
	public void TC_SitePackage_Distributor_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of Site package [Assignment Type: Hosted Only] in distributor level ");
		this.DataList();
		String availableTo = Repository.getProperty("SitePackage_availableToReseller");
		String name = Repository.getProperty("SitePackage_name");
		String description = Repository.getProperty("SitePackage_description");
		String packagecode = Repository.getProperty("SitePackage_packagecode");
		String country = Repository.getProperty("SitePackage_country");
		String packageType = Repository.getProperty("SitePackage_packageType");
		String primaryPackage = Repository.getProperty("SitePackage_primaryPackage");
		String multipleInstancesValue = Repository.getProperty("SitePackage_multipleInstancesAllowedValue");
		String[]  NumberCategoryCategoryCheckboxValue = {""};
		String[] NumberCategoryLabelName={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("SitePackage_secondaryPackageCheckboxValue");
	    String[] SitePackage_parentPackgeCheckboxValue={"YES"};
	    String[] SitePackage_parentPackge={"Automation HostedOnly Site Pkg [ Hosted ]"};
	    String[] SitePackage_SerivcesCheckboxValue={"YES"};
		String[] SitePackage_Serivces={"BW-Call Centre Queue Basic [Automation HostedOnly Site Pkg]"};
	   	String[]  SitePackage_parentServiceCheckboxValue={};
		String[]  SitePackage_parentService={};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("SitePackage_freeDays");
		String setupCharge = Repository.getProperty("SitePackage_setupCharge");
		String recurringCharge = Repository.getProperty("SitePackage_recurringCharge");
		String ceaseCharge = Repository.getProperty("SitePackage_ceaseCharge");
		String rebateValue = Repository.getProperty("SitePackage_rebateValue");
		String secondaryRebateValue = Repository.getProperty("SitePackage_secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("SitePackage_setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("SitePackage_recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("SitePackage_ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("SitePackage_setupCostBuy");
		String recurringCostBuy = Repository.getProperty("SitePackage_recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("SitePackage_ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("SitePackage_licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("SitePackage_monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("SitePackage_monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("SitePackage_licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("SitePackage_monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("SitePackage_monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("SitePackage_licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("SitePackage_licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("SitePackage_licenseUnassignedCost");
		String ApplyallSDRTariffValue = Repository.getProperty("SitePackage_ApplyallSDRTariffValue");
		String minimumDuration = Repository.getProperty("SitePackage_minimumDuration");
		String notificationPeriod = Repository.getProperty("SitePackage_notificationPeriod");
		String quarantinePeriod = Repository.getProperty("SitePackage_quarantinePeriod");
		String availableToDistributor = Repository.getProperty("availableToDistributor");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("nopackageValue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		
		Package_ADD pkgr = PageFactory.initElements(driver,Package_ADD.class);
		pkgr.Package_PlatformOwner_ADD(availableTo,availableToDistributor,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,NumberCategoryCategoryCheckboxValue,NumberCategoryLabelName,SitePackage_SerivcesCheckboxValue,SitePackage_Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,SitePackage_parentPackgeCheckboxValue,SitePackage_parentPackge,SitePackage_parentServiceCheckboxValue,SitePackage_parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	
	@Test(priority = 26, enabled = true)
	public void TC_BusinessPackage_Distributor_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of Business package [Assignment Type: Hosted Only] ");
		this.DataList();
		String availableTo = Repository.getProperty("BusinessPackage_availableToReseller");
		String name = Repository.getProperty("BusinessPackage_name");
		String description = Repository.getProperty("BusinessPackage_description");
		String packagecode = Repository.getProperty("BusinessPackage_packagecode");
		String country = Repository.getProperty("BusinessPackage_country");
		String packageType = Repository.getProperty("BusinessPackage_packageType");
		String primaryPackage = Repository.getProperty("BusinessPackage_primaryPackage");
		String multipleInstancesValue = Repository.getProperty("BusinessPackage_multipleInstancesAllowedValue");
		String[] BusinessPackage_numberCategory={"   "};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("BusinessPackage_secondaryPackageCheckboxValue");
		String[] BusinessPackage_parentPackgeCheckboxValue={"YES"};
		String[] BusinessPackage_parentPackge={"Automation HostedOnly Business Pkg [ Hosted ]"};
	    String[] BusinessPackage_SerivcesCheckboxValue= {"YES"};
	    String[] BusinessPackage_Serivces={"BW-Call Centre Queue Basic [Automation HostedOnly Business Pkg]"};
	    String[] BusinessPackage_parentServiceCheckboxValue= {};
	    String[]  BusinessPackage_parentService={};
	    
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("BusinessPackage_freeDays");
		String setupCharge = Repository.getProperty("BusinessPackage_setupCharge");
		String recurringCharge = Repository.getProperty("BusinessPackage_recurringCharge");
		String ceaseCharge = Repository.getProperty("BusinessPackage_ceaseCharge");
		String rebateValue = Repository.getProperty("BusinessPackage_rebateValue");
		String secondaryRebateValue = Repository.getProperty("BusinessPackage_secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("BusinessPackage_setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("BusinessPackage_recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("BusinessPackage_ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("BusinessPackage_setupCostBuy");
		String recurringCostBuy = Repository.getProperty("BusinessPackage_recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("BusinessPackage_ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("BusinessPackage_licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("BusinessPackage_monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("BusinessPackage_monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("BusinessPackage_licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("BusinessPackage_monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("BusinessPackage_monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("BusinessPackage_licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("BusinessPackage_licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("BusinessPackage_licenseUnassignedCost");
		String ApplyallSDRTariffValue = Repository.getProperty("BusinessPackage_ApplyallSDRTariffValue");
		String minimumDuration = Repository.getProperty("BusinessPackage_minimumDuration");
		String notificationPeriod = Repository.getProperty("BusinessPackage_notificationPeriod");
		String quarantinePeriod = Repository.getProperty("BusinessPackage_quarantinePeriod");
		String availableToDistributor = Repository.getProperty("availableToDistributor");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("nopackageValue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		
		Package_ADD pkgr = PageFactory.initElements(driver,Package_ADD.class);
		pkgr.Package_PlatformOwner_ADD(availableTo,availableToDistributor,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,BusinessPackage_numberCategory,BusinessPackage_SerivcesCheckboxValue,BusinessPackage_Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,BusinessPackage_parentPackgeCheckboxValue,BusinessPackage_parentPackge,BusinessPackage_parentServiceCheckboxValue,BusinessPackage_parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 27, enabled = true)
	public void TC_BusinessSitePackage_Distributor_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of BusinessSite package [Assignment Type: Hosted Only] ");
		this.DataList();
		String availableTo = Repository.getProperty("BusinessSitePackage_availableToReseller");
		String name = Repository.getProperty("BusinessSitePackage_name");
		String description = Repository.getProperty("BusinessSitePackage_description");
		String packagecode = Repository.getProperty("BusinessSitePackage_packagecode");
		String country = Repository.getProperty("BusinessSitePackage_country");
		String packageType = Repository.getProperty("BusinessSitePackage_packageType");
		String primaryPackage = Repository.getProperty("BusinessSitePackage_primaryPackage");
		String multipleInstancesValue = Repository.getProperty("BusinessSitePackage_multipleInstancesAllowedValue");
		String[] numberCategoryCheckboxValue = {""};
		String[] BusinessSitePackage_numberCategory={"   "};
		String secondaryPackageCheckboxValue = Repository.getProperty("BusinessSitePackage_secondaryPackageCheckboxValue");
		String[] BusinessSitePackage_parentPackgeCheckboxValue= {"YES"};
		String[] BusinessSitePackage_parentPackge={"Automation HostedOnly Business site Pkg [ Hosted ]"};
		String[] BusinessSitePackage_SerivcesCheckboxValue= {"YES"};
	    String[] BusinessSitePackage_Serivces={"BW-Call Centre Queue Basic [Automation HostedOnly Business site Pkg]"};
	    String[]  BusinessSitePackage_parentServiceValue={};
	    String[]  BusinessSitePackage_parentService={};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("BusinessSitePackage_freeDays");
		String setupCharge = Repository.getProperty("BusinessSitePackage_setupCharge");
		String recurringCharge = Repository.getProperty("BusinessSitePackage_recurringCharge");
		String ceaseCharge = Repository.getProperty("BusinessSitePackage_ceaseCharge");
		String rebateValue = Repository.getProperty("BusinessSitePackage_rebateValue");
		String secondaryRebateValue = Repository.getProperty("BusinessSitePackage_secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("BusinessSitePackage_setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("BusinessSitePackage_recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("BusinessSitePackage_ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("BusinessSitePackage_setupCostBuy");
		String recurringCostBuy = Repository.getProperty("BusinessSitePackage_recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("BusinessSitePackage_ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("BusinessSitePackage_licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("BusinessSitePackage_monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("BusinessSitePackage_monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("BusinessSitePackage_licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("BusinessSitePackage_monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("BusinessSitePackage_monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("BusinessSitePackage_licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("BusinessSitePackage_licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("BusinessSitePackage_licenseUnassignedCost");
		String ApplyallSDRTariffValue = Repository.getProperty("BusinessSitePackage_ApplyallSDRTariffValue");
		String minimumDuration = Repository.getProperty("BusinessSitePackage_minimumDuration");
		String notificationPeriod = Repository.getProperty("BusinessSitePackage_notificationPeriod");
		String quarantinePeriod = Repository.getProperty("BusinessSitePackage_quarantinePeriod");
		String availableToDistributor = Repository.getProperty("availableToDistributor");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("nopackageValue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		
		Package_ADD pkgr = PageFactory.initElements(driver,Package_ADD.class);
		pkgr.Package_PlatformOwner_ADD(availableTo,availableToDistributor,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,BusinessSitePackage_numberCategory,BusinessSitePackage_SerivcesCheckboxValue,BusinessSitePackage_Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,BusinessSitePackage_parentPackgeCheckboxValue,BusinessSitePackage_parentPackge,BusinessSitePackage_parentServiceValue,BusinessSitePackage_parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	@Test(priority = 28, enabled = true)
	public void TC_SipOnlyUserPackage_Distributor_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of User package with primary package selected ( SIP Only user package ) in Distributor level");
		this.DataList();
		String availableTo = Repository.getProperty("SipOnlyUserPackageavailableTo");
		String name = Repository.getProperty("SipOnlyUserPackagename");
		String description = Repository.getProperty("SipOnlyUserPackagedescription");
		String packagecode = Repository.getProperty("SipOnlyUserPackagepackagecode");
		String country = Repository.getProperty("SipOnlyUserPackagecountry");
		String packageType = Repository.getProperty("SipOnlyUserPackagepackageType");
		String primaryPackage = Repository.getProperty("SipOnlyUserPackageprimaryPackage");
		String multipleInstancesValue = Repository.getProperty("SipOnlyUserPackagemultipleInstancesValue");
		String[] numberCategoryCheckboxValue = {""};
		String[] SipOnlyUserPackagenumberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("SipOnlyUserPackagesecondaryPackageCheckboxValue");
		String[] SipOnlyUserPackageparentPackgeCheckboxvalue= {""};
		String[] SipOnlyUserPackageparentPackge={"AutomationBoth User Pkg [ Both ]"};
		String[] SipOnlyUserPackageSerivcesCheckboxValue= {"YES"};
	    String[] SipOnlyUserPackageSerivces={"BW-Call Waiting [AutomationBoth User Pkg]"};
	    String[]  SipOnlyUserPackageparentServiceCheckboxValue={};
	    String[]  SipOnlyUserPackageparentService={};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("SipOnlyUserPackagefreeDays");
		String setupCharge = Repository.getProperty("SipOnlyUserPackagesetupCharge");
		String recurringCharge = Repository.getProperty("SipOnlyUserPackagerecurringCharge");
		String ceaseCharge = Repository.getProperty("SipOnlyUserPackageceaseCharge");
		String rebateValue = Repository.getProperty("SipOnlyUserPackagerebateValue");
		String secondaryRebateValue = Repository.getProperty("SipOnlyUserPackagesecondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("SipOnlyUserPackagesetupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("SipOnlyUserPackagerecurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("SipOnlyUserPackageceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("SipOnlyUserPackagesetupCostBuy");
		String recurringCostBuy = Repository.getProperty("SipOnlyUserPackagerecurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("SipOnlyUserPackageceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("SipOnlyUserPackagelicensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("SipOnlyUserPackagemonthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("SipOnlyUserPackagemonthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("SipOnlyUserPackagelicensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("SipOnlyUserPackagemonthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("SipOnlyUserPackagemonthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("SipOnlyUserPackagelicenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("SipOnlyUserPackagelicenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("SipOnlyUserPackagelicenseUnassignedCost");
		String ApplyallSDRTariffValue = Repository.getProperty("SipOnlyUserPackage_ApplyallSDRTariffValue");
		String minimumDuration = Repository.getProperty("SipOnlyUserPackageminimumDuration");
		String notificationPeriod = Repository.getProperty("SipOnlyUserPackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("SipOnlyUserPackagequarantinePeriod");
		String availableToDistributor = Repository.getProperty("availableToDistributor");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		String nopackageValue=Repository.getProperty("nopackageValue");	
		Package_ADD pkgr = PageFactory.initElements(driver,Package_ADD.class);
		pkgr.Package_PlatformOwner_ADD(availableTo,availableToDistributor,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,SipOnlyUserPackagenumberCategory,SipOnlyUserPackageSerivcesCheckboxValue,SipOnlyUserPackageSerivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,SipOnlyUserPackageparentPackgeCheckboxvalue,SipOnlyUserPackageparentPackge,SipOnlyUserPackageparentServiceCheckboxValue,SipOnlyUserPackageparentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 29, enabled = true)
	public void TC_SecondarySelected_Siponly_Distributor_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of User package  with primary package AND SERVICES not selected and secondary package selected  in Distributor level");
		this.DataList();
		String availableTo = Repository.getProperty("SecondarySelectedSipOnlyUserPackageavailableTo");
		String name = Repository.getProperty("SecondarySelectedSipOnlyUserPackagename");
		String description = Repository.getProperty("SecondarySelectedSipOnlyUserPackagedescription");
		String packagecode = Repository.getProperty("SecondarySelectedSipOnlyUserPackagepackagecode");
		String country = Repository.getProperty("SecondarySelectedSipOnlyUserPackagecountry");
		String packageType = Repository.getProperty("SecondarySelectedSipOnlyUserPackagepackageType");
		String primaryPackage = Repository.getProperty("SecondarySelectedSipOnlyUserPackageprimaryPackage");
		String multipleInstancesValue = Repository.getProperty("SecondarySelectedSipOnlyUserPackagemultipleInstancesValue");
		String[] SecondarySelectedSipOnlyUserPackagenumberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("SecondarySelectedSipOnlyUserPackagesecondaryPackageCheckboxValue");
		String[] SecondarySelectedSipOnlyUserPackageparentPackgeCheckboxValue={"YES"};
		String[] SecondarySelectedSipOnlyUserPackageparentPackge={"AutomationBoth User Pkg [ Both ]"};
		String[] SecondarySelectedSipOnlyUserPackageSerivcesCheckboxValue={};
	    String[] SecondarySelectedSipOnlyUserPackageSerivces={};
	    String[]  SecondarySelectedSipOnlyUserPackageparentServiceCheckboxValue={""};
	    String[]  SecondarySelectedSipOnlyUserPackageparentService={""};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("SecondarySelectedSipOnlyUserPackagefreeDays");
		String setupCharge = Repository.getProperty("SecondarySelectedSipOnlyUserPackagesetupCharge");
		String recurringCharge = Repository.getProperty("SecondarySelectedSipOnlyUserPackagerecurringCharge");
		String ceaseCharge = Repository.getProperty("SecondarySelectedSipOnlyUserPackageceaseCharge");
		String rebateValue = Repository.getProperty("SecondarySelectedSipOnlyUserPackagerebateValue");
		String secondaryRebateValue = Repository.getProperty("SecondarySelectedSipOnlyUserPackagesecondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("SecondarySelectedSipOnlyUserPackagesetupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("SecondarySelectedSipOnlyUserPackagerecurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("SecondarySelectedSipOnlyUserPackageceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("SecondarySelectedSipOnlyUserPackagesetupCostBuy");
		String recurringCostBuy = Repository.getProperty("SecondarySelectedSipOnlyUserPackagerecurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("SecondarySelectedSipOnlyUserPackageceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("SecondarySelectedSipOnlyUserPackagelicensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("SecondarySelectedSipOnlyUserPackagemonthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("SecondarySelectedSipOnlyUserPackagemonthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("SecondarySelectedSipOnlyUserPackagelicensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("SecondarySelectedSipOnlyUserPackagemonthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("SecondarySelectedSipOnlyUserPackagemonthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("SecondarySelectedSipOnlyUserPackagelicenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("SecondarySelectedSipOnlyUserPackagelicenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("SecondarySelectedSipOnlyUserPackagelicenseUnassignedCost");
		String ApplyallSDRTariffValue = Repository.getProperty("SipOnlyUserPackage_ApplyallSDRTariffValue");
		String minimumDuration = Repository.getProperty("SecondarySelectedSipOnlyUserPackageminimumDuration");
		String notificationPeriod = Repository.getProperty("SecondarySelectedSipOnlyUserPackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("SecondarySelectedSipOnlyUserPackagequarantinePeriod");
		String availableToDistributor = Repository.getProperty("availableToDistributor");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		
		String nopackageValue=Repository.getProperty("nopackageValue");	
		Package_ADD pkgr = PageFactory.initElements(driver,Package_ADD.class);
		pkgr.Package_PlatformOwner_ADD(availableTo,availableToDistributor,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,SecondarySelectedSipOnlyUserPackagenumberCategory,SecondarySelectedSipOnlyUserPackageSerivcesCheckboxValue,SecondarySelectedSipOnlyUserPackageSerivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,SecondarySelectedSipOnlyUserPackageparentPackgeCheckboxValue,SecondarySelectedSipOnlyUserPackageparentPackge,SecondarySelectedSipOnlyUserPackageparentServiceCheckboxValue,SecondarySelectedSipOnlyUserPackageparentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
		
	
	@Test(priority = 30, enabled = true)
	public void TC_OWNSecondaryPackage_Distributor_ADD() throws InterruptedException, IOException, AWTException {	
		Description("check whether there is an option for cretaing own secondary package in distributor without any parent package");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryDistributor");
		String name = Repository.getProperty("name_OwnSecondaryDistributor");
		String description = Repository.getProperty("description_OwnSecondaryDistributor");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryDistributor");
		String country = Repository.getProperty("country_OwnSecondaryDistributor");
		String packageType = Repository.getProperty("packageType_OwnSecondaryDistributor");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryDistributor");
		String multipleInstancesValue = Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryDistributor");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue= {""};
		String[] ParentPackageCheckbox= {""};
		String[] parentPackge={""};
		String[]ServiceCheckbox= {""};
		String[] Service={""};
		String [] parentServiceCheckbox= {"YES"};
		String[] parentService={"Webex Meeting 3"};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("freeDays_OwnSecondaryDistributor");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryDistributor");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryDistributor");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryDistributor");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryDistributor");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryDistributor");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryDistributor");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryDistributor");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryDistributor");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryDistributor");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryDistributor");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryDistributor");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryDistributor");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryDistributor");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryDistributor");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryDistributor");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryDistributor");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryDistributor");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryDistributor");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryDistributor");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryDistributor");
		String ApplyallSDRTariffValue = Repository.getProperty("ApplyallSDRTariffValue_OwnSecondaryDistributor");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryDistributor");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryDistributor");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryDistributor");
		String availableToReseller = Repository.getProperty("availableToReseller_OwnSecondaryDistributor");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryDistributor");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryDistributor");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryDistributor");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryDistributor");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryDistributor");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryDistributor");
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryDistributor");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryDistributor");
		String deviceRented=Repository.getProperty("deviceRented_OwnSecondaryDistributor");
		String upgradePriority=Repository.getProperty("upgradePriority_OwnSecondaryDistributor");
		String nopackageValue=Repository.getProperty("nopackageValue");	
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Service,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,parentPackge,parentServiceCheckbox,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 31, enabled = true)
	public void TC_OWNSecondaryPackage_Distributor_ADD_AlreadyExistCheck() throws InterruptedException, IOException, AWTException {	
		Description("check whether there is an option for cretaing already existing own secondary package in distributor without any parent package");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryDistributor");
		String name = Repository.getProperty("name_OwnSecondaryDistributor");
		String description = Repository.getProperty("description_OwnSecondaryDistributor");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryDistributor");
		String country = Repository.getProperty("country_OwnSecondaryDistributor");
		String packageType = Repository.getProperty("packageType_OwnSecondaryDistributor");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryDistributor");
		String multipleInstancesValue = Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryDistributor");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue= {""};
		String[] ParentPackageCheckbox= {""};
		String[] parentPackge={""};
		String[]ServiceCheckbox= {""};
		String[] Service={""};
		String [] parentServiceCheckbox= {"YES"};
		String[] parentService={"Webex Meeting 3"};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("freeDays_OwnSecondaryDistributor");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryDistributor");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryDistributor");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryDistributor");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryDistributor");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryDistributor");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryDistributor");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryDistributor");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryDistributor");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryDistributor");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryDistributor");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryDistributor");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryDistributor");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryDistributor");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryDistributor");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryDistributor");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryDistributor");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryDistributor");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryDistributor");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryDistributor");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryDistributor");
		String ApplyallSDRTariffValue = Repository.getProperty("ApplyallSDRTariffValue_OwnSecondaryDistributor");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryDistributor");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryDistributor");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryDistributor");
		String availableToReseller = Repository.getProperty("availableToReseller_OwnSecondaryDistributor");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryDistributor");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryDistributor");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryDistributor");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryDistributor");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryDistributor");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryDistributor");
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryDistributor");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryDistributor");
		String deviceRented=Repository.getProperty("deviceRented_OwnSecondaryDistributor");
		String upgradePriority=Repository.getProperty("upgradePriority_OwnSecondaryDistributor");
		String nopackageValue=Repository.getProperty("nopackageValue");				
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Service,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,parentPackge,parentServiceCheckbox,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 32, enabled = true)
	public void TC_OWNSecondaryPackage_Distributor_ADD_MultipleWebbexService() throws InterruptedException, IOException, AWTException {	
		Description("check whether multiple webex services can be added in the same package");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryDistributor");
		String name = Repository.getProperty("name_OwnSecondaryDistributor");
		String description = Repository.getProperty("description_OwnSecondaryDistributor");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryDistributor");
		String country = Repository.getProperty("country_OwnSecondaryDistributor");
		String packageType = Repository.getProperty("packageType_OwnSecondaryDistributor");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryDistributor");
		String multipleInstancesValue = Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryDistributor");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue= {""};
		String[] ParentPackageCheckbox= {""};
		String[] parentPackge={""};
		String[]ServiceCheckbox= {""};
		String[] Service={""};
		String [] parentServiceCheckbox= {"YES","YES","YES"};
		String[] parentService= {"BW-Call Forwarding Always","WebeMeeting3","WebeSoftphoneOnly"};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("freeDays_OwnSecondaryDistributor");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryDistributor");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryDistributor");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryDistributor");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryDistributor");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryDistributor");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryDistributor");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryDistributor");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryDistributor");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryDistributor");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryDistributor");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryDistributor");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryDistributor");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryDistributor");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryDistributor");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryDistributor");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryDistributor");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryDistributor");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryDistributor");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryDistributor");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryDistributor");
		String ApplyallSDRTariffValue = Repository.getProperty("ApplyallSDRTariffValue_OwnSecondaryDistributor");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryDistributor");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryDistributor");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryDistributor");
		String availableToReseller = Repository.getProperty("availableToReseller_OwnSecondaryDistributor");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryDistributor");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryDistributor");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryDistributor");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryDistributor");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryDistributor");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryDistributor");
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryDistributor");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryDistributor");
		String deviceRented=Repository.getProperty("deviceRented_OwnSecondaryDistributor");
		String upgradePriority=Repository.getProperty("upgradePriority_OwnSecondaryDistributor");
		String nopackageValue=Repository.getProperty("nopackageValue");		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Service,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,parentPackge,parentServiceCheckbox,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}

	@Test(priority = 33, enabled = true)
	public void TC_OWNSecondaryPackage_Distributor_ADD_NOService() throws InterruptedException, IOException, AWTException {	
		Description("Check whether it is able to create own secondary package without adding any services when parent package is not selectd");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryDistributor");
		String name = Repository.getProperty("name_OwnSecondaryDistributor");
		String description = Repository.getProperty("description_OwnSecondaryDistributor");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryDistributor");
		String country = Repository.getProperty("country_OwnSecondaryDistributor");
		String packageType = Repository.getProperty("packageType_OwnSecondaryDistributor");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryDistributor");
		String multipleInstancesValue = Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryDistributor");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue= {""};
		String[] ParentPackageCheckbox= {""};
		String[] parentPackge={""};
		String[]ServiceCheckbox= {""};
		String[] Service={""};
		String [] parentServiceCheckbox= {""};
		String[] parentService= {""};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("freeDays_OwnSecondaryDistributor");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryDistributor");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryDistributor");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryDistributor");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryDistributor");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryDistributor");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryDistributor");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryDistributor");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryDistributor");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryDistributor");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryDistributor");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryDistributor");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryDistributor");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryDistributor");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryDistributor");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryDistributor");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryDistributor");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryDistributor");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryDistributor");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryDistributor");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryDistributor");
		String ApplyallSDRTariffValue = Repository.getProperty("ApplyallSDRTariffValue_OwnSecondaryDistributor");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryDistributor");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryDistributor");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryDistributor");
		String availableToReseller = Repository.getProperty("availableToReseller_OwnSecondaryDistributor");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryDistributor");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryDistributor");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryDistributor");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryDistributor");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryDistributor");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryDistributor");
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryDistributor");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryDistributor");
		String deviceRented=Repository.getProperty("deviceRented_OwnSecondaryDistributor");
		String upgradePriority=Repository.getProperty("upgradePriority_OwnSecondaryDistributor");
		String nopackageValue=Repository.getProperty("nopackageValue");	
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Service,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,parentPackge,parentServiceCheckbox,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 34, enabled = true)
	public void TC_OWNSecondaryPackage_Distributor_ADD_BothBWAndWebex() throws InterruptedException, IOException, AWTException {	
		Description("check whether combination of both webex(1 webex service) and broadworks services can be added within the same package from distributor level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryDistributor_BothWebexAndBW");
		String name = Repository.getProperty("name_OwnSecondaryDistributor_BothWebexAndBW");
		String description = Repository.getProperty("description_OwnSecondaryDistributor_BothWebexAndBW");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryDistributor_BothWebexAndBW");
		String country = Repository.getProperty("country_OwnSecondaryDistributor_BothWebexAndBW");
		String packageType = Repository.getProperty("packageType_OwnSecondaryDistributor_BothWebexAndBW");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryDistributor_BothWebexAndBW");
		String multipleInstancesValue = Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryDistributor_BothWebexAndBW");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue= {""};
		String[] ParentPackageCheckbox= {""};
		String[] parentPackge={""};
		String[]ServiceCheckbox= {""};
		String[] Service={""};
		String [] parentServiceCheckbox= {"YES","YES"};
		String[] parentService= {"BW-ShareCallAppearance","WebeSoftphoneOnly"};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("freeDays_OwnSecondaryDistributor_BothWebexAndBW");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryDistributor_BothWebexAndBW");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryDistributor_BothWebexAndBW");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryDistributor_BothWebexAndBW");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryDistributor_BothWebexAndBW");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryDistributor_BothWebexAndBW");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryDistributor_BothWebexAndBW");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryDistributor_BothWebexAndBW");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryDistributor_BothWebexAndBW");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryDistributor_BothWebexAndBW");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryDistributor_BothWebexAndBW");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryDistributor_BothWebexAndBW");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryDistributor_BothWebexAndBW");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryDistributor_BothWebexAndBW");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryDistributor_BothWebexAndBW");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryDistributor_BothWebexAndBW");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryDistributor_BothWebexAndBW");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryDistributor_BothWebexAndBW");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryDistributor_BothWebexAndBW");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryDistributor_BothWebexAndBW");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryDistributor_BothWebexAndBW");
		String ApplyallSDRTariffValue = Repository.getProperty("ApplyallSDRTariffValue_OwnSecondaryDistributor_BothWebexAndBW");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryDistributor_BothWebexAndBW");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryDistributor_BothWebexAndBW");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryDistributor_BothWebexAndBW");
		String availableToReseller = Repository.getProperty("availableToReseller_OwnSecondaryDistributor_BothWebexAndBW");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryDistributor_BothWebexAndBW");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryDistributor_BothWebexAndBW");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryDistributor_BothWebexAndBW");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryDistributor_BothWebexAndBW");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryDistributor_BothWebexAndBW");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryDistributor_BothWebexAndBW");
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryDistributor_BothWebexAndBW");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryDistributor_BothWebexAndBW");
		String deviceRented=Repository.getProperty("deviceRented_OwnSecondaryDistributor_BothWebexAndBW");
		String upgradePriority=Repository.getProperty("upgradePriority_OwnSecondaryDistributor_BothWebexAndBW");
		String nopackageValue=Repository.getProperty("nopackageValue");			
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Service,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,parentPackge,parentServiceCheckbox,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 35, enabled = true)
	public void TC_RecreatingOWNSecondaryPackage_Distributor_ADD_BothBWAndWebex() throws InterruptedException, IOException, AWTException {	
		Description("Check whether it is able recreate secondary packge (from PO level) having both Webex(1 webex service) and bw service in distributor level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String name = Repository.getProperty("name_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String description = Repository.getProperty("description_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String country = Repository.getProperty("country_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String packageType = Repository.getProperty("packageType_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String multipleInstancesValue = Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue= {""};
		String[] ParentPackageCheckbox= {"YES"};
		String[] parentPackge={"Automation PO Own Secondary Pkg 2 [ Hosted ]"};
		String[]ServiceCheckbox= {"YES","YES"};
		String[] Service={"BW-Call Waiting [Automation PO Own Secondary Pkg 2]","Webex Meeting 3 [Automation PO Own Secondary Pkg 2]"};
		String [] parentServiceCheckbox= {""};
		String[] parentService= {""};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("freeDays_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryDistributor_BothWebexAndBW_Recreation");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String ApplyallSDRTariffValue = Repository.getProperty("ApplyallSDRTariffValue_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String availableToReseller = Repository.getProperty("availableToReseller_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String deviceRented=Repository.getProperty("deviceRented_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String upgradePriority=Repository.getProperty("upgradePriority_OwnSecondaryDistributor_BothWebexAndBW_Recreation");
		String nopackageValue=Repository.getProperty("nopackageValue");					
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Service,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,parentPackge,parentServiceCheckbox,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
		
	@Test(priority = 36, enabled = true)
	public void TC_UserPackage_Distributor_ADD_Withdevice() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of user package with device without selecting secondary package in Distributor level");
		this.DataList();
		String availableTo = Repository.getProperty("availableToPkgWithDevice");
		String name = Repository.getProperty("namePkgWithDevice");
		String description = Repository.getProperty("descriptionPkgWithDevice");
		String packagecode = Repository.getProperty("packagecodePkgWithDevice");
		String country = Repository.getProperty("countryPkgWithDevice");
		String packageType = Repository.getProperty("packageTypePkgWithDevice");
		String primaryPackage = Repository.getProperty("primaryPackagePkgWithDevice");
		String multipleInstancesValue = Repository.getProperty("multipleInstancesAllowedValuePkgWithDevice");
		String[] numberCategory={"   "};
		String[] numberCategoryCheckboxValue= {""};
		String[] ParentPackageCheckbox= {""};
		String[] parentPackge={""};
		String[]ServiceCheckbox= {""};
		String[] Service={""};
		String[]  parentService={""};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("freeDaysPkgWithDevice");
		String setupCharge = Repository.getProperty("setupChargePkgWithDevice");
		String recurringCharge = Repository.getProperty("recurringChargePkgWithDevice");
		String ceaseCharge = Repository.getProperty("ceaseChargePkgWithDevice");
		String rebateValue = Repository.getProperty("rebateValuePkgWithDevice");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValuePkgWithDevice");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCodePkgWithDevice");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCodePkgWithDevice");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCodePkgWithDevice");
		String setupCostBuy = Repository.getProperty("setupCostBuyPkgWithDevice");
		String recurringCostBuy = Repository.getProperty("recurringCostBuyPkgWithDevice");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuyPkgWithDevice");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePricePkgWithDevice");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssignedPkgWithDevice");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassignedPkgWithDevice");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominalPkgWithDevice");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominalPkgWithDevice");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominalPkgWithDevice");
		String licenseSetupCost = Repository.getProperty("licenseSetupCostPkgWithDevice");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCostPkgWithDevice");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCostPkgWithDevice");
		String ApplyallSDRTariffValue = Repository.getProperty("ApplyallSDRTariffValuePkgWithDevice");
		String minimumDuration = Repository.getProperty("minimumDurationPkgWithDevice");
		String notificationPeriod = Repository.getProperty("notificationPeriodPkgWithDevice");
		String quarantinePeriod = Repository.getProperty("quarantinePeriodPkgWithDevice");
		String availableToReseller = Repository.getProperty("availableToResellerPkgWithDevice");
		String assignmentType = Repository.getProperty("assignmentTypePkgWithDevice");
		String isprimaryValue = Repository.getProperty("isprimaryValuePkgWithDevice");
		String dependentPackage = Repository.getProperty("dependentPackagePkgWithDevice");
		String keyLampCount = Repository.getProperty("keyLampCountPkgWithDevice");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValuePkgWithDevice");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValuePkgWithDevice");
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValuePkgWithDevice");
		String [] parentServiceCheckbox= {};
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_ResellerPkgWithDevice");
		String deviceRented=Repository.getProperty("deviceRentedPkgWithDevice");
		String upgradePriority=Repository.getProperty("upgradePriorityPkgWithDevice");
		String nopackageValue=Repository.getProperty("nopackageValue");		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Service,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,parentPackge,parentServiceCheckbox,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 37, enabled = true)
	public void TC_UserPackage_Distributor_ADD_NopAckage() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of  No package in distributor level");
		this.DataList();
		String availableTo = Repository.getProperty("availableToNoPackage");
		String name = Repository.getProperty("nameNoPackage");
		String description = Repository.getProperty("descriptionNoPackage");
		String packagecode = Repository.getProperty("packagecodeNoPackage");
		String country = Repository.getProperty("countryNoPackage");
		String packageType = Repository.getProperty("packageTypeNoPackage");
		String primaryPackage = Repository.getProperty("primaryPackageNoPackage");
		String multipleInstancesValue = Repository.getProperty("multipleInstancesAllowedValueNoPackage");
		String[] numberCategory={"   "};
		String[] numberCategoryCheckboxValue= {""};
		String[] ParentPackageCheckbox= {""};
		String[] parentPackge={""};
		String[]ServiceCheckbox= {""};
		String[] Service={""};
		String[]  parentService={""};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("freeDaysNoPackage");
		String setupCharge = Repository.getProperty("setupChargeNoPackage");
		String recurringCharge = Repository.getProperty("recurringChargeNoPackage");
		String ceaseCharge = Repository.getProperty("ceaseChargeNoPackage");
		String rebateValue = Repository.getProperty("rebateValueNoPackage");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValueNoPackage");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCodeNoPackage");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCodeNoPackage");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCodeNoPackage");
		String setupCostBuy = Repository.getProperty("setupCostBuyNoPackage");
		String recurringCostBuy = Repository.getProperty("recurringCostBuyNoPackage");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuyNoPackage");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePriceNoPackage");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssignedNoPackage");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassignedNoPackage");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominalNoPackage");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominalNoPackage");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominalNoPackage");
		String licenseSetupCost = Repository.getProperty("licenseSetupCostNoPackage");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCostNoPackage");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCostNoPackage");
		String ApplyallSDRTariffValue = Repository.getProperty("ApplyallSDRTariffValueNoPackage");
		String minimumDuration = Repository.getProperty("minimumDurationNoPackage");
		String notificationPeriod = Repository.getProperty("notificationPeriodNoPackage");
		String quarantinePeriod = Repository.getProperty("quarantinePeriodNoPackage");
		String availableToReseller = Repository.getProperty("availableToResellerNoPackage");
		String assignmentType = Repository.getProperty("assignmentTypeNoPackage");
		String isprimaryValue = Repository.getProperty("isprimaryValueNoPackage");
		String dependentPackage = Repository.getProperty("dependentPackageNoPackage");
		String keyLampCount = Repository.getProperty("keyLampCountNoPackage");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValueNoPackage");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValueNoPackage");
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValueNoPackage");
		String [] parentServiceCheckbox= {};
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_ResellerNoPackage");
		String deviceRented=Repository.getProperty("deviceRentedNoPackage");
		String upgradePriority=Repository.getProperty("upgradePriorityNoPackage");
		String nopackageValue=Repository.getProperty("nopackageValueNoPackage");		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Service,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,parentPackge,parentServiceCheckbox,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 38, enabled = true)
	public void TC_UserPackage_Distributor_ADD_NopAckage_WithOwnLevelService() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of  No package in distributor level with ownlevelservice");
		this.DataList();
		String availableTo = Repository.getProperty("availableToNoPackage");
		String name = Repository.getProperty("nameNoPackage");
		String description = Repository.getProperty("descriptionNoPackage");
		String packagecode = Repository.getProperty("packagecodeNoPackage");
		String country = Repository.getProperty("countryNoPackage");
		String packageType = Repository.getProperty("packageTypeNoPackage");
		String primaryPackage = Repository.getProperty("primaryPackageNoPackage");
		String multipleInstancesValue = Repository.getProperty("multipleInstancesAllowedValueNoPackage");
		String[] numberCategory={"   "};
		String[] numberCategoryCheckboxValue= {""};
		String[] ParentPackageCheckbox= {""};
		String[] parentPackge={""};
		String[]ServiceCheckbox= {""};
		String[] Service={""};
		String[]  parentService={""};
		String[] ownlevelService={"Test Bundle"};
		String[]  ownlevelServiceCheckbox={"YES"};
		
		
	    String freeDays = Repository.getProperty("freeDaysNoPackage");
		String setupCharge = Repository.getProperty("setupChargeNoPackage");
		String recurringCharge = Repository.getProperty("recurringChargeNoPackage");
		String ceaseCharge = Repository.getProperty("ceaseChargeNoPackage");
		String rebateValue = Repository.getProperty("rebateValueNoPackage");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValueNoPackage");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCodeNoPackage");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCodeNoPackage");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCodeNoPackage");
		String setupCostBuy = Repository.getProperty("setupCostBuyNoPackage");
		String recurringCostBuy = Repository.getProperty("recurringCostBuyNoPackage");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuyNoPackage");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePriceNoPackage");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssignedNoPackage");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassignedNoPackage");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominalNoPackage");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominalNoPackage");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominalNoPackage");
		String licenseSetupCost = Repository.getProperty("licenseSetupCostNoPackage");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCostNoPackage");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCostNoPackage");
		String ApplyallSDRTariffValue = Repository.getProperty("ApplyallSDRTariffValueNoPackage");
		String minimumDuration = Repository.getProperty("minimumDurationNoPackage");
		String notificationPeriod = Repository.getProperty("notificationPeriodNoPackage");
		String quarantinePeriod = Repository.getProperty("quarantinePeriodNoPackage");
		String availableToReseller = Repository.getProperty("availableToResellerNoPackage");
		String assignmentType = Repository.getProperty("assignmentTypeNoPackage");
		String isprimaryValue = Repository.getProperty("isprimaryValueNoPackage");
		String dependentPackage = Repository.getProperty("dependentPackageNoPackage");
		String keyLampCount = Repository.getProperty("keyLampCountNoPackage");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValueNoPackage");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValueNoPackage");
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValueNoPackage");
		String [] parentServiceCheckbox= {};
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_ResellerNoPackage");
		String deviceRented=Repository.getProperty("deviceRentedNoPackage");
		String upgradePriority=Repository.getProperty("upgradePriorityNoPackage");
		String nopackageValue=Repository.getProperty("nopackageValueNoPackage");		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Service,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,parentPackge,parentServiceCheckbox,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 39, enabled = true)
	public void TC_UserPackage_Distributor_ADD_WithUcOneService() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of user package without selecting secondary package in Distributor level WithUcOneService");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_WithUcOneService");
		String name = Repository.getProperty("name_WithUcOneService");
		String description = Repository.getProperty("description_WithUcOneService");
		String packagecode = Repository.getProperty("packagecode_WithUcOneService");
		String country = Repository.getProperty("country_WithUcOneService");
		String packageType = Repository.getProperty("packageType_WithUcOneService");
		String primaryPackage = Repository.getProperty("primaryPackage_WithUcOneService");
		String multipleInstancesValue = Repository.getProperty("multipleInstancesAllowedValue_WithUcOneService");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue= {""};
		String[] ParentPackageCheckbox= {""};
		String[] parentPackge={"Automation HostedOnly Site Pkg [ Hosted ]"};
		String[]ServiceCheckbox= {"YES"};
		String[] Service={"VIP-UC-One Trio - Softphone Only [Automation_UCOnePKGCheck]"};
		String[]  parentService={"Automation_WebexMeeting251"};
		
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		
	    String freeDays = Repository.getProperty("freeDays_WithUcOneService");
		String setupCharge = Repository.getProperty("setupCharge_WithUcOneService");
		String recurringCharge = Repository.getProperty("recurringCharge_WithUcOneService");
		String ceaseCharge = Repository.getProperty("ceaseCharge_WithUcOneService");
		String rebateValue = Repository.getProperty("rebateValue_WithUcOneService");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_WithUcOneService");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_WithUcOneService");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_WithUcOneService");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_WithUcOneService");
		String setupCostBuy = Repository.getProperty("setupCostBuy_WithUcOneService");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_WithUcOneService");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_WithUcOneService");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_WithUcOneService");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_WithUcOneService");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_WithUcOneService");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_WithUcOneService");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_WithUcOneService");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_WithUcOneService");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_WithUcOneService");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_WithUcOneService");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_WithUcOneService");
		String ApplyallSDRTariffValue = Repository.getProperty("ApplyallSDRTariffValue_WithUcOneService");
		String minimumDuration = Repository.getProperty("minimumDuration_WithUcOneService");
		String notificationPeriod = Repository.getProperty("notificationPeriod_WithUcOneService");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_WithUcOneService");
		String availableToReseller = Repository.getProperty("availableToReseller_WithUcOneService");
		String assignmentType = Repository.getProperty("assignmentType_WithUcOneService");
		String isprimaryValue = Repository.getProperty("isprimaryValue_WithUcOneService");
		String dependentPackage = Repository.getProperty("dependentPackage_WithUcOneService");
		String keyLampCount = Repository.getProperty("keyLampCount_WithUcOneService");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_WithUcOneService");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_WithUcOneService");
		String nopackageValue=Repository.getProperty("nopackageValue");
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_WithUcOneService");
		String [] parentServiceCheckbox= {};
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_WithUcOneService");
		String deviceRented=Repository.getProperty("deviceRented_WithUcOneService");
		String upgradePriority=Repository.getProperty("upgradePriority_WithUcOneService");
				
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Service,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,parentPackge,parentServiceCheckbox,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	
	
	@Test(priority = 25, enabled = true)
	public void TC_SitePackageownlevel_Distributor_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of Site package [Assignment Type: Hosted Only] in distributor level ");
		this.DataList();
		String availableTo = Repository.getProperty("SitePackageownlevel_availableToReseller");
		String name = Repository.getProperty("SitePackageownlevel_name");
		String description = Repository.getProperty("SitePackageownlevel_description");
		String packagecode = Repository.getProperty("SitePackageownlevel_packagecode");
		String country = Repository.getProperty("SitePackageownlevel_country");
		String packageType = Repository.getProperty("SitePackageownlevel_packageType");
		String primaryPackage = Repository.getProperty("SitePackage_primaryPackage");
		String multipleInstancesValue = Repository.getProperty("SitePackage_multipleInstancesAllowedValue");
		String[]  NumberCategoryCategoryCheckboxValue = {""};
		String[] NumberCategoryLabelName={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("SitePackage_secondaryPackageCheckboxValue");
	    String[] SitePackage_parentPackgeCheckboxValue={"YES"};
	    String[] SitePackage_parentPackge={"Automation HostedOnly Site Pkg [ Hosted ]"};
	    String[] SitePackage_SerivcesCheckboxValue={"YES"};
		String[] SitePackage_Serivces={"BW-Call Centre Queue Basic [Automation HostedOnly Site Pkg]"};
	   	String[]  SitePackage_parentServiceCheckboxValue={};
		String[]  SitePackage_parentService={};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("SitePackage_freeDays");
		String setupCharge = Repository.getProperty("SitePackage_setupCharge");
		String recurringCharge = Repository.getProperty("SitePackage_recurringCharge");
		String ceaseCharge = Repository.getProperty("SitePackage_ceaseCharge");
		String rebateValue = Repository.getProperty("SitePackage_rebateValue");
		String secondaryRebateValue = Repository.getProperty("SitePackage_secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("SitePackage_setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("SitePackage_recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("SitePackage_ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("SitePackage_setupCostBuy");
		String recurringCostBuy = Repository.getProperty("SitePackage_recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("SitePackage_ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("SitePackage_licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("SitePackage_monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("SitePackage_monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("SitePackage_licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("SitePackage_monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("SitePackage_monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("SitePackage_licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("SitePackage_licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("SitePackage_licenseUnassignedCost");
		String ApplyallSDRTariffValue = Repository.getProperty("SitePackage_ApplyallSDRTariffValue");
		String minimumDuration = Repository.getProperty("SitePackage_minimumDuration");
		String notificationPeriod = Repository.getProperty("SitePackage_notificationPeriod");
		String quarantinePeriod = Repository.getProperty("SitePackage_quarantinePeriod");
		String availableToDistributor = Repository.getProperty("availableToDistributor");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("nopackageValue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		
		Package_ADD pkgr = PageFactory.initElements(driver,Package_ADD.class);
		pkgr.Package_PlatformOwner_ADD(availableTo,availableToDistributor,name, description, packagecode, country, packageType, assignmentType,multipleInstancesValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,NumberCategoryCategoryCheckboxValue,NumberCategoryLabelName,SitePackage_SerivcesCheckboxValue,SitePackage_Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,ApplyallSDRTariffValue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,SitePackage_parentPackgeCheckboxValue,SitePackage_parentPackge,SitePackage_parentServiceCheckboxValue,SitePackage_parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	
		
	@AfterClass
	public void quit() {
		this.after();
	}
	}
