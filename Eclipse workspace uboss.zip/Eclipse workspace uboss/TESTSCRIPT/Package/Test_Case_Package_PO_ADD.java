/*-- =============================================
-- Author		: Oommen K Raju
-- Created Date : 03-04-2020
-- Description	: Package creation PO level 
-- Modified by	: Oommen K Raju
-- Modified Date: 15-04-2020
-- Project		: UBOSS-5-0-5
-- =============================================*/

package Package;

import java.awt.AWTException;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.drd.uboss5.testbase.TestBase;
import Login.Login;



public class Test_Case_Package_PO_ADD extends TestBase {

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String PackageCreation;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Package\\CommonData_Package.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\DataList\\Package\\DATALIST_PACKAGE_CREATION_PLATFORMOWNER.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		PackageCreation = Repository.getProperty("Package_Creation");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("Testing scenario for creating package in PO level");
		init();
	}

	@Test(priority = 1, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("Login to Uboss");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("oommen.raju@drd.co.in","P@ss12345678");
	

	}

	@Test(priority = 2, enabled = true)
	public void TC_Package_Creation_PO_Url() throws InterruptedException, IOException {
		Description("Naviagate to Pacakge creation page in PO level");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		this.CommonData();
		pkg.GoToUrl(PackageCreation);
		
				
	}
	
	@Test(priority = 3, enabled =true)
	public void TC_Package_Creation_PO_Validation() throws InterruptedException, IOException, AWTException {
		Description("Checking the validations of pacakge creation page in po level");
		this.DataList();
		String availableToDistributor = Repository.getProperty("availableToDistributor");
		String availableToReseller=Repository.getProperty("availableToReseller");
		String name = Repository.getProperty("name");
		String description = Repository.getProperty("description");
		String packagecode = Repository.getProperty("packagecode");
		String country = Repository.getProperty("country");
		String packageType = Repository.getProperty("packageType");
		String assignmentType = Repository.getProperty("assignmentType");
		String multipleInstancesAllowedValue = Repository.getProperty("multipleInstancesAllowedValue");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue=Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String[] numberCategoryCheckboxValue= {"YES"};
		String[] numberCategory={"   category"};
		String[]ServiceCheckbox= {"YES"};
		String[] Serivces={"BW-Call Centre Agent Basic"};
		String freeDays = Repository.getProperty("freeDays");
		String setupCharge = Repository.getProperty("setupCharge");
		String recurringCharge = Repository.getProperty("recurringCharge");
		String ceaseCharge = Repository.getProperty("ceaseCharge");
		String rebateValue = Repository.getProperty("rebateValue");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("setupCostBuy");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("minimumDuration");
		String notificationPeriod = Repository.getProperty("notificationPeriod");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod");
		String notificationPeriodCheckboxvalue=Repository.getProperty("notificationPeriodCheckboxvalue");
		String primaryPackage=Repository.getProperty("primaryPackage");
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String secondaryPackageCheckboxValue=Repository.getProperty("secondaryPackageCheckboxValue");
		String InvalidData_Test=Repository.getProperty("InvalidData_Test");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD_Validation(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,notificationPeriodCheckboxvalue,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,secondaryPackageCheckboxValue,InvalidData_Test);
	
	}
	
	@Test(priority = 4, enabled = true)
	public void TC_UserPackage_PO_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of User package [Assignment Type: Hosted Only] in PO level");
		this.DataList();
		String availableToDistributor = Repository.getProperty("availableToDistributor");
		String availableToReseller = Repository.getProperty("availableToReseller");
		String name = Repository.getProperty("name");
		String description = Repository.getProperty("description");
		String packagecode = Repository.getProperty("packagecode");
		String country = Repository.getProperty("country");
		String packageType = Repository.getProperty("packageType");
		String assignmentType = Repository.getProperty("assignmentType");
		String multipleInstancesAllowedValue = Repository.getProperty("multipleInstancesAllowedValue");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("nopackageValue");
		String[] numberCategoryCheckboxValue= {"YES"};
		String[] numberCategory={"   category"};
		String[]ServiceCheckbox= {"YES"};
		String[] Serivces= {"BW-Call Waiting"};
		String freeDays = Repository.getProperty("freeDays");
		String setupCharge = Repository.getProperty("setupCharge");
		String recurringCharge = Repository.getProperty("recurringCharge");
		String ceaseCharge = Repository.getProperty("ceaseCharge");
		String rebateValue = Repository.getProperty("rebateValue");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("setupCostBuy");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("minimumDuration");
		String notificationPeriod = Repository.getProperty("notificationPeriod");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod");
		String primaryPackage=Repository.getProperty("primaryPackage");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("secondaryPackageCheckboxValue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 5, enabled = true)
	public void TC_SitePackage_PO_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of Site package [Assignment Type: Hosted Only] in PO level");
		this.DataList();
		String availableToDistributor = Repository.getProperty("SitePackage_availableToDistributor");
		String availableToReseller = Repository.getProperty("SitePackage_availableToReseller");
		String name = Repository.getProperty("SitePackage_name");
		String description = Repository.getProperty("SitePackage_description");
		String packagecode = Repository.getProperty("SitePackage_packagecode");
		String country = Repository.getProperty("SitePackage_country");
		String packageType = Repository.getProperty("SitePackage_packageType");
		String assignmentType = Repository.getProperty("SitePackage_assignmentType");
		String multipleInstancesAllowedValue = Repository.getProperty("SitePackage_multipleInstancesAllowedValue");
		String isprimaryValue = Repository.getProperty("SitePackage_isprimaryValue");
		String dependentPackage = Repository.getProperty("SitePackage_dependentPackage");
		String keyLampCount = Repository.getProperty("SitePackage_keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("SitePackage_canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("SitePackage_canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("SitePackage_nopackageValue");
		String[] SitenumberCategoryCheckboxValue= {""};
		String[] SitePackage_numberCategory={};
		String[] SitePackage_SerivcesCheckbox= {"YES"};
		String[] SitePackage_Serivces={"BW-Call Centre Queue Basic"};
		String freeDays = Repository.getProperty("SitePackage_freeDays");
		String setupCharge = Repository.getProperty("SitePackage_setupCharge");
		String recurringCharge = Repository.getProperty("SitePackage_recurringCharge");
		String ceaseCharge = Repository.getProperty("SitePackage_ceaseCharge");
		String rebateValue = Repository.getProperty("SitePackage_rebateValue");
		String secondaryRebateValue = Repository.getProperty("SitePackage_secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("SitePackage_setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("SitePackage_recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("SitePackage_ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("SitePackage_setupCostBuy");
		String recurringCostBuy = Repository.getProperty("SitePackage_recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("SitePackage_ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("SitePackage_licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("SitePackage_monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("SitePackage_monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("SitePackage_licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("SitePackage_monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("SitePackage_monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("SitePackage_licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("SitePackage_licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("SitePackage_licenseUnassignedCost");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("SitePackage_applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("SitePackage_minimumDuration");
		String notificationPeriod = Repository.getProperty("SitePackage_notificationPeriod");
		String quarantinePeriod = Repository.getProperty("SitePackage_quarantinePeriod");
		String primaryPackage=Repository.getProperty("primaryPackage");
		String [] parentServiceCheckbox= {};
		String [] ParentService= {""};
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("SitesecondaryPackageCheckboxValue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
	
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,SitenumberCategoryCheckboxValue,SitePackage_numberCategory,SitePackage_SerivcesCheckbox,SitePackage_Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 6, enabled = true)
	public void TC_BusinessPackage_PO_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of Busines package [Assignment Type: Hosted Only] in PO level");
		this.DataList();
		String availableToDistributor = Repository.getProperty("BusinessPackage_availableToDistributor");
		String availableToReseller = Repository.getProperty("BusinessPackage_availableToReseller");
		String name = Repository.getProperty("BusinessPackage_name");
		String description = Repository.getProperty("BusinessPackage_description");
		String packagecode = Repository.getProperty("BusinessPackage_packagecode");
		String country = Repository.getProperty("BusinessPackage_country");
		String packageType = Repository.getProperty("BusinessPackage_packageType");
		String assignmentType = Repository.getProperty("BusinessPackage_assignmentType");
		String multipleInstancesAllowedValue = Repository.getProperty("BusinessPackage_multipleInstancesAllowedValue");
		String isprimaryValue = Repository.getProperty("BusinessPackage_isprimaryValue");
		String dependentPackage = Repository.getProperty("BusinessPackage_dependentPackage");
		String keyLampCount = Repository.getProperty("BusinessPackage_keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("BusinessPackage_canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("BusinessPackage_canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("BusinessPackage_nopackageValue");
		
		String[] BusinessPackage_CheckboxValue= {};
		String[] BusinessPackage_numberCategory={};
		String[] BusinessPackageSerivcesCheckbox= {"YES"};
		String[] BusinessPackage_Serivces={"BW-Call Centre Queue Basic"};
		String freeDays = Repository.getProperty("BusinessPackage_freeDays");
		String setupCharge = Repository.getProperty("BusinessPackage_setupCharge");
		String recurringCharge = Repository.getProperty("BusinessPackage_recurringCharge");
		String ceaseCharge = Repository.getProperty("BusinessPackage_ceaseCharge");
		String rebateValue = Repository.getProperty("BusinessPackage_rebateValue");
		String secondaryRebateValue = Repository.getProperty("BusinessPackage_secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("BusinessPackage_setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("BusinessPackage_recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("BusinessPackage_ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("BusinessPackage_setupCostBuy");
		String recurringCostBuy = Repository.getProperty("BusinessPackage_recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("BusinessPackage_ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("BusinessPackage_licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("BusinessPackage_monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("BusinessPackage_monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("BusinessPackage_licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("BusinessPackage_monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("BusinessPackage_monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("BusinessPackage_licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("BusinessPackage_licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("BusinessPackage_licenseUnassignedCost");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("BusinessPackage_applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("BusinessPackage_minimumDuration");
		String notificationPeriod = Repository.getProperty("BusinessPackage_notificationPeriod");
		String quarantinePeriod = Repository.getProperty("BusinessPackage_quarantinePeriod");
		String primaryPackage=Repository.getProperty("primaryPackage");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String secondaryPackageCheckboxValue=Repository.getProperty("BusinessPackagesecondaryPackageCheckboxValue");
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,BusinessPackage_CheckboxValue,BusinessPackage_numberCategory,BusinessPackageSerivcesCheckbox,BusinessPackage_Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 7, enabled = true)
	public void TC_BusinessSitePackage_PO_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of Business Site package [Assignment Type: Hosted Only] in PO level");
		this.DataList();
		String availableToDistributor = Repository.getProperty("BusinessSitePackage_availableToDistributor");
		String availableToReseller = Repository.getProperty("BusinessSitePackage_availableToReseller");
		String name = Repository.getProperty("BusinessSitePackage_name");
		String description = Repository.getProperty("BusinessSitePackage_description");
		String packagecode = Repository.getProperty("BusinessSitePackage_packagecode");
		String country = Repository.getProperty("BusinessSitePackage_country");
		String packageType = Repository.getProperty("BusinessSitePackage_packageType");
		String assignmentType = Repository.getProperty("BusinessSitePackage_assignmentType");
		String multipleInstancesAllowedValue = Repository.getProperty("BusinessSitePackage_multipleInstancesAllowedValue");
		String isprimaryValue = Repository.getProperty("BusinessSitePackage_isprimaryValue");
		String dependentPackage = Repository.getProperty("BusinessSitePackage_dependentPackage");
		String keyLampCount = Repository.getProperty("BusinessSitePackage_keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("BusinessSitePackage_canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("BusinessSitePackage_canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("BusinessSitePackage_nopackageValue");
		
		String[] BusinessSitePackage_numberCategoryCheckboxValue= {};
		String[] BusinessSitePackage_numberCategory={};
		String[] BusinessSitePackageSerivcesCheckbox= {"YES"};
		String[] BusinessSitePackage_Serivces={"BW-Call Centre Queue Basic"};
		String freeDays = Repository.getProperty("BusinessSitePackage_freeDays");
		String setupCharge = Repository.getProperty("BusinessSitePackage_setupCharge");
		String recurringCharge = Repository.getProperty("BusinessSitePackage_recurringCharge");
		String ceaseCharge = Repository.getProperty("BusinessSitePackage_ceaseCharge");
		String rebateValue = Repository.getProperty("BusinessSitePackage_rebateValue");
		String secondaryRebateValue = Repository.getProperty("BusinessSitePackage_secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("BusinessSitePackage_setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("BusinessSitePackage_recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("BusinessSitePackage_ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("BusinessSitePackage_setupCostBuy");
		String recurringCostBuy = Repository.getProperty("BusinessSitePackage_recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("BusinessSitePackage_ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("BusinessSitePackage_licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("BusinessSitePackage_monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("BusinessSitePackage_monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("BusinessSitePackage_licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("BusinessSitePackage_monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("BusinessSitePackage_monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("BusinessSitePackage_licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("BusinessSitePackage_licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("BusinessSitePackage_licenseUnassignedCost");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("BusinessSitePackage_applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("BusinessSitePackage_minimumDuration");
		String notificationPeriod = Repository.getProperty("BusinessSitePackage_notificationPeriod");
		String quarantinePeriod = Repository.getProperty("BusinessSitePackage_quarantinePeriod");
		String primaryPackage=Repository.getProperty("primaryPackage");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("BusinessSitePackageCheckboxValue");
		String [] ParentService= {};
		String [] parentServiceCheckbox= {};
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,BusinessSitePackage_numberCategoryCheckboxValue,BusinessSitePackage_numberCategory,BusinessSitePackageSerivcesCheckbox,BusinessSitePackage_Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 8, enabled = true)
	public void TC_SipOnlyUserPackage_PO_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of User package [Assignment Type: SIP Only] in PO level");
		this.DataList();
		String availableToDistributor = Repository.getProperty("SipOnlyUserPackage_availableToDistributor");
		String availableToReseller = Repository.getProperty("SipOnlyUserPackage_availableToReseller");
		String name = Repository.getProperty("SipOnlyUserPackage_name");
		String description = Repository.getProperty("SipOnlyUserPackage_description");
		String packagecode = Repository.getProperty("SipOnlyUserPackage_packagecode");
		String country = Repository.getProperty("SipOnlyUserPackage_country");
		String packageType = Repository.getProperty("SipOnlyUserPackage_packageType");
		String assignmentType = Repository.getProperty("SipOnlyUserPackage_assignmentType");
		String multipleInstancesAllowedValue = Repository.getProperty("SipOnlyUserPackage_multipleInstancesAllowedValue");
		String isprimaryValue = Repository.getProperty("SipOnlyUserPackage_isprimaryValue");
		String dependentPackage = Repository.getProperty("SipOnlyUserPackage_dependentPackage");
		String keyLampCount = Repository.getProperty("SipOnlyUserPackage_keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("SipOnlyUserPackage_canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("SipOnlyUserPackage_canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("nopackageValue1");
		String[] SipOnlyUserPackage_numberCategoryCheckboxValue= {"YES"};
		String[] SipOnlyUserPackage_numberCategory={"   category"};
		String[] SipOnlyUserPackage_SerivcesCheckboxValue={"YES"};
		String[] SipOnlyUserPackage_Serivces={"BW-Call Waiting"};
		String freeDays = Repository.getProperty("SipOnlyUserPackage_freeDays");
		String setupCharge = Repository.getProperty("SipOnlyUserPackage_setupCharge");
		String recurringCharge = Repository.getProperty("SipOnlyUserPackage_recurringCharge");
		String ceaseCharge = Repository.getProperty("SipOnlyUserPackage_ceaseCharge");
		String rebateValue = Repository.getProperty("SipOnlyUserPackage_rebateValue");
		String secondaryRebateValue = Repository.getProperty("SipOnlyUserPackage_secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("SipOnlyUserPackage_setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("SipOnlyUserPackage_recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("SipOnlyUserPackage_ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("SipOnlyUserPackage_setupCostBuy");
		String recurringCostBuy = Repository.getProperty("SipOnlyUserPackage_recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("SipOnlyUserPackage_ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("SipOnlyUserPackage_licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("SipOnlyUserPackage_monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("SipOnlyUserPackage_monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("SipOnlyUserPackage_licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("SipOnlyUserPackage_monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("SipOnlyUserPackage_monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("SipOnlyUserPackage_licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("SipOnlyUserPackage_licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("SipOnlyUserPackage_licenseUnassignedCost");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("SipOnlyUserPackage_applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("SipOnlyUserPackage_minimumDuration");
		String notificationPeriod = Repository.getProperty("SipOnlyUserPackage_notificationPeriod");
		String quarantinePeriod = Repository.getProperty("SipOnlyUserPackage_quarantinePeriod");
		String primaryPackage=Repository.getProperty("primaryPackage");
		String [] ParentPackage= {};
		String [] ParentPackageCheckbox= {""};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("SipOnlyUserPackagesecondaryPackageCheckboxValue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,SipOnlyUserPackage_numberCategoryCheckboxValue,SipOnlyUserPackage_numberCategory,SipOnlyUserPackage_SerivcesCheckboxValue,SipOnlyUserPackage_Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackage,ParentPackageCheckbox,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 9, enabled = true)
	public void TC_UserPackage_Both_PO_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of User package [Assignment Type: Both] in PO level");
		this.DataList();
		String availableToDistributor = Repository.getProperty("BothUserPackage_availableToDistributor");
		String availableToReseller = Repository.getProperty("BothUserPackage_availableToReseller");
		String name = Repository.getProperty("BothUserPackage_name");
		String description = Repository.getProperty("BothUserPackage_description");
		String packagecode = Repository.getProperty("BothUserPackage_packagecode");
		String country = Repository.getProperty("BothUserPackage_country");
		String packageType = Repository.getProperty("BothUserPackage_packageType");
		String assignmentType = Repository.getProperty("BothUserPackage_assignmentType");
		String multipleInstancesAllowedValue = Repository.getProperty("BothUserPackage_multipleInstancesAllowedValue");
		String isprimaryValue = Repository.getProperty("BothUserPackage_isprimaryValue");
		String dependentPackage = Repository.getProperty("BothUserPackage_dependentPackage");
		String keyLampCount = Repository.getProperty("BothUserPackage_keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("BothUserPackage_canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("BothUserPackage_canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("BothUserPackage_nopackageValue");
		String[] BothUserPackage_numberCategoryCheckboxValue={"YES"};
		String[] BothUserPackage_numberCategory={"   category"};
		String[] BothUserPackage_SerivcesCheckboxVlaue={"YES"};
		String[] BothUserPackage_Serivces={"BW-Call Waiting"};
		String freeDays = Repository.getProperty("BothUserPackage_freeDays");
		String setupCharge = Repository.getProperty("BothUserPackage_setupCharge");
		String recurringCharge = Repository.getProperty("BothUserPackage_recurringCharge");
		String ceaseCharge = Repository.getProperty("BothUserPackage_ceaseCharge");
		String rebateValue = Repository.getProperty("BothUserPackage_rebateValue");
		String secondaryRebateValue = Repository.getProperty("BothUserPackage_secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("BothUserPackage_setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("BothUserPackage_recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("BothUserPackage_ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("BothUserPackage_setupCostBuy");
		String recurringCostBuy = Repository.getProperty("BothUserPackage_recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("BothUserPackage_ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("BothUserPackage_licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("BothUserPackage_monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("BothUserPackage_monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("BothUserPackage_licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("BothUserPackage_monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("BothUserPackage_monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("BothUserPackage_licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("BothUserPackage_licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("BothUserPackage_licenseUnassignedCost");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("BothUserPackage_applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("BothUserPackage_minimumDuration");
		String notificationPeriod = Repository.getProperty("BothUserPackage_notificationPeriod");
		String quarantinePeriod = Repository.getProperty("BothUserPackage_quarantinePeriod");
		String primaryPackage=Repository.getProperty("primaryPackage");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("BothUserPackagesecondaryPackageCheckboxValue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,BothUserPackage_numberCategoryCheckboxValue,BothUserPackage_numberCategory,BothUserPackage_SerivcesCheckboxVlaue,BothUserPackage_Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelService,ownlevelServiceCheckbox,secondaryPackageCheckboxValue,	commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 10, enabled = true)
	public void TC_UserPackage_SecondarySelected_Hostedonly_PO_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of User package [Assignment Type: HostedOnly and secondary package selected] in PO level");
		this.DataList();
		String availableToDistributor = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_availableToDistributor");
		String availableToReseller = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_availableToReseller");
		String name = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_name");
		String description = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_description");
		String packagecode = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_packagecode");
		String country = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_country");
		String packageType = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_packageType");
		String assignmentType = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_assignmentType");
		String multipleInstancesAllowedValue = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_multipleInstancesAllowedValue");
		String isprimaryValue = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_isprimaryValue");
		String dependentPackage = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_dependentPackage");
		String keyLampCount = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("HostedOnlySecondarySelectedUserPackage_canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("nopackageValue");
		String HostedOnlySecondarySelectedUserPackagenopackageValue=Repository.getProperty("HostedOnlySecondarySelectedUserPackage_canBeAssignedCheckboxValue");
		String[] HostedOnlySecondarySelectedUserPackage_numberCategoryChecboxValue={"YES"};
		String[] HostedOnlySecondarySelectedUserPackage_numberCategory={"   category"};
		String[] HostedOnlySecondarySelectedUserPackage_SerivcesCheckboxvalue={"YES"};
		String[] HostedOnlySecondarySelectedUserPackage_Serivces={"BW-Call Waiting"};
		String freeDays = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_freeDays");
		String setupCharge = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_setupCharge");
		String recurringCharge = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_recurringCharge");
		String ceaseCharge = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_ceaseCharge");
		String rebateValue = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_rebateValue");
		String secondaryRebateValue = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_setupCostBuy");
		String recurringCostBuy = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_licenseUnassignedCost");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("HostedOnlySecondarySelectedUserPackage_applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_minimumDuration");
		String notificationPeriod = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_notificationPeriod");
		String quarantinePeriod = Repository.getProperty("HostedOnlySecondarySelectedUserPackage_quarantinePeriod");
		String primaryPackage=Repository.getProperty("primaryPackage");		
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("HostedOnlySecondarySelectedCheckboxValue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,HostedOnlySecondarySelectedUserPackage_numberCategoryChecboxValue,HostedOnlySecondarySelectedUserPackage_numberCategory,HostedOnlySecondarySelectedUserPackage_SerivcesCheckboxvalue,HostedOnlySecondarySelectedUserPackage_Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority
				);
	}
	
	
	@Test(priority = 11, enabled = true)
	public void TC_UserPackage_SecondarySelected_Siponly_PO_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of User package [Assignment Type: Sip Only and secondary package selected] in PO level");
		this.DataList();
		String availableToDistributor = Repository.getProperty("SipOnlySecondarySelectedUserPackage_availableToDistributor");
		String availableToReseller = Repository.getProperty("SipOnlySecondarySelectedUserPackage_availableToReseller");
		String name = Repository.getProperty("SipOnlySecondarySelectedUserPackage_name");
		String description = Repository.getProperty("SipOnlySecondarySelectedUserPackage_description");
		String packagecode = Repository.getProperty("SipOnlySecondarySelectedUserPackage_packagecode");
		String country = Repository.getProperty("SipOnlySecondarySelectedUserPackage_country");
		String packageType = Repository.getProperty("SipOnlySecondarySelectedUserPackage_packageType");
		String assignmentType = Repository.getProperty("SipOnlySecondarySelectedUserPackage_assignmentType");
		String multipleInstancesAllowedValue = Repository.getProperty("SipOnlySecondarySelectedUserPackage_multipleInstancesAllowedValue");
		String isprimaryValue = Repository.getProperty("SipOnlySecondarySelectedUserPackage_isprimaryValue");
		String dependentPackage = Repository.getProperty("SipOnlySecondarySelectedUserPackage_dependentPackage");
		String keyLampCount = Repository.getProperty("SipOnlySecondarySelectedUserPackage_keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("SipOnlySecondarySelectedUserPackage_canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("SipOnlySecondarySelectedUserPackage_canBeAssignedCheckboxValue");
		String nopackageValue=Repository.getProperty("SipOnlySecondarySelectedUserPackage_nopackageValue");
		String[] SipOnlySecondarySelectedUserPackage_numberCategoryValue={"YES"};
		String[] SipOnlySecondarySelectedUserPackage_numberCategory={"   category"};
		String[] SipOnlySecondarySelectedUserPackage_SerivcesValue={"YES"};
		String[] SipOnlySecondarySelectedUserPackage_Serivces={"BW-Call Waiting"};
		String freeDays = Repository.getProperty("SipOnlySecondarySelectedUserPackage_freeDays");
		String setupCharge = Repository.getProperty("SipOnlySecondarySelectedUserPackage_setupCharge");
		String recurringCharge = Repository.getProperty("SipOnlySecondarySelectedUserPackage_recurringCharge");
		String ceaseCharge = Repository.getProperty("SipOnlySecondarySelectedUserPackage_ceaseCharge");
		String rebateValue = Repository.getProperty("SipOnlySecondarySelectedUserPackage_rebateValue");
		String secondaryRebateValue = Repository.getProperty("SipOnlySecondarySelectedUserPackage_secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("SipOnlySecondarySelectedUserPackage_setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("SipOnlySecondarySelectedUserPackage_recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("SipOnlySecondarySelectedUserPackage_ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("SipOnlySecondarySelectedUserPackage_setupCostBuy");
		String recurringCostBuy = Repository.getProperty("SipOnlySecondarySelectedUserPackage_recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("SipOnlySecondarySelectedUserPackage_ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("SipOnlySecondarySelectedUserPackage_licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("SipOnlySecondarySelectedUserPackage_monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("SipOnlySecondarySelectedUserPackage_monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("SipOnlySecondarySelectedUserPackage_licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("SipOnlySecondarySelectedUserPackage_monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("SipOnlySecondarySelectedUserPackage_monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("SipOnlySecondarySelectedUserPackage_licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("SipOnlySecondarySelectedUserPackage_licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("SipOnlySecondarySelectedUserPackage_licenseUnassignedCost");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("SipOnlySecondarySelectedUserPackage_applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("SipOnlySecondarySelectedUserPackage_minimumDuration");
		String notificationPeriod = Repository.getProperty("SipOnlySecondarySelectedUserPackage_notificationPeriod");
		String quarantinePeriod = Repository.getProperty("SipOnlySecondarySelectedUserPackage_quarantinePeriod");
		String primaryPackage=Repository.getProperty("primaryPackage");	
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("SipOnlySecondarySelectedUserPackageCheckboxValue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented=Repository.getProperty("deviceRented");
		String upgradePriority=Repository.getProperty("upgradePriority");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,SipOnlySecondarySelectedUserPackage_numberCategoryValue,SipOnlySecondarySelectedUserPackage_numberCategory,SipOnlySecondarySelectedUserPackage_SerivcesValue,SipOnlySecondarySelectedUserPackage_Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 12, enabled = true)
	public void TC_OWNSecondaryPackage_PO_ADD() throws InterruptedException, IOException, AWTException {	
		Description("check whether there is an option for cretaing own secondary package in PO without any parent package");
		this.DataList();
		String availableToDistributor = Repository.getProperty("availableToDistributor_OwnSecondaryPO");
		String availableToReseller = Repository.getProperty("availableToReseller_OwnSecondaryPO");
		String name = Repository.getProperty("name_OwnSecondaryPO");
		String description = Repository.getProperty("description_OwnSecondaryPO");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryPO");
		String country = Repository.getProperty("country_OwnSecondaryPO");
		String packageType = Repository.getProperty("packageType_OwnSecondaryPO");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryPO");
		String multipleInstancesAllowedValue = Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryPO");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryPO");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryPO");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryPO");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryPO");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryPO");
		String nopackageValue=Repository.getProperty("nopackageValue");
		String[] numberCategoryCheckboxValue={""};
		String[] numberCategory={"   "};
		String[]ServiceCheckbox= {"YES"};
		String[] Serivces= {"Webex Meeting 3"};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryPO");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryPO");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryPO");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryPO");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryPO");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryPO");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryPO");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryPO");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryPO");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryPO");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryPO");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryPO");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryPO");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryPO");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryPO");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryPO");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryPO");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryPO");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryPO");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryPO");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryPO");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryPO");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryPO");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryPO");
		String primaryPackage=Repository.getProperty("primaryPackage_OwnSecondaryPO");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryPO");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryPO");
		String deviceRented=Repository.getProperty("deviceRented_OwnSecondaryPO");
		String upgradePriority=Repository.getProperty("upgradePriority_OwnSecondaryPO");
		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 13, enabled = true)
	public void TC_OWNSecondaryPackage_PO_ADD_AlreadyExistCheck() throws InterruptedException, IOException, AWTException {	
		Description("check whether there is an option for cretaing already existing own secondary package in PO without any parent package");
		this.DataList();
		String availableToDistributor = Repository.getProperty("availableToDistributor_OwnSecondaryPO");
		String availableToReseller = Repository.getProperty("availableToReseller_OwnSecondaryPO");
		String name = Repository.getProperty("name_OwnSecondaryPO");
		String description = Repository.getProperty("description_OwnSecondaryPO");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryPO");
		String country = Repository.getProperty("country_OwnSecondaryPO");
		String packageType = Repository.getProperty("packageType_OwnSecondaryPO");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryPO");
		String multipleInstancesAllowedValue = Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryPO");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryPO");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryPO");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryPO");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryPO");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryPO");
		String nopackageValue=Repository.getProperty("nopackageValue_OwnSecondaryPO");
		String[] numberCategoryCheckboxValue= {""};
		String[] numberCategory={"   "};
		String[]ServiceCheckbox= {"YES"};
		String[] Serivces= {"Webex Meeting 3"};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryPO");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryPO");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryPO");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryPO");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryPO");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryPO");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryPO");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryPO");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryPO");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryPO");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryPO");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryPO");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryPO");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryPO");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryPO");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryPO");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryPO");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryPO");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryPO");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryPO");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryPO");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryPO");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryPO");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryPO");
		String primaryPackage=Repository.getProperty("primaryPackage_OwnSecondaryPO");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryPO");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryPO");
		String deviceRented=Repository.getProperty("deviceRented_OwnSecondaryPO");
		String upgradePriority=Repository.getProperty("upgradePriority_OwnSecondaryPO");
		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 14, enabled = true)
	public void TC_OWNSecondaryPackage_PO_ADD_MultipleWebbexService() throws InterruptedException, IOException, AWTException {	
		Description("check whether multiple webex services can be added in the same package");
		this.DataList();
		String availableToDistributor = Repository.getProperty("availableToDistributor_OwnSecondaryPO");
		String availableToReseller = Repository.getProperty("availableToReseller_OwnSecondaryPO");
		String name = Repository.getProperty("name_OwnSecondaryPO");
		String description = Repository.getProperty("description_OwnSecondaryPO");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryPO");
		String country = Repository.getProperty("country_OwnSecondaryPO");
		String packageType = Repository.getProperty("packageType_OwnSecondaryPO");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryPO");
		String multipleInstancesAllowedValue = Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryPO");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryPO");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryPO");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryPO");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryPO");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryPO");
		String nopackageValue=Repository.getProperty("nopackageValue_OwnSecondaryPO");
		String[] numberCategoryCheckboxValue= {""};
		String[] numberCategory={"   "};
		String[]ServiceCheckbox= {"YES","YES"};
		String[] Serivces= {"WebeSoftphoneOnly","Webex Meeting 3"};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryPO");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryPO");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryPO");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryPO");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryPO");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryPO");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryPO");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryPO");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryPO");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryPO");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryPO");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryPO");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryPO");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryPO");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryPO");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryPO");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryPO");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryPO");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryPO");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryPO");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryPO");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryPO");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryPO");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryPO");
		String primaryPackage=Repository.getProperty("primaryPackage_OwnSecondaryPO");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryPO");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryPO");
		String deviceRented=Repository.getProperty("deviceRented_OwnSecondaryPO");
		String upgradePriority=Repository.getProperty("upgradePriority_OwnSecondaryPO");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelService,ownlevelServiceCheckbox,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 15, enabled = true)
	public void TC_OWNSecondaryPackage_PO_ADD_NOService() throws InterruptedException, IOException, AWTException {	
		Description("Check whether it is able to create own secondary package without adding any services when parent package is not selectd");
		this.DataList();
		String availableToDistributor = Repository.getProperty("availableToDistributor_OwnSecondaryPO");
		String availableToReseller = Repository.getProperty("availableToReseller_OwnSecondaryPO");
		String name = Repository.getProperty("name_OwnSecondaryPO");
		String description = Repository.getProperty("description_OwnSecondaryPO");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryPO");
		String country = Repository.getProperty("country_OwnSecondaryPO");
		String packageType = Repository.getProperty("packageType_OwnSecondaryPO");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryPO");
		String multipleInstancesAllowedValue = Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryPO");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryPO");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryPO");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryPO");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryPO");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryPO");
		String nopackageValue=Repository.getProperty("nopackageValue_OwnSecondaryPO2");
		
		String[] numberCategoryCheckboxValue= {""};
		String[] numberCategory={"   "};
		String[]ServiceCheckbox= {""};
		String[] Serivces= {""};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryPO");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryPO");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryPO");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryPO");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryPO");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryPO");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryPO");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryPO");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryPO");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryPO");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryPO");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryPO");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryPO");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryPO");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryPO");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryPO");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryPO");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryPO");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryPO");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryPO");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryPO");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryPO");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryPO");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryPO");
		String primaryPackage=Repository.getProperty("primaryPackage_OwnSecondaryPO");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryPO");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryPO");
		String deviceRented=Repository.getProperty("deviceRented_OwnSecondaryPO");
		String upgradePriority=Repository.getProperty("upgradePriority_OwnSecondaryPO");
		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 16, enabled = true)
	public void TC_OWNSecondaryPackage_POr_ADD_BothBWAndWebex() throws InterruptedException, IOException, AWTException {	
		Description("check whether combination of both webex and broadworks services can be added within the same package");
		this.DataList();
		String availableToDistributor = Repository.getProperty("aavailableToDistributor_OwnSecondaryPO_BothWebexAndBW");
		String availableToReseller = Repository.getProperty("availableToReseller_OwnSecondaryPO_BothWebexAndBW");
		String name = Repository.getProperty("name_OwnSecondaryPO_BothWebexAndBW");
		String description = Repository.getProperty("description_OwnSecondaryPO_BothWebexAndBW");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryPO_BothWebexAndBW");
		String country = Repository.getProperty("country_OwnSecondaryPO_BothWebexAndBW");
		String packageType = Repository.getProperty("packageType_OwnSecondaryPO_BothWebexAndBW");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryPO_BothWebexAndBW");
		String multipleInstancesAllowedValue = Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryPO_BothWebexAndBW");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryPO_BothWebexAndBW");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryPO_BothWebexAndBW");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryPO_BothWebexAndBW");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryPO_BothWebexAndBW");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryPO_BothWebexAndBW");
		String nopackageValue=Repository.getProperty("nopackageValue_OwnSecondaryPO_BothWebexAndBW");
		String[] numberCategoryCheckboxValue= {""};
		String[] numberCategory={"   "};
		String[]ServiceCheckbox= {"YES","YES"};
		String[] Serivces= {"BW-Call Waiting","Webex Meeting 3"};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryPO_BothWebexAndBW");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryPO_BothWebexAndBW");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryPO_BothWebexAndBW");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryPO_BothWebexAndBW");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryPO_BothWebexAndBW");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryPO_BothWebexAndBW");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryPO_BothWebexAndBW");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryPO_BothWebexAndBW");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryPO_BothWebexAndBW");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryPO_BothWebexAndBW");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryPO_BothWebexAndBW");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryPO_BothWebexAndBW");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryPO_BothWebexAndBW");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryPO_BothWebexAndBW");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryPO_BothWebexAndBW");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryPO_BothWebexAndBW");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryPO_BothWebexAndBW");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryPO_BothWebexAndBW");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryPO_BothWebexAndBW");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryPO_BothWebexAndBW");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryPO_BothWebexAndBW");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryPO_BothWebexAndBW");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryPO_BothWebexAndBW");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryPO_BothWebexAndBW");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryPO_BothWebexAndBW");
		String primaryPackage=Repository.getProperty("primaryPackage_OwnSecondaryPO_BothWebexAndBW");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryPO_BothWebexAndBW");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryPO_BothWebexAndBW");
		String deviceRented=Repository.getProperty("deviceRented_OwnSecondaryPO_BothWebexAndBW");
		String upgradePriority=Repository.getProperty("upgradePriority_OwnSecondaryPO_BothWebexAndBW");
		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 17, enabled = true)
	public void TC_UserPackage_PO_ADD_Withdevice() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of user package with device without selecting secondary package in PO level");
		this.DataList();
		String availableToDistributor = Repository.getProperty("availableToDistributorPkgWithDevice");
		String availableToReseller = Repository.getProperty("availableToResellerPkgWithDevice");
		String name = Repository.getProperty("namePkgWithDevice");
		String description = Repository.getProperty("descriptionPkgWithDevice");
		String packagecode = Repository.getProperty("packagecodePkgWithDevice");
		String country = Repository.getProperty("countryPkgWithDevice");
		String packageType = Repository.getProperty("packageTypePkgWithDevice");
		String assignmentType = Repository.getProperty("assignmentTypePkgWithDevice");
		String multipleInstancesAllowedValue = Repository.getProperty("multipleInstancesAllowedValuePkgWithDevice");
		String isprimaryValue = Repository.getProperty("isprimaryValuePkgWithDevice");
		String dependentPackage = Repository.getProperty("dependentPackagePkgWithDevice");
		String keyLampCount = Repository.getProperty("keyLampCountPkgWithDevice");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValuePkgWithDevice");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValuePkgWithDevice");
		String nopackageValue=Repository.getProperty("nopackageValuePkgWithDevice");
		String[] numberCategoryCheckboxValue= {"YES"};
		String[] numberCategory={"   category"};
		String[]ServiceCheckbox= {"YES"};
		String[] Serivces= {"BW-Call Waiting"};
		String freeDays = Repository.getProperty("freeDaysPkgWithDevice");
		String setupCharge = Repository.getProperty("setupChargePkgWithDevice");
		String recurringCharge = Repository.getProperty("recurringChargePkgWithDevice");
		String ceaseCharge = Repository.getProperty("ceaseChargePkgWithDevice");
		String rebateValue = Repository.getProperty("rebateValuePkgWithDevice");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValuePkgWithDevice");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCodePkgWithDevice");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCodePkgWithDevice");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCodePkgWithDevice");
		String setupCostBuy = Repository.getProperty("setupCostBuyPkgWithDevice");
		String recurringCostBuy = Repository.getProperty("recurringCostBuyPkgWithDevice");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuyPkgWithDevice");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePricePkgWithDevice");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssignedPkgWithDevice");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassignedPkgWithDevice");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominalPkgWithDevice");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominalPkgWithDevice");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominalPkgWithDevice");
		String licenseSetupCost = Repository.getProperty("licenseSetupCostPkgWithDevice");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCostPkgWithDevice");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCostPkgWithDevice");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvaluePkgWithDevice");
		String minimumDuration = Repository.getProperty("minimumDurationPkgWithDevice");
		String notificationPeriod = Repository.getProperty("notificationPeriodPkgWithDevice");
		String quarantinePeriod = Repository.getProperty("quarantinePeriodPkgWithDevice");
		String primaryPackage=Repository.getProperty("primaryPackagePkgWithDevice");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("secondaryPackageCheckboxValuePkgWithDevice");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_ResellerPkgWithDevice");
		String deviceRented=Repository.getProperty("deviceRentedPkgWithDevice");
		String upgradePriority=Repository.getProperty("upgradePriorityPkgWithDevice");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
		
	@Test(priority = 18, enabled = true)
	public void TC_UserPackage_PO_ADD_Nopackage() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of user package with No package selected  in PO level");
		this.DataList();
		String availableToDistributor = Repository.getProperty("availableToDistributorNoPackage");
		String availableToReseller = Repository.getProperty("availableToResellerNoPackage");
		String name = Repository.getProperty("nameNoPackage");
		String description = Repository.getProperty("descriptionNoPackage");
		String packagecode = Repository.getProperty("packagecodeNoPackage");
		String country = Repository.getProperty("countryNoPackage");
		String packageType = Repository.getProperty("packageTypeNoPackage");
		String assignmentType = Repository.getProperty("assignmentTypeNoPackage");
		String multipleInstancesAllowedValue = Repository.getProperty("multipleInstancesAllowedValueNoPackage");
		String isprimaryValue = Repository.getProperty("isprimaryValueNoPackage");
		String dependentPackage = Repository.getProperty("dependentPackageNoPackage");
		String keyLampCount = Repository.getProperty("keyLampCountNoPackage");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValueNoPackage");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValueNoPackage");
		String nopackageValue=Repository.getProperty("nopackageValueNoPackage");
		String[] numberCategoryCheckboxValue= {"YES"};
		String[] numberCategory={"   category"};
		String[]ServiceCheckbox= {"YES"};
		String[] Serivces= {"BW-Call Waiting"};
		
		String freeDays = Repository.getProperty("freeDaysNoPackage");
		String setupCharge = Repository.getProperty("setupChargeNoPackage");
		String recurringCharge = Repository.getProperty("recurringChargeNoPackage");
		String ceaseCharge = Repository.getProperty("ceaseChargeNoPackage");
		String rebateValue = Repository.getProperty("rebateValueNoPackage");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValueNoPackage");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCodeNoPackage");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCodeNoPackage");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCodeNoPackage");
		String setupCostBuy = Repository.getProperty("setupCostBuyNoPackage");
		String recurringCostBuy = Repository.getProperty("recurringCostBuyNoPackage");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuyNoPackage");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePriceNoPackage");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssignedNoPackage");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassignedNoPackage");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominalNoPackage");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominalNoPackage");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominalNoPackage");
		String licenseSetupCost = Repository.getProperty("licenseSetupCostNoPackage");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCostNoPackage");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCostNoPackage");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalueNoPackage");
		String minimumDuration = Repository.getProperty("minimumDurationNoPackage");
		String notificationPeriod = Repository.getProperty("notificationPeriodNoPackage");
		String quarantinePeriod = Repository.getProperty("quarantinePeriodNoPackage");
		String primaryPackage=Repository.getProperty("primaryPackageNoPackage");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("secondaryPackageCheckboxValueNoPackage");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_ResellerNoPackage");
		String deviceRented=Repository.getProperty("deviceRentedNoPackage");
		String upgradePriority=Repository.getProperty("upgradePriorityNoPackage");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 19, enabled = true)
	public void TC_UserPackage_PO_ADD_Nopackage2() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of user package with No package for the purpose of checking recreted No package with own bundle service can able to edit in child levels");
		this.DataList();
		String availableToDistributor = Repository.getProperty("availableToDistributorNoPackage");
		String availableToReseller = Repository.getProperty("availableToResellerNoPackage");
		String name = Repository.getProperty("nameNoPackage2");
		String description = Repository.getProperty("descriptionNoPackage");
		String packagecode = Repository.getProperty("packagecodeNoPackage");
		String country = Repository.getProperty("countryNoPackage");
		String packageType = Repository.getProperty("packageTypeNoPackage");
		String assignmentType = Repository.getProperty("assignmentTypeNoPackage");
		String multipleInstancesAllowedValue = Repository.getProperty("multipleInstancesAllowedValueNoPackage");
		String isprimaryValue = Repository.getProperty("isprimaryValueNoPackage");
		String dependentPackage = Repository.getProperty("dependentPackageNoPackage");
		String keyLampCount = Repository.getProperty("keyLampCountNoPackage");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValueNoPackage");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValueNoPackage");
		String nopackageValue=Repository.getProperty("nopackageValueNoPackage");
		String[] numberCategoryCheckboxValue= {"NO"};
		String[] numberCategory={"   category"};
		String[]ServiceCheckbox= {"NO"};
		String[] Serivces= {"BW-Call Waiting"};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDaysNoPackage");
		String setupCharge = Repository.getProperty("setupChargeNoPackage");
		String recurringCharge = Repository.getProperty("recurringChargeNoPackage");
		String ceaseCharge = Repository.getProperty("ceaseChargeNoPackage");
		String rebateValue = Repository.getProperty("rebateValueNoPackage");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValueNoPackage");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCodeNoPackage");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCodeNoPackage");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCodeNoPackage");
		String setupCostBuy = Repository.getProperty("setupCostBuyNoPackage");
		String recurringCostBuy = Repository.getProperty("recurringCostBuyNoPackage");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuyNoPackage");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePriceNoPackage");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssignedNoPackage");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassignedNoPackage");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominalNoPackage");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominalNoPackage");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominalNoPackage");
		String licenseSetupCost = Repository.getProperty("licenseSetupCostNoPackage");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCostNoPackage");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCostNoPackage");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalueNoPackage");
		String minimumDuration = Repository.getProperty("minimumDurationNoPackage");
		String notificationPeriod = Repository.getProperty("notificationPeriodNoPackage");
		String quarantinePeriod = Repository.getProperty("quarantinePeriodNoPackage");
		String primaryPackage=Repository.getProperty("primaryPackageNoPackage");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String secondaryPackageCheckboxValue=Repository.getProperty("secondaryPackageCheckboxValueNoPackage");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_ResellerNoPackage");
		String deviceRented=Repository.getProperty("deviceRentedNoPackage");
		String upgradePriority=Repository.getProperty("upgradePriorityNoPackage");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 20, enabled = true)
	public void TC_UserPackage_PO_ADD_WithUcOneService() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of User package [Assignment Type: Hosted Only] in PO level With UCOneService ");
		this.DataList();
		String availableToDistributor = Repository.getProperty("availableToDistributor_WithUcOneService");
		String availableToReseller = Repository.getProperty("availableToReseller_WithUcOneService");
		String name = Repository.getProperty("name_WithUcOneService");
		String description = Repository.getProperty("description_WithUcOneService");
		String packagecode = Repository.getProperty("packagecode_WithUcOneService");
		String country = Repository.getProperty("country_WithUcOneService");
		String packageType = Repository.getProperty("packageType_WithUcOneService");
		String assignmentType = Repository.getProperty("assignmentType_WithUcOneService");
		String multipleInstancesAllowedValue = Repository.getProperty("multipleInstancesAllowedValue_WithUcOneService");
		String isprimaryValue = Repository.getProperty("isprimaryValue_WithUcOneService");
		String dependentPackage = Repository.getProperty("dependentPackage_WithUcOneService");
		String keyLampCount = Repository.getProperty("keyLampCount_WithUcOneService");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_WithUcOneService");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_WithUcOneService");
		String nopackageValue=Repository.getProperty("nopackageValue_WithUcOneService");
		String[] numberCategoryCheckboxValue= {"YES"};
		String[] numberCategory={"   category"};
		String[]ServiceCheckbox= {"YES"};
		String[] Serivces= {"VIP-UC-One Trio - Softphone Only"};
		String freeDays = Repository.getProperty("freeDays_WithUcOneService");
		String setupCharge = Repository.getProperty("setupCharge_WithUcOneService");
		String recurringCharge = Repository.getProperty("recurringCharge_WithUcOneService");
		String ceaseCharge = Repository.getProperty("ceaseCharge_WithUcOneService");
		String rebateValue = Repository.getProperty("rebateValue_WithUcOneService");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_WithUcOneService");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_WithUcOneService");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_WithUcOneService");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_WithUcOneService");
		String setupCostBuy = Repository.getProperty("setupCostBuy_WithUcOneService");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_WithUcOneService");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_WithUcOneService");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_WithUcOneService");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_WithUcOneService");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_WithUcOneService");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_WithUcOneService");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_WithUcOneService");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_WithUcOneService");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_WithUcOneService");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_WithUcOneService");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_WithUcOneService");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_WithUcOneService");
		String minimumDuration = Repository.getProperty("minimumDuration_WithUcOneService");
		String notificationPeriod = Repository.getProperty("notificationPeriod_WithUcOneService");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_WithUcOneService");
		String primaryPackage=Repository.getProperty("primaryPackage_WithUcOneService");
		String [] ParentPackageCheckbox= {""};
		String [] ParentPackage= {""};
		String [] parentServiceCheckbox= {};
		String [] ParentService= {};
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String secondaryPackageCheckboxValue=Repository.getProperty("secondaryPackageCheckboxValue_WithUcOneService");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_WithUcOneService");
		String deviceRented=Repository.getProperty("deviceRented_WithUcOneService");
		String upgradePriority=Repository.getProperty("upgradePriority_WithUcOneService");
		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableToDistributor,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,ServiceCheckbox,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	
	
	
	
	@AfterClass
	public void quit() {
		this.after();
	}
	}
