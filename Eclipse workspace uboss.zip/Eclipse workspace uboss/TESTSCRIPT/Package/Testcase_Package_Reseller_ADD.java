/*-- =============================================
-- Author		: Oommen K Raju
-- Created Date : 6-04-2020
-- Description	: Package Recreation Reseller level
-- Modified by	: Oommen K Raju
-- Modified Date: 18-05-2020
-- Project		: UBOSS-5-0-5
-- =============================================*/

package Package;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.drd.uboss5.testbase.TestBase;

import Login.Login;

public class Testcase_Package_Reseller_ADD extends TestBase {

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Package_Creation_Reseller;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Package\\CommonData_Package.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\DataList\\Package\\DATALIST_PACKAGE_CREATION_RESELLER.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Package_Creation_Reseller = Repository.getProperty("Package_Creation_Reseller");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("Testing scenario for creating package in Reseller level");
		init();
	}

	@Test(priority = 40, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("Login to Uboss");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("oommen.raju@drd.co.in","P@ss12345678");

	}

	@Test(priority = 41, enabled = true)
	public void TC_Package_Reseller_Url() throws InterruptedException, IOException {
		Description("Naviagate to Pacakge creation page in Reseller level");
		Package_ADD pkgr = PageFactory.initElements(driver, Package_ADD.class);
		this.CommonData();
		pkgr.GoToUrl(Package_Creation_Reseller);

	}
	
	@Test(priority = 42, enabled = true)
	public void TC_Package_Reseller_Validation() throws InterruptedException, IOException, AWTException {	
		Description("Checking the validations of pacakge creation page in Reseller level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo");
		String name = Repository.getProperty("name");
		String description = Repository.getProperty("description");
		String packagecode = Repository.getProperty("packagecode");
		String packageType = Repository.getProperty("packageType");
		String primaryPackage=Repository.getProperty("primaryPackage");
		String[] numberCategoryCheckboxValue = {"YES"};
		String[] numberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue");
		String [] ParentPackageCheckbox= {};
		String[] ParentPackage={""};
		String[] SerivcesCheckboxValue={"YES"};
	    String[] Serivces={"BW-Call Waiting [July 7 Package]"};
	    String parentServiceCheckbox[]={"YES"};
	    String[]  ParentService={"BundleUser"};
	    String freeDays = Repository.getProperty("freeDays");
		String setupCharge = Repository.getProperty("setupCharge");
		String recurringCharge = Repository.getProperty("recurringCharge");
		String ceaseCharge = Repository.getProperty("ceaseCharge");
		String rebateValue = Repository.getProperty("rebateValue");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("setupCostBuy");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost");
		String minimumDuration = Repository.getProperty("minimumDuration");
		String notificationPeriod = Repository.getProperty("notificationPeriod");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod");
		String availableToDistributor=Repository.getProperty("availableToDistributor");	
		String country=Repository.getProperty("country");	
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValue");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String notificationPeriodCheckboxvalue=Repository.getProperty("notificationPeriodCheckboxvalue");
		String InvalidData_Test=Repository.getProperty("InvalidData_Test");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD_Validation(availableToDistributor,availableTo,name, description, packagecode,country,packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,notificationPeriodCheckboxvalue,primaryPackage,ParentPackageCheckbox,ParentPackage,parentServiceCheckbox,ParentService,secondaryPackageCheckboxValue,InvalidData_Test);
	
	}
	@Test(priority = 43, enabled = true)
	public void TC_UserPackage_Reseller_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of package without selecting secondary package  in Reseller level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo");
		String name = Repository.getProperty("name");
		String description = Repository.getProperty("description");
		String packagecode = Repository.getProperty("packagecode");
		String packageType = Repository.getProperty("packageType");
		String primaryPackage = Repository.getProperty("primaryPackage");
		String[] numberCategoryCheckboxValue = {"YES"};
		String[] numberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue");
		String[] parentPackgeCheckboxValue={""};
		String[] parentPackge={""};
		String[] SerivcesCheckboxValue= {"YES"};
		String[] Serivces={"BW-Call Waiting [July 7 Package]"};
	    String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={"BundleUser"};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays");
		String setupCharge = Repository.getProperty("setupCharge");
		String recurringCharge = Repository.getProperty("recurringCharge");
		String ceaseCharge = Repository.getProperty("ceaseCharge");
		String rebateValue = Repository.getProperty("rebateValue");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("setupCostBuy");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost");
		String minimumDuration = Repository.getProperty("minimumDuration");
		String notificationPeriod = Repository.getProperty("notificationPeriod");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod");
		String country=Repository.getProperty("country");
		String availableToReseller= Repository.getProperty("availableToReseller");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValue");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller");
		String deviceRented = Repository.getProperty("deviceRented");
		String upgradePriority = Repository.getProperty("upgradePriority");
		String nopackageValue = Repository.getProperty("nopackageValue");
		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	@Test(priority = 44, enabled = true)
	public void TC_SitePackage_Reseller_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of site package in Reseller level");
		this.DataList();
		String availableTo = Repository.getProperty("SitePackageavailableTo");
		String name = Repository.getProperty("SitePackagename");
		String description = Repository.getProperty("SitePackagedescription");
		String packagecode = Repository.getProperty("SitePackagepackagecode");
		String packageType = Repository.getProperty("SitePackagepackageType");
		String primaryPackage = Repository.getProperty("SitePackageprimaryPackage");
		String[] SitePackagenumberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {};
		String secondaryPackageCheckboxValue = Repository.getProperty("SitePackagesecondaryPackageCheckboxValue");
		String[] SitePackageparentPackgeCheckboxValkue= {"YES"};
		String[] SitePackageparentPackge={"Automation HostedOnly Site Pkg [ Hosted ]"};
		String[] SitePackageSerivcesCheckboxValue= {"YES"};
		String[] SitePackageSerivces={"BW-Call Centre Queue Basic [Automation HostedOnly Site Pkg]"};
		String[]  SitePackageparentServiceCheckboxvalue= {""};
	    String[]  SitePackageparentService={"BW-Call Park"};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("SitePackagefreeDays");
		String setupCharge = Repository.getProperty("SitePackagesetupCharge");
		String recurringCharge = Repository.getProperty("SitePackagerecurringCharge");
		String ceaseCharge = Repository.getProperty("SitePackageceaseCharge");
		String rebateValue = Repository.getProperty("SitePackagerebateValue");
		String secondaryRebateValue = Repository.getProperty("SitePackagesecondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("SitePackagesetupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("SitePackagerecurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("SitePackageceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("SitePackagesetupCostBuy");
		String recurringCostBuy = Repository.getProperty("SitePackagerecurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("SitePackageceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("SitePackagelicensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("SitePackagemonthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("SitePackagelicensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("SitePackagemonthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("SitePackagemonthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("SitePackagelicenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("SitePackagelicenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("SitePackagelicenseUnassignedCost");
		String minimumDuration = Repository.getProperty("SitePackageminimumDuration");
		String notificationPeriod = Repository.getProperty("SitePackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("SitePackagequarantinePeriod");
		String country=Repository.getProperty("country");
		String availableToReseller= Repository.getProperty("availableToReseller");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String multipleInstancesAllowedValue=Repository.getProperty("SitePackagemultipleInstancesAllowedValue");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String commisonCategory_Reseller=Repository.getProperty("SitePackagecommissionCategory");
		String deviceRented = Repository.getProperty("SitePackagedeviceRented");
		String upgradePriority = Repository.getProperty("SitePackageupgradePriority");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,SitePackagenumberCategory,SitePackageSerivcesCheckboxValue,SitePackageSerivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,SitePackageparentPackgeCheckboxValkue,SitePackageparentPackge,SitePackageparentServiceCheckboxvalue,SitePackageparentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
@Test(priority = 45, enabled = true)
	public void TC_BusinessPackage_Reseller_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of business package in Reseller level");
		this.DataList();
		String availableTo = Repository.getProperty("BusinessPackageavailableTo");
		String name = Repository.getProperty("BusinessPackagename");
		String description = Repository.getProperty("BusinessPackagedescription");
		String packagecode = Repository.getProperty("BusinessPackagepackagecode");
		String packageType = Repository.getProperty("BusinessPackagepackageType");
		String primaryPackage = Repository.getProperty("BusinessPackageprimaryPackage");
		String[] numberCategoryCheckboxValue = {"YES"};
		String[] BusinessPackagenumberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("BusinessPackagesecondaryPackageCheckboxValue");
		String[] BusinessPackageparentPackgeCheckboxValue={"YES"};
		String[] BusinessPackageparentPackge={"Automation HostedOnly Business Pkg [ Hosted ]"};
		String[] BusinessPackageSerivcesCheckboxValue= {"YES"};
		String[] BusinessPackageSerivces={"BW-Call Centre Queue Basic [Automation HostedOnly Business Pkg]"};
		String[]  BusinessPackageparentServiceCheckboxValue={""};
	    String[]  BusinessPackageparentService={"BW-Call Park"};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("BusinessPackagefreeDays");
		String setupCharge = Repository.getProperty("BusinessPackagesetupCharge");
		String recurringCharge = Repository.getProperty("BusinessPackagerecurringCharge");
		String ceaseCharge = Repository.getProperty("BusinessPackageceaseCharge");
		String rebateValue = Repository.getProperty("BusinessPackagerebateValue");
		String secondaryRebateValue = Repository.getProperty("BusinessPackagesecondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("BusinessPackagesetupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("BusinessPackagerecurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("BusinessPackageceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("BusinessPackagesetupCostBuy");
		String recurringCostBuy = Repository.getProperty("BusinessPackagerecurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("BusinessPackageceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("BusinessPackagelicensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("BusinessPackagemonthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("BusinessmonthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("BusinessPackagelicensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("BusinessPackagemonthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("BusinessPackagemonthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("BusinessPackagelicenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("BusinessPackagelicenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("BusinessPackagelicenseUnassignedCost");
		String minimumDuration = Repository.getProperty("BusinessPackageminimumDuration");
		String notificationPeriod = Repository.getProperty("BusinessPackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("BusinessPackagequarantinePeriod");
		String country=Repository.getProperty("country");
		String availableToReseller= Repository.getProperty("availableToReseller");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("BusinessPackagecanAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("BusinessPackagecanBeAssignedCheckboxValue");
		String multipleInstancesAllowedValue=Repository.getProperty("BusinessPackagemultipleInstancesValue");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String commisonCategory_Reseller=Repository.getProperty("BusinessPackagecommissionCategory");
		String deviceRented = Repository.getProperty("BusinessPackagedeviceRented");
		String upgradePriority = Repository.getProperty("BusinessPackageupgradePriority");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,BusinessPackagenumberCategory,BusinessPackageSerivcesCheckboxValue,BusinessPackageSerivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,BusinessPackageparentPackgeCheckboxValue,BusinessPackageparentPackge,BusinessPackageparentServiceCheckboxValue,BusinessPackageparentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
@Test(priority = 46, enabled = true)
	public void TC_BusinessSitePackage_Reseller_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of business site package in Reseller level");
		this.DataList();
		String availableTo = Repository.getProperty("BusinessSitePackageavailableTo");
		String name = Repository.getProperty("BusinessSitePackagename");
		String description = Repository.getProperty("BusinessSitePackagedescription");
		String packagecode = Repository.getProperty("BusinessSitePackagepackagecode");
		String packageType = Repository.getProperty("BusinessSitePackagepackageType");
		String primaryPackage = Repository.getProperty("BusinessSitePackageprimaryPackage");
		String[] BusinessSitePackagenumberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("BusinessSitePackagesecondaryPackageCheckboxValue");
		String[] BusinessSitePackageparentPackgeCheckboxValue={"YES"};
		String[] BusinessSitePackageparentPackge={"Automation HostedOnly Business Site Pkg [ Hosted ]"};
		String[] BusinessSitePackageSerivcesCheckboxValue={"YES"};
		String[] BusinessSitePackageSerivces={"BW-Call Centre Queue Basic [Automation HostedOnly Business Site Pkg]"};
		String[]  BusinessSitePackageparentServiceCheckboxValue={""};
	    String[]  BusinessSitePackageparentService={"BW-Pick-Up Group"};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("BusinessSitePackagefreeDays");
		String setupCharge = Repository.getProperty("BusinessSitePackagesetupCharge");
		String recurringCharge = Repository.getProperty("BusinessSitePackagerecurringCharge");
		String ceaseCharge = Repository.getProperty("BusinessSitePackageceaseCharge");
		String rebateValue = Repository.getProperty("BusinessSitePackagerebateValue");
		String secondaryRebateValue = Repository.getProperty("BusinessSitePackagesecondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("BusinessSitePackagesetupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("BusinessSitePackagerecurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("BusinessSitePackageceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("BusinessSitePackagesetupCostBuy");
		String recurringCostBuy = Repository.getProperty("BusinessSitePackagerecurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("BusinessSitePackageceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("BusinessSitePackagelicensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("BusinessSitePackagemonthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("BusinessSitemonthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("BusinessSitePackagelicensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("BusinessSitePackagemonthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("BusinessSitePackagemonthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("BusinessSitePackagelicenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("BusinessSitePackagelicenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("BusinessSitePackagelicenseUnassignedCost");
		String minimumDuration = Repository.getProperty("BusinessSitePackageminimumDuration");
		String notificationPeriod = Repository.getProperty("BusinessSitePackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("BusinessSitePackagequarantinePeriod");
		String country=Repository.getProperty("country");
		String availableToReseller= Repository.getProperty("availableToReseller");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("BusinessPackagecanAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("BusinessPackagecanBeAssignedCheckboxValue");
		String multipleInstancesAllowedValue=Repository.getProperty("BusinessPackagemultipleInstancesValue");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String commissionCategory = Repository.getProperty("BusinessSitePackagecommissionCategory");
		String deviceRented = Repository.getProperty("BusinessSitePackagedeviceRented");
		String upgradePriority = Repository.getProperty("BusinessSitePackageupgradePriority");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,BusinessSitePackagenumberCategory,BusinessSitePackageSerivcesCheckboxValue,BusinessSitePackageSerivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,BusinessSitePackageparentPackgeCheckboxValue,BusinessSitePackageparentPackge,BusinessSitePackageparentServiceCheckboxValue,BusinessSitePackageparentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commissionCategory,deviceRented,upgradePriority);
	}
	
	@Test(priority = 47, enabled = true)
	public void TC_UserPackage_Reseller_ADD_ParentPackageWithWebexAndBW() throws InterruptedException, IOException, AWTException {	
		Description("Check whether it is able recreate an own secondary package from distributor level having both Webex[1 webex service] and bw service  in reseller level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryReseller_BothWebexAndBW");
		String name = Repository.getProperty("name_OwnSecondaryReseller_BothWebexAndBW");
		String description = Repository.getProperty("description_OwnSecondaryReseller_BothWebexAndBW");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryReseller_BothWebexAndBW");
		String packageType = Repository.getProperty("packageType_OwnSecondaryReseller_BothWebexAndBW");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryReseller_BothWebexAndBW");
		String[] numberCategoryCheckboxValue = {"YES"};
		String[] numberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryReseller_BothWebexAndBW");
		String[] parentPackgeCheckboxValue={"YES"};
		String[] parentPackge={"Automation PO Own Secondary Pkg Recreation[ Hosted ]"};
		String[] SerivcesCheckboxValue= {"YES","YES"};
		String[] Serivces={"BW-Call Waiting [Automation PO Own Secondary Pkg Recreation]","Webex Meeting 3 [Automation PO Own Secondary Pkg Recreation]"};
		String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={""};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryReseller_BothWebexAndBW");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryReseller_BothWebexAndBW");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryReseller_BothWebexAndBW");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryReseller_BothWebexAndBW");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryReseller_BothWebexAndBW");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryReseller_BothWebexAndBW");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryReseller_BothWebexAndBW");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryReseller_BothWebexAndBW");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryReseller_BothWebexAndBW");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryReseller_BothWebexAndBW");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryReseller_BothWebexAndBW");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryReseller_BothWebexAndBW");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryReseller_BothWebexAndBW");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryReseller_BothWebexAndBW");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryReseller_BothWebexAndBW");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryReseller_BothWebexAndBW");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryReseller_BothWebexAndBW");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryReseller_BothWebexAndBW");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryReseller_BothWebexAndBW");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryReseller_BothWebexAndBW");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryReseller_BothWebexAndBW");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryReseller_BothWebexAndBW");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryReseller_BothWebexAndBW");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryReseller_BothWebexAndBW");
		String country=Repository.getProperty("country_OwnSecondaryReseller_BothWebexAndBW");
		String availableToReseller= Repository.getProperty("availableToReseller_OwnSecondaryReseller_BothWebexAndBW");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryReseller_BothWebexAndBW");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryReseller_BothWebexAndBW");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryReseller_BothWebexAndBW");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryReseller_BothWebexAndBW");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryReseller_BothWebexAndBW");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryReseller_BothWebexAndBW");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryReseller_BothWebexAndBW");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryReseller_BothWebexAndBW");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryReseller_BothWebexAndBW");
		String deviceRented = Repository.getProperty("deviceRented_OwnSecondaryReseller_BothWebexAndBW");
		String upgradePriority = Repository.getProperty("upgradePriority_OwnSecondaryReseller_BothWebexAndBW");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 48, enabled = true)
	public void TC_UserPackage_Reseller_ADD_OwnSecondaryPackage() throws InterruptedException, IOException, AWTException {	
		Description("check whether there is an option for cretaing own secondary package in reseller without any parent package");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryReseller");
		String name = Repository.getProperty("name_OwnSecondaryReseller");
		String description = Repository.getProperty("description_OwnSecondaryReseller");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryReseller");
		String packageType = Repository.getProperty("packageType_OwnSecondaryReseller");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryReseller");
		String[] numberCategoryCheckboxValue = {"YES"};
		String[] numberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryReseller");
		String[] parentPackgeCheckboxValue={};
		String[] parentPackge={};
		String[] SerivcesCheckboxValue= {""};
		String[] Serivces={""};
		String[]  parentServiceCheckboxValue={"YES"};
	    String[]  parentService={"WebeMeeting3"};
	    String[] ownlevelService={""};
			String[] ownlevelServiceCheckbox={""};
	    String freeDays = Repository.getProperty("freeDays_OwnSecondaryReseller");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryReseller");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryReseller");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryReseller");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryReseller");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryReseller");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryReseller");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryReseller");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryReseller");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryReseller");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryReseller");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryReseller");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryReseller");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryReseller");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryReseller");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryReseller");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryReseller");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryReseller");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryReseller");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryReseller");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryReseller");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryReseller");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryReseller");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryReseller");
		String country=Repository.getProperty("country_OwnSecondaryReseller");
		String availableToReseller= Repository.getProperty("availableToReseller_OwnSecondaryReseller");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryReseller");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryReseller");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryReseller");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryReseller");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryReseller");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryReseller");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryReseller");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryReseller");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryReseller");
		String deviceRented = Repository.getProperty("deviceRented_OwnSecondaryReseller");
		String upgradePriority = Repository.getProperty("upgradePriority_OwnSecondaryReseller");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 49, enabled = true)
	public void TC_OWNSecondaryPackage_Reseller_ADD_AlreadyExistCheck() throws InterruptedException, IOException, AWTException {	
		Description("check whether there is an option for cretaing already existing own secondary package in reseller without any parent package");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryReseller");
		String name = Repository.getProperty("name_OwnSecondaryReseller");
		String description = Repository.getProperty("description_OwnSecondaryReseller");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryReseller");
		String packageType = Repository.getProperty("packageType_OwnSecondaryReseller");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryReseller");
		String[] numberCategoryCheckboxValue = {"YES"};
		String[] numberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryReseller");
		String[] parentPackgeCheckboxValue={};
		String[] parentPackge={};
	    String[] SerivcesCheckboxValue= {""};
	    String[] Serivces={""};
	    String[]  parentServiceCheckboxValue={"YES"};
	    String[]  parentService={"WebeMeeting3"};
	    String[] ownlevelService={""};
			String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryReseller");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryReseller");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryReseller");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryReseller");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryReseller");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryReseller");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryReseller");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryReseller");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryReseller");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryReseller");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryReseller");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryReseller");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryReseller");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryReseller");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryReseller");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryReseller");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryReseller");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryReseller");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryReseller");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryReseller");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryReseller");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryReseller");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryReseller");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryReseller");
		String country=Repository.getProperty("country_OwnSecondaryReseller");
		String availableToReseller= Repository.getProperty("availableToReseller_OwnSecondaryReseller");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryReseller");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryReseller");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryReseller");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryReseller");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryReseller");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryReseller");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryReseller");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryReseller");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryReseller");
		String deviceRented = Repository.getProperty("deviceRented_OwnSecondaryReseller");
		String upgradePriority = Repository.getProperty("upgradePriority_OwnSecondaryReseller");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 50, enabled = true)
	public void TC_OWNSecondaryPackage_Distributor_ADD_MultipleWebbexService() throws InterruptedException, IOException, AWTException {	
		Description("check whether multiple webex services can be added in the same package");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryReseller");
		String name = Repository.getProperty("name_OwnSecondaryReseller");
		String description = Repository.getProperty("description_OwnSecondaryReseller");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryReseller");
		String packageType = Repository.getProperty("packageType_OwnSecondaryReseller");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryReseller");
		String[] numberCategoryCheckboxValue = {"YES"};
		String[] numberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryReseller");
		String[] parentPackgeCheckboxValue={};
		String[] parentPackge={};
		String[] SerivcesCheckboxValue= {""};
		String[] Serivces={""};
	    String[]  parentServiceCheckboxValue={"YES","YES"};
	    String[]  parentService={"WebeSoftphoneOnly","WebeMeeting3"};
	    String[] ownlevelService={""};
			String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryReseller");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryReseller");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryReseller");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryReseller");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryReseller");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryReseller");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryReseller");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryReseller");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryReseller");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryReseller");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryReseller");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryReseller");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryReseller");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryReseller");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryReseller");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryReseller");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryReseller");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryReseller");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryReseller");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryReseller");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryReseller");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryReseller");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryReseller");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryReseller");
		String country=Repository.getProperty("country_OwnSecondaryReseller");
		String availableToReseller= Repository.getProperty("availableToReseller_OwnSecondaryReseller");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryReseller");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryReseller");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryReseller");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryReseller");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryReseller");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryReseller");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryReseller");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryReseller");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryReseller");
		String deviceRented = Repository.getProperty("deviceRented_OwnSecondaryReseller");
		String upgradePriority = Repository.getProperty("upgradePriority_OwnSecondaryReseller");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 51, enabled = true)
	public void TC_OWNSecondaryPackage_Reseller_ADD_NOService() throws InterruptedException, IOException, AWTException {	
		Description("Check whether it is able to create own secondary package without adding any services when parent package is not selectd in reseller level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryReseller");
		String name = Repository.getProperty("name_OwnSecondaryReseller");
		String description = Repository.getProperty("description_OwnSecondaryReseller");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryReseller");
		String packageType = Repository.getProperty("packageType_OwnSecondaryReseller");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryReseller");
		String[] numberCategoryCheckboxValue = {""};
		String[] numberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryReseller");
		String[] parentPackgeCheckboxValue={};
		String[] parentPackge={};
	    String[] SerivcesCheckboxValue= {""};
	    String[] Serivces={""};
	    String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={""};
	    String[] ownlevelService={""};
			String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryReseller");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryReseller");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryReseller");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryReseller");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryReseller");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryReseller");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryReseller");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryReseller");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryReseller");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryReseller");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryReseller");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryReseller");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryReseller");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryReseller");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryReseller");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryReseller");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryReseller");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryReseller");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryReseller");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryReseller");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryReseller");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryReseller");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryReseller");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryReseller");
		String country=Repository.getProperty("country_OwnSecondaryReseller");
		String availableToReseller= Repository.getProperty("availableToReseller_OwnSecondaryReseller");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryReseller");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryReseller");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryReseller");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryReseller");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryReseller");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryReseller");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryReseller");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryReseller");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryReseller");
		String deviceRented = Repository.getProperty("deviceRented_OwnSecondaryReseller");
		String upgradePriority = Repository.getProperty("upgradePriority_OwnSecondaryReseller");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 52, enabled = true)
	public void TC_OWNSecondaryPackage_Reseller_ADD_BothBWAndWebex() throws InterruptedException, IOException, AWTException {	
		Description("check whether combination of both webex(1 webex service) and broadworks services can be added within the same own secondary package in reseller level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String name = Repository.getProperty("name_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String description = Repository.getProperty("description_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String packageType = Repository.getProperty("packageType_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String[] numberCategoryCheckboxValue = {"YES"};
		String[] numberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String[] parentPackgeCheckboxValue={""};
		String[] parentPackge={""};
	    String[] SerivcesCheckboxValue= {""};
	    String[] Serivces={""};
	    String[]  parentServiceCheckboxValue={"YES","YES"};
	    String[]  parentService={"BW-ShareCallAppearance","WebeSoftphoneOnly"};
	    String[] ownlevelService={""};
			String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryReseller_BothWebexAndBW_Creation");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String country=Repository.getProperty("country_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String availableToReseller= Repository.getProperty("availableToReseller_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValue_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String deviceRented = Repository.getProperty("deviceRented_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String upgradePriority = Repository.getProperty("upgradePriority_OwnSecondaryReseller_BothWebexAndBW_Creation");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	@Test(priority = 53, enabled = true)
	public void TC_UserPackage_Reseller_ADD_WithDevice() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of user package with device without selecting secondary package  in Reseller level");
		this.DataList();
		String availableTo = Repository.getProperty("availableToPkgWithDevice");
		String name = Repository.getProperty("namePkgWithDevice");
		String description = Repository.getProperty("descriptionPkgWithDevice");
		String packagecode = Repository.getProperty("packagecodePkgWithDevice");
		String packageType = Repository.getProperty("packageTypePkgWithDevice");
		String primaryPackage = Repository.getProperty("primaryPackagePkgWithDevice");
		String[] numberCategoryCheckboxValue = {"YES"};
		String[] numberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValuePkgWithDevice");
		String[] parentPackgeCheckboxValue={""};
		String[] parentPackge={""};
		String[] SerivcesCheckboxValue= {""};
		String[] Serivces={""};
		String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={""};
	    String[] ownlevelService={""};
			String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDaysPkgWithDevice");
		String setupCharge = Repository.getProperty("setupChargePkgWithDevice");
		String recurringCharge = Repository.getProperty("recurringChargePkgWithDevice");
		String ceaseCharge = Repository.getProperty("ceaseChargePkgWithDevice");
		String rebateValue = Repository.getProperty("rebateValuePkgWithDevice");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValuePkgWithDevice");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCodePkgWithDevice");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCodePkgWithDevice");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCodePkgWithDevice");
		String setupCostBuy = Repository.getProperty("setupCostBuyPkgWithDevice");
		String recurringCostBuy = Repository.getProperty("recurringCostBuyPkgWithDevice");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuyPkgWithDevice");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePricePkgWithDevice");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssignedPkgWithDevice");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassignedPkgWithDevice");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominalPkgWithDevice");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominalPkgWithDevice");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominalPkgWithDevice");
		String licenseSetupCost = Repository.getProperty("licenseSetupCostPkgWithDevice");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCostPkgWithDevice");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCostPkgWithDevice");
		String minimumDuration = Repository.getProperty("minimumDurationPkgWithDevice");
		String notificationPeriod = Repository.getProperty("notificationPeriodPkgWithDevice");
		String quarantinePeriod = Repository.getProperty("quarantinePeriodPkgWithDevice");
		String country=Repository.getProperty("countryPkgWithDevice");
		String availableToReseller= Repository.getProperty("availableToResellerPkgWithDevice");
		String assignmentType = Repository.getProperty("assignmentTypePkgWithDevice");
		String isprimaryValue = Repository.getProperty("isprimaryValuePkgWithDevice");
		String dependentPackage = Repository.getProperty("dependentPackagePkgWithDevice");
		String keyLampCount = Repository.getProperty("keyLampCountPkgWithDevice");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValuePkgWithDevice");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValuePkgWithDevice");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValuePkgWithDevice");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvaluePkgWithDevice");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_ResellerPkgWithDevice");
		String deviceRented = Repository.getProperty("deviceRentedPkgWithDevice");
		String upgradePriority = Repository.getProperty("upgradePriorityPkgWithDevice");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 54, enabled = true)
	public void TC_UserPackage_Reseller_ADD_NoPackage() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of No package in Reseller level");
		this.DataList();
		String availableTo = Repository.getProperty("availableToNoPackage");
		String name = Repository.getProperty("nameNoPackage");
		String description = Repository.getProperty("descriptionNoPackage");
		String packagecode = Repository.getProperty("packagecodeNoPackage");
		String packageType = Repository.getProperty("packageTypeNoPackage");
		String primaryPackage = Repository.getProperty("primaryPackageNoPackage");
		String[] numberCategoryCheckboxValue = {"YES"};
		String[] numberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValueNoPackage");
		String[] parentPackgeCheckboxValue={""};
		String[] parentPackge={""};
		String[] SerivcesCheckboxValue= {""};
		String[] Serivces={""};
		String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={""};
	    String[] ownlevelService={""};
			String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDaysNoPackage");
		String setupCharge = Repository.getProperty("setupChargeNoPackage");
		String recurringCharge = Repository.getProperty("recurringChargeNoPackage");
		String ceaseCharge = Repository.getProperty("ceaseChargeNoPackage");
		String rebateValue = Repository.getProperty("rebateValueNoPackage");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValueNoPackage");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCodeNoPackage");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCodeNoPackage");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCodeNoPackage");
		String setupCostBuy = Repository.getProperty("setupCostBuyNoPackage");
		String recurringCostBuy = Repository.getProperty("recurringCostBuyNoPackage");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuyNoPackage");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePriceNoPackage");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssignedNoPackage");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassignedNoPackage");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominalNoPackage");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominalNoPackage");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominalNoPackage");
		String licenseSetupCost = Repository.getProperty("licenseSetupCostNoPackage");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCostNoPackage");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCostNoPackage");
		String minimumDuration = Repository.getProperty("minimumDurationNoPackage");
		String notificationPeriod = Repository.getProperty("notificationPeriodNoPackage");
		String quarantinePeriod = Repository.getProperty("quarantinePeriodNoPackage");
		String country=Repository.getProperty("countryNoPackage");
		String availableToReseller= Repository.getProperty("availableToResellerNoPackage");
		String assignmentType = Repository.getProperty("assignmentTypeNoPackage");
		String isprimaryValue = Repository.getProperty("isprimaryValueNoPackage");
		String dependentPackage = Repository.getProperty("dependentPackageNoPackage");
		String keyLampCount = Repository.getProperty("keyLampCountNoPackage");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValueNoPackage");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValueNoPackage");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValueNoPackage");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalueNoPackage");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_ResellerNoPackage");
		String deviceRented = Repository.getProperty("deviceRentedNoPackage");
		String upgradePriority = Repository.getProperty("upgradePriorityNoPackage");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}

	@Test(priority = 55, enabled = true)
	public void TC_UserPackage_Reseller_ADD_NoPackage2() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of No package in Reseller level with ownlevelservice");
		this.DataList();
		String availableTo = Repository.getProperty("availableToNoPackage");
		String name = Repository.getProperty("nameNoPackage");
		String description = Repository.getProperty("descriptionNoPackage");
		String packagecode = Repository.getProperty("packagecodeNoPackage");
		String packageType = Repository.getProperty("packageTypeNoPackage");
		String primaryPackage = Repository.getProperty("primaryPackageNoPackage");
		String[] numberCategoryCheckboxValue = {"YES"};
		String[] numberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValueNoPackage");
		String[] parentPackgeCheckboxValue={""};
		String[] parentPackge={""};
		String[] SerivcesCheckboxValue= {""};
		String[] Serivces={""};
		String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={""};
	    String[] ownlevelService={"Test Bundle"};
		String[] ownlevelServiceCheckbox={"YES"};
		String freeDays = Repository.getProperty("freeDaysNoPackage");
		String setupCharge = Repository.getProperty("setupChargeNoPackage");
		String recurringCharge = Repository.getProperty("recurringChargeNoPackage");
		String ceaseCharge = Repository.getProperty("ceaseChargeNoPackage");
		String rebateValue = Repository.getProperty("rebateValueNoPackage");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValueNoPackage");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCodeNoPackage");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCodeNoPackage");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCodeNoPackage");
		String setupCostBuy = Repository.getProperty("setupCostBuyNoPackage");
		String recurringCostBuy = Repository.getProperty("recurringCostBuyNoPackage");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuyNoPackage");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePriceNoPackage");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssignedNoPackage");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassignedNoPackage");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominalNoPackage");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominalNoPackage");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominalNoPackage");
		String licenseSetupCost = Repository.getProperty("licenseSetupCostNoPackage");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCostNoPackage");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCostNoPackage");
		String minimumDuration = Repository.getProperty("minimumDurationNoPackage");
		String notificationPeriod = Repository.getProperty("notificationPeriodNoPackage");
		String quarantinePeriod = Repository.getProperty("quarantinePeriodNoPackage");
		String country=Repository.getProperty("countryNoPackage");
		String availableToReseller= Repository.getProperty("availableToResellerNoPackage");
		String assignmentType = Repository.getProperty("assignmentTypeNoPackage");
		String isprimaryValue = Repository.getProperty("isprimaryValueNoPackage");
		String dependentPackage = Repository.getProperty("dependentPackageNoPackage");
		String keyLampCount = Repository.getProperty("keyLampCountNoPackage");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValueNoPackage");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValueNoPackage");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValueNoPackage");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalueNoPackage");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_ResellerNoPackage");
		String deviceRented = Repository.getProperty("deviceRentedNoPackage");
		String upgradePriority = Repository.getProperty("upgradePriorityNoPackage");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 56, enabled = true)
	public void TC_UserPackage_Reseller_ADD_WithUcOneService() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of package without selecting secondary package  in Reseller level WithUcOneService");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_WithUcOneService");
		String name = Repository.getProperty("name_WithUcOneService");
		String description = Repository.getProperty("description_WithUcOneService");
		String packagecode = Repository.getProperty("packagecode_WithUcOneService");
		String packageType = Repository.getProperty("packageType_WithUcOneService");
		String primaryPackage = Repository.getProperty("primaryPackage_WithUcOneService");
		String[] numberCategoryCheckboxValue = {"YES"};
		String[] numberCategory={"   category"};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_WithUcOneService");
		String[] parentPackgeCheckboxValue={""};
		String[] parentPackge={""};
		String[] SerivcesCheckboxValue= {"YES"};
		String[] Serivces={"VIP-UC-One Trio - Softphone Only [Automation_UCOnePKGCheck]"};
	    String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={"BundleUser"};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_WithUcOneService");
		String setupCharge = Repository.getProperty("setupCharge_WithUcOneService");
		String recurringCharge = Repository.getProperty("recurringCharge_WithUcOneService");
		String ceaseCharge = Repository.getProperty("ceaseCharge_WithUcOneService");
		String rebateValue = Repository.getProperty("rebateValue_WithUcOneService");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_WithUcOneService");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_WithUcOneService");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_WithUcOneService");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_WithUcOneService");
		String setupCostBuy = Repository.getProperty("setupCostBuy_WithUcOneService");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_WithUcOneService");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_WithUcOneService");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_WithUcOneService");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_WithUcOneService");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_WithUcOneService");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_WithUcOneService");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_WithUcOneService");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_WithUcOneService");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_WithUcOneService");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_WithUcOneService");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_WithUcOneService");
		String minimumDuration = Repository.getProperty("minimumDuration_WithUcOneService");
		String notificationPeriod = Repository.getProperty("notificationPeriod_WithUcOneService");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_WithUcOneService");
		String country=Repository.getProperty("country_WithUcOneService");
		String availableToReseller= Repository.getProperty("availableToReseller_WithUcOneService");
		String assignmentType = Repository.getProperty("assignmentType_WithUcOneService");
		String isprimaryValue = Repository.getProperty("isprimaryValue_WithUcOneService");
		String dependentPackage = Repository.getProperty("dependentPackage_WithUcOneService");
		String keyLampCount = Repository.getProperty("keyLampCount_WithUcOneService");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_WithUcOneService");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_WithUcOneService");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValue_WithUcOneService");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_WithUcOneService");
		String commisonCategory_Reseller=Repository.getProperty("commisonCategory_Reseller_WithUcOneService");
		String deviceRented = Repository.getProperty("deviceRented_WithUcOneService");
		String upgradePriority = Repository.getProperty("upgradePriority_WithUcOneService");
		String nopackageValue = Repository.getProperty("nopackageValue_WithUcOneService");
		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@AfterClass
	public void quit() {
		this.after();
	}
	}
