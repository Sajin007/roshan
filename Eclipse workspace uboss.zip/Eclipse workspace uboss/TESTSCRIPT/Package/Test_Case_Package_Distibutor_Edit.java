/*-- =============================================
-- Author		: Oommen K Raju
-- Created Date : 8-04-2020
-- Description	: PlatformOwner Creation
-- Modified by	: Package Edit Distributor level
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

package Package;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.drd.uboss5.testbase.TestBase;

import Login.Login;

public class Test_Case_Package_Distibutor_Edit extends TestBase {

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Package_Creation_Distributor;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Package\\CommonData_Package.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\DataList\\Package\\DATALIST_PACKAGE_DISTIBUTOR_EDIT.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Package_Creation_Distributor = Repository.getProperty("Package_Creation_Distributor");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("Testing scenario for editing package in Distributor level");
		init();
	}

	@Test(priority = 131, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("Login to Uboss");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("oommen.raju@drd.co.in","P@ss12345678");

	}

	@Test(priority = 132, enabled = true)
	public void TC_Package_Distributor_Url() throws InterruptedException, IOException {
		Description("Naviagate to package list page in Distributor level for editing");
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		this.CommonData();
		pkg.GoToUrl(Package_Creation_Distributor);
		//pkg.GoToUrl("http://10.3.2.224:3015/package/index/2/134");
	}
		
//	@Test(priority = 133, enabled = true)
//	public void TC_Package_Distributor_Validation() throws InterruptedException, IOException, AWTException {
//		Description("Checking the validations of package edit in Distributor level");
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		this.DataList();
//		String listsearch1 = Repository.getProperty("listsearch1");
//		String invalidData = Repository.getProperty("invalidData");
//		pkg.Package_Edit_Validation(listsearch1,invalidData);
//
//	}
//	@Test(priority = 134, enabled = true)
//	public void TC_UserPackage_Distributor_Edit() throws InterruptedException, IOException, AWTException {	
//		Description("Checking the user package recreation edit in Distributor level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("listsearch1");
//		String name = Repository.getProperty("name");
//		String description = Repository.getProperty("description");
//		String packageCode = Repository.getProperty("packageCode");
//		String minimumDuration = Repository.getProperty("minimumDuration");
//		String notificationPeriod = Repository.getProperty("notificationPeriod");
//		String quarantinePeriod = Repository.getProperty("quarantinePeriod");
//		String searchUsageInstancewise	 = Repository.getProperty("searchUsageInstancewise");
//		String search = Repository.getProperty("search");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	@Test(priority = 135, enabled = true)
//	 public void TC_UserPackage_Distributor_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of user package recreation edit in Distributor level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("listsearch1");
//		String []filetype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,filetype);
//	}
//	
//	@Test(priority = 136, enabled = true)
//	public void TC_SitePackage_Distributor_Edit() throws InterruptedException, IOException, AWTException {	
//		Description("Checking the site package recreation edit in Distributor level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("Sitelistsearch1");
//		String name = Repository.getProperty("Sitename");
//		String description = Repository.getProperty("Sitedescription");
//		String packageCode = Repository.getProperty("SitepackageCode");
//		String minimumDuration = Repository.getProperty("SiteminimumDuration");
//		String notificationPeriod = Repository.getProperty("SitenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("SitequarantinePeriod");
//		String searchUsageInstancewise	 = Repository.getProperty("SitesearchUsageInstancewise");
//		String search = Repository.getProperty("Sitesearch");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	@Test(priority = 137, enabled = true)
//	 public void TC_SitePackage_Distributor_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of site package recreation edit in Distributor level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("Sitelistsearch1");
//		String []Sitefiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,Sitefiletype);
//	}
//	
//	@Test(priority = 138, enabled = true)
//	public void TC_BusinessPackage_Distributor_Edit() throws InterruptedException, IOException, AWTException {	
//		Description("Checking the Business package recreation edit in Distributor level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("Businesslistsearch1");
//		String name = Repository.getProperty("Businessname");
//		String description = Repository.getProperty("Businessdescription");
//		String packageCode = Repository.getProperty("BusinesspackageCode");
//		String minimumDuration = Repository.getProperty("BusinessminimumDuration");
//		String notificationPeriod = Repository.getProperty("BusinessnotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("BusinessquarantinePeriod");
//		String searchUsageInstancewise	 = Repository.getProperty("BusinesssearchUsageInstancewise");
//		String search = Repository.getProperty("Businesssearch");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	@Test(priority = 139, enabled = true)
//	 public void TC_BusinessPackage_Distributor_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of Business package recreation edit in Distributor level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("Businesslistsearch1");
//		String []Businessfiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,Businessfiletype);
//	}
//	
//	
//	@Test(priority = 140, enabled = true)
//	public void TC_BusinessSitePackage_Distributor_Edit() throws InterruptedException, IOException, AWTException {	
//		Description("Checking the Business site package recreation edit in Distributor level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("BusinessSitelistsearch1");
//		String name = Repository.getProperty("BusinessSitename");
//		String description = Repository.getProperty("BusinessSitedescription");
//		String packageCode = Repository.getProperty("BusinessSitepackageCode");
//		String minimumDuration = Repository.getProperty("BusinessSiteminimumDuration");
//		String notificationPeriod = Repository.getProperty("BusinessSitenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("BusinessSitequarantinePeriod");
//		String searchUsageInstancewise	 = Repository.getProperty("BusinessSitesearchUsageInstancewise");
//		String search = Repository.getProperty("BusinessSitesearch");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	@Test(priority = 141, enabled = true)
//	 public void TC_BusinessSitePackage_Distributor_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of Business site package recreation edit in Distributor level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("BusinessSitelistsearch1");
//		String []BusinessSitefiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,BusinessSitefiletype);
//	}
//	
//	
//	
//	@Test(priority = 142, enabled = true)
//	public void TC_SIPOnlyPackage_Distributor_Edit() throws InterruptedException, IOException, AWTException {	
//		Description("Checking the SIPOnly package edit recreation in Distributor level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("SIPOnlylistsearch1");
//		String name = Repository.getProperty("SIPOnlyname");
//		String description = Repository.getProperty("SIPOnlydescription");
//		String packageCode = Repository.getProperty("SIPOnlypackageCode");
//		String minimumDuration = Repository.getProperty("SIPOnlyminimumDuration");
//		String notificationPeriod = Repository.getProperty("SIPOnlynotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("SIPOnlyquarantinePeriod");
//		String searchUsageInstancewise	 = Repository.getProperty("SIPOnlysearchUsageInstancewise");
//		String search = Repository.getProperty("SIPOnlysearch");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	@Test(priority = 143, enabled = true)
//	 public void TC_SIPOnlyPackage_Distributor_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of SIPOnly package edit recreation in Distributor level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("SIPOnlylistsearch1");
//		String []SIPOnlyfiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,SIPOnlyfiletype);
//	}
//	
//
//	@Test(priority = 144, enabled = true)
//	public void TC_OWNSecondaryPackage_Edit() throws InterruptedException, IOException, AWTException {
//		Description("check whether there is an option for editing own secondary package in distributor,without any parent package");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("DistributorOwnSecondary_Packagelistsearch1");
//		String name = Repository.getProperty("DistributorOwnSecondaryPackagename");
//		String description = Repository.getProperty("DistributorOwnSecondaryPackagedescription");
//		String packageCode = Repository.getProperty("DistributorOwnSecondaryPackagepackageCode");
//		String minimumDuration = Repository.getProperty("DistributorOwnSecondaryPackageminimumDuration");
//		String notificationPeriod = Repository.getProperty("DistributorOwnSecondaryPackagenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("DistributorOwnSecondaryPackagequarantinePeriod");
//		String searchUsageInstancewise = Repository.getProperty("DistributorOwnSecondaryPackagesearchUsageInstancewise");
//		String search = Repository.getProperty("search");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 145, enabled = true)
//	 public void TC_OWNSecondaryPackage_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("check whether there is an option for editing own secondary package in distributor without any parent package");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("DistributorOwnSecondary_Packagelistsearch1");
//		String []DistributoOwnSecondaryfiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,DistributoOwnSecondaryfiletype);
//	}
//	
//	@Test(priority = 146,enabled = true)
//	public void TC_OWNSecondaryPackage_ContainsBothBWAndWebexService_Edit() throws InterruptedException, IOException, AWTException {
//		Description("check whether there is an option for editing own secondary package in Distributor having both webex and bw service ");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("DistributorOwnSecondaryBothWebexAndBW_Packagelistsearch1");
//		String name = Repository.getProperty("DistributorOwnSecondaryBothWebexAndBWPackagename");
//		String description = Repository.getProperty("DistributorOwnSecondaryBothWebexAndBWPackagedescription");
//		String packageCode = Repository.getProperty("DistributorOwnSecondaryBothWebexAndBWPackagepackageCode");
//		String minimumDuration = Repository.getProperty("DistributorOwnSecondaryBothWebexAndBWPackageminimumDuration");
//		String notificationPeriod = Repository.getProperty("DistributorOwnSecondaryBothWebexAndBWPackagenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("DistributorOwnSecondaryBothWebexAndBWPackagequarantinePeriod");
//		String searchUsageInstancewise = Repository.getProperty("DistributorOwnSecondaryBothWebexAndBWPackagesearchUsageInstancewise");
//		String search = Repository.getProperty("search");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//
//	@Test(priority = 147, enabled = true)
//	 public void TC_OWNSecondaryPackage_ContainsBothBWAndWebexService_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("check whether there is an option for editing own secondary package having both webex and bw services in distributor");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("DistributorOwnSecondaryBothWebexAndBW_Packagelistsearch1");
//		String []DistributorOwnSecondaryfiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,DistributorOwnSecondaryfiletype);
//	}
//	
//	@Test(priority = 148, enabled = true)
//	public void TC_OWNSecondaryPackage_Edit_Withdevice() throws InterruptedException, IOException, AWTException {
//		Description("check whether there is an option for editing recreated own secondary package having device in distributor level  ");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("OwnSecondaryWithDevice_Packagelistsearch1");
//		String name = Repository.getProperty("OwnSecondaryWithDevicePackagename");
//		String description = Repository.getProperty("OwnSecondaryWithDevicePackagedescription");
//		String packageCode = Repository.getProperty("OwnSecondaryWithDevicePackagepackageCode");
//		String minimumDuration = Repository.getProperty("OwnSecondaryWithDevicePackageminimumDuration");
//		String notificationPeriod = Repository.getProperty("OwnSecondaryWithDevicePackagenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("OwnSecondaryWithDevicePackagequarantinePeriod");
//		String searchUsageInstancewise = Repository.getProperty("OwnSecondaryWithDevicePackagesearchUsageInstancewise");
//	
//		String search = Repository.getProperty("search");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 149, enabled = true)
//	 public void TC_OWNSecondaryPackage_Delete_Withdevice() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of business recreated own secondary package  with device edit in distributor level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("OwnSecondaryWithDevice_Packagelistsearch1");
//		String []BusinessReecreatedOWNSECONDARYPackageBothWebexAndBWfiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,BusinessReecreatedOWNSECONDARYPackageBothWebexAndBWfiletype);
//	}
//	
//	
//	@Test(priority = 150, enabled = false)
//	public void TC_OWNSecondaryPackage_Edit_NoPackage() throws InterruptedException, IOException, AWTException {
//		Description("check whether there is an option for editing recreated No package in business level  ");
//		System.out.println("Bug raised , bradworks error is showing while saving  recreated no package in distributor level");
////		this.DataList();
////		String listsearch1 = Repository.getProperty("NoPackageSearch");
////		String name = Repository.getProperty("NoPackagename");
////		String description = Repository.getProperty("NoPackagedescription");
////		String packageCode = Repository.getProperty("NoPackageCode");
////		String minimumDuration = Repository.getProperty("NoPackageminimumDuration");
////		String notificationPeriod = Repository.getProperty("NoPackagenotificationPeriod");
////		String quarantinePeriod = Repository.getProperty("NoPackagequarantinePeriod");
////		String searchUsageInstancewise = Repository.getProperty("NoPackageUsageInstancewise");
////		String search = Repository.getProperty("search");
////		String includeremovedValue=Repository.getProperty("includeremovedValue");
////		String commisionCategory=Repository.getProperty("commisionCategory");
////		String[] ownlevelService={""};
////		String[] ownlevelServiceCheckbox={""};
////		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
////		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 151, enabled = true)
//	 public void TC_OWNSecondaryPackage_Delete_NoPackage() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of distributor recreated own secondary package having both bw and webex service recreation edit in Billing business level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("NoPackageSearch");
//		String []NoPackagefiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,NoPackagefiletype);
//	}


//	@Test(priority = 152, enabled = true)
//	public void TC_Package_Edit_NoPackage_WithOwnLevelService() throws InterruptedException, IOException, AWTException {
//		Description("check whether there is an option for editing recreated No package in business level  ");
//		System.out.println("Bug raised , bradworks error is showing while saving  recreated no package in distributor level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("NoPackageSearch1");
//		String name = Repository.getProperty("NoPackagename1");
//		String description = Repository.getProperty("NoPackagedescription1");
//		String packageCode = Repository.getProperty("NoPackageCode1");
//		String minimumDuration = Repository.getProperty("NoPackageminimumDuration1");
//		String notificationPeriod = Repository.getProperty("NoPackagenotificationPeriod1");
//		String quarantinePeriod = Repository.getProperty("NoPackagequarantinePeriod1");
//		String searchUsageInstancewise = Repository.getProperty("NoPackageUsageInstancewise1");
//		String search = Repository.getProperty("search1");
//		String includeremovedValue=Repository.getProperty("includeremovedValue1");
//		String commisionCategory=Repository.getProperty("commisionCategory1");
//		String[] ownlevelService={"Test Bundle"};
//		String[] ownlevelServiceCheckbox={"NO"};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//
//	@Test(priority = 153, enabled = true)
//	 public void TC_Package_Delete_NoPackage() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Scenarios of distributor recreated package having both bw and webex service recreation edit in distributor level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("NoPackageSearch1");
//		String []NoPackagefiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,NoPackagefiletype);
//	}

	@Test(priority = 133, enabled = true)
	public void TC_UserPackage_Billingbusiness_Edit_WithUcOneService() throws InterruptedException, IOException, AWTException {
	Description("Checking the package recreation edit in Distributor level WithUcOne service");
	this.DataList();
	String listsearch1 = Repository.getProperty("listsearch1_WithUcOneService");
	String name = Repository.getProperty("name_WithUcOneService");
	String description = Repository.getProperty("description_WithUcOneService");
	String packageCode = Repository.getProperty("packageCode_WithUcOneService");
	String minimumDuration = Repository.getProperty("minimumDuration_WithUcOneService");
	String notificationPeriod = Repository.getProperty("notificationPeriod_WithUcOneService");
	String quarantinePeriod = Repository.getProperty("quarantinePeriod_WithUcOneService");
	String searchUsageInstancewise = Repository.getProperty("searchUsageInstancewise_WithUcOneService");
	String search = Repository.getProperty("search_WithUcOneService");
	String includeremovedValue=Repository.getProperty("includeremovedValue_WithUcOneService");
	String commisionCategory=Repository.getProperty("commisionCategory_WithUcOneService");
	String[] ownlevelService={""};
	String[] ownlevelServiceCheckbox={""};
	Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
	pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
}


@Test(priority = 134, enabled = true)
 public void TC_UserPackage_Billingbusiness_Delete_WithUcOneService() throws InterruptedException, IOException, AWTException {	
	Description("Check in the Senarios of package  recreation  edit in Distributor level:Delete,List Page,Export");
	this.DataList();
	String listsearch1 = Repository.getProperty("listsearch1_WithUcOneService");
	String []filetype = {"EXCEL","CSV" };
	Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
	pkg.Package_Delete(listsearch1,filetype);
}
//	@AfterClass
//	public void quit() {
//		this.after();
//	}
	}
