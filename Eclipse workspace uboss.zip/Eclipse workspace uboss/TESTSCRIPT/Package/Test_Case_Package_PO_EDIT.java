/*-- =============================================
-- Author		: Oommen K Raju
-- Created Date : 8-04-2020
-- Description	: Package Edit PO level
-- Modified by	: Oommen K Raju
-- Modified Date: 17-04-2020
-- Project		: UBOSS-5-0-5
-- =============================================*/

package Package;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.drd.uboss5.testbase.TestBase;

import Login.Login;

public class Test_Case_Package_PO_EDIT extends TestBase {

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Package_Creation;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Package\\CommonData_Package.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\DataList\\Package\\DATALIST_PACKAGE_PLATFORMOWNER_EDIT.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Package_Creation = Repository.getProperty("Package_Creation");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("Testing scenario for editing package in PO level");
		init();
	}

	@Test(priority = 152, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("Login to Uboss");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("oommen.raju@drd.co.in","P@ss12345678");

	}
	
	@Test(priority = 153, enabled = true)
	public void TC_Package_PlatformOwner_Url() throws InterruptedException, IOException {
		Description("Naviagate to package list page in PO level for editing");
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		this.CommonData();
		pkg.GoToUrl(Package_Creation);
	}
	
//	@Test(priority = 154, enabled = true)
//	public void TC_Package_PlatformOwner_Validation() throws InterruptedException, IOException, AWTException {
//		Description("Checking the validations of package edit in PO level");
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		this.DataList();
//		String listsearch1 = Repository.getProperty("listsearch1");
//		String invalidData = Repository.getProperty("invalidData");
//		pkg.Package_Edit_Validation(listsearch1,invalidData);
//
//	}
//		
//	@Test(priority = 155, enabled = true)
//	public void TC_SitePackage_Platformwer_Edit() throws InterruptedException, IOException, AWTException {	
//		Description("Checking the site package creation edit in PO level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("Sitelistsearch1");
//		String name = Repository.getProperty("Sitename");
//		String description = Repository.getProperty("Sitedescription");
//		String packageCode = Repository.getProperty("SitepackageCode");
//		String minimumDuration = Repository.getProperty("SiteminimumDuration");
//		String notificationPeriod = Repository.getProperty("SitenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("SitequarantinePeriod");
//		String searchUsageInstancewise	 = Repository.getProperty("SitesearchUsageInstancewise");
//		String search = Repository.getProperty("Sitesearch");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 156, enabled = true)
//	 public void TC_SitePackage_PlatformOwner_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of site package creation edit in PO level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("Sitelistsearch1");
//		String []Sitefiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,Sitefiletype);
//	}
//	
//	
//	@Test(priority = 157, enabled = true)
//	public void TC_BusinessPackage_Platformwer_Edit() throws InterruptedException, IOException, AWTException {	
//		Description("Checking the business package creation edit in PO level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("Businesslistsearch1");
//		String name = Repository.getProperty("Businessname");
//		String description = Repository.getProperty("Businessdescription");
//		String packageCode = Repository.getProperty("BusinesspackageCode");
//		String minimumDuration = Repository.getProperty("BusinessminimumDuration");
//		String notificationPeriod = Repository.getProperty("BusinessnotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("BusinessquarantinePeriod");
//		String searchUsageInstancewise	 = Repository.getProperty("BusinesssearchUsageInstancewise");
//		String search = Repository.getProperty("Businesssearch");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//	String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 158, enabled = true)
//	 public void TC_BusinessPackage_PlatformOwner_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of site package creation edit in PO level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("Businesslistsearch1");
//		String []Businessfiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,Businessfiletype);
//	}
//	
//	@Test(priority = 159, enabled = true)
//	public void TC_BusinessSitePackage_Platformwer_Edit() throws InterruptedException, IOException, AWTException {	
//		Description("Checking the business site package creation edit in PO level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("BusinessSitelistsearch1");
//		String name = Repository.getProperty("BusinessSitename");
//		String description = Repository.getProperty("BusinessSitedescription");
//		String packageCode = Repository.getProperty("BusinessSitepackageCode");
//		String minimumDuration = Repository.getProperty("BusinessSiteminimumDuration");
//		String notificationPeriod = Repository.getProperty("BusinessSitenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("BusinessSitequarantinePeriod");
//		String searchUsageInstancewise	 = Repository.getProperty("BusinessSitesearchUsageInstancewise");
//		String search = Repository.getProperty("BusinessSitesearch");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 160, enabled = true)
//	 public void TC_BusinessSitePackage_PlatformOwner_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of site package creation edit in PO level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("BusinessSitelistsearch1");
//		String []BusinessSitefiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,BusinessSitefiletype);
//	}
//	
//	@Test(priority = 161, enabled = true)
//	public void TC_SipOnlyUserPackage_Platformwer_Edit() throws InterruptedException, IOException, AWTException {	
//		Description("Checking the SipOnlyUserPackage creation edit in PO level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("SipOnlyUserPackagelistsearch1");
//		String name = Repository.getProperty("SipOnlyUserPackagename");
//		String description = Repository.getProperty("SipOnlyUserPackagedescription");
//		String packageCode = Repository.getProperty("SipOnlyUserPackagepackageCode");
//		String minimumDuration = Repository.getProperty("SipOnlyUserPackageminimumDuration");
//		String notificationPeriod = Repository.getProperty("SipOnlyUserPackagenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("SipOnlyUserPackagequarantinePeriod");
//		String searchUsageInstancewise	 = Repository.getProperty("SipOnlyUserPackagesearchUsageInstancewise");
//		String search = Repository.getProperty("SipOnlyUserPackagesearch");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//
//	@Test(priority = 162, enabled = true)
//	 public void TC_SipOnlyUserPackage_PlatformOwner_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of SipOnlyUserPackage creation edit in PO level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("SipOnlyUserPackagelistsearch1");
//		String []SipOnlyUserPackagefiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,SipOnlyUserPackagefiletype);
//	}
//	
//	@Test(priority = 163, enabled = true)
//	public void TC_BothUserPackage_Platformwer_Edit() throws InterruptedException, IOException, AWTException {	
//		Description("Checking the SipOnly UserPackage creation with assignment type : Both edit in PO level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("BothUserPackagelistsearch1");
//		String name = Repository.getProperty("BothUserPackagename");
//		String description = Repository.getProperty("BothUserPackagedescription");
//		String packageCode = Repository.getProperty("BothUserPackagepackageCode");
//		String minimumDuration = Repository.getProperty("BothUserPackageminimumDuration");
//		String notificationPeriod = Repository.getProperty("BothUserPackagenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("BothUserPackagequarantinePeriod");
//		String searchUsageInstancewise	 = Repository.getProperty("BothUserPackagesearchUsageInstancewise");
//		String search = Repository.getProperty("BothUserPackagesearch");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 164, enabled = true)
//	 public void TC_BothUserPackage_PlatformOwner_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of SipOnly UserPackage creation with assignment type: both edit in PO level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("BothUserPackagelistsearch1");
//		String []BothUserPackagefiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,BothUserPackagefiletype);
//	}
//	
//		
//
//	@Test(priority = 165, enabled = true)
//	public void TC_HostedOnlySecondarySelectedUserPackage_Platformwer_Edit() throws InterruptedException, IOException, AWTException {	
//		Description("Checking the HostedOnly UserPackage  creation with secondary package selected edit in PO level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("HostedOnlySecondarySelectedUserPackagelistsearch1");
//		String name = Repository.getProperty("HostedOnlySecondarySelectedUserPackagename");
//		String description = Repository.getProperty("HostedOnlySecondarySelectedUserPackagedescription");
//		String packageCode = Repository.getProperty("HostedOnlySecondarySelectedUserPackagepackageCode");
//		String minimumDuration = Repository.getProperty("HostedOnlySecondarySelectedUserPackageminimumDuration");
//		String notificationPeriod = Repository.getProperty("HostedOnlySecondarySelectedUserPackagenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("HostedOnlySecondarySelectedUserPackagequarantinePeriod");
//		String searchUsageInstancewise	 = Repository.getProperty("HostedOnlySecondarySelectedUserPackagesearchUsageInstancewise");
//		String search = Repository.getProperty("HostedOnlySecondarySelectedUserPackagesearch");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 166, enabled = true)
//	 public void TC_HostedOnlySecondarySelectedUserPackage_PlatformOwner_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of HostedOnly UserPackage creation with secondary package selecetd edit in PO level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("HostedOnlySecondarySelectedUserPackagelistsearch1");
//		String []HostedOnlySecondarySelectedUserPackagefiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,HostedOnlySecondarySelectedUserPackagefiletype);
//	}
//	
//	
//	@Test(priority = 167, enabled = true)
//	public void TC_OWNSecondaryPackage_Edit() throws InterruptedException, IOException, AWTException {
//		Description("check whether there is an option for editing own secondary package in PO,without any parent package");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("POOwnSecondary_Packagelistsearch1");
//		String name = Repository.getProperty("POOwnSecondaryPackagename");
//		String description = Repository.getProperty("POOwnSecondaryPackagedescription");
//		String packageCode = Repository.getProperty("POOwnSecondaryPackagepackageCode");
//		String minimumDuration = Repository.getProperty("POOwnSecondaryPackageminimumDuration");
//		String notificationPeriod = Repository.getProperty("POOwnSecondaryPackagenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("POOwnSecondaryPackagequarantinePeriod");
//		String searchUsageInstancewise = Repository.getProperty("POOwnSecondaryPackagesearchUsageInstancewise");
//		String search = Repository.getProperty("search");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 168, enabled = true)
//	 public void TC_OWNSecondaryPackage_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("check whether there is an option for editing own secondary package in PO without any parent package");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("POOwnSecondary_Packagelistsearch1");
//		String []POOwnSecondaryfiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,POOwnSecondaryfiletype);
//	}
//	
//	
//	@Test(priority = 169, enabled = true)
//	public void TC_OWNSecondaryPackage_Edit_BothWebexAndBW() throws InterruptedException, IOException, AWTException {
//		Description("check whether there is an option for editing own secondary package in PO having both webex and BW services");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("POOwnSecondary_Packagelistsearch1_BothWebexAndBW");
//		String name = Repository.getProperty("POOwnSecondaryPackagename_BothWebexAndBW");
//		String description = Repository.getProperty("POOwnSecondaryPackagedescription_BothWebexAndBW");
//		String packageCode = Repository.getProperty("POOwnSecondaryPackagepackageCode_BothWebexAndBW");
//		String minimumDuration = Repository.getProperty("POOwnSecondaryPackageminimumDuration_BothWebexAndBW");
//		String notificationPeriod = Repository.getProperty("POOwnSecondaryPackagenotificationPeriod_BothWebexAndBW");
//		String quarantinePeriod = Repository.getProperty("POOwnSecondaryPackagequarantinePeriod_BothWebexAndBW");
//		String searchUsageInstancewise = Repository.getProperty("POOwnSecondaryPackagesearchUsageInstancewise_BothWebexAndBW");
//		String search = Repository.getProperty("search");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 170, enabled = true)
//	 public void TC_OWNSecondaryPackage_Delete_BothWebexAndBW() throws InterruptedException, IOException, AWTException {	
//		Description("check whether there is an option for editing own secondary package in PO having both webex and BW services");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("POOwnSecondary_Packagelistsearch1_BothWebexAndBW");
//		String []POOwnSecondaryfiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,POOwnSecondaryfiletype);
//	}
//	
//	@Test(priority = 171, enabled = true)
//	public void TC_OWNSecondaryPackage_Edit_Withdevice() throws InterruptedException, IOException, AWTException {
//		Description("check whether there is an option for editing recreated own secondary package having device in PO level  ");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("OwnSecondaryWithDevice_Packagelistsearch1");
//		String name = Repository.getProperty("OwnSecondaryWithDevicePackagename");
//		String description = Repository.getProperty("OwnSecondaryWithDevicePackagedescription");
//		String packageCode = Repository.getProperty("OwnSecondaryWithDevicePackagepackageCode");
//		String minimumDuration = Repository.getProperty("OwnSecondaryWithDevicePackageminimumDuration");
//		String notificationPeriod = Repository.getProperty("OwnSecondaryWithDevicePackagenotificationPeriod");
//		String quarantinePeriod = Repository.getProperty("OwnSecondaryWithDevicePackagequarantinePeriod");
//		String searchUsageInstancewise = Repository.getProperty("OwnSecondaryWithDevicePackagesearchUsageInstancewise");
//	
//		String search = Repository.getProperty("search");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 172, enabled = true)
//	 public void TC_OWNSecondaryPackage_Delete_Withdevice() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of business recreated own secondary package  with device edit in PO level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("OwnSecondaryWithDevice_Packagelistsearch1");
//		String []BusinessReecreatedOWNSECONDARYPackageBothWebexAndBWfiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,BusinessReecreatedOWNSECONDARYPackageBothWebexAndBWfiletype);
//	}
//
//	
//	@Test(priority = 173, enabled = true)
//	public void TC_UserPackage_Platformwer_Edit() throws InterruptedException, IOException, AWTException {	
//		Description("Checking the package creation edit in PO level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("listsearch1");
//		String name = Repository.getProperty("name");
//		String description = Repository.getProperty("description");
//		String packageCode = Repository.getProperty("packageCode");
//		String minimumDuration = Repository.getProperty("minimumDuration");
//		String notificationPeriod = Repository.getProperty("notificationPeriod");
//		String quarantinePeriod = Repository.getProperty("quarantinePeriod");
//		String searchUsageInstancewise	 = Repository.getProperty("searchUsageInstancewise");
//		String search = Repository.getProperty("search");
//		String includeremovedValue=Repository.getProperty("includeremovedValue");
//		String commisionCategory=Repository.getProperty("commisionCategory");
//		String[] ownlevelService={""};
//		String[] ownlevelServiceCheckbox={""};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 174, enabled = true)
//	 public void TC_UserPackage_PlatformOwner_Delete() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of package creation edit in PO level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("listsearch1");
//		String []filetype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,filetype);
//	}
//	
//	@Test(priority = 175, enabled = false)
//	public void TC_OWNSecondaryPackage_Edit_NoPackage() throws InterruptedException, IOException, AWTException {
//		Description("check whether there is an option for editing recreated No package in business level  ");
//		System.out.println("Bug raised , bradworks error is showing while saving  recreated no package in PO level");
////		this.DataList();
////		String listsearch1 = Repository.getProperty("NoPackageSearch");
////		String name = Repository.getProperty("NoPackagename");
////		String description = Repository.getProperty("NoPackagedescription");
////		String packageCode = Repository.getProperty("NoPackageCode");
////		String minimumDuration = Repository.getProperty("NoPackageminimumDuration");
////		String notificationPeriod = Repository.getProperty("NoPackagenotificationPeriod");
////		String quarantinePeriod = Repository.getProperty("NoPackagequarantinePeriod");
////		String searchUsageInstancewise = Repository.getProperty("NoPackageUsageInstancewise");
////		String search = Repository.getProperty("search");
////		String includeremovedValue=Repository.getProperty("includeremovedValue");
////		String commisionCategory=Repository.getProperty("commisionCategory");
////		String[] ownlevelService={""};
//	//	String[] ownlevelServiceCheckbox={""};
////		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
////		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//	@Test(priority = 176, enabled = true)
//	 public void TC_OWNSecondaryPackage_Delete_NoPackage() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Senarios of business recreated own secondary package having both bw and webex service recreation edit in Billing business level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("NoPackageSearch");
//		String []NoPackagefiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,NoPackagefiletype);
//	}

//	
//	@Test(priority = 177, enabled = true)
//	public void TC_Package_Edit_NoPackage_WithOwnLevelService() throws InterruptedException, IOException, AWTException {
//		Description("check whether there is an option for editing recreated No package in business level  ");
//		System.out.println("Bug raised , bradworks error is showing while saving  recreated no package in PO level");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("NoPackageSearch1");
//		String name = Repository.getProperty("NoPackagename1");
//		String description = Repository.getProperty("NoPackagedescription1");
//		String packageCode = Repository.getProperty("NoPackageCode1");
//		String minimumDuration = Repository.getProperty("NoPackageminimumDuration1");
//		String notificationPeriod = Repository.getProperty("NoPackagenotificationPeriod1");
//		String quarantinePeriod = Repository.getProperty("NoPackagequarantinePeriod1");
//		String searchUsageInstancewise = Repository.getProperty("NoPackageUsageInstancewise1");
//		String search = Repository.getProperty("search1");
//		String includeremovedValue=Repository.getProperty("includeremovedValue1");
//		String commisionCategory=Repository.getProperty("commisionCategory1");
//		String[] ownlevelService={"Test Bundle"};
//		String[] ownlevelServiceCheckbox={"NO"};
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
//	}
//	
//
//	@Test(priority = 178, enabled = true)
//	 public void TC_Package_Delete_NoPackage() throws InterruptedException, IOException, AWTException {	
//		Description("Check in the Scenarios of business recreated package having both bw and webex service recreation edit in PO level:Delete,List Page,Export");
//		this.DataList();
//		String listsearch1 = Repository.getProperty("NoPackageSearch1");
//		String []NoPackagefiletype = {"EXCEL","CSV" };
//		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
//		pkg.Package_Delete(listsearch1,NoPackagefiletype);
//	}
	
	
	@Test(priority = 179, enabled = true)
	public void TC_UserPackage_Billingbusiness_Edit_WithUcOneService() throws InterruptedException, IOException, AWTException {
	Description("Checking the package recreation edit in PO level WithUcOne service");
	this.DataList();
	String listsearch1 = Repository.getProperty("listsearch1_WithUcOneService");
	String name = Repository.getProperty("name_WithUcOneService");
	String description = Repository.getProperty("description_WithUcOneService");
	String packageCode = Repository.getProperty("packageCode_WithUcOneService");
	String minimumDuration = Repository.getProperty("minimumDuration_WithUcOneService");
	String notificationPeriod = Repository.getProperty("notificationPeriod_WithUcOneService");
	String quarantinePeriod = Repository.getProperty("quarantinePeriod_WithUcOneService");
	String searchUsageInstancewise = Repository.getProperty("searchUsageInstancewise_WithUcOneService");
	String search = Repository.getProperty("search_WithUcOneService");
	String includeremovedValue=Repository.getProperty("includeremovedValue_WithUcOneService");
	String commisionCategory=Repository.getProperty("commisionCategory_WithUcOneService");
	String[] ownlevelService={""};
	String[] ownlevelServiceCheckbox={""};
	Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
	pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
}


@Test(priority = 180, enabled = true)
 public void TC_UserPackage_Billingbusiness_Delete_WithUcOneService() throws InterruptedException, IOException, AWTException {	
	Description("Check in the Senarios of package  recreation  edit in PO level:Delete,List Page,Export");
	this.DataList();
	String listsearch1 = Repository.getProperty("listsearch1_WithUcOneService");
	String []filetype = {"EXCEL","CSV" };
	Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
	pkg.Package_Delete(listsearch1,filetype);
}

	
//	@AfterClass
//	public void quit() {
//		this.after();
//	}
	}
