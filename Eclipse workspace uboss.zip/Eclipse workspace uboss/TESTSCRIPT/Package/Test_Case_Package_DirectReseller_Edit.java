/*-- =============================================
-- Author		: Oommen K Raju
-- Created Date : 7-04-2020
-- Description	: Package Edit Direct Reseller 
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

package Package;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.drd.uboss5.testbase.TestBase;

import Login.Login;

public class Test_Case_Package_DirectReseller_Edit extends TestBase {

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Package_Creation_DirectReseller;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Package\\CommonData_Package.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\DataList\\Package\\DATALIST_PACKAGE_DIRECTRESELLER_EDIT.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Package_Creation_DirectReseller = Repository.getProperty("Package_Creation_DirectReseller");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		init();
	}

	@Test(priority = 1, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("oommen.raju@drd.co.in","P@ss1234567");

	}

	@Test(priority = 2, enabled = true)
	public void TC_Package_DirectReseller_Url() throws InterruptedException, IOException {
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		this.CommonData();
		pkg.GoToUrl(Package_Creation_DirectReseller);

	}
	@Test(priority = 3, enabled = true)
	public void TC_Package_DirectReseller_Validation() throws InterruptedException, IOException, AWTException {
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		this.DataList();
		String listsearch1 = Repository.getProperty("listsearch1");
		String invalidData = Repository.getProperty("invalidData");
		pkg.Package_Edit_Validation(listsearch1,invalidData);

	}
	
	@Test(priority = 4, enabled = true)
	public void TC_Package1_DirectReseller_Edit() throws InterruptedException, IOException, AWTException {	
		this.DataList();
		String listsearch1 = Repository.getProperty("listsearch1");
		String name = Repository.getProperty("name");
		String description = Repository.getProperty("description");
		String packageCode = Repository.getProperty("packageCode");
		String commisionCategory = Repository.getProperty("commisionCategory");
		String minimumDuration = Repository.getProperty("minimumDuration");
		String notificationPeriod = Repository.getProperty("notificationPeriod");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod");
		String searchUsageInstancewise	 = Repository.getProperty("searchUsageInstancewise");
		String search = Repository.getProperty("search");
		String includeremovedValue = Repository.getProperty("includeremovedValue");
		String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
			
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
	}
	@Test(priority = 5, enabled = true)
	 public void TC_Package1_DirectReseller_Delete() throws InterruptedException, IOException, AWTException {	
		this.DataList();
		String listsearch1 = Repository.getProperty("listsearch1");
		String []filetype = {"EXCEL","CSV" };
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Delete(listsearch1,filetype);
	}
	
	@Test(priority = 6, enabled = true)
	public void TC_Package_Edit_NoPackage_WithOwnLevelService() throws InterruptedException, IOException, AWTException {
		Description("check whether there is an option for editing recreated No package in business level  ");
		System.out.println("Bug raised , bradworks error is showing while saving  recreated no package in billing business level");
		this.DataList();
		String listsearch1 = Repository.getProperty("NoPackageSearch1");
		String name = Repository.getProperty("NoPackagename1");
		String description = Repository.getProperty("NoPackagedescription1");
		String packageCode = Repository.getProperty("NoPackageCode1");
		String minimumDuration = Repository.getProperty("NoPackageminimumDuration1");
		String notificationPeriod = Repository.getProperty("NoPackagenotificationPeriod1");
		String quarantinePeriod = Repository.getProperty("NoPackagequarantinePeriod1");
		String searchUsageInstancewise = Repository.getProperty("NoPackageUsageInstancewise1");
		String search = Repository.getProperty("search1");
		String includeremovedValue=Repository.getProperty("includeremovedValue1");
		String commisionCategory=Repository.getProperty("commisionCategory1");
		String[] ownlevelService={"Test Bundle"};
		String[] ownlevelServiceCheckbox={"NO"};
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Edit(listsearch1,name,description,packageCode,ownlevelServiceCheckbox,ownlevelService,minimumDuration,notificationPeriod,quarantinePeriod,searchUsageInstancewise,search,includeremovedValue,commisionCategory);
	}
	

	@Test(priority = 7, enabled = true)
	 public void TC_Package_Delete_NoPackage() throws InterruptedException, IOException, AWTException {	
		Description("Check in the Scenarios of business recreated package having both bw and webex service recreation edit in Billing business level:Delete,List Page,Export");
		this.DataList();
		String listsearch1 = Repository.getProperty("NoPackageSearch1");
		String []NoPackagefiletype = {"EXCEL","CSV" };
		Package_Editt pkg = PageFactory.initElements(driver, Package_Editt.class);
		pkg.Package_Delete(listsearch1,NoPackagefiletype);
	}

	@AfterClass
	public void quit() {
		this.after();
	}
	}
