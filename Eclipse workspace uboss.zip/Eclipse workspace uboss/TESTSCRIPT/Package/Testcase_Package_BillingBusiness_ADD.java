/*-- =============================================
-- Author		: Oommen K Raju
-- Created Date : 8-04-2020
-- Description	: Package Billing business Recreation
-- Modified by	: Oommen K Raju
-- Modified Date: 18-05-2020
-- Project		: UBOSS-5-0-5
-- =============================================*/
package Package;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.drd.uboss5.testbase.TestBase;

import Login.Login;

public class Testcase_Package_BillingBusiness_ADD extends TestBase {

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Package_Creation_BillingBusiness;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Package\\CommonData_Package.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\DataList\\Package\\DATALIST_PACKAGE_CREATION_BILLINGBUSINESS.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Package_Creation_BillingBusiness = Repository.getProperty("Package_Creation_BillingBusiness");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("Testing scenario for creating package in Billing business level");
		init();
	}

	@Test(priority = 57, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("Login to Uboss");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("oommen.raju@drd.co.in","P@ss12345678");

	}

	@Test(priority = 58, enabled = true)
	public void TC_Package_Billingbusiness_Url() throws InterruptedException, IOException {
		Description("Naviagate to Pacakge creation page in Billing business level");
		Package_ADD pkgr = PageFactory.initElements(driver, Package_ADD.class);
		this.CommonData();
		pkgr.GoToUrl(Package_Creation_BillingBusiness);

	}
	
	@Test(priority = 59, enabled = true)
	public void TC_Package_Billingbusiness_Validation() throws InterruptedException, IOException, AWTException {	
		Description("Checking the validations of pacakge creation page in Billing business level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo");
		String name = Repository.getProperty("name");
		String description = Repository.getProperty("description");
		String packagecode = Repository.getProperty("packagecode");
		String packageType = Repository.getProperty("packageType");
		String primaryPackage = Repository.getProperty("primaryPackage");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue");
		String[] parentPackgeCheckboxValue= {"YES"};
		String[] parentPackge={"Automation2020 Reseller_Package BusinessSite [ Hosted ]"};
		String[] SerivcesCheckboxValue= {""};
	    String[] Serivces={"BW-Call Centre Queue Premium [Automation2020 Reseller_Package BusinessSite]"};
	    String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={"BundleUser"};
		String freeDays = Repository.getProperty("freeDays");
		String setupCharge = Repository.getProperty("setupCharge");
		String recurringCharge = Repository.getProperty("recurringCharge");
		String ceaseCharge = Repository.getProperty("ceaseCharge");
		String rebateValue = Repository.getProperty("rebateValue");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("setupCostBuy");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost");
		String minimumDuration = Repository.getProperty("minimumDuration");
		String notificationPeriod = Repository.getProperty("notificationPeriod");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod");
		String availableToReseller=Repository.getProperty("availableToReseller");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String country=Repository.getProperty("country");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesAllowedValue");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String notificationPeriodCheckboxvalue=Repository.getProperty("notificationPeriodCheckboxvalue");
		String InvalidData_Test=Repository.getProperty("InvalidData_Test");
		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD_Validation(availableToReseller,availableTo,name, description, packagecode,country,packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,notificationPeriodCheckboxvalue,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,secondaryPackageCheckboxValue,InvalidData_Test);
	
	}
	
	@Test(priority = 60, enabled = true)
	public void TC_UserPackage_BillingBusiness_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of package in billing business without selecting secondary package level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo");
		String name = Repository.getProperty("name");
		String description = Repository.getProperty("description");
		String packagecode = Repository.getProperty("packagecode");
		String packageType = Repository.getProperty("packageType");
		String primaryPackage = Repository.getProperty("primaryPackage");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue");
		String[] parentPackgeCheckboxValue= {""};
	    String[] parentPackge={"Automation2020 Reseller_Package BusinessSite [ Hosted ]"};
	    String[] SerivcesCheckboxValue={"YES"};
	    String[] Serivces={"BW-Call Waiting [July 7 Package]"};
	    String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={"bundlebatch"};
	    
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays");
		String setupCharge = Repository.getProperty("setupCharge");
		String recurringCharge = Repository.getProperty("recurringCharge");
		String ceaseCharge = Repository.getProperty("ceaseCharge");
		String rebateValue = Repository.getProperty("rebateValue");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("setupCostBuy");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost");
		String minimumDuration = Repository.getProperty("minimumDuration");
		String notificationPeriod = Repository.getProperty("notificationPeriod");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod");
		String country=Repository.getProperty("country");
		String availableToReseller= Repository.getProperty("availableToReseller");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValue");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategory");
		String deviceRented = Repository.getProperty("deviceRented");
		String upgradePriority = Repository.getProperty("upgradePriority");
		String nopackageValue = Repository.getProperty("nopackageValue");
		
		
		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 61, enabled = true)
	public void TC_SitePackage_BillingBusiness_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of site package in billing business level");
		this.DataList();
		String availableTo = Repository.getProperty("SitePackageavailableTo");
		String name = Repository.getProperty("SitePackagename");
		String description = Repository.getProperty("SitePackagedescription");
		String packagecode = Repository.getProperty("SitePackagepackagecode");
		String packageType = Repository.getProperty("SitePackagepackageType");
		String primaryPackage = Repository.getProperty("SitePackageprimaryPackage");
		String[] SitePackagenumberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {"YES"}; 
		String secondaryPackageCheckboxValue = Repository.getProperty("SitePackagesecondaryPackageCheckboxValue");
		String[] SitePackageparentPackgeCheckboxValue={"YES"};
		String[] SitePackageparentPackge={"Automation HostedOnly Site Pkg [ Hosted ]"};
		String[] SitePackageSerivcesCheckboxValue={"YES"};
	    String[] SitePackageSerivces={"BW-Call Centre Queue Basic [Automation HostedOnly Site Pkg]"};
	    String[]  SitePackageparentServiceCheckboxValue={""};
	    String[]  SitePackageparentService={"bundlebatch"};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("SitePackagefreeDays");
		String setupCharge = Repository.getProperty("SitePackagesetupCharge");
		String recurringCharge = Repository.getProperty("SitePackagerecurringCharge");
		String ceaseCharge = Repository.getProperty("SitePackageceaseCharge");
		String rebateValue = Repository.getProperty("SitePackagerebateValue");
		String secondaryRebateValue = Repository.getProperty("SitePackagesecondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("SitePackagesetupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("SitePackagerecurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("SitePackageceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("SitePackagesetupCostBuy");
		String recurringCostBuy = Repository.getProperty("SitePackagerecurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("SitePackageceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("SitePackagelicensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("SitePackagemonthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("SitePackagemonthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("SitePackagelicensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("SitePackagemonthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("SitePackagemonthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("SitePackagelicenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("SitePackagelicenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("SitePackagelicenseUnassignedCost");
		String minimumDuration = Repository.getProperty("SitePackageminimumDuration");
		String notificationPeriod = Repository.getProperty("SitePackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("SitePackagequarantinePeriod");
		String country=Repository.getProperty("country");
		String availableToReseller= Repository.getProperty("availableToReseller");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValue");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategory");
		String deviceRented = Repository.getProperty("SitePackagedeviceRented");
		String upgradePriority = Repository.getProperty("SitePackageupgradePriority");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,SitePackagenumberCategory,SitePackageSerivcesCheckboxValue,SitePackageSerivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,SitePackageparentPackgeCheckboxValue,SitePackageparentPackge,SitePackageparentServiceCheckboxValue,SitePackageparentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 62, enabled = true)
	public void TC_BusinessSitePackage_BillingBusiness_ADD() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of businessSite package in billing business level");
		this.DataList();
		String availableTo = Repository.getProperty("BusinessSitePackageavailableTo");
		String name = Repository.getProperty("BusinessSitePackagename");
		String description = Repository.getProperty("BusinessSitePackagedescription");
		String packagecode = Repository.getProperty("BusinessSitePackagepackagecode");
		String packageType = Repository.getProperty("BusinessSitePackagepackageType");
		String primaryPackage = Repository.getProperty("BusinessSitePackageprimaryPackage");
		String[] BusinessSitePackagenumberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("BusinessSitePackagesecondaryPackageCheckboxValue");
		String[] BusinessSitePackageparentPackgeCheckboxValue={"YES"};
		String[] BusinessSitePackageparentPackge={"Automation HostedOnly Business site Pkg [ Hosted ]"};
		String[] BusinessSitePackageSerivcesCheckboxValue={"YES"};
	    String[] BusinessSitePackageSerivces={"BW-Call Centre Queue Basic [Automation HostedOnly Business site Pkg]"};
	    String[]  BusinessSitePackageparentServiceCheckboxValue={""};
	    String[]  BusinessSitePackageparentService={"bundlebatch"};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("BusinessSitePackagefreeDays");
		String setupCharge = Repository.getProperty("BusinessSitePackagesetupCharge");
		String recurringCharge = Repository.getProperty("BusinessSitePackagerecurringCharge");
		String ceaseCharge = Repository.getProperty("BusinessSitePackageceaseCharge");
		String rebateValue = Repository.getProperty("BusinessSitePackagerebateValue");
		String secondaryRebateValue = Repository.getProperty("BusinessSitePackagesecondaryRebateValue");
		String setupChargeNominalCode = Repository.getProperty("BusinessSitePackagesetupChargeNominalCode");
		String recurringChargeNominalCode = Repository.getProperty("BusinessSitePackagerecurringChargeNominalCode");
		String ceaseChargeNominalCode = Repository.getProperty("BusinessSitePackageceaseChargeNominalCode");
		String setupCostBuy = Repository.getProperty("BusinessSitePackagesetupCostBuy");
		String recurringCostBuy = Repository.getProperty("BusinessSitePackagerecurringCostBuy");
		String ceaseCostBuy = Repository.getProperty("BusinessSitePackageceaseCostBuy");
		String licensePurchasePrice = Repository.getProperty("BusinessSitePackagelicensePurchasePrice");
		String monthlyFeeAssigned = Repository.getProperty("BusinessSitePackagemonthlyFeeAssigned");
		String monthlyFeeunassigned = Repository.getProperty("BusinessSitePackagemonthlyFeeunassigned");		
		String licensePurchaseNominal = Repository.getProperty("BusinessSitePackagelicensePurchaseNominal");
		String monthlyFeeAssignedNominal = Repository.getProperty("BusinessSitePackagemonthlyFeeAssignedNominal");
		String monthlyFeeUnassignedNominal = Repository.getProperty("BusinessSitePackagemonthlyFeeUnassignedNominal");
		String licenseSetupCost = Repository.getProperty("BusinessSitePackagelicenseSetupCost");
		String licenseAssignedCost = Repository.getProperty("BusinessSitePackagelicenseAssignedCost");
		String licenseUnassignedCost = Repository.getProperty("BusinessSitePackagelicenseUnassignedCost");
		String minimumDuration = Repository.getProperty("BusinessSitePackageminimumDuration");
		String notificationPeriod = Repository.getProperty("BusinessSitePackagenotificationPeriod");
		String quarantinePeriod = Repository.getProperty("BusinessSitePackagequarantinePeriod");
		String country=Repository.getProperty("country");
		String availableToReseller= Repository.getProperty("availableToReseller");
		String assignmentType = Repository.getProperty("assignmentType");
		String isprimaryValue = Repository.getProperty("isprimaryValue");
		String dependentPackage = Repository.getProperty("dependentPackage");
		String keyLampCount = Repository.getProperty("keyLampCount");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValue");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategory");
		String deviceRented = Repository.getProperty("BusinessSitePackagedeviceRented");
		String upgradePriority = Repository.getProperty("BusinessSitePackageupgradePriority");
		String nopackageValue = Repository.getProperty("nopackageValue");

		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,BusinessSitePackagenumberCategory,BusinessSitePackageSerivcesCheckboxValue,BusinessSitePackageSerivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,BusinessSitePackageparentPackgeCheckboxValue,BusinessSitePackageparentPackge,BusinessSitePackageparentServiceCheckboxValue,BusinessSitePackageparentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	
	@Test(priority = 63, enabled = true)
	public void TC_UserPackage_Business_ADD_ParentPackageWithWebexAndBW() throws InterruptedException, IOException, AWTException {	
		Description("Check whether it is able recreate secondary packge having both Webex and bw service in business level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryBusiness_BothWebexAndBW");
		String name = Repository.getProperty("name_OwnSecondaryBusiness_BothWebexAndBW");
		String description = Repository.getProperty("description_OwnSecondaryBusiness_BothWebexAndBW");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryBusiness_BothWebexAndBW");
		String packageType = Repository.getProperty("packageType_OwnSecondaryBusiness_BothWebexAndBW");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryBusiness_BothWebexAndBW");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryBusiness_BothWebexAndBW");
		String[] parentPackgeCheckboxValue= {"YES"};
	    String[] parentPackge={"Automation PO Own Secondary Pkg Recreation[ Hosted ]"};
		String[] SerivcesCheckboxValue={"YES","YES"};
	    String[] Serivces={"BW-Call Waiting [Automation PO Own Secondary Pkg Recreation]","Webex Meeting 3 [Automation PO Own Secondary Pkg Recreation]"};
	    String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={""};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryBusiness_BothWebexAndBW");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryBusiness_BothWebexAndBW");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryBusiness_BothWebexAndBW");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryBusiness_BothWebexAndBW");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryBusiness_BothWebexAndBW");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryBusiness_BothWebexAndBW");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryBusiness_BothWebexAndBW");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryBusiness_BothWebexAndBW");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryBusiness_BothWebexAndBW");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryBusiness_BothWebexAndBW");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryBusiness_BothWebexAndBW");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryBusiness_BothWebexAndBW");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryBusiness_BothWebexAndBW");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryBusiness_BothWebexAndBW");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryBusiness_BothWebexAndBW");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryBusiness_BothWebexAndBW");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryBusiness_BothWebexAndBW");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryBusiness_BothWebexAndBW");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryBusiness_BothWebexAndBW");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryBusiness_BothWebexAndBW");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryBusiness_BothWebexAndBW");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryBusiness_BothWebexAndBW");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryBusiness_BothWebexAndBW");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryBusiness_BothWebexAndBW");
		String country=Repository.getProperty("country_OwnSecondaryBusiness_BothWebexAndBW");
		String availableToReseller= Repository.getProperty("availableToReseller_OwnSecondaryBusiness_BothWebexAndBW");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryBusiness_BothWebexAndBW");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryBusiness_BothWebexAndBW");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryBusiness_BothWebexAndBW");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryBusiness_BothWebexAndBW");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryBusiness_BothWebexAndBW");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryBusiness_BothWebexAndBW");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValue_OwnSecondaryBusiness_BothWebexAndBW");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryBusiness_BothWebexAndBW");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategory_OwnSecondaryBusiness_BothWebexAndBW");
		String deviceRented = Repository.getProperty("deviceRented_OwnSecondaryBusiness_BothWebexAndBW");
		String upgradePriority = Repository.getProperty("upgradePriority_OwnSecondaryBusiness_BothWebexAndBW");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 64, enabled = true)
	public void TC_UserPackage_Business_ADD_OwnSecondaryPackage() throws InterruptedException, IOException, AWTException {	
		Description("check whether there is an option for cretating own secondary package in business without any parent package");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryBusiness");
		String name = Repository.getProperty("name_OwnSecondaryBusiness");
		String description = Repository.getProperty("description_OwnSecondaryBusiness");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryBusiness");
		String packageType = Repository.getProperty("packageType_OwnSecondaryBusiness");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryBusiness");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryBusiness");
		String[] parentPackgeCheckboxValue= {""};
	    String[] parentPackge={""};
		String[] SerivcesCheckboxValue={""};
	    String[] Serivces={""};
	    String[]  parentServiceCheckboxValue={"YES"};
	    String[]  parentService={"WebeSoftphoneOnly"};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryBusiness");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryBusiness");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryBusiness");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryBusiness");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryBusiness");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryBusiness");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryBusiness");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryBusiness");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryBusiness");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryBusiness");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryBusiness");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryBusiness");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryBusiness");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryBusiness");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryBusiness");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryBusiness");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryBusiness");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryBusiness");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryBusiness");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryBusiness");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryBusiness");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryBusiness");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryBusiness");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryBusiness");
		String country=Repository.getProperty("country_OwnSecondaryBusiness");
		String availableToReseller= Repository.getProperty("availableToReseller_OwnSecondaryBusiness");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryBusiness");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryBusiness");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryBusiness");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryBusiness");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryBusiness");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryBusiness");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValue_OwnSecondaryBusiness");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryBusiness");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategory_OwnSecondaryBusiness");
		String deviceRented = Repository.getProperty("deviceRented_OwnSecondaryBusiness");
		String upgradePriority = Repository.getProperty("upgradePriority_OwnSecondaryBusiness");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 65, enabled = true)
	public void TC_OWNSecondaryPackage_Buisness_ADD_AlreadyExistCheck() throws InterruptedException, IOException, AWTException {	
		Description("check whether there is an option for cretaing already existing own secondary package in business without any parent package");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryBusiness");
		String name = Repository.getProperty("name_OwnSecondaryBusiness");
		String description = Repository.getProperty("description_OwnSecondaryBusiness");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryBusiness");
		String packageType = Repository.getProperty("packageType_OwnSecondaryBusiness");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryBusiness");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryBusiness");
	    String[] parentPackgeCheckboxValue= {""};
	    String[] parentPackge={""};
		String[] SerivcesCheckboxValue={""};
	    String[] Serivces={""};
	    String[]  parentServiceCheckboxValue={"YES"};
	    String[]  parentService={"WebeSoftphoneOnly"};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryBusiness");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryBusiness");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryBusiness");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryBusiness");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryBusiness");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryBusiness");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryBusiness");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryBusiness");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryBusiness");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryBusiness");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryBusiness");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryBusiness");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryBusiness");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryBusiness");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryBusiness");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryBusiness");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryBusiness");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryBusiness");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryBusiness");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryBusiness");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryBusiness");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryBusiness");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryBusiness");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryBusiness");
		String country=Repository.getProperty("country_OwnSecondaryBusiness");
		String availableToReseller= Repository.getProperty("availableToReseller_OwnSecondaryBusiness");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryBusiness");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryBusiness");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryBusiness");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryBusiness");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryBusiness");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryBusiness");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValue_OwnSecondaryBusiness");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryBusiness");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategory_OwnSecondaryBusiness");
		String deviceRented = Repository.getProperty("deviceRented_OwnSecondaryBusiness");
		String upgradePriority = Repository.getProperty("upgradePriority_OwnSecondaryBusiness");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 66, enabled = true)
	public void TC_OWNSecondaryPackage_Distributor_ADD_MultipleWebbexService() throws InterruptedException, IOException, AWTException {	
		Description("check whether multiple webex services can be added in the same package");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryBusiness");
		String name = Repository.getProperty("name_OwnSecondaryBusiness");
		String description = Repository.getProperty("description_OwnSecondaryBusiness");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryBusiness");
		String packageType = Repository.getProperty("packageType_OwnSecondaryBusiness");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryBusiness");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryBusiness");
		String[] parentPackgeCheckboxValue= {""};
	    String[] parentPackge={""};
	    String[] SerivcesCheckboxValue={""};
	    String[] Serivces={""};
	    String[]  parentServiceCheckboxValue={"YES","YES"};
	    String[]  parentService={"WebeSoftphoneOnly","Webex Meeting 3"};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryBusiness");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryBusiness");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryBusiness");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryBusiness");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryBusiness");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryBusiness");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryBusiness");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryBusiness");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryBusiness");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryBusiness");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryBusiness");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryBusiness");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryBusiness");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryBusiness");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryBusiness");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryBusiness");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryBusiness");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryBusiness");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryBusiness");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryBusiness");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryBusiness");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryBusiness");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryBusiness");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryBusiness");
		String country=Repository.getProperty("country_OwnSecondaryBusiness");
		String availableToReseller= Repository.getProperty("availableToReseller_OwnSecondaryBusiness");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryBusiness");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryBusiness");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryBusiness");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryBusiness");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryBusiness");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryBusiness");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValue_OwnSecondaryBusiness");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryBusiness");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategory_OwnSecondaryBusiness");
		String deviceRented = Repository.getProperty("deviceRented_OwnSecondaryBusiness");
		String upgradePriority = Repository.getProperty("upgradePriority_OwnSecondaryBusiness");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 67, enabled = true)
	public void TC_OWNSecondaryPackage_Business_ADD_NOService() throws InterruptedException, IOException, AWTException {	
		Description("Check whether it is able to create own secondary package without adding any services when parent package is not selectd in business level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryBusiness");
		String name = Repository.getProperty("name_OwnSecondaryBusiness");
		String description = Repository.getProperty("description_OwnSecondaryBusiness");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryBusiness");
		String packageType = Repository.getProperty("packageType_OwnSecondaryBusiness");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryBusiness");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryBusiness");
		String[] parentPackgeCheckboxValue= {""};
	    String[] parentPackge={""};
		String[] SerivcesCheckboxValue={""};
	    String[] Serivces={""};
	    String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={""};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryBusiness");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryBusiness");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryBusiness");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryBusiness");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryBusiness");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryBusiness");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryBusiness");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryBusiness");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryBusiness");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryBusiness");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryBusiness");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryBusiness");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryBusiness");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryBusiness");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryBusiness");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryBusiness");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryBusiness");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryBusiness");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryBusiness");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryBusiness");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryBusiness");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryBusiness");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryBusiness");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryBusiness");
		String country=Repository.getProperty("country_OwnSecondaryBusiness");
		String availableToReseller= Repository.getProperty("availableToReseller_OwnSecondaryBusiness");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryBusiness");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryBusiness");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryBusiness");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryBusiness");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryBusiness");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryBusiness");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValue_OwnSecondaryBusiness");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryBusiness");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategory_OwnSecondaryBusiness");
		String deviceRented = Repository.getProperty("deviceRented_OwnSecondaryBusiness");
		String upgradePriority = Repository.getProperty("upgradePriority_OwnSecondaryBusiness");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 68, enabled = true)
	public void TC_OWNSecondaryPackage_Business_ADD_BothBWAndWebex() throws InterruptedException, IOException, AWTException {	
		Description("check whether combination of both webex and broadworks services can be added within the same own secondary package in business level");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_OwnSecondaryBusiness_BothWebexAndBW_Creation_BothWebexAndBW_Creation");
		String name = Repository.getProperty("name_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String description = Repository.getProperty("description_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String packagecode = Repository.getProperty("packagecode_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String packageType = Repository.getProperty("packageType_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String primaryPackage = Repository.getProperty("primaryPackage_OwnSecondaryBusiness");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String[] parentPackgeCheckboxValue= {""};
	    String[] parentPackge={""};
	    String[] SerivcesCheckboxValue={""};
	    String[] Serivces={""};
	    String[]  parentServiceCheckboxValue={"YES","YES"};
	    String[]  parentService={"BW-ShareCallAppearance","Webex Meeting 3"};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String setupCharge = Repository.getProperty("setupCharge_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String recurringCharge = Repository.getProperty("recurringCharge_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String ceaseCharge = Repository.getProperty("ceaseCharge_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String rebateValue = Repository.getProperty("rebateValue_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String setupCostBuy = Repository.getProperty("setupCostBuy_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_OwnSecondaryBusiness_BothWebexAndBW_Creation");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String minimumDuration = Repository.getProperty("minimumDuration_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String notificationPeriod = Repository.getProperty("notificationPeriod_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String country=Repository.getProperty("country_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String availableToReseller= Repository.getProperty("availableToReseller_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String assignmentType = Repository.getProperty("assignmentType_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String isprimaryValue = Repository.getProperty("isprimaryValue_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String dependentPackage = Repository.getProperty("dependentPackage_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String keyLampCount = Repository.getProperty("keyLampCount_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValue_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategory_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String deviceRented = Repository.getProperty("deviceRented_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String upgradePriority = Repository.getProperty("upgradePriority_OwnSecondaryBusiness_BothWebexAndBW_Creation");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 69, enabled = true)
	public void TC_UserPackage_BillingBusiness_ADD_WithDevice() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of package in billing business with device in business level");
		this.DataList();
		String availableTo = Repository.getProperty("availableToPkgWithDevice");
		String name = Repository.getProperty("namePkgWithDevice");
		String description = Repository.getProperty("descriptionPkgWithDevice");
		String packagecode = Repository.getProperty("packagecodePkgWithDevice");
		String packageType = Repository.getProperty("packageTypePkgWithDevice");
		String primaryPackage = Repository.getProperty("primaryPackagePkgWithDevice");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValuePkgWithDevice");
		String[] parentPackgeCheckboxValue= {""};
	    String[] parentPackge={""};
		String[] SerivcesCheckboxValue={""};
	    String[] Serivces={""};
	    String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={""};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDaysPkgWithDevice");
		String setupCharge = Repository.getProperty("setupChargePkgWithDevice");
		String recurringCharge = Repository.getProperty("recurringChargePkgWithDevice");
		String ceaseCharge = Repository.getProperty("ceaseChargePkgWithDevice");
		String rebateValue = Repository.getProperty("rebateValuePkgWithDevice");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValuePkgWithDevice");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCodePkgWithDevice");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCodePkgWithDevice");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCodePkgWithDevice");
		String setupCostBuy = Repository.getProperty("setupCostBuyPkgWithDevice");
		String recurringCostBuy = Repository.getProperty("recurringCostBuyPkgWithDevice");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuyPkgWithDevice");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePricePkgWithDevice");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssignedPkgWithDevice");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassignedPkgWithDevice");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominalPkgWithDevice");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominalPkgWithDevice");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominalPkgWithDevice");
		String licenseSetupCost = Repository.getProperty("licenseSetupCostPkgWithDevice");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCostPkgWithDevice");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCostPkgWithDevice");
		String minimumDuration = Repository.getProperty("minimumDurationPkgWithDevice");
		String notificationPeriod = Repository.getProperty("notificationPeriodPkgWithDevice");
		String quarantinePeriod = Repository.getProperty("quarantinePeriodPkgWithDevice");
		String country=Repository.getProperty("countryPkgWithDevice");
		String availableToReseller= Repository.getProperty("availableToResellerPkgWithDevice");
		String assignmentType = Repository.getProperty("assignmentTypePkgWithDevice");
		String isprimaryValue = Repository.getProperty("isprimaryValuePkgWithDevice");
		String dependentPackage = Repository.getProperty("dependentPackagePkgWithDevice");
		String keyLampCount = Repository.getProperty("keyLampCountPkgWithDevice");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValuePkgWithDevice");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValuePkgWithDevice");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValuePkgWithDevice");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvaluePkgWithDevice");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategoryPkgWithDevice");
		String deviceRented = Repository.getProperty("deviceRentedPkgWithDevice");
		String upgradePriority = Repository.getProperty("upgradePriorityPkgWithDevice");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	
	@Test(priority = 70, enabled = true)
	public void TC_UserPackage_BillingBusiness_ADD_NoPackage() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of No package in billing business level");
		this.DataList();
		String availableTo = Repository.getProperty("availableToNoPackage");
		String name = Repository.getProperty("nameNoPackage");
		String description = Repository.getProperty("descriptionNoPackage");
		String packagecode = Repository.getProperty("packagecodeNoPackage");
		String packageType = Repository.getProperty("packageTypeNoPackage");
		String primaryPackage = Repository.getProperty("primaryPackageNoPackage");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValueNoPackage");
		String[] parentPackgeCheckboxValue= {""};
	    String[] parentPackge={""};
		String[] SerivcesCheckboxValue={""};
	    String[] Serivces={""};
	    String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={""};
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDaysNoPackage");
		String setupCharge = Repository.getProperty("setupChargeNoPackage");
		String recurringCharge = Repository.getProperty("recurringChargeNoPackage");
		String ceaseCharge = Repository.getProperty("ceaseChargeNoPackage");
		String rebateValue = Repository.getProperty("rebateValueNoPackage");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValueNoPackage");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCodeNoPackage");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCodeNoPackage");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCodeNoPackage");
		String setupCostBuy = Repository.getProperty("setupCostBuyNoPackage");
		String recurringCostBuy = Repository.getProperty("recurringCostBuyNoPackage");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuyNoPackage");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePriceNoPackage");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssignedNoPackage");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassignedNoPackage");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominalNoPackage");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominalNoPackage");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominalNoPackage");
		String licenseSetupCost = Repository.getProperty("licenseSetupCostNoPackage");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCostNoPackage");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCostNoPackage");
		String minimumDuration = Repository.getProperty("minimumDurationNoPackage");
		String notificationPeriod = Repository.getProperty("notificationPeriodNoPackage");
		String quarantinePeriod = Repository.getProperty("quarantinePeriodNoPackage");
		String country=Repository.getProperty("countryNoPackage");
		String availableToReseller= Repository.getProperty("availableToResellerNoPackage");
		String assignmentType = Repository.getProperty("assignmentTypeNoPackage");
		String isprimaryValue = Repository.getProperty("isprimaryValueNoPackage");
		String dependentPackage = Repository.getProperty("dependentPackageNoPackage");
		String keyLampCount = Repository.getProperty("keyLampCountNoPackage");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValueNoPackage");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValueNoPackage");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValueNoPackage");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalueNoPackage");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategoryNoPackage");
		String deviceRented = Repository.getProperty("deviceRentedNoPackage");
		String upgradePriority = Repository.getProperty("upgradePriorityNoPackage");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	
	@Test(priority = 71, enabled = true)
	public void TC_UserPackage_BillingBusiness_ADD_NoPackage2() throws InterruptedException, IOException, AWTException {	
		Description("Checking the recreation of No package in billing business level");
		this.DataList();
		String availableTo = Repository.getProperty("availableToNoPackage");
		String name = Repository.getProperty("nameNoPackage");
		String description = Repository.getProperty("descriptionNoPackage");
		String packagecode = Repository.getProperty("packagecodeNoPackage");
		String packageType = Repository.getProperty("packageTypeNoPackage");
		String primaryPackage = Repository.getProperty("primaryPackageNoPackage");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValueNoPackage");
		String[] parentPackgeCheckboxValue= {""};
	    String[] parentPackge={""};
		String[] SerivcesCheckboxValue={""};
	    String[] Serivces={""};
	    String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={""};
	    String[] ownlevelService={"Test Bundle"};
		String[] ownlevelServiceCheckbox={"YES"};
		String freeDays = Repository.getProperty("freeDaysNoPackage");
		String setupCharge = Repository.getProperty("setupChargeNoPackage");
		String recurringCharge = Repository.getProperty("recurringChargeNoPackage");
		String ceaseCharge = Repository.getProperty("ceaseChargeNoPackage");
		String rebateValue = Repository.getProperty("rebateValueNoPackage");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValueNoPackage");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCodeNoPackage");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCodeNoPackage");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCodeNoPackage");
		String setupCostBuy = Repository.getProperty("setupCostBuyNoPackage");
		String recurringCostBuy = Repository.getProperty("recurringCostBuyNoPackage");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuyNoPackage");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePriceNoPackage");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssignedNoPackage");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassignedNoPackage");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominalNoPackage");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominalNoPackage");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominalNoPackage");
		String licenseSetupCost = Repository.getProperty("licenseSetupCostNoPackage");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCostNoPackage");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCostNoPackage");
		String minimumDuration = Repository.getProperty("minimumDurationNoPackage");
		String notificationPeriod = Repository.getProperty("notificationPeriodNoPackage");
		String quarantinePeriod = Repository.getProperty("quarantinePeriodNoPackage");
		String country=Repository.getProperty("countryNoPackage");
		String availableToReseller= Repository.getProperty("availableToResellerNoPackage");
		String assignmentType = Repository.getProperty("assignmentTypeNoPackage");
		String isprimaryValue = Repository.getProperty("isprimaryValueNoPackage");
		String dependentPackage = Repository.getProperty("dependentPackageNoPackage");
		String keyLampCount = Repository.getProperty("keyLampCountNoPackage");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValueNoPackage");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValueNoPackage");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValueNoPackage");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalueNoPackage");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategoryNoPackage");
		String deviceRented = Repository.getProperty("deviceRentedNoPackage");
		String upgradePriority = Repository.getProperty("upgradePriorityNoPackage");
		String nopackageValue = Repository.getProperty("nopackageValue");
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@Test(priority = 72, enabled = true)
	public void TC_UserPackage_BillingBusiness_ADD_WithUCOneService() throws InterruptedException, IOException, AWTException {	
		Description("Checking the creation of package in billing business without selecting secondary package level With UcOneService");
		this.DataList();
		String availableTo = Repository.getProperty("availableTo_WithUcOneService");
		String name = Repository.getProperty("name_WithUcOneService");
		String description = Repository.getProperty("description_WithUcOneService");
		String packagecode = Repository.getProperty("packagecode_WithUcOneService");
		String packageType = Repository.getProperty("packageType_WithUcOneService");
		String primaryPackage = Repository.getProperty("primaryPackage_WithUcOneService");
		String[] numberCategory={"   category"};
		String[] numberCategoryCheckboxValue = {""};
		String secondaryPackageCheckboxValue = Repository.getProperty("secondaryPackageCheckboxValue_WithUcOneService");
		String[] parentPackgeCheckboxValue= {""};
	    String[] parentPackge={"Automation2020 Reseller_Package BusinessSite [ Hosted ]"};
	    String[] SerivcesCheckboxValue={"YES"};
	    String[] Serivces={"BW-Call Waiting [July 7 Package]"};
	    String[]  parentServiceCheckboxValue={""};
	    String[]  parentService={"bundlebatch"};
	    
	    String[] ownlevelService={""};
		String[] ownlevelServiceCheckbox={""};
		String freeDays = Repository.getProperty("freeDays_WithUcOneService");
		String setupCharge = Repository.getProperty("setupCharge_WithUcOneService");
		String recurringCharge = Repository.getProperty("recurringCharge_WithUcOneService");
		String ceaseCharge = Repository.getProperty("ceaseCharge_WithUcOneService");
		String rebateValue = Repository.getProperty("rebateValue_WithUcOneService");
		String secondaryRebateValue = Repository.getProperty("secondaryRebateValue_WithUcOneService");
		String setupChargeNominalCode = Repository.getProperty("setupChargeNominalCode_WithUcOneService");
		String recurringChargeNominalCode = Repository.getProperty("recurringChargeNominalCode_WithUcOneService");
		String ceaseChargeNominalCode = Repository.getProperty("ceaseChargeNominalCode_WithUcOneService");
		String setupCostBuy = Repository.getProperty("setupCostBuy_WithUcOneService");
		String recurringCostBuy = Repository.getProperty("recurringCostBuy_WithUcOneService");
		String ceaseCostBuy = Repository.getProperty("ceaseCostBuy_WithUcOneService");
		String licensePurchasePrice = Repository.getProperty("licensePurchasePrice_WithUcOneService");
		String monthlyFeeAssigned = Repository.getProperty("monthlyFeeAssigned_WithUcOneService");
		String monthlyFeeunassigned = Repository.getProperty("monthlyFeeunassigned_WithUcOneService");		
		String licensePurchaseNominal = Repository.getProperty("licensePurchaseNominal_WithUcOneService");
		String monthlyFeeAssignedNominal = Repository.getProperty("monthlyFeeAssignedNominal_WithUcOneService");
		String monthlyFeeUnassignedNominal = Repository.getProperty("monthlyFeeUnassignedNominal_WithUcOneService");
		String licenseSetupCost = Repository.getProperty("licenseSetupCost_WithUcOneService");
		String licenseAssignedCost = Repository.getProperty("licenseAssignedCost_WithUcOneService");
		String licenseUnassignedCost = Repository.getProperty("licenseUnassignedCost_WithUcOneService");
		String minimumDuration = Repository.getProperty("minimumDuration_WithUcOneService");
		String notificationPeriod = Repository.getProperty("notificationPeriod_WithUcOneService");
		String quarantinePeriod = Repository.getProperty("quarantinePeriod_WithUcOneService");
		String country=Repository.getProperty("country_WithUcOneService");
		String availableToReseller= Repository.getProperty("availableToReseller_WithUcOneService");
		String assignmentType = Repository.getProperty("assignmentType_WithUcOneService");
		String isprimaryValue = Repository.getProperty("isprimaryValue_WithUcOneService");
		String dependentPackage = Repository.getProperty("dependentPackage_WithUcOneService");
		String keyLampCount = Repository.getProperty("keyLampCount_WithUcOneService");
		String canAlterPackageCheckboxValue = Repository.getProperty("canAlterPackageCheckboxValue_WithUcOneService");
		String canBeAssignedCheckboxValue=Repository.getProperty("canBeAssignedCheckboxValue_WithUcOneService");
		String multipleInstancesAllowedValue=Repository.getProperty("multipleInstancesValue_WithUcOneService");
		String applyallSDRTariffCheckBoxvalue=Repository.getProperty("applyallSDRTariffCheckBoxvalue_WithUcOneService");
		String commisonCategory_Reseller=Repository.getProperty("commissionCategory_WithUcOneService");
		String deviceRented = Repository.getProperty("deviceRented_WithUcOneService");
		String upgradePriority = Repository.getProperty("upgradePriority_WithUcOneService");
		String nopackageValue = Repository.getProperty("nopackageValue_WithUcOneService");
		
		
		
		Package_ADD pkg = PageFactory.initElements(driver, Package_ADD.class);
		pkg.Package_PlatformOwner_ADD(availableTo,availableToReseller,name, description, packagecode, country, packageType, assignmentType,multipleInstancesAllowedValue,isprimaryValue,dependentPackage,keyLampCount,canAlterPackageCheckboxValue,canBeAssignedCheckboxValue,nopackageValue,numberCategoryCheckboxValue,numberCategory,SerivcesCheckboxValue,Serivces,freeDays,
				setupCharge,recurringCharge,ceaseCharge,rebateValue,secondaryRebateValue,setupChargeNominalCode,recurringChargeNominalCode,ceaseChargeNominalCode,setupCostBuy,recurringCostBuy,ceaseCostBuy,
				licensePurchasePrice,monthlyFeeAssigned,monthlyFeeunassigned,licensePurchaseNominal,monthlyFeeAssignedNominal,monthlyFeeUnassignedNominal,licenseSetupCost,licenseAssignedCost,licenseUnassignedCost,applyallSDRTariffCheckBoxvalue,
				minimumDuration,notificationPeriod,quarantinePeriod,primaryPackage,parentPackgeCheckboxValue,parentPackge,parentServiceCheckboxValue,parentService,ownlevelServiceCheckbox,ownlevelService,secondaryPackageCheckboxValue,commisonCategory_Reseller,deviceRented,upgradePriority);
	}
	
	@AfterClass
	public void quit() {
	this.after();
	}
	

	}
