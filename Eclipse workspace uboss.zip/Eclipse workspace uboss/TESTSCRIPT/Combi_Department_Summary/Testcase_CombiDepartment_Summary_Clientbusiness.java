package Combi_Department_Summary;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Jun 2, 2020,10:14:22 AM
-- Description	: Testcase_CombiDepartment_Summary_Clientbusiness.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-ROSHAN_RAJU
-- =============================================*/
public class Testcase_CombiDepartment_Summary_Clientbusiness extends TestBase {
	
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Combi_Department_Summary;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Combi_Department_Summary\\CommonData_Combi_Department_Summary.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\Combi_Department_Summary\\Datalist_Combi_Department_Summary.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Combi_Department_Summary = Repository.getProperty("Combi_Department_Summary_CB");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("*Testing all scenarios in Combi department summary report page in client busns level*");
		init();
	}

	@Test(priority = 4, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("******Login to Uboss******");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}
	
	@Test(priority = 5, enabled = true)
	public void TC_Combi_Department_Summary_Url() throws InterruptedException, IOException {
		Description("*****Navigating to  Combi department summary report page in client busns level*****");
		Combi_Department_Summary CDP = PageFactory.initElements(driver, Combi_Department_Summary.class);
		this.CommonData();
		CDP.GoToUrl(Combi_Department_Summary);
	
	}
	
	@Test(priority = 6, enabled = true)
	public void TC_Combi_Department_Summary_Report() throws InterruptedException, IOException, AWTException {
		Description("****Checking whether Combi department summary report page have any issues when: view and Export records*****");
		Combi_Department_Summary CDP = PageFactory.initElements(driver, Combi_Department_Summary.class);
		this.DataList();
		
		String invoicemonth = Repository.getProperty("invoicemonth");
		String []filetype = {"CSV" ,"PDF","EXCEL"};
		
		CDP.Combi_Department_Summary_report(invoicemonth, filetype);
		
	}
		
	@AfterClass
	public void quit() {
		this.after();
	}

}
