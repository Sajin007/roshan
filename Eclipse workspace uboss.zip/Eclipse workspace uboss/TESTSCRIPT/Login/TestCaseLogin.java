/*-- =============================================
-- Author		: 
-- Created Date :
-- Description	: 
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/


package Login;

import java.io.IOException;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

public class TestCaseLogin extends TestBase {

	@BeforeClass
	public void setUP() throws IOException {
		init();
		// loadPropertiesFile();
	}

	@Test(priority = 1, enabled = true)
	public void Login() throws InterruptedException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("Roshan224@drd.co.in", "P@ss123456");

		//Roshan224@drd.co.in
		//P@ss123456
	}

	
	@AfterTest()
	public void tearDown() {
		// driver.quit();

	}

}
