package LiveHardwareOrders;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : May 21, 2020,1:59:04 PM
-- Description	: Test_Case_LiveHardwareOrders_Site_View.java
-- Modified by	: 
-- Modified Date: 
-- Project		: UBOSS-5-0-0-Dennu
-- =============================================*/
public class Test_Case_LiveHardwareOrders_Site_View extends TestBase {
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String LiveHardwareOrdersPage;

	/*******************************/
	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\LiveHardwareOrders\\CommonData_LiveHardwareOrders.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {

		f = new File(System.getProperty("user.dir") + "\\DataList\\LiveHardwareOrders\\Datalist_LiveHardwareOrders_Site_View.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		LiveHardwareOrdersPage = Repository.getProperty("LiveHardwareOrdersSite");
	}
	public void DataList() throws IOException {
		loadDataList();

	}

	/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		description("Testing All Scenarios In Live Hardware Orders Page in Billing Business Site");
		init();
	}
	@BeforeMethod
	public void Sleep() throws IOException, AWTException, InterruptedException {
		Thread.sleep(4000);
	}
	@Test(priority = 13, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		description("Login to Uboss");
		Thread.sleep(3000);
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("dennuthomas@drd.co.in", "P@ss12345");
		Thread.sleep(3000);
	}

	@Test(priority = 14, enabled = true)
	public void TC_LiveHardwareOrdersSite_Url() throws InterruptedException, IOException {
		description("Navigating to Live Hardware Orders Page in Billing Business Site");
		LiveHardwareOrders LHO = PageFactory.initElements(driver, LiveHardwareOrders.class);
		this.CommonData();
		LHO.GoToUrl(LiveHardwareOrdersPage);

	}
	@Test(priority = 15, enabled = true)
	public void TC_LiveHardwareOrdersSite_view() throws InterruptedException, IOException, AWTException {
		description("Test cases in Live Hardware Orders Page for View,Search and export scenarios in Billing Business Site");
		this.DataList();
		String DateFrom = Repository.getProperty("DateFrom");
		String DateTo = Repository.getProperty("DateTo");
		String SettingsButton_Visibility = Repository.getProperty("SettingsButton_Visibility");
		String searchs = Repository.getProperty("searchs");
		String []filetype = {"EXCEL","CSV"};
		LiveHardwareOrders LHO = PageFactory.initElements(driver, LiveHardwareOrders.class);
		LHO.livehardwareorders_View(DateFrom,DateTo,SettingsButton_Visibility,searchs,filetype);
	}
	
	@AfterClass
	public void quit() {
	this.after();	

}
}