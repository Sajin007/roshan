package Mobilecallclass;

import java.awt.AWTException;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		:Roshan Raju
-- Created Date : 15- April-2020
-- Description	:Testcase Mobilecallclass add page 
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/


public class TestCase_Mobilecallclass_PO_ADD extends TestBase {

	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Mobilecallclass_Creation;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Mobilecallclass\\CommonData_Mobilecallclass.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\DataList\\Mobilecallclass\\Datalist_Mobilecallclass_PO_ADD.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Mobilecallclass_Creation = Repository.getProperty("PO_Mobilecallclasscreation");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("*********Testing all scenarios in mobile call class in PO level**************");
		init();
	}

	@Test(priority = 1, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("*********Login with correct username and password**************");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}


	@Test(priority = 2, enabled = true)
	public void TC_Mobilecallclass_Url() throws InterruptedException, IOException {
		Description("*****************Navigating to mobile call class Url***********");
		Mobilecallclass_ADD mob = PageFactory.initElements(driver, Mobilecallclass_ADD.class);
		this.CommonData();
		mob.GoToUrl(Mobilecallclass_Creation);
	
	}
	
	@Test(priority = 3, enabled = true)
	public void TC_Mobilecallclass_Validation() throws InterruptedException, IOException, AWTException {
		Description("*************Checking all mandatory validation in add page****************");
		Mobilecallclass_ADD mob = PageFactory.initElements(driver, Mobilecallclass_ADD.class);
		this.DataList();
		mob.Mobilecallclass_validation();
	
	}
	
	@Test(priority = 4, enabled = true)
	public void TC_Mobilecallclass_ADD() throws InterruptedException, IOException, AWTException {
		Description("********************Checking scenarios in add page*********************");
		
		this.DataList();
		String Name = Repository.getProperty("Name");
		String Description = Repository.getProperty("Description");
		String Call_Class = Repository.getProperty("Call_Class");
		String Carrier_Name = Repository.getProperty("Carrier_Name");
		String Event_Type = Repository.getProperty("Event_Type");
		String Direction = Repository.getProperty("Direction");
		//String Charge_Code1 = Repository.getProperty("Charge_Code1");
		String Charge_Code2 = Repository.getProperty("Charge_Code2");
		String Charge_Code = Repository.getProperty("Charge_Code");
		
		Mobilecallclass_ADD mob = PageFactory.initElements(driver, Mobilecallclass_ADD.class);
		mob.Mobilecallclass_add(Name,Description,Call_Class,Carrier_Name,Event_Type,Direction,Charge_Code,Charge_Code2);
		
	}
	@AfterClass
	public void quit() {
		this.after();
	}
}
