package Mobilecallclass;

import java.awt.AWTException;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		:Roshan Raju
-- Created Date : 17- April-2020
-- Description	:Testcase Mobilecallclass edit page 
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/
public class TestCase_Mobilecallclass_Edit extends TestBase {
	
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Mobilecallclass_Creation;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Mobilecallclass\\CommonData_Mobilecallclass.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\DataList\\Mobilecallclass\\Datalist_Mobilecallclass_PO_Edit.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Mobilecallclass_Creation = Repository.getProperty("PO_Mobilecallclasscreation");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("*********Testing all scenarios in mobile call class edit in PO level**************");
		init();
	}

	@Test(priority = 5, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("*********Login with correct username and password**************");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}


	@Test(priority = 6, enabled = true)
	public void TC_Mobilecallclass_Url() throws InterruptedException, IOException {
		Description("*****************Navigating to mobile call class Url***********");
		Mobilecallclass_Edit mob = PageFactory.initElements(driver, Mobilecallclass_Edit.class);
		this.CommonData();
		mob.GoToUrl(Mobilecallclass_Creation);
	
	}
	@Test(priority = 7, enabled = true)
	public void TC_Mobilecallclass_Edit_Validation() throws InterruptedException, IOException, AWTException {
		Description("*************Checking all mandatory validation in edit page****************");
		Mobilecallclass_Edit mob = PageFactory.initElements(driver, Mobilecallclass_Edit.class);
		
		this.DataList();
		String Search = Repository.getProperty("Search");
		String Event_Type = Repository.getProperty("Event_Type");
		String Phone_Numbers = Repository.getProperty("Direction");
		
		mob.Mobilecallclass_Edit_Validation(Search,Event_Type,Phone_Numbers);
		
	}
	
	@Test(priority = 8, enabled = true)
	public void TC_Mobilecallclass_Edit() throws InterruptedException, IOException, AWTException {
		Description("**********checking scenarios in edit page*****************");
		Mobilecallclass_Edit mob = PageFactory.initElements(driver, Mobilecallclass_Edit.class);
		
		this.DataList();
		String Search1 = Repository.getProperty("Search1");
		String Description = Repository.getProperty("Description");
		String Call_Class = Repository.getProperty("Call_Class");
		String Carrier_Name = Repository.getProperty("Carrier_Name");
		String Event_Type1 = Repository.getProperty("Event_Type1");
		String Direction1 = Repository.getProperty("Direction1");
		
		mob.Mobilecallclass_edit(Search1,Description,Call_Class,Carrier_Name,Event_Type1,Direction1);
		
}

	@Test(priority = 9, enabled = true)
	public void TC_Mobilecallclass_Delete() throws InterruptedException, IOException, AWTException {
		Description("***********checking scenarios in delete case*****************");
		Mobilecallclass_Edit mob = PageFactory.initElements(driver, Mobilecallclass_Edit.class);	
		this.DataList();
		String Search2 = Repository.getProperty("Search2");	
		mob.Mobilecallclass_delete(Search2);
	}
	
	@AfterClass
	public void quit() {
		this.after();
	}
}
