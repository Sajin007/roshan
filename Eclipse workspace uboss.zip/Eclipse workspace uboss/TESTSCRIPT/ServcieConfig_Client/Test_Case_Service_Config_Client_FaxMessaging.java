package ServcieConfig_Client;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Broadworks.BroadWorksCheck;
import Login.Login;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Oct 16, 2020 , 6:06:15 PM
-- Description	: Test_Case_Service_Config_Client_FaxMessaging.java
-- Modified by	: 
-- Modified Date:
-- Project		: Uboss-5-0-5
-- =============================================*/
public class Test_Case_Service_Config_Client_FaxMessaging extends TestBase {

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String ServiceConfig_Clinet;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir")
				+ "\\CommonData\\ServcieConfig_Client\\CommonData_ServiceConf_Client.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir")
				+ "\\DataList\\ServcieConfig_Client\\DataList_ServiceConfg_FaxMessaging.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		ServiceConfig_Clinet = Repository.getProperty("ServiceConfig_Client");
	}

	public void DataList() throws IOException {
		loadDataList();

	}

	/*-----------------------------------------------------------------------------------------------------*/

	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		description("Testing for Service Config page of clinet for service (Fax Messaging) assign in web and Bw");
		init();
	}
	@BeforeMethod
	public void Sleep() throws IOException, AWTException, InterruptedException {
		Thread.sleep(4000);
	}
	@Test(priority = 13, enabled = true)
	public void TC__Login() throws InterruptedException, IOException {
		description("Login to Uboss");
		Thread.sleep(3000);
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("dennuthomas@drd.co.in", "P@ss12345");
		Thread.sleep(3000);

	}

	@Test(priority = 14, enabled = true)
	public void TC_ServiceConfig_Clinet_Url() throws InterruptedException, IOException {
		description("Navigate to Service config page of client");
		Service_Config_FaxMessaging Obj_servCofig = PageFactory.initElements(driver, Service_Config_FaxMessaging.class);
		this.CommonData();
		Obj_servCofig.GoToUrl(ServiceConfig_Clinet);
		Thread.sleep(2000);

	}
	
	@Test(priority = 15, enabled = true)
	public void TC_ServiceConfig_Clinet_AssingVal() throws InterruptedException, IOException {
		Service_Config_FaxMessaging Obj_servCofig = PageFactory.initElements(driver, Service_Config_FaxMessaging.class);
		this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		String EnbaleCheckbox = Repository.getProperty("EnbaleCheckbox");
		String faxnum = Repository.getProperty("faxnum");
		String faxExtn = Repository.getProperty("faxExtninvalid1");
		String faxExtn1 = Repository.getProperty("faxExtninvalid2");
		description(
				"Checking the Fax Messaging Serivce is listed in service config page and checking service validation");
		Obj_servCofig.servicConfigValidation(Servicename, EnbaleCheckbox, faxnum, faxExtn,faxExtn1);
	}
	
	@Test(priority = 16, enabled = true)
	public void TC_ServiceConfig_Clinet_Assing() throws InterruptedException, IOException {
		Service_Config_FaxMessaging Obj_servCofig = PageFactory.initElements(driver, Service_Config_FaxMessaging.class);
		this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		String EnbaleCheckbox = Repository.getProperty("EnbaleCheckbox");
		String faxnum = Repository.getProperty("faxnum1");
		String faxExtn = Repository.getProperty("faxExtnvalid");
		description("Checking the Fax Messaging is listed in service config page and checking service enable");
		Obj_servCofig.servicConfig(Servicename, EnbaleCheckbox, faxnum,faxExtn);
	}
	
	
	@Test(priority = 17, enabled = true)
	public void TC_ServiceConfig_BW() throws InterruptedException, IOException {
		description(
				"Checking Fax Messaging Serivce is listed in BW  and also checking in  Bw the selected service details are shown same as web");
		this.DataList();
		String UserMenu = Repository.getProperty("UserMenu");
		String webelementUserMenu = Repository.getProperty("webelementUserMenu");
		String UserID = Repository.getProperty("UserID");
		String webelementUserID = Repository.getProperty("webelementUserID");
		String UserContains = Repository.getProperty("UserContains");
		String webelementUserContains = Repository.getProperty("webelementUserContains");
		String UserText = Repository.getProperty("UserText");
		String webelementUserText = Repository.getProperty("webelementUserText");
		String UserSearch = Repository.getProperty("UserSearch");
		String webelementUserSearch = Repository.getProperty("webelementUserSearch");
		String UserSelect = Repository.getProperty("UserSelect");
		String webelementUserSelect = Repository.getProperty("webelementUserSelect");
		String UserMenuMessaging = Repository.getProperty("UserMenuMessaging");
		String webelementUserMenuMessaging = Repository.getProperty("webelementUserMenuMessaging");
		String UserMenuFaxMessaging = Repository.getProperty("UserMenuFaxMessagingON");
		String webelementUserMenuFaxMessaging = Repository.getProperty("webelementUserMenuFaxMessaging");
		String UserFaxMessaging = Repository.getProperty("UserFaxMessagingON");
		String webelementUserFaxMessaging = Repository.getProperty("webelementUserFaxMessagingON");
		String UserFaxNum = Repository.getProperty("UserFaxNumadd");
		String webelementUserFaxNum = Repository.getProperty("webelementUserFaxNum");
		String UserFaxExtn = Repository.getProperty("UserFaxExtnadd");
		String webelementUserFaxExtn = Repository.getProperty("webelementUserFaxExtn");
		String[] Type = { UserMenu, UserID, UserContains, UserText, UserSearch, UserSelect, UserMenuMessaging,
				UserMenuFaxMessaging, UserFaxMessaging, UserFaxNum,UserFaxExtn, "" };

		String[] Webelemt = { webelementUserMenu, webelementUserID, webelementUserContains, webelementUserText,
				webelementUserSearch, webelementUserSelect, webelementUserMenuMessaging,
				webelementUserMenuFaxMessaging, webelementUserFaxMessaging, webelementUserFaxNum,webelementUserFaxExtn, "" };
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.open();");
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		BroadWorksCheck Brow = PageFactory.initElements(driver, BroadWorksCheck.class);
		Brow.mainBroadworks(Type, Webelemt);
	}
	
	@Test(priority = 18, enabled = true)
	public void TC_ServiceConfig_Clinet_Assingedit() throws InterruptedException, IOException {
		Service_Config_FaxMessaging Obj_servCofig = PageFactory.initElements(driver, Service_Config_FaxMessaging.class);
		this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		String EnbaleCheckbox = Repository.getProperty("EnbaleCheckboxnochange");
		String faxnum = Repository.getProperty("faxnumedit");
		String faxExtn = Repository.getProperty("faxExtnvalidedit");
		description(
				"Checking the Fax Messaging Serivce is listed in service config page and checking service enable edit ");
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(0));
		Obj_servCofig.servicConfig(Servicename, EnbaleCheckbox, faxnum,faxExtn);
	}
	
	@Test(priority = 19, enabled = true)
	public void TC_ServiceConfig_Edit_BW() throws InterruptedException, IOException {
		description(
				"Checking Fax Messaging Serivce is listed in BW  and also checking in  Bw the selected service details are shown same as web");
		this.DataList();
		String UserMenu = Repository.getProperty("UserMenu");
		String webelementUserMenu = Repository.getProperty("webelementUserMenu");
		String UserID = Repository.getProperty("UserID");
		String webelementUserID = Repository.getProperty("webelementUserID");
		String UserContains = Repository.getProperty("UserContains");
		String webelementUserContains = Repository.getProperty("webelementUserContains");
		String UserText = Repository.getProperty("UserText");
		String webelementUserText = Repository.getProperty("webelementUserText");
		String UserSearch = Repository.getProperty("UserSearch");
		String webelementUserSearch = Repository.getProperty("webelementUserSearch");
		String UserSelect = Repository.getProperty("UserSelect");
		String webelementUserSelect = Repository.getProperty("webelementUserSelect");
		String UserMenuMessaging = Repository.getProperty("UserMenuMessaging");
		String webelementUserMenuMessaging = Repository.getProperty("webelementUserMenuMessaging");
		String UserMenuFaxMessaging = Repository.getProperty("UserMenuFaxMessagingON");
		String webelementUserMenuFaxMessaging = Repository.getProperty("webelementUserMenuFaxMessaging");
		String UserFaxMessaging = Repository.getProperty("UserFaxMessagingON");
		String webelementUserFaxMessaging = Repository.getProperty("webelementUserFaxMessagingON");
		String UserFaxNum = Repository.getProperty("UserFaxNumedit");
		String webelementUserFaxNum = Repository.getProperty("webelementUserFaxNum");
		String UserFaxExtn = Repository.getProperty("UserFaxExtnedit");
		String webelementUserFaxExtn = Repository.getProperty("webelementUserFaxExtn");
		String[] Type = { UserMenu, UserID, UserContains, UserText, UserSearch, UserSelect, UserMenuMessaging,
				UserMenuFaxMessaging, UserFaxMessaging, UserFaxNum,UserFaxExtn, "" };

		String[] Webelemt = { webelementUserMenu, webelementUserID, webelementUserContains, webelementUserText,
				webelementUserSearch, webelementUserSelect, webelementUserMenuMessaging,
				webelementUserMenuFaxMessaging, webelementUserFaxMessaging, webelementUserFaxNum,webelementUserFaxExtn, "" };
		Thread.sleep(4000);
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		BroadWorksCheck Brow = PageFactory.initElements(driver, BroadWorksCheck.class);
		Brow.mainBroadworks(Type, Webelemt);

	}
	@Test(priority = 20, enabled = true)
	public void TC_ServiceConfig_Client_disable() throws InterruptedException, IOException {
		Service_Config_FaxMessaging Obj_servCofig = PageFactory.initElements(driver, Service_Config_FaxMessaging.class);
		this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		String EnbaleCheckbox = Repository.getProperty("EnbaleUNCheckbox");
		String faxnum = Repository.getProperty("faxnumclear");
		String faxExtn = Repository.getProperty("faxExtnclear");
		description(
				"Checking the Fax Messaging Serivce is listed in service config page and checking service disable");
		
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(0));
		Obj_servCofig.servicConfig(Servicename, EnbaleCheckbox, faxnum,faxExtn);
	}

	@Test(priority = 21, enabled = true)
	public void TC_ServiceConfig_Disable_BW() throws InterruptedException, IOException {
		description(
				"Checking Fax Messaging Serivce is listed in BW  and also checking in  Bw the selected service details are shown same as web");
		this.DataList();
		String UserMenu = Repository.getProperty("UserMenu");
		String webelementUserMenu = Repository.getProperty("webelementUserMenu");
		String UserID = Repository.getProperty("UserID");
		String webelementUserID = Repository.getProperty("webelementUserID");
		String UserContains = Repository.getProperty("UserContains");
		String webelementUserContains = Repository.getProperty("webelementUserContains");
		String UserText = Repository.getProperty("UserText");
		String webelementUserText = Repository.getProperty("webelementUserText");
		String UserSearch = Repository.getProperty("UserSearch");
		String webelementUserSearch = Repository.getProperty("webelementUserSearch");
		String UserSelect = Repository.getProperty("UserSelect");
		String webelementUserSelect = Repository.getProperty("webelementUserSelect");
		String UserMenuMessaging = Repository.getProperty("UserMenuMessaging");
		String webelementUserMenuMessaging = Repository.getProperty("webelementUserMenuMessaging");
		String UserMenuFaxMessaging = Repository.getProperty("UserMenuFaxMessagingOFF");
		String webelementUserMenuFaxMessaging = Repository.getProperty("webelementUserMenuFaxMessaging");
		String UserFaxMessaging = Repository.getProperty("UserMenuFaxMessagingUnassign");
		String webelementUserFaxMessagingOFF = Repository.getProperty("webelementUserFaxMessagingOFF");
		String UserFaxNum = Repository.getProperty("UserFaxNumclear");
		String webelementUserFaxNum = Repository.getProperty("webelementUserFaxNum");
		String UserFaxExtn = Repository.getProperty("UserFaxExtnclear");
		String webelementUserFaxExtn = Repository.getProperty("webelementUserFaxExtn");
		String[] Type = { UserMenu, UserID, UserContains, UserText, UserSearch, UserSelect, UserMenuMessaging,
				UserMenuFaxMessaging, UserFaxMessaging, UserFaxNum,UserFaxExtn, "" };

		String[] Webelemt = { webelementUserMenu, webelementUserID, webelementUserContains, webelementUserText,
				webelementUserSearch, webelementUserSelect, webelementUserMenuMessaging,
				webelementUserMenuFaxMessaging, webelementUserFaxMessagingOFF, webelementUserFaxNum,webelementUserFaxExtn, "" };
		
		Thread.sleep(4000);
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		BroadWorksCheck Brow = PageFactory.initElements(driver, BroadWorksCheck.class);
		Brow.mainBroadworks(Type, Webelemt);

	}

	@AfterClass
	public void quit() {
		this.after();

	}

}
