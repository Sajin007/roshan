package ServcieConfig_Client;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Broadworks.BroadWorksCheck;
import Login.Login;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Oct 13, 2020 , 12:09:04 PM
-- Description	: Test_Case_Service_Config_Client_RemoteOffice.java
-- Modified by	: 
-- Modified Date:
-- Project		: Uboss-5-0-5
-- =============================================*/
public class Test_Case_Service_Config_Client_RemoteOffice extends TestBase {

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String ServiceConfig_Clinet;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir")
				+ "\\CommonData\\ServcieConfig_Client\\CommonData_ServiceConf_Client.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir")
				+ "\\DataList\\ServcieConfig_Client\\DataList_ServiceConfg_RemoteOffice.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		ServiceConfig_Clinet = Repository.getProperty("ServiceConfig_Client");
	}

	public void DataList() throws IOException {
		loadDataList();

	}

	/*-----------------------------------------------------------------------------------------------------*/

	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		description("Testing for Service Config page of clinet for service (Remote Office) assign in web and Bw");
		init();
	}
	@BeforeMethod
	public void Sleep() throws IOException, AWTException, InterruptedException {
		Thread.sleep(4000);
	}
	@Test(priority = 22, enabled = true)
	public void TC__Login() throws InterruptedException, IOException {
		description("Login to Uboss");
		Thread.sleep(3000);
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("dennuthomas@drd.co.in", "P@ss12345");
		Thread.sleep(3000);

	}

	@Test(priority = 23, enabled = true)
	public void TC_ServiceConfig_Clinet_Url() throws InterruptedException, IOException {
		description("Navigate to Service config page of client");
		Service_Config_RemoteOffice Obj_servCofig = PageFactory.initElements(driver, Service_Config_RemoteOffice.class);
		this.CommonData();
		Obj_servCofig.GoToUrl(ServiceConfig_Clinet);
		Thread.sleep(2000);

	}

	@Test(priority = 24, enabled = true)
	public void TC_ServiceConfig_Clinet_AssingVal() throws InterruptedException, IOException {
		Service_Config_RemoteOffice Obj_servCofig = PageFactory.initElements(driver, Service_Config_RemoteOffice.class);
		this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		String EnbaleCheckbox = Repository.getProperty("EnbaleCheckbox");
		String RemoveROCheckbox = Repository.getProperty("RemoveRemoteCheckbox");
		String RONum = Repository.getProperty("RemoteNumberInvalid");
		description(
				"Checking the Remote Office Serivce is listed in service config page and checking service validation");
		Obj_servCofig.servicConfigValidation(Servicename, EnbaleCheckbox, RemoveROCheckbox, RONum);
	}

	@Test(priority = 25, enabled = true)
	public void TC_ServiceConfig_Clinet_Assing() throws InterruptedException, IOException {
		Service_Config_RemoteOffice Obj_servCofig = PageFactory.initElements(driver, Service_Config_RemoteOffice.class);
		this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		String EnbaleCheckbox = Repository.getProperty("EnbaleCheckbox");
		String RemoveROCheckbox = Repository.getProperty("RemoveRemoteCheckbox");
		String RONum = Repository.getProperty("RemoteNumberValid");
		description(
				"Checking the Remote Office Serivce is listed in service config page and Details of serivce  in web");
		Obj_servCofig.servicConfig(Servicename, EnbaleCheckbox, RemoveROCheckbox, RONum);
	}

	@Test(priority = 26, enabled = true)
	public void TC_ServiceConfig_BW() throws InterruptedException, IOException {
		description(
				"Checking Remote Office Serivce is listed in BW  and also checking in  Bw the selected service details are shown same as web");
		this.DataList();
		String UserMenu = Repository.getProperty("UserMenu");
		String webelementUserMenu = Repository.getProperty("webelementUserMenu");
		String UserID = Repository.getProperty("UserID");
		String webelementUserID = Repository.getProperty("webelementUserID");
		String UserContains = Repository.getProperty("UserContains");
		String webelementUserContains = Repository.getProperty("webelementUserContains");
		String UserText = Repository.getProperty("UserText");
		String webelementUserText = Repository.getProperty("webelementUserText");
		String UserSearch = Repository.getProperty("UserSearch");
		String webelementUserSearch = Repository.getProperty("webelementUserSearch");
		String UserSelect = Repository.getProperty("UserSelect");
		String webelementUserSelect = Repository.getProperty("webelementUserSelect");
		String UserMenuCallControl = Repository.getProperty("UserMenuCallControl");
		String webelementUserMenuCallControl = Repository.getProperty("webelementUserMenuCallControl");
		String UserMenuRemoteOffice = Repository.getProperty("UserMenuRemoteOffice");
		String webelementUserMenuRemoteOffice = Repository.getProperty("webelementUserMenuRemoteOffice");
		String UserRemoteOffice = Repository.getProperty("UserRemoteOfficeON");
		String webelementUserRemoteOffice = Repository.getProperty("webelementUserRemoteOfficeON");
		String UserRONum = Repository.getProperty("UserRONumadd");
		String webelementUserRONum = Repository.getProperty("webelementUserRONum");

		String[] Type = { UserMenu, UserID, UserContains, UserText, UserSearch, UserSelect, UserMenuCallControl,
				UserMenuRemoteOffice, UserRemoteOffice, UserRONum, "" };

		String[] Webelemt = { webelementUserMenu, webelementUserID, webelementUserContains, webelementUserText,
				webelementUserSearch, webelementUserSelect, webelementUserMenuCallControl,
				webelementUserMenuRemoteOffice, webelementUserRemoteOffice, webelementUserRONum, "" };
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.open();");
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		BroadWorksCheck Brow = PageFactory.initElements(driver, BroadWorksCheck.class);
		Brow.mainBroadworks(Type, Webelemt);
	}

	@Test(priority = 27, enabled = true)
	public void TC_ServiceConfig_Client_Edit() throws InterruptedException, IOException {
		Service_Config_RemoteOffice Obj_servCofig = PageFactory.initElements(driver, Service_Config_RemoteOffice.class);
		this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		String EnbaleCheckbox = Repository.getProperty("EnbaleCheckboxnochange");
		String RemoveROCheckbox = Repository.getProperty("RemoveRemoteOfficeUnCheckbox");
		String RONum = Repository.getProperty("RemoteNumberValidEdit");
		description(
				"Checking the Remote Office Serivce is listed in service config page and Details of serivce changed in web");
		Thread.sleep(4000);
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(0));
		Obj_servCofig.servicConfig(Servicename, EnbaleCheckbox, RemoveROCheckbox, RONum);
	}

	@Test(priority = 28, enabled = true)
	public void TC_ServiceConfig_Edit_BW() throws InterruptedException, IOException {
		description(
				"Checking Remote Office Serivce is listed in BW  and also checking in  Bw the selected service details are shown same as web");
		this.DataList();
		String UserMenu = Repository.getProperty("UserMenu");
		String webelementUserMenu = Repository.getProperty("webelementUserMenu");
		String UserID = Repository.getProperty("UserID");
		String webelementUserID = Repository.getProperty("webelementUserID");
		String UserContains = Repository.getProperty("UserContains");
		String webelementUserContains = Repository.getProperty("webelementUserContains");
		String UserText = Repository.getProperty("UserText");
		String webelementUserText = Repository.getProperty("webelementUserText");
		String UserSearch = Repository.getProperty("UserSearch");
		String webelementUserSearch = Repository.getProperty("webelementUserSearch");
		String UserSelect = Repository.getProperty("UserSelect");
		String webelementUserSelect = Repository.getProperty("webelementUserSelect");
		String UserMenuCallControl = Repository.getProperty("UserMenuCallControl");
		String webelementUserMenuCallControl = Repository.getProperty("webelementUserMenuCallControl");
		String UserMenuRemoteOffice = Repository.getProperty("UserMenuRemoteOffice");
		String webelementUserMenuRemoteOffice = Repository.getProperty("webelementUserMenuRemoteOffice");
		String UserRemoteOffice = Repository.getProperty("UserRemoteOfficeON");
		String webelementUserRemoteOffice = Repository.getProperty("webelementUserRemoteOfficeON");
		String UserRONum = Repository.getProperty("UserRONumedit");
		String webelementUserRONum = Repository.getProperty("webelementUserRONum");

		String[] Type = { UserMenu, UserID, UserContains, UserText, UserSearch, UserSelect, UserMenuCallControl,
				UserMenuRemoteOffice, UserRemoteOffice, UserRONum, "" };

		String[] Webelemt = { webelementUserMenu, webelementUserID, webelementUserContains, webelementUserText,
				webelementUserSearch, webelementUserSelect, webelementUserMenuCallControl,
				webelementUserMenuRemoteOffice, webelementUserRemoteOffice, webelementUserRONum, "" };
		Thread.sleep(4000);
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		BroadWorksCheck Brow = PageFactory.initElements(driver, BroadWorksCheck.class);
		Brow.mainBroadworks(Type, Webelemt);

	}

	@Test(priority = 29, enabled = true)
	public void TC_ServiceConfig_Client_disable() throws InterruptedException, IOException {
		Service_Config_RemoteOffice Obj_servCofig = PageFactory.initElements(driver,
				Service_Config_RemoteOffice.class);
		this.DataList();
		String Servicename = Repository.getProperty("Servicename");
		String EnbaleCheckbox = Repository.getProperty("EnbaleUNCheckbox");
		String RemoveROCheckbox = Repository.getProperty("RemoteUNCheckbox");
		String RONum = Repository.getProperty("RemoteNumberClear");
		description("Checking the Remote Office Serivce is listed in service config page and Details of serivce changed in web ");
		Thread.sleep(4000);
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(0));
		Obj_servCofig.servicConfig(Servicename,EnbaleCheckbox, RemoveROCheckbox, RONum);
	}

	@Test(priority = 30, enabled = true)
	public void TC_ServiceConfig_Disable_BW() throws InterruptedException, IOException {
		description(
				"Checking Remote Office Serivce is listed in BW  and also checking in  Bw the selected service details are shown same as web");
		this.DataList();
		String UserMenu = Repository.getProperty("UserMenu");
		String webelementUserMenu = Repository.getProperty("webelementUserMenu");
		String UserID = Repository.getProperty("UserID");
		String webelementUserID = Repository.getProperty("webelementUserID");
		String UserContains = Repository.getProperty("UserContains");
		String webelementUserContains = Repository.getProperty("webelementUserContains");
		String UserText = Repository.getProperty("UserText");
		String webelementUserText = Repository.getProperty("webelementUserText");
		String UserSearch = Repository.getProperty("UserSearch");
		String webelementUserSearch = Repository.getProperty("webelementUserSearch");
		String UserSelect = Repository.getProperty("UserSelect");
		String webelementUserSelect = Repository.getProperty("webelementUserSelect");
		String UserMenuCallControl = Repository.getProperty("UserMenuCallControl");
		String webelementUserMenuCallControl = Repository.getProperty("webelementUserMenuCallControl");
		String UserMenuRemoteOffice = Repository.getProperty("UserMenuRemoteOfficeOFF");
		String webelementUserMenuRemoteOffice = Repository.getProperty("webelementUserMenuRemoteOffice");
		String UserRemoteOffice = Repository.getProperty("UserMenuRemoteOfficeUnassign");
		String webelementUserRemoteOffice = Repository.getProperty("webelementUserRemoteOfficeOFF");
		String UserRONum = Repository.getProperty("UserRONumclear");
		String webelementUserRONum = Repository.getProperty("webelementUserRONum");

		String[] Type = { UserMenu, UserID, UserContains, UserText, UserSearch, UserSelect, UserMenuCallControl,
				UserMenuRemoteOffice, UserRemoteOffice, UserRONum, "" };

		String[] Webelemt = { webelementUserMenu, webelementUserID, webelementUserContains, webelementUserText,
				webelementUserSearch, webelementUserSelect, webelementUserMenuCallControl,
				webelementUserMenuRemoteOffice, webelementUserRemoteOffice, webelementUserRONum, "" };
		Thread.sleep(4000);
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		BroadWorksCheck Brow = PageFactory.initElements(driver, BroadWorksCheck.class);
		Brow.mainBroadworks(Type, Webelemt);

	}

	@AfterClass
	public void quit() {
		this.after();

	}

}
