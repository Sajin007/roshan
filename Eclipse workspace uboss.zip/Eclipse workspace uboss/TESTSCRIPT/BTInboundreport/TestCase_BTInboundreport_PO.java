package BTInboundreport;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		:Roshan Raju
-- Created Date : 12- May-2020
-- Description	:Test case BT inboundreport 
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class TestCase_BTInboundreport_PO extends TestBase {
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String BTInbound_Report;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\BTInboundeport\\CommonData_BTInboundreport.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\BTInboundreport\\Datalist_BTInboundreport_PO.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		BTInbound_Report = Repository.getProperty("PO_BTinboundreport");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("*Testing all scenarios in BTInbound report page in PO level*");
		init();
	}

	@Test(priority = 1, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("******Login to Uboss******");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}

	@Test(priority = 2, enabled = true)
	public void TC_BTInboundreport_Url() throws InterruptedException, IOException {
		Description("*****Navigating to BTInbound report page in PO level*****");
		BTInboundreport BT = PageFactory.initElements(driver, BTInboundreport.class);
		this.CommonData();
		BT.GoToUrl(BTInbound_Report);
	
	}
	
	@Test(priority = 3, enabled = true)
	public void TC_BTInboundreport() throws InterruptedException, IOException, AWTException {
		Description("****Checking whether BTInbound report page have any issues when: view and Export records*****");
		BTInboundreport BT = PageFactory.initElements(driver, BTInboundreport.class);
		this.DataList();
		
		String Apply_Date = Repository.getProperty("Apply_Date");
	
		String []filetype = {"EXCEL","CSV","PDF"};
		BT.BTinboundreport(Apply_Date,filetype);
		
	}
	
	@AfterClass
	public void quit() {
		this.after();
}
}
