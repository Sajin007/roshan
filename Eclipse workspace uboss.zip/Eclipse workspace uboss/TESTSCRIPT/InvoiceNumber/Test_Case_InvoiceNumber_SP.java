/*-- =============================================
-- Author		: Dennu Thomas
-- Created Date : 08-Apr-20
-- Description	: Invoice Number SP
-- Modified by	: Dennu Thomas
-- Modified Date: 30-Oct-20
-- Project		: UBOSS-5-0-5
-- =============================================*/


package InvoiceNumber;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

public class Test_Case_InvoiceNumber_SP extends TestBase{
	/*******************************/
	String InvoiceNumber_SP;

	/*******************************/
	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\InvoiceNumber\\CommonData_InvoiceNumber.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {

		f = new File(System.getProperty("user.dir") + "\\DataList\\InvoiceNumber\\Datalist_InvoiceNumber_SP.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		InvoiceNumber_SP = Repository.getProperty("InvoiceNumSP");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}

	
	
/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		description("Testing All Scenarios In Invoice Number Page in SP");
		init();
	}
	@BeforeMethod
	public void Sleep() throws IOException, AWTException, InterruptedException {
		Thread.sleep(4000);
	}
	@Test(priority = 1, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		description("Login to Uboss");
		Thread.sleep(3000);
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("dennuthomas@drd.co.in","P@ss12345");
		Thread.sleep(3000);
	}

	
	@Test(priority = 2, enabled = true)
	public void TC_InvocieNumber_url() throws InterruptedException, IOException {
		description("Navigating to Invoice Number Page in SP");
		InvoiceNumber in = PageFactory.initElements(driver, InvoiceNumber.class);
		this.CommonData();
		in.GoToUrl(InvoiceNumber_SP);

	}

	
	
	@Test(priority = 3, enabled = true)
	public void TC_InvcoiceNumer_Validtion() throws InterruptedException, IOException, AWTException {	
		description("Checking all scenarios in Invoice Number Validation in SP");
		this.DataList();
		String invoicenum = Repository.getProperty("invoicenuminvalid");
		String invoicevalue = Repository.getProperty("invoicevalueinvalid");
		InvoiceNumber in = PageFactory.initElements(driver, InvoiceNumber.class);
		in.Invoicenumber_Validation(invoicenum,invoicevalue);
	}
	
	@Test(priority = 4, enabled = true)
	public void TC_InvocieNumber() throws InterruptedException, IOException, AWTException {
		description("Checking all scenarios in Invoice Number Creation in SP");
		this.DataList();
		String invoicenum = Repository.getProperty("invoicenumsp");
		String invoiceprefix = Repository.getProperty("invoiceprefixsp");
		String invoicesuffix = Repository.getProperty("invoicesuffixsp");
		String invoicevalue = Repository.getProperty("invoicevaluesp");
		InvoiceNumber in = PageFactory.initElements(driver, InvoiceNumber.class);
		in.Invoicenumumber(invoicenum, invoiceprefix, invoicesuffix,invoicevalue);
	}
	@AfterClass
	public void quit() {
	this.after();	
	
	}
}
