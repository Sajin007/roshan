/*-- =============================================
-- Author		: Dennu Thomas
-- Created Date : 09-Apr-20
-- Description	: Invoice Number PO
-- Modified by	: Dennu Thomas
-- Modified Date: 30-Oct-20
-- Project		: UBOSS-5-0-5
-- =============================================*/

package InvoiceNumber;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

public class Test_Case_InvoiceNumber_PO extends TestBase {
	/*******************************/
	String InvoiceNumber_PO;

	/*******************************/
	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\InvoiceNumber\\CommonData_InvoiceNumber.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {

		f = new File(System.getProperty("user.dir")
				+ "\\DataList\\InvoiceNumber\\Datalist_InvoiceNumber_PO.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		InvoiceNumber_PO = Repository.getProperty("InvoiceNumPO");
	}

	public void DataList() throws IOException {
		loadDataList();

	}

	/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		description("Testing All Scenarios In Invoice Number Page in PO");
		init();
	}
	@BeforeMethod
	public void Sleep() throws IOException, AWTException, InterruptedException {
		Thread.sleep(4000);
	}
	@Test(priority = 5, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		description("Login to Uboss");
		Thread.sleep(3000);
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("dennuthomas@drd.co.in", "P@ss12345");
		Thread.sleep(3000);
	}

	@Test(priority = 6, enabled = true)
	public void TC_InvocieNumber_Url() throws InterruptedException, IOException {
		description("Navigating to Invoice Number Page in PO");
		InvoiceNumber in = PageFactory.initElements(driver, InvoiceNumber.class);
		this.CommonData();
		in.GoToUrl(InvoiceNumber_PO);

	}

	@Test(priority = 7, enabled = true)
	public void TC_InvoiceNumber_Validation() throws InterruptedException, IOException, AWTException {
		description("Checking all validation  in Invoice Number in PO");
		this.DataList();
		String invoicenum = Repository.getProperty("invoicenuminvalid");
		String invoicevalue = Repository.getProperty("invoicevalueinvalid");
		InvoiceNumber in = PageFactory.initElements(driver, InvoiceNumber.class);
		in.Invoicenumber_Validation(invoicenum,invoicevalue);
	}

	@Test(priority = 8, enabled = true)
	public void TC_InvocieNumber() throws InterruptedException, IOException, AWTException {
		description("Checking all scenarios in Invoice Number Creation in PO");
		this.DataList();
		String invoicenum = Repository.getProperty("invoicenumpo");
		String invoiceprefix = Repository.getProperty("invoiceprefixpo");
		String invoicesuffix = Repository.getProperty("invoicesuffixpo");
		String invoicevalue = Repository.getProperty("invoicevaluepo");
		InvoiceNumber in = PageFactory.initElements(driver, InvoiceNumber.class);
		in.Invoicenumumber(invoicenum, invoiceprefix, invoicesuffix, invoicevalue);
	}
	@AfterClass
	public void quit() {
	this.after();	
	
	}
}
