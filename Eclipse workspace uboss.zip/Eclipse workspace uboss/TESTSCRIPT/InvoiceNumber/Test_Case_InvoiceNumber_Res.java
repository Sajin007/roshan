/*-- =============================================
-- Author		: Dennu Thomas
-- Created Date : 09-Apr-20
-- Description	: Invoice Number Res
-- Modified by	: Dennu Thomas
-- Modified Date: 30-Oct-20
-- Project		: UBOSS-5-0-5
-- =============================================*/
package InvoiceNumber;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

public class Test_Case_InvoiceNumber_Res extends TestBase{
	/*******************************/
	String InvoiceNumber_Res;

	/*******************************/
	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\InvoiceNumber\\CommonData_InvoiceNumber.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {

		f = new File(System.getProperty("user.dir") + "\\DataList\\InvoiceNumber\\Datalist_InvoiceNumber_Reseller_.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		InvoiceNumber_Res = Repository.getProperty("InvoiceNumRes");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}

	
	
/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		description("Testing All Scenarios In Invoice Number Page in Distributor Reseller");
		init();
	}
	@BeforeMethod
	public void Sleep() throws IOException, AWTException, InterruptedException {
		Thread.sleep(4000);
	}
	@Test(priority = 13, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		description("Login to Uboss");
		Thread.sleep(3000);
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("dennuthomas@drd.co.in","P@ss12345");
		Thread.sleep(3000);
	}

	
	@Test(priority = 14, enabled = true)
	public void TC_InvoiceNumber_Url() throws InterruptedException, IOException {
		description("Navigating to Invoice Number Page in Distributor Reseller");
		InvoiceNumber in = PageFactory.initElements(driver, InvoiceNumber.class);
		this.CommonData();
		in.GoToUrl(InvoiceNumber_Res);

	}

	
	
	@Test(priority = 15, enabled = true)
	public void TC_InvoiceNumber_Validation() throws InterruptedException, IOException, AWTException {	
		description("Checking all validation  in Invoice Number in Distributor Reseller");
		this.DataList();
		String invoicenum = Repository.getProperty("invoicenuminvalid");
		String invoicevalue = Repository.getProperty("invoicevalueinvalid");
		InvoiceNumber in = PageFactory.initElements(driver, InvoiceNumber.class);
		in.Invoicenumber_Validation(invoicenum,invoicevalue);
	}
	
	@Test(priority = 16, enabled = true)
	public void TC_InvoiceNumber() throws InterruptedException, IOException, AWTException {
		description("Checking all scenarios in Invoice Number Creation in Distributor Reseller");
		this.DataList();
		String invoicenum = Repository.getProperty("invoicenumres");
		String invoiceprefix = Repository.getProperty("invoiceprefixres");
		String invoicesuffix = Repository.getProperty("invoicesuffixres");
		String invoicevalue = Repository.getProperty("invoicevalueres");		
		InvoiceNumber in = PageFactory.initElements(driver, InvoiceNumber.class);
		in.Invoicenumumber(invoicenum, invoiceprefix, invoicesuffix,invoicevalue);
	}
	@AfterClass
	public void quit() {
	this.after();	
	
	}
}
