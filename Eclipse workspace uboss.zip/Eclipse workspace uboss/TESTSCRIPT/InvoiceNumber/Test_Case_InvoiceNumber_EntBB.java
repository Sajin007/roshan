package InvoiceNumber;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : 09-Apr-20
-- Description	: Test_Case_InvoiceNumber_EntBB.java
-- Modified by	: Dennu Thomas
-- Modified Date: 30-Oct-20
-- Project		: Uboss-5-0-5
-- =============================================*/
public class Test_Case_InvoiceNumber_EntBB extends TestBase {
/*******************************/
String InvoiceNumber_BB;

/*******************************/
public static Properties Repository = new Properties();
public File f;
public FileInputStream FI;

public void loadCommonData() throws IOException {
	f = new File(System.getProperty("user.dir") + "\\CommonData\\InvoiceNumber\\CommonData_InvoiceNumber.properties");
	FI = new FileInputStream(f);
	Repository.load(FI);

}
public void loadDataList() throws IOException {

	f = new File(System.getProperty("user.dir") + "\\DataList\\InvoiceNumber\\Datalist_InvoiceNumber_EntBillingBusiness.properties");
	FI = new FileInputStream(f);
	Repository.load(FI);

}
public void CommonData() throws IOException {
	loadCommonData();
	InvoiceNumber_BB = Repository.getProperty("InvoiceNumEntBB");
	}

public void DataList() throws IOException {
	loadDataList();
	
	}



/*-----------------------------------------------------------------------------------------------------*/
@BeforeClass
public void setUP() throws IOException, AWTException, InterruptedException {
	description("Testing All Scenarios In Invoice Number Page in Enterprise Billing Business");
	init();
}
@BeforeMethod
public void Sleep() throws IOException, AWTException, InterruptedException {
	Thread.sleep(4000);
}
@Test(priority = 25, enabled = true)
public void TC_Login() throws InterruptedException, AWTException {
	description("Login to Uboss");
	Thread.sleep(3000);
	Login login = PageFactory.initElements(driver, Login.class);
	login.LogintoUboss("dennuthomas@drd.co.in","P@ss12345");
	Thread.sleep(3000);
}


@Test(priority = 26, enabled = true)
public void TC_InvoiceNumber_Url() throws InterruptedException, IOException {
	description("Navigating to Invoice Number Page in Billing Business");
	InvoiceNumber in = PageFactory.initElements(driver, InvoiceNumber.class);
	this.CommonData();
	in.GoToUrl(InvoiceNumber_BB);

}



@Test(priority = 27, enabled = true)
public void TC_InvocieNumebr_Validation() throws InterruptedException, IOException, AWTException {	
	description("Checking all validation  in Invoice Number in Billing Business");
	this.DataList();
	String invoicenum = Repository.getProperty("invoicenuminvalid");
	String invoicevalue = Repository.getProperty("invoicevalueinvalid");
	InvoiceNumber in = PageFactory.initElements(driver, InvoiceNumber.class);
	in.Invoicenumber_Validation(invoicenum,invoicevalue);
}

@Test(priority = 28, enabled = true)
public void TC_InvocieNumeber() throws InterruptedException, IOException, AWTException {
	description("Checking all scenarios in Invoice Number Creation in Billing Business");
	this.DataList();
	String invoicenum = Repository.getProperty("invoicenumbb");
	String invoiceprefix = Repository.getProperty("invoiceprefixbb");
	String invoicesuffix = Repository.getProperty("invoicesuffixbb");
	String invoicevalue = Repository.getProperty("invoicevaluebb");
	InvoiceNumber in = PageFactory.initElements(driver, InvoiceNumber.class);
	in.Invoicenumumber(invoicenum, invoiceprefix, invoicesuffix,invoicevalue);
}
@AfterClass
public void quit() {
this.after();	

}
}
