package ServiceAssignment;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Oct 7, 2020 , 4:11:42 PM
-- Description	: Test_Case_UnityDashboardTabular100P_SeviceAssignment_CB_EDIT.java
-- Modified by	: 
-- Modified Date:
-- Project		: Uboss-5-0-5
-- =============================================*/
public class Test_Case_UnityDashboardTabular100P_SeviceAssignment_CB_EDIT extends TestBase{
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Service;

	/*******************************/
	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\ServiceAssignment\\CommonData_UnityDashboardTabular100P.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {

		f = new File(
		System.getProperty("user.dir") + "\\DataList\\ServiceAssignment\\Datalist_UnityDashboardTabular100P_CB_EDIT.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		Service = Repository.getProperty("UnityDashboardTabular100P_ServiceAssignmentCB");
	}

	public void DataList() throws IOException {
		loadDataList();

	}
	/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		description("Testing All Scenarios In Unity Dashboard Tabular 100+ Service Assignment in CB");
		init();
	}
	@BeforeMethod
	public void Sleep() throws IOException, AWTException, InterruptedException {
		Thread.sleep(4000);
	}
	@Test(priority = 141, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		description("Login to Uboss");
		Thread.sleep(3000);
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("dennuthomas@drd.co.in", "P@ss12345");
		Thread.sleep(3000);
	}

	@Test(priority = 142, enabled = true)
	public void TC_ServicePage_Url() throws InterruptedException, IOException {
		description("Navigating to Service Assignment Page in CB");
		UnityDashboardTabular100P_ServiceAssignment_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardTabular100P_ServiceAssignment_EDIT.class);
		this.CommonData();
		ALNP.GoToUrl(Service);

	}

	@Test(priority = 143, enabled = true)
	public void TC_UnityDashboardTabular100PServiceAssignment_Edit() throws InterruptedException, IOException, AWTException {
		description("Test cases in Unity Dashboard Tabular 100+ Service Assignment Edit in CB");
		this.DataList();
		String searchs=Repository.getProperty("searchs");
		String des = Repository.getProperty("des");
		String department = Repository.getProperty("department");
		UnityDashboardTabular100P_ServiceAssignment_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardTabular100P_ServiceAssignment_EDIT.class);
		ALNP.Serviceassignment_EDIT( searchs,des,department );
	}

	@Test(priority = 144, enabled = true)
	public void TC_UnityDashboardTabular100PServiceAssignment_Delete() throws InterruptedException, IOException, AWTException {
		description("Test cases in Unity Dashboard Tabular 100+ Service Assignment Delete in CB");
		this.DataList();
		String searchs=Repository.getProperty("searchs");
		
		UnityDashboardTabular100P_ServiceAssignment_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardTabular100P_ServiceAssignment_EDIT.class);
		ALNP.Serviceassignment_Delete( searchs);
	}


	@AfterClass
	public void quit() {
	this.after();	

	} 
}
