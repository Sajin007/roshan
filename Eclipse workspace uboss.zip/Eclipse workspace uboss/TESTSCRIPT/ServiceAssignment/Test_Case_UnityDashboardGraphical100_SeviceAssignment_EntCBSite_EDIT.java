package ServiceAssignment;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Oct 1, 2020 , 3:11:06 PM
-- Description	: Test_Case_UnityDashboardGraphical100_SeviceAssignment_EntCBSite_EDIT.java
-- Modified by	: 
-- Modified Date:
-- Project		: Uboss-5-0-5
-- =============================================*/
public class Test_Case_UnityDashboardGraphical100_SeviceAssignment_EntCBSite_EDIT extends TestBase{
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Service;

	/*******************************/
	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\ServiceAssignment\\CommonData_UnityDashboardGraphical100.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {

		f = new File(
		System.getProperty("user.dir") + "\\DataList\\ServiceAssignment\\Datalist_UnityDashboardGraphical100_EntCBSite_EDIT.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		Service = Repository.getProperty("UnityDashboardGraphical100_ServiceAssignmentEntCBSite");
	}

	public void DataList() throws IOException {
		loadDataList();

	}
	/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		description("Testing All Scenarios In Unity Dashboard Graphical 100 Service Assignment in EntCBSite");
		init();
	}
	@BeforeMethod
	public void Sleep() throws IOException, AWTException, InterruptedException {
		Thread.sleep(4000);
	}
	@Test(priority = 117, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		description("Login to Uboss");
		Thread.sleep(3000);
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("dennuthomas@drd.co.in", "P@ss12345");
		Thread.sleep(3000);
	}

	@Test(priority = 118, enabled = true)
	public void TC_ServicePage_Url() throws InterruptedException, IOException {
		description("Navigating to Service Assignment Page in EntCBSite");
		UnityDashboardGraphical100_ServiceAssignment_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardGraphical100_ServiceAssignment_EDIT.class);
		this.CommonData();
		ALNP.GoToUrl(Service);

	}

	@Test(priority = 119, enabled = true)
	public void TC_UnityDashboardGraphical100ServiceAssignment_Edit() throws InterruptedException, IOException, AWTException {
		description("Test cases in Unity Dashboard Graphical 100 Service Assignment Edit in EntCBSite");
		this.DataList();
		String searchs=Repository.getProperty("searchs");
		String des = Repository.getProperty("des");
		String department = Repository.getProperty("department");
		UnityDashboardGraphical100_ServiceAssignment_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardGraphical100_ServiceAssignment_EDIT.class);
		ALNP.Serviceassignment_EDIT( searchs,des,department );
	}

	@Test(priority = 120, enabled = true)
	public void TC_UnityDashboardGraphical100ServiceAssignment_Delete() throws InterruptedException, IOException, AWTException {
		description("Test cases in Unity Dashboard Graphical 100 Service Assignment Delete in EntCBSite");
		this.DataList();
		String searchs=Repository.getProperty("searchs");
		
		UnityDashboardGraphical100_ServiceAssignment_EDIT ALNP = PageFactory.initElements(driver, UnityDashboardGraphical100_ServiceAssignment_EDIT.class);
		ALNP.Serviceassignment_Delete( searchs);
	}


	@AfterClass
	public void quit() {
	this.after();	

	} 
}

