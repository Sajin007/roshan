package Poratluser;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;
import Portaluser.Portaluser_ADD;

/*-- =============================================
-- Author		:Roshan Raju
-- Created Date : 31- March-2020
-- Description	:Portal user add page
-- Modified by	:Roshan Raju
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class TestCase_PortalUser_SP_ADD extends TestBase {

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Portaluser_Creation;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Portaluser\\CommonData_PortalUser.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\Portaluser\\DataList_PortalUser_SP_ADD.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		Portaluser_Creation = Repository.getProperty("SP_Portalusercreation");
	}

	public void DataList() throws IOException {
		loadDataList();

	}

	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("*********Testing all scenarios in portal user add in SP level**************");
		init();
	}

	@Test(priority = 1, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("*********Login with correct username and password**************");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com", "P@ss123456780");

	}

	@Test(priority = 2, enabled = true)
	public void TC_Portaluser_Url() throws InterruptedException, IOException {
		Portaluser_ADD po = PageFactory.initElements(driver, Portaluser_ADD.class);
		Description("*****************Navigating to portal user Url in SP level***********");
		this.CommonData();
		po.GoToUrl(Portaluser_Creation);

	}

	@Test(priority = 3, enabled = false)
	public void TC_Portaluser_Validation() throws InterruptedException, IOException, AWTException {
		Portaluser_ADD add = PageFactory.initElements(driver, Portaluser_ADD.class);
		Description("*****************checking all mandatory validations***********");
		this.DataList();
		String EmailEmpty = Repository.getProperty("EmailEmpty");
		String PasswordEmpty = Repository.getProperty("PasswordEmpty");
		String Password = Repository.getProperty("Password");
		String Confirm_PasswordEmpty = Repository.getProperty("Confirm_PasswordEmpty");
		String Display_NameEmpty = Repository.getProperty("Display_NameEmpty");
		String Display_Name = Repository.getProperty("Display_Name");
		String Phone_NumbersEmpty = Repository.getProperty("Phone_NumbersEmpty");
		String Phone_Numbers = Repository.getProperty("Phone_Numbers");
		String Call_Recording_Security = Repository.getProperty("Call_Recording_Securitydefault");
		String PhotoEmpty = Repository.getProperty("PhotoEmpty");
		String sendEmailcheckboxuncheck = Repository.getProperty("sendEmailcheckboxuncheck");
		String Time_Zoneempty = Repository.getProperty("Time_ZoneEmpty");
		String Time_Zone = Repository.getProperty("Time_Zone");
		String Language = Repository.getProperty("LanguageEmpty");

		
		String[] setuserrolecheckboxEmpty = {};
		String[] setuserrolecheckbox = {"Administrator"};
		String[] TicketStatusDefaults = {};
		String[] numberportcheckbox = {};
		
		String Emailinvalid = Repository.getProperty("Emailinvalid");
		String Confirm_Passwordrule = Repository.getProperty("Confirm_Passwordrule");
	
		
		
		add.Portaluser_creation_validation(EmailEmpty, PasswordEmpty, Confirm_PasswordEmpty, Display_NameEmpty, Phone_NumbersEmpty,
				Call_Recording_Security, PhotoEmpty, sendEmailcheckboxuncheck, Time_Zoneempty, Language, setuserrolecheckboxEmpty,
				TicketStatusDefaults, numberportcheckbox);
		add.Portaluser_creation_validation(Emailinvalid, Password, Confirm_Passwordrule, Display_Name, Phone_Numbers,
				Call_Recording_Security, PhotoEmpty, sendEmailcheckboxuncheck, Time_Zone, Language, setuserrolecheckbox,
				TicketStatusDefaults, numberportcheckbox);
	}

	@Test(priority = 4, enabled = true)
	public void TC_Portaluser_ADD() throws InterruptedException, IOException, AWTException {
		Description("*****************checking scenarios in add page in SP level***********");
		this.DataList();
		String Email = Repository.getProperty("Email");
		String Password = Repository.getProperty("Password");
		String Confirm_Password = Repository.getProperty("Confirm_Password");
		String Display_Name = Repository.getProperty("Display_Name");
		String Phone_Numbers = Repository.getProperty("Phone_Numbers");
		String Call_Recording_Security = Repository.getProperty("Call_Recording_Security");
		String Photo = Repository.getProperty("Photo");
		String sendEmailcheckbox = Repository.getProperty("sendEmailcheckbox");
		String Time_Zone = Repository.getProperty("Time_Zone");
		String Language = Repository.getProperty("Language");

		String[] setuserrolecheckbox = {"Administrator"};
		String[] TicketStatusDefaults = { "New", "Open" };
		String[] releasenotificationcheckbox = { "Major", "Minor" };
		String[] numberportcheckbox = { "Port Request and Validation", "Pending Customer" };

		Portaluser_ADD add1 = PageFactory.initElements(driver, Portaluser_ADD.class);
		add1.portaluser_Add(Email, Password, Confirm_Password, Display_Name, Phone_Numbers, Call_Recording_Security,
				Photo, sendEmailcheckbox,Time_Zone, Language, setuserrolecheckbox, TicketStatusDefaults,
				releasenotificationcheckbox, numberportcheckbox);
	}

	@AfterClass
	public void quit() {
		this.after();
	}

}
