package Poratluser;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;
import Portaluser.Portaluser_Edit;

/*-- =============================================
-- Author		:Roshan Raju
-- Created Date : 31- March-2020
-- Description	:Portal user edit and delete page
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class TestCase_PortalUser_SP_Edit extends TestBase  {
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Portaluser_Creation;

	/*******************************/
	
	
	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Portaluser\\CommonData_PortalUser.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\DataList\\Portaluser\\DataList_Portaluser_SP_Edit.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Portaluser_Creation = Repository.getProperty("SP_Portalusercreation");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("*********Testing all scenarios in portal user edit in SP level**************");
		init();
	}

	@Test(priority = 5, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Description("*********Login with correct username and password**************");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}

	@Test(priority = 6, enabled = true)
	public void TC_Portaluser_Url() throws InterruptedException, IOException {
		Description("*********Navigating to portal user Url in SP level**************");
		Portaluser_Edit edit = PageFactory.initElements(driver, Portaluser_Edit.class);
		this.CommonData();
		edit.GoToUrl(Portaluser_Creation);

	}
	
	@Test(priority = 7, enabled = true)
	public void TC_Portaluser_Edit_Validation() throws InterruptedException, IOException, AWTException {
		Description("*********Checing mandatory validation of edit page**************");
		this.DataList();
		String Search = Repository.getProperty("Search");
		String PasswordEmpty = Repository.getProperty("PasswordEmpty");
		String Phone_NumbersEmpty = Repository.getProperty("Phone_NumbersEmpty");
		String Time_ZoneEmpty = Repository.getProperty("Time_ZoneEmpty");
		String LanguageEmpty = Repository.getProperty("LanguageEmpty");
		String PhotoEmpty = Repository.getProperty("PhotoEmpty");
		String Display_NameEmpty = Repository.getProperty("Display_NameEmpty");
		String Confirm_Passwordrule = Repository.getProperty("Confirm_Passwordrule");
	
		
		String Call_Recording_SecurityEmpty = Repository.getProperty("Call_Recording_Security");
	
		
		Portaluser_Edit edit = PageFactory.initElements(driver, Portaluser_Edit.class);
		edit.Portaluser_Edit_validation(Search, PasswordEmpty, Phone_NumbersEmpty,Time_ZoneEmpty, LanguageEmpty,PhotoEmpty,Display_NameEmpty,Confirm_Passwordrule, Call_Recording_SecurityEmpty);
	}
	
	@Test(priority = 8, enabled = true)
	public void TC_Portaluser_Edit() throws InterruptedException, IOException, AWTException {
		Description("*********Checing scenarios in edit page in SP level**************");
		this.DataList();
		String Search = Repository.getProperty("Search");
		String Password = Repository.getProperty("Password");
		String Phone_Numbers = Repository.getProperty("Phone_Numbers");
		String Time_Zone = Repository.getProperty("Time_Zone");
		String Language = Repository.getProperty("Language");
		String Photo = Repository.getProperty("Photo");
		String Display_Name = Repository.getProperty("Display_Name");
		String Confirm_Password = Repository.getProperty("Confirm_Password");
		
		
		String [] buttons ={"add","add","add","Remove","Remove","Remove"};
		String[] buddynames = {"asd","Ajeesh","Balaji R","Ajeesh","asd","Balaji R"};
		String Call_Recording_Security = Repository.getProperty("Call_Recording_Security");
		String [] setuserrolecheckbox  = {"Call Recording"}; 
        String [] TicketStatusDefaults  = {"New","Open","Deleted"}; 
        String ticketmovesto = Repository.getProperty("ticketmovesto");
        String [] numberportcheckbox  = {"To Be Submitted To Carrier","Accepted"}; 
		Portaluser_Edit edit = PageFactory.initElements(driver, Portaluser_Edit.class);
		edit.Portaluser_edit( Search,  Password,  Phone_Numbers,  Time_Zone,  Language, Photo,
				 Display_Name,  Confirm_Password,  Call_Recording_Security,  setuserrolecheckbox,
				 TicketStatusDefaults, ticketmovesto,buttons, buddynames,  numberportcheckbox);
	}
	
	@Test(priority = 9, enabled = true)
	public void TC_Portaluser_Delete() throws InterruptedException, IOException, AWTException {
		Description("*********Checing scenarios in delete case in SP level**************");
		this.DataList();
		String Search2 = Repository.getProperty("Search2");		
		Portaluser_Edit edit = PageFactory.initElements(driver, Portaluser_Edit.class);
		edit.Portaluser_Delete(Search2);
	}
	@AfterClass
	public void quit() {
		this.after();
	}
	}
