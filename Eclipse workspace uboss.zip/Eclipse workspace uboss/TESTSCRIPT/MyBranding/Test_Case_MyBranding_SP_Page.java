/*-- =============================================
-- Author		: Dennu Thomas
-- Created Date : 20-Apr-20
-- Description	: TestCase MyBranding SP
-- Modified by	: 
-- Modified Date:  
-- Project		: UBOSS-5-0-5
-- =============================================*/
package MyBranding;
import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;
import Login.Login;

public class Test_Case_MyBranding_SP_Page  extends TestBase {
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String MyBrandingPage;

	/*******************************/
	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\MyBranding\\CommonData_MyBranding.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {

		f = new File(System.getProperty("user.dir") + "\\DataList\\MyBranding\\Datalist_MyBranding_SP_Page.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		MyBrandingPage = Repository.getProperty("MyBrandingSP");
	}

	public void DataList() throws IOException {
		loadDataList();

	}

	/*-----------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		description("Testing All Scenarios In My Branding Page in SP");
		init();
	}
	@BeforeMethod
	public void Sleep() throws IOException, AWTException, InterruptedException {
		Thread.sleep(4000);
	}
	@Test(priority = 1, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		description("Login to Uboss");
		Thread.sleep(3000);
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("dennuthomas@drd.co.in", "P@ss12345");
		Thread.sleep(3000);
	}

	@Test(priority = 2, enabled = true)
	public void TC_MyBranding_Url() throws InterruptedException, IOException {
		description("Navigating to My Branding Page in SP");
		MyBranding MB = PageFactory.initElements(driver, MyBranding.class);
		this.CommonData();
		MB.GoToUrl(MyBrandingPage);

	}
	
	@Test(priority = 3, enabled = true)
	public void TC_MyBranding_SP() throws InterruptedException, IOException, AWTException {
		description("Test cases in My Branding Page for Upload logo and validation scenarios in SP");
		this.DataList();
		String FilePath=Repository.getProperty("filepath");
		String FilePath1=Repository.getProperty("filepath1");
		String dur = Repository.getProperty("dur");
		String exurl = Repository.getProperty("exurl");
		MyBranding MB = PageFactory.initElements(driver, MyBranding.class);
		MB.MyBranding_Page(FilePath,FilePath1, dur, exurl);

	}
	@AfterClass
	public void quit() {
	this.after();	

	}

}
