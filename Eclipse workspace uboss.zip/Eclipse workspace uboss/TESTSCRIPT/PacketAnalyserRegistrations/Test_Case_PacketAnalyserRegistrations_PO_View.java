package PacketAnalyserRegistrations;
/*-- =============================================
-- Author		: dennu.thomas
-- Created Date : Jun 1, 2020,8:30:27 AM
-- Description	: Test_Case_PacketAnalyserRegistrations_PO_View.java
-- Modified by	: 
-- Modified Date: 
-- Project		: UBOSS-5-0-0-Dennu
-- =============================================*/

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;


public class Test_Case_PacketAnalyserRegistrations_PO_View extends TestBase {
/*-----------------------------------------------------------------------------------------------------*/
/*******************************/
String PARegPage;

/*******************************/
public static Properties Repository = new Properties();
public File f;
public FileInputStream FI;

public void loadCommonData() throws IOException {
	f = new File(System.getProperty("user.dir") + "\\CommonData\\PacketAnalyserRegistrations\\CommonData_PacketAnalyserRegistrations.properties");
	FI = new FileInputStream(f);
	Repository.load(FI);

}

public void loadDataList() throws IOException {

	f = new File(System.getProperty("user.dir") + "\\DataList\\PacketAnalyserRegistrations\\Datalist_PacketAnalyserRegistrations_PO_Page.properties");
	FI = new FileInputStream(f);
	Repository.load(FI);

}
public void CommonData() throws IOException {
	loadCommonData();
	PARegPage = Repository.getProperty("PARegPagePO");
}
public void DataList() throws IOException {
	loadDataList();

}

/*-----------------------------------------------------------------------------------------------------*/
@BeforeClass
public void setUP() throws IOException, AWTException, InterruptedException {
	init();
}
@BeforeMethod
public void Sleep() throws IOException, AWTException, InterruptedException {
	Thread.sleep(4000);
}
@Test(priority = 1, enabled = true)
public void TC_Login() throws InterruptedException, AWTException {
	Thread.sleep(3000);
	Login login = PageFactory.initElements(driver, Login.class);
	login.LogintoUboss("dennuthomas@drd.co.in", "P@ss12345");
	Thread.sleep(3000);
}

@Test(priority = 2, enabled = true)
public void TC_PacketAnalyserRegistrations_Url() throws InterruptedException, IOException {
	PacketAnalyserRegistrations PA = PageFactory.initElements(driver, PacketAnalyserRegistrations.class);
	this.CommonData();
	PA.GoToUrl(PARegPage);

}
@Test(priority = 3, enabled = true)
public void TC_PacketAnalyserRegistrationstab_view() throws Exception {
	this.DataList();
	String reg = Repository.getProperty("reg");
	String sec = Repository.getProperty("sec");
	String DateTime = Repository.getProperty("DateTime");
	String searchs = Repository.getProperty("searchs");
	String []FileTpye = {"CSV"};
	String ActReg = Repository.getProperty("ActReg");
	String searchs1 = Repository.getProperty("searchs1");
	String []FileTpye1 = {"CSV"};
	String AttReg = Repository.getProperty("AttReg");
	String FromDate= Repository.getProperty("FromDate");
	String ToDate= Repository.getProperty("ToDate");
	String searchs2 = Repository.getProperty("searchs2");
	String []FileTpye2 = {"CSV"};
	String Unmap = Repository.getProperty("Unmap");
	String FromDate1= Repository.getProperty("FromDate1");
	String ToDate1= Repository.getProperty("ToDate1");
	String searchs3 = Repository.getProperty("searchs3");
	String []FileTpye3 = {"CSV"};
	PacketAnalyserRegistrations PA = PageFactory.initElements(driver, PacketAnalyserRegistrations.class);
	PA.registrationtab_View(reg,sec,DateTime,searchs,FileTpye,ActReg,searchs1,FileTpye1,AttReg,FromDate,ToDate,searchs2,FileTpye2,Unmap,FromDate1,ToDate1,searchs3,FileTpye3);
}
}
