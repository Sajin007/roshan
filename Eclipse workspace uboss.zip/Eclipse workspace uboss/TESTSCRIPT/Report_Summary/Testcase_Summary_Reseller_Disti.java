package Report_Summary;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : May 28, 2020,12:16:31 AM
-- Description	: Testcase_Summary_Reseller.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-ROSHAN_RAJU
-- =============================================*/
public class Testcase_Summary_Reseller_Disti extends TestBase {
	
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Report_Summary;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Report_Summary\\CommonData_Reportsummary.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\Report_Summary\\Datalist_Summary_Reseller_Disti.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Report_Summary = Repository.getProperty("summary_Reseller_Disti");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		init();
	}

	@Test(priority = 9, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}
	
	@Test(priority = 10, enabled = true)
	public void TC_Report_summary_Url() throws InterruptedException, IOException {
		Report_Summary RP = PageFactory.initElements(driver, Report_Summary.class);
		this.CommonData();
		RP.GoToUrl(Report_Summary);
	
	}
	
	@Test(priority = 11, enabled = true)
	public void TC_Report_Summary_Package() throws InterruptedException, IOException, AWTException {
		Report_Summary RP = PageFactory.initElements(driver, Report_Summary.class);
		this.DataList();
		
		String invoicemonth = Repository.getProperty("invoicemonth");
		String TAB = Repository.getProperty("TAB_Package");
		//String packagetab = Repository.getProperty("packagetab");
		String []filetype = {"EXCEL","CSV"};
		String link = Repository.getProperty("link_Package");
		String distributorcheckbox = Repository.getProperty("distributorcheckbox");
		String resellercheckbox = Repository.getProperty("resellercheckbox");
		String resellercheckboxdisti = Repository.getProperty("resellercheckboxdisti");
		String businesscheckbox = Repository.getProperty("businesscheckbox");
		String sitecheckbox = Repository.getProperty("sitecheckbox");
		String resellercheckboxdisti1 = Repository.getProperty("resellercheckboxdisti1");
		RP.Report_Summary_report(invoicemonth,TAB,filetype,link,distributorcheckbox,resellercheckbox,resellercheckboxdisti,businesscheckbox,sitecheckbox);
	}
	
	
	@Test(priority = 12, enabled = true)
	public void TC_Report_Summary_Service() throws InterruptedException, IOException, AWTException {
		Report_Summary RP = PageFactory.initElements(driver, Report_Summary.class);
		this.DataList();
		
		String invoicemonth = Repository.getProperty("invoicemonth");
		String TAB = Repository.getProperty("TAB_Service");
		//String packagetab = Repository.getProperty("packagetab");
		String []filetype = {"EXCEL","CSV"};
		String link = Repository.getProperty("link_Service");
		String distributorcheckbox = Repository.getProperty("distributorcheckbox");
		String resellercheckbox = Repository.getProperty("resellercheckbox");
		String resellercheckboxdisti = Repository.getProperty("resellercheckboxdisti");
		String businesscheckbox = Repository.getProperty("businesscheckbox");
		String sitecheckbox = Repository.getProperty("sitecheckbox");
		String resellercheckboxdisti1 = Repository.getProperty("resellercheckboxdisti1");
		RP.Report_Summary_report(invoicemonth,TAB,filetype,link,distributorcheckbox,resellercheckbox,resellercheckboxdisti,businesscheckbox,sitecheckbox);
	}
	
	@AfterClass
	public void quit() {
		this.after();
	}

}
