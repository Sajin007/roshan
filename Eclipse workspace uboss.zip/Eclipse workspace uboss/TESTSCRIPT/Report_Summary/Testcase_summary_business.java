package Report_Summary;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : May 29, 2020,7:23:54 AM
-- Description	: Testcase_summary_business.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-ROSHAN_RAJU
-- =============================================*/
public class Testcase_summary_business extends TestBase {
	
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String Report_Summary;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\Report_Summary\\CommonData_Reportsummary.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\Report_Summary\\Datalist_summary_business.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		Report_Summary = Repository.getProperty("summary_business");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		init();
	}

	@Test(priority = 21, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}
	
	@Test(priority = 22, enabled = true)
	public void TC_Report_summary_Url() throws InterruptedException, IOException {
		Report_Summary RP = PageFactory.initElements(driver, Report_Summary.class);
		this.CommonData();
		RP.GoToUrl(Report_Summary);
	
	}
	
	@Test(priority = 23, enabled = true)
	public void TC_Report_Summary_Report_Package() throws InterruptedException, IOException, AWTException {
		Report_Summary RP = PageFactory.initElements(driver, Report_Summary.class);
		this.DataList();
		
		String invoicemonth = Repository.getProperty("invoicemonth");
		String TAB = Repository.getProperty("TAB_Package");
		String link = Repository.getProperty("link_Package");
		String []filetype = {"CSV","EXCEL"};
		RP.Report_Summary_report2(invoicemonth,TAB,link,filetype);
	}
	
	@Test(priority = 24, enabled = true)
	public void TC_Report_Summary_Report_Service() throws InterruptedException, IOException, AWTException {
		Report_Summary RP = PageFactory.initElements(driver, Report_Summary.class);
		this.DataList();
		
		String invoicemonth = Repository.getProperty("invoicemonth");
		String TAB = Repository.getProperty("TAB_Service");		
		String link = Repository.getProperty("link_Service");
		String []filetype = {"CSV","EXCEL"};
		RP.Report_Summary_report2(invoicemonth,TAB,link,filetype);
	}
	
	@AfterClass
	public void quit() {
		this.after();
	}

}
