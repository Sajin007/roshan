package Packageservicemigration;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Login.Login;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : May 18, 2020,5:08:46 PM
-- Description	: Testcase_Package_service_migration_Business.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-0-ROSHAN_RAJU
-- =============================================*/
public class Testcase_Package_service_migration_Business extends TestBase {
	
	
	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String PackageMigration;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\CommonData\\packageservicemigration\\CommonData_package.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir") + "\\Datalist\\Packageservicemigration\\Datalist_Package_service_migration_business.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}
	public void CommonData() throws IOException {
		loadCommonData();
		PackageMigration = Repository.getProperty("Package_Migration_business");
		}
	
	public void DataList() throws IOException {
		loadDataList();
		
		}
	
	
	/*-------------------------------------------------------------------------------------------------------------------------------*/
	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		
		init();
	}

	@Test(priority = 13, enabled = true)
	public void TC_Login() throws InterruptedException, AWTException {
		
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com","P@ss123456780");

	}
	
	@Test(priority = 14, enabled = true)
	public void TC_Package_migration_Url() throws InterruptedException, IOException {
		
		Package_Service_migration pkg = PageFactory.initElements(driver, Package_Service_migration.class);
		this.CommonData();
		pkg.GoToUrl(PackageMigration);

	}

	@Test(priority = 15, enabled = true)
	public void TC_Package_migration() throws InterruptedException, IOException, AWTException {
		
		this.DataList();
		String reseller=Repository.getProperty("reseller");
		String business=Repository.getProperty("business");
		String oldpacandser=Repository.getProperty("oldpacandser");
		String newpacandser=Repository.getProperty("newpacandser");
		Package_Service_migration pkg = PageFactory.initElements(driver, Package_Service_migration.class);
		pkg.Pkg_Service_migration(reseller,business,oldpacandser, newpacandser);
	
	}
	
	@Test(priority = 16, enabled = true)
	public void TC_Service_migration() throws InterruptedException, IOException, AWTException {
		
		this.DataList();
		String reseller=Repository.getProperty("reseller");
		String business=Repository.getProperty("business");
		String oldpacandser1=Repository.getProperty("oldpacandser1");
		String newpacandser1=Repository.getProperty("newpacandser1");
		Package_Service_migration pkg = PageFactory.initElements(driver, Package_Service_migration.class);
		pkg.Pkg_Service_migration( reseller,business, oldpacandser1, newpacandser1);
	
	}
	
	@AfterClass
	public void quit() {
		this.after();
	}
	
}


