package ServiceConfig_Client;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.drd.uboss5.testbase.TestBase;

import Broadworks.BroadWorksCheck;
import Login.Login;
import ServcieConfig_Client.ServiceConfig_BW_Hot_Desking_Host;

/*-- =============================================
-- Author		: roshan.raju
-- Created Date : Oct 14, 2020 , 6:21:12 PM
-- Description	: Test_Case_ServiceConfig_Client_BW_Hot_Desking_Host.java
-- Modified by	: 
-- Modified Date:
-- Project		: UBOSS-5-0-5
-- =============================================*/

public class Test_Case_ServiceConfig_Client_BW_Hot_Desking_Host extends TestBase {

	/*-----------------------------------------------------------------------------------------------------*/
	/*******************************/
	String ServiceConfig_Client;

	/*******************************/

	public static Properties Repository = new Properties();
	public File f;
	public FileInputStream FI;

	public void loadCommonData() throws IOException {
		f = new File(System.getProperty("user.dir")
				+ "\\CommonData\\ServiceConfig_Client\\CommonData_ServiceConfig_Client_BW_Hot_Desking_Host.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void loadDataList() throws IOException {
		f = new File(System.getProperty("user.dir")
				+ "\\Datalist\\ServiceConfig_Client\\Datalist_ServiceConfig_Client_BW_Hot_Desking_Host.properties");
		FI = new FileInputStream(f);
		Repository.load(FI);

	}

	public void CommonData() throws IOException {
		loadCommonData();
		ServiceConfig_Client = Repository.getProperty("ServiceConfig_Client");
	}

	public void DataList() throws IOException {
		loadDataList();

	}

	/*-----------------------------------------------------------------------------------------------------*/

	@BeforeClass
	public void setUP() throws IOException, AWTException, InterruptedException {
		Description("Testing for Service Config page of clinet for service (Hot Desking Host) assign in web and Bw");
		init();
	}

	@Test(priority = 1, enabled = true)
	public void TC__Login() throws InterruptedException, IOException {

		Description("Login with correct username and password");
		Login login = PageFactory.initElements(driver, Login.class);
		login.LogintoUboss("roshan224new@drd.com", "P@ss123456780");

	}

	@Test(priority = 2, enabled = true)
	public void TC_ServiceConfig_Client_Url() throws InterruptedException, IOException {

		ServiceConfig_BW_Hot_Desking_Host TPS = PageFactory.initElements(driver,ServiceConfig_BW_Hot_Desking_Host.class);
		this.CommonData();
		TPS.GoTUrl(ServiceConfig_Client);
		Thread.sleep(2000);

	}

	@Test(priority = 3, enabled = true)
	public void TC_ServiceConfig_Validation() throws InterruptedException, IOException {

		ServiceConfig_BW_Hot_Desking_Host TPS = PageFactory.initElements(driver,ServiceConfig_BW_Hot_Desking_Host.class);
		this.DataList();

		String Servicename = Repository.getProperty("Servicename");
		TPS.servicConfig_Validation(Servicename);

	}

	@Test(priority = 4, enabled = true)
	public void TC_ServiceConfig_BW_Hot_Desking_Host() throws InterruptedException, IOException {

		ServiceConfig_BW_Hot_Desking_Host TPS = PageFactory.initElements(driver,ServiceConfig_BW_Hot_Desking_Host.class);
		this.DataList();

		String Servicename =Repository.getProperty("Servicename");
		String Checkbox =Repository.getProperty("Checkbox");
		String Checkbox2 =Repository.getProperty("Checkbox2");
		String associationlimit =Repository.getProperty("associationlimit");
		TPS.Servicemethod(Servicename,Checkbox,Checkbox2,associationlimit);

	}

	@Test(priority = 5, enabled = true)
	public void TC_Broadworks_checking() throws InterruptedException, IOException, AWTException {
		this.DataList();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.open();");
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));



		String UserMenu1 = Repository.getProperty("UserMenu");
		String webelementUserMenu1 = Repository.getProperty("webelementUserMenu");

		String UserID1 = Repository.getProperty("UserID");
		String webelementUserID1 = Repository.getProperty("webelementUserID");

		String UserContains1 = Repository.getProperty("UserContains");
		String webelementUserContains1 = Repository.getProperty("webelementUserContains");

		String UserText1 = Repository.getProperty("UserText");
		String webelementUserText1 = Repository.getProperty("webelementUserText");

		String UserSearch1 = Repository.getProperty("UserSearch");
		String webelementUserSearch1 = Repository.getProperty("webelementUserSearch");

		String UserSelect1 = Repository.getProperty("UserSelect");
		String webelementUserSelect1 = Repository.getProperty("webelementUserSelect");

		String UserCallControl = Repository.getProperty("UserCallControl");
		String webelementUserCallControl = Repository.getProperty("webelementUserCallControl");

		String UserHotelingHost_on = Repository.getProperty("UserHotelingHost_on");
		String webelementUserHotelingHost = Repository.getProperty("webelementUserHotelingHost");

		String UserHotelingHostradiobutton_on = Repository.getProperty("UserHotelingHostradiobutton_on");
		String webelementUserHotelingHostradiobutton_on = Repository.getProperty("webelementUserHotelingHostradiobutton_on");
		
		String UserEnforceassociationlimit_checkbox_on = Repository.getProperty("UserEnforceassociationlimit_checkbox_on");
		String webelementUserEnforceassociationlimit_checkbox = Repository.getProperty("webelementUserEnforceassociationlimit_checkbox");
		
		String UserEnforceassociationlimitfield = Repository.getProperty("UserEnforceassociationlimitfield");
		String webelementUserEnforceassociationlimitfield = Repository.getProperty("webelementUserEnforceassociationlimitfield");

		String[] Type = { UserMenu1, UserID1, UserContains1, UserText1, UserSearch1, UserSelect1, UserCallControl,
				UserHotelingHost_on, UserHotelingHostradiobutton_on,UserEnforceassociationlimit_checkbox_on,UserEnforceassociationlimitfield, "" };

		String[] Webelemt = { webelementUserMenu1, webelementUserID1, webelementUserContains1, webelementUserText1,
				webelementUserSearch1, webelementUserSelect1, webelementUserCallControl, webelementUserHotelingHost,
				webelementUserHotelingHostradiobutton_on,webelementUserEnforceassociationlimit_checkbox,webelementUserEnforceassociationlimitfield, "" };

		BroadWorksCheck Brow = PageFactory.initElements(driver, BroadWorksCheck.class);
		Brow.mainBroadworks(Type, Webelemt);
		
		 Thread.sleep(2000);
		 driver.switchTo().window(tabs2.get(0));
	}
	
////////////*******************
	@Test(priority = 6, enabled = true)
	public void TC_ServiceConfig_BW_Hot_Desking_Host_uncheck() throws InterruptedException, IOException {

		ServiceConfig_BW_Hot_Desking_Host TPS = PageFactory.initElements(driver,
				ServiceConfig_BW_Hot_Desking_Host.class);
		this.DataList();

		String Servicename =Repository.getProperty("Servicename");
		String Checkbox3 =Repository.getProperty("Checkbox3");
		String Checkbox4 =Repository.getProperty("Checkbox4");
		String associationlimit =Repository.getProperty("associationlimit");
		TPS.Servicemethod(Servicename,Checkbox3,Checkbox4,associationlimit);
	}

	@Test(priority = 7, enabled = true)
	public void TC_Broadworks_uncheck() throws InterruptedException, IOException, AWTException {
		this.DataList();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.open();");
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));



		String UserMenu1 = Repository.getProperty("UserMenu");
		String webelementUserMenu1 = Repository.getProperty("webelementUserMenu");

		String UserID1 = Repository.getProperty("UserID");
		String webelementUserID1 = Repository.getProperty("webelementUserID");

		String UserContains1 = Repository.getProperty("UserContains");
		String webelementUserContains1 = Repository.getProperty("webelementUserContains");

		String UserText1 = Repository.getProperty("UserText");
		String webelementUserText1 = Repository.getProperty("webelementUserText");

		String UserSearch1 = Repository.getProperty("UserSearch");
		String webelementUserSearch1 = Repository.getProperty("webelementUserSearch");

		String UserSelect1 = Repository.getProperty("UserSelect");
		String webelementUserSelect1 = Repository.getProperty("webelementUserSelect");

		String UserCallControl = Repository.getProperty("UserCallControl");
		String webelementUserCallControl = Repository.getProperty("webelementUserCallControl");

		String UserHotelingHost_off = Repository.getProperty("UserHotelingHost_off");
		String webelementUserHotelingHost = Repository.getProperty("webelementUserHotelingHost");

		String UserHotelingHostradiobutton_off = Repository.getProperty("UserHotelingHostradiobutton_off");
		String webelementUserHotelingHostradiobutton_off = Repository.getProperty("webelementUserHotelingHostradiobutton_off");
		
		String UserEnforceassociationlimit_checkbox_off = Repository.getProperty("UserEnforceassociationlimit_checkbox_off");
		String webelementUserEnforceassociationlimit_checkbox = Repository.getProperty("webelementUserEnforceassociationlimit_checkbox");
		
		String UserEnforceassociationlimitfield = Repository.getProperty("UserEnforceassociationlimitfield");
		String webelementUserEnforceassociationlimitfield = Repository.getProperty("webelementUserEnforceassociationlimitfield");

		String[] Type = { UserMenu1, UserID1, UserContains1, UserText1, UserSearch1, UserSelect1, UserCallControl,
				UserHotelingHost_off, UserHotelingHostradiobutton_off,UserEnforceassociationlimit_checkbox_off,UserEnforceassociationlimitfield, "" };

		String[] Webelemt = { webelementUserMenu1, webelementUserID1, webelementUserContains1, webelementUserText1,
				webelementUserSearch1, webelementUserSelect1, webelementUserCallControl, webelementUserHotelingHost,
				webelementUserHotelingHostradiobutton_off,webelementUserEnforceassociationlimit_checkbox,webelementUserEnforceassociationlimitfield, "" };

		BroadWorksCheck Brow = PageFactory.initElements(driver, BroadWorksCheck.class);
		Brow.mainBroadworks(Type, Webelemt);
		
		 Thread.sleep(2000);
		 //driver.switchTo().window(tabs2.get(1)).close();
	}

}
